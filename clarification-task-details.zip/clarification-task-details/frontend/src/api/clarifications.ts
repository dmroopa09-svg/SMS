import { apiClient } from "./client";

/**
 * Clarification oversight API - supervisors, managers, superadmins.
 * Talks to api/clarifications/team in GTXH.OMC.
 */

// ---------------------------------------------------------------------------
// ADAPT THIS ONE BLOCK if apiClient exposes different method names.
// Everything below goes through it, so this is the only place to change.
// ---------------------------------------------------------------------------
const http = {
  get: <T>(url: string) => apiClient.get<T>(url) as Promise<T>,
  post: <T>(url: string, body?: unknown) => apiClient.post<T>(url, body) as Promise<T>,
};

/**
 * apiClient's base URL already ends in /api - adding it again here produced
 * https://localhost:7062/api/api/clarifications/... and a 404 on every call.
 */
const BASE = "/clarifications/team";

// ---------------------------------------------------------------------------
// States. These match the backend exactly - do not invent new strings here,
// the server filters on them.
// ---------------------------------------------------------------------------
export const ClarificationState = {
  All: "All",
  /** Waiting on QA. This is the backlog a supervisor opens the screen to see. */
  AwaitingQa: "AwaitingQa",
  /** QA answered; the agent has something to read. */
  Received: "Received",
  /** No tasks blocked any more. */
  Closed: "Closed",
} as const;

export type ClarificationStateValue =
  (typeof ClarificationState)[keyof typeof ClarificationState];

export const STATE_LABELS: Record<string, string> = {
  All: "All",
  AwaitingQa: "Awaiting QA",
  Received: "Answered",
  Closed: "Closed",
};

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface ClarificationQueueItem {
  ticketId: number;
  processId: number | null;
  processName: string | null;
  state: string;
  createdDate: string;
  lastUpdateDate: string | null;
  raisedByUserId: number | null;
  raisedByName: string | null;
  lastAuditorId: string | null;
  lastAuditorName: string | null;
  taskCount: number;
  blockedTaskCount: number;
  commentCount: number;
  firstQuestion: string | null;
  lastComment: string | null;
  lastCommentBy: string | null;
  /** Hours since the agent's last unanswered message. Null once QA replied. */
  hoursWaiting: number | null;

  /** Client-side only, built in mapRow. Not sent by the server. */
  displayId: string;
}

export interface PagedClarifications {
  items: ClarificationQueueItem[];
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export interface ClarificationComment {
  commentId: number;
  userType: string; // "Agent" | "Auditor"
  userName: string | null;
  comment: string;
  createdDate: string;
}

export interface ClarificationTask {
  taskId: number;
  externalRef: string | null;
  status: string | null;
  isBlocked: boolean;
  processId: number;
  /** Raw TaskData JSON, rendered against `fields` below. */
  taskData: string | null;
  createdDate: string | null;
  assignedUserName: string | null;
}

/** One configured field of the ticket's process, in display order. */
export interface ClarificationField {
  fieldName: string;
  displayOrder: number;
  fieldType: string | null;
}

export interface ClarificationThread {
  ticket: ClarificationQueueItem;
  comments: ClarificationComment[];
  tasks: ClarificationTask[];
  /** Field config for this ticket's process. Drives the task detail panel. */
  fields: ClarificationField[];
  canComment: boolean;
  canResume: boolean;
}

export interface ClarificationAgentSummary {
  userId: number;
  userName: string | null;
  received: number;
  awaitingQa: number;
  closed: number;
  total: number;
  longestWaitHours: number | null;
}

export interface ClarificationProcessSummary {
  processId: number | null;
  processName: string | null;
  received: number;
  awaitingQa: number;
  closed: number;
  total: number;
}

export interface ClarificationSummary {
  received: number;
  awaitingQa: number;
  closed: number;
  total: number;
  /** AwaitingQa tickets with no reply for more than 24 hours. */
  ageing: number;
  agentsBlocked: number;
  byAgent: ClarificationAgentSummary[];
  byProcess: ClarificationProcessSummary[];
}

export interface ClarificationScope {
  roleName: string;
  allUsers: boolean;
  /**
   * False means this user only sees their own clarifications and belongs on the
   * agent app, not here. The screen shows a notice rather than an empty table.
   */
  isOversight: boolean;
  /** -1 when allUsers is true. */
  visibleAgentCount: number;
  canComment: boolean;
  canResume: boolean;
}

export interface ClarificationQuery {
  state?: string | null;
  agentUserId?: number | null;
  processId?: number | null;
  search?: string | null;
  fromDate?: string | null;
  toDate?: string | null;
  minHoursWaiting?: number | null;
  page?: number;
  pageSize?: number;
  sortKey?: string | null;
  sortDirection?: string | null;
}

// ---------------------------------------------------------------------------
// Calls
// ---------------------------------------------------------------------------

/**
 * Ticket ids are bare numbers on the server. The table wants something that
 * reads as a reference, so it is built here - a display format is a
 * presentation concern and does not belong in the database.
 */
function withDisplayId(
  raw: Omit<ClarificationQueueItem, "displayId">,
): ClarificationQueueItem {
  return { ...raw, displayId: `CLR-${String(raw.ticketId).padStart(5, "0")}` };
}

export async function listClarifications(
  query: ClarificationQuery = {},
): Promise<PagedClarifications> {
  const body = {
    state: query.state ?? null,
    agentUserId: query.agentUserId ?? null,
    processId: query.processId ?? null,
    search: query.search ?? null,
    fromDate: query.fromDate ?? null,
    toDate: query.toDate ?? null,
    minHoursWaiting: query.minHoursWaiting ?? null,
    page: query.page ?? 1,
    pageSize: query.pageSize ?? 10,
    sortKey: query.sortKey ?? null,
    sortDirection: query.sortDirection ?? null,
  };

  const res = await http.post<PagedClarifications>(`${BASE}/search`, body);
  return { ...res, items: (res?.items ?? []).map(withDisplayId) };
}

function mapThread(t: ClarificationThread): ClarificationThread {
  return { ...t, ticket: withDisplayId(t.ticket) };
}

export async function getClarificationThread(
  ticketId: number,
): Promise<ClarificationThread> {
  return mapThread(await http.get<ClarificationThread>(`${BASE}/${ticketId}`));
}

export async function addClarificationComment(
  ticketId: number,
  comment: string,
): Promise<ClarificationThread> {
  return mapThread(
    await http.post<ClarificationThread>(`${BASE}/${ticketId}/comments`, { comment }),
  );
}

export async function resumeClarification(
  ticketId: number,
): Promise<ClarificationThread> {
  return mapThread(await http.post<ClarificationThread>(`${BASE}/${ticketId}/resume`));
}

export function getClarificationSummary(): Promise<ClarificationSummary> {
  return http.get<ClarificationSummary>(`${BASE}/summary`);
}

export function getClarificationScope(): Promise<ClarificationScope> {
  return http.get<ClarificationScope>(`${BASE}/scope`);
}

// ---------------------------------------------------------------------------
// Task data helpers
//
// Live here rather than in the component so the detail panel and anything else
// that renders task fields later stay consistent.
// ---------------------------------------------------------------------------

export function parseTaskData(json: string | null | undefined): Record<string, unknown> {
  if (!json) return {};
  if (typeof json === "object") return json as Record<string, unknown>;
  try {
    const parsed = JSON.parse(json);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : {};
  } catch {
    // Malformed TaskData must not take the panel down.
    return {};
  }
}

/** WL_Status_Date -> "WL Status Date". The configured name is the label. */
export function fieldLabel(fieldName: string): string {
  return fieldName.replace(/[_]+/g, " ").trim();
}

export function formatFieldValue(value: unknown): string {
  if (value === null || value === undefined) return "—";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (Array.isArray(value)) return value.length ? value.join(", ") : "—";

  const s = String(value).trim();
  if (s === "") return "—";

  // Dates arrive as ISO or as "7/14/2026 12:00:00 AM" depending on the source
  // column type. Only reformat the ISO shape - reformatting the other would
  // mean guessing whether 7/14 is July or the 7th of day 14.
  if (/^\d{4}-\d{2}-\d{2}([T ]|$)/.test(s)) {
    const d = new Date(s.includes("T") && !/[zZ]|[+-]\d{2}:\d{2}$/.test(s) ? `${s}Z` : s);
    if (!isNaN(d.getTime())) {
      const pad = (n: number) => n.toString().padStart(2, "0");
      const hasTime = d.getHours() || d.getMinutes();
      const date = `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
      return hasTime ? `${date} ${pad(d.getHours())}:${pad(d.getMinutes())}` : date;
    }
  }

  return s;
}

/**
 * Best-effort account reference for a task chip subtitle, the way the QA app
 * shows "Account: D260174583". Field naming varies by process, so the first
 * configured field whose name looks like an account wins.
 */
export function findAccountValue(
  data: Record<string, unknown>,
  fields: ClarificationField[],
): string | null {
  const candidate = fields.find((f) => /account/i.test(f.fieldName));
  if (candidate) {
    const v = formatFieldValue(data[candidate.fieldName]);
    if (v !== "—") return v;
  }
  const key = Object.keys(data).find((k) => /account/i.test(k));
  if (!key) return null;
  const v = formatFieldValue(data[key]);
  return v === "—" ? null : v;
}
