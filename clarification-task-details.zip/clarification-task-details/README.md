# Task details on the clarification thread

The admin modal showed task chips as plain text. The QA app expands each task
into its full field panel. This adds the same thing.

## Files

    backend/BACKEND_PATCH.md            4 additions, nothing existing changes shape
    frontend/src/api/clarifications.ts  REPLACE
    frontend/src/components/Clarification.tsx  REPLACE

Apply the backend patch FIRST - the frontend reads thread.fields and
thread.ticket, which the current response does not have.

## What changed

BACKEND
  The thread now returns the ticket's process field config (name + display
  order) alongside the tasks, so the UI can render TaskData in the configured
  order with the configured labels. One query, already inside the caller's
  scope, no new endpoint and no guessing at a process-fields API from the
  frontend.

  Returns ClarificationOversightThreadDto rather than editing
  ClarificationThreadDto, so the agent app's contract is untouched.

FRONTEND
  Task chips are now expandable rows: task ref, account, status badge, and on
  click the full field panel.

  A single-task ticket opens expanded automatically - making someone click
  again to see the only thing there is pure friction.

  Fields not in the process config but present in TaskData are appended rather
  than dropped. A field removed from the config still has values on tasks
  raised before that change, and hiding them would silently lose context from
  an older clarification.

  Comments now show an AGENT / AUDITOR badge, matching the QA app.

  Header now shows the state badge, process, agent and task counts.

  canComment / canResume now come from the thread rather than global scope, so
  a closed ticket correctly shows read-only even for a superadmin.

## Two things to check from the screenshot

1. PROCESS NAME showed as "—" on CLR-10011. See the SQL at the end of
   BACKEND_PATCH.md - most likely those seeded tasks point at a ProcessId with
   no matching row in dbo.Processes.

2. THE CONVERSATION LOOKED EMPTY. The name resolved (Ramesh Muniraj) but no
   message text was visible. If that is not just the photo, check that
   CLR_Ticket_Comm.Comment is populated for that ticket:

       SELECT CommId, UserType, UserId, LEN(Comment) AS Len, RowInsertDate
       FROM   dbo.CLR_Ticket_Comm WHERE TicketId = 10011 ORDER BY RowInsertDate;

   Len 0 or null means the raise wrote an empty comment. The modal now renders
   "No messages on this clarification yet" instead of a silent blank, so the
   two cases are distinguishable on screen.
