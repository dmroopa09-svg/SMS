# Backend - return task fields with the thread

Four additions. Nothing existing changes shape, so the agent app is untouched.

The thread already returns each task's raw `taskData` JSON. What it does not
return is **which fields that process has and in what order**, so the frontend
has no way to render "WL Code" before "Account" rather than whatever order the
JSON keys happen to be in.

Rather than have the admin app guess at a process-fields endpoint, the thread
carries the field list with it. One query, already inside the caller's scope,
no new endpoint.

---

## 1. `Application/DTOs/ClarificationOversightDtos.cs` - append

```csharp
/// <summary>
/// One field of the process this ticket belongs to, so the UI can render a
/// task's taskData in the configured order with the configured labels instead
/// of whatever order the JSON keys happen to be in.
/// </summary>
public class ClarificationFieldDto
{
    public string FieldName { get; set; } = string.Empty;
    public int DisplayOrder { get; set; }
    public string? FieldType { get; set; }
}

public class ClarificationOversightTaskDto
{
    public long TaskId { get; set; }
    public string? ExternalRef { get; set; }
    public string? Status { get; set; }
    public bool IsBlocked { get; set; }
    public int ProcessId { get; set; }

    /// <summary>Raw TaskData JSON. The UI parses it against Fields below.</summary>
    public string? TaskData { get; set; }

    public DateTime? CreatedDate { get; set; }
    public string? AssignedUserName { get; set; }
}

/// <summary>
/// Oversight thread. Parallel to ClarificationThreadDto rather than an edit to
/// it, so the agent app's contract is not touched.
/// </summary>
public class ClarificationOversightThreadDto
{
    public ClarificationOversightTicketDto Ticket { get; set; } = new();
    public List<ClarificationCommentDto> Comments { get; set; } = new();
    public List<ClarificationOversightTaskDto> Tasks { get; set; } = new();

    /// <summary>Field config for this ticket's process, in display order.</summary>
    public List<ClarificationFieldDto> Fields { get; set; } = new();

    public bool CanComment { get; set; }
    public bool CanResume { get; set; }
}
```

## 2. `Application/Interfaces/IClarificationOversightService.cs`

Change the three return types from `ClarificationThreadDto?` to
`ClarificationOversightThreadDto?`:

```csharp
Task<ClarificationOversightThreadDto?> GetThreadAsync(...);
Task<ClarificationOversightThreadDto?> AddCommentAsync(...);
Task<ClarificationOversightThreadDto?> ResumeAsync(...);
```

## 3. `Application/Services/ClarificationOversightService.cs`

Change the same three signatures, then replace `BuildThreadAsync` and
`LoadTasksAsync`:

```csharp
    private async Task<ClarificationOversightThreadDto?> BuildThreadAsync(
        ClarificationOversightScope scope,
        long ticketId,
        CancellationToken cancellationToken)
    {
        var row = await BuildProjection(scope, new ClarificationOversightQueryRequest())
            .Where(r => r.TicketId == ticketId)
            .FirstOrDefaultAsync(cancellationToken);

        if (row is null)
            return null;

        var comments = await LoadCommentsAsync(ticketId, cancellationToken);
        var tasks = await LoadTasksAsync(ticketId, cancellationToken);
        var fields = await LoadFieldsAsync(row.ProcessId, cancellationToken);
        var names = await ResolveNamesAsync(new[] { row }, cancellationToken);
        var state = DeriveState(row);

        return new ClarificationOversightThreadDto
        {
            Ticket = MapTicket(row, state, names),
            Comments = comments,
            Tasks = tasks,
            Fields = fields,
            CanComment = scope.CanComment && state != DTOs.ClarificationState.Closed,
            CanResume = scope.CanResume && state != DTOs.ClarificationState.Closed,
        };
    }

    /// <summary>
    /// Field config for one process, in display order.
    ///
    /// Materialised before mapping because FieldType may be an enum and
    /// .ToString() on it does not translate to SQL.
    /// </summary>
    private async Task<List<ClarificationFieldDto>> LoadFieldsAsync(
        int? processId,
        CancellationToken cancellationToken)
    {
        if (processId is not int pid || pid <= 0)
            return new List<ClarificationFieldDto>();

        var rows = await _db.ProcessFields.AsNoTracking()
            .Where(f => f.ProcessId == pid && !f.IsDeleted)
            .OrderBy(f => f.DisplayOrder)
            .Select(f => new { f.FieldName, f.DisplayOrder, f.FieldType })
            .ToListAsync(cancellationToken);

        return rows.Select(f => new ClarificationFieldDto
        {
            FieldName = f.FieldName,
            DisplayOrder = f.DisplayOrder,
            FieldType = f.FieldType?.ToString(),
        }).ToList();
    }

    private async Task<List<ClarificationOversightTaskDto>> LoadTasksAsync(
        long ticketId,
        CancellationToken cancellationToken)
    {
        var rows = await (from l in _db.ClarificationTicketTasks.AsNoTracking()
                          join tk in _db.Tasks.AsNoTracking() on l.TaskId equals tk.TaskId
                          where l.TicketId == ticketId
                          select new
                          {
                              tk.TaskId,
                              tk.ExternalRef,
                              tk.Status,
                              tk.TaskData,
                              tk.ProcessId,
                              tk.CreatedDate,
                              tk.AssignedUserId,
                          })
            .ToListAsync(cancellationToken);

        var userIds = rows.Where(r => r.AssignedUserId.HasValue)
            .Select(r => r.AssignedUserId!.Value).Distinct().ToList();
        var names = await LoadAgentNamesAsync(userIds, cancellationToken);

        return rows.Select(r => new ClarificationOversightTaskDto
        {
            TaskId = r.TaskId,
            ExternalRef = r.ExternalRef,
            Status = r.Status.ToString(),
            IsBlocked = r.Status == TaskStatusEnum.Clarification,
            TaskData = r.TaskData,
            ProcessId = r.ProcessId,
            CreatedDate = r.CreatedDate,
            AssignedUserName = r.AssignedUserId.HasValue
                               && names.TryGetValue(r.AssignedUserId.Value, out var n) ? n : null,
        }).ToList();
    }
```

**If `ProcessField.FieldType` is a plain `string`**, drop the `?.ToString()` and
just assign it.

## 4. `API/Controllers/ClarificationOversightController.cs`

Change the three action return types:

```csharp
public async Task<ActionResult<ClarificationOversightThreadDto>> GetThread(...)
public async Task<ActionResult<ClarificationOversightThreadDto>> AddComment(...)
public async Task<ActionResult<ClarificationOversightThreadDto>> Resume(...)
```

No body changes.

---

## Check this while you are in here

The modal header showed `—` where the process name belongs. That comes from:

```csharp
ProcessName = (from l in _db.ClarificationTicketTasks
               join tk in _db.Tasks on l.TaskId equals tk.TaskId
               join p in _db.Processes on tk.ProcessId equals p.ProcessId
               where l.TicketId == t.TicketId
               select p.ProcessName).FirstOrDefault(),
```

Null means the `Processes` join found nothing. Run:

```sql
DECLARE @TicketId bigint = 10011;   -- CLR-10011 from the screenshot

SELECT  l.TaskId, tk.ProcessId, p.ProcessId AS JoinedProcessId, p.ProcessName
FROM    dbo.CLR_Ticket_Tasks l
JOIN    dbo.Tasks tk ON tk.TaskId = l.TaskId
LEFT JOIN dbo.Processes p ON p.ProcessId = tk.ProcessId
WHERE   l.TicketId = @TicketId;
```

`JoinedProcessId` null on every row means those tasks point at a ProcessId with
no row in `Processes` - seeded test data, most likely. If the column is called
something other than `ProcessName`, that is the other possibility.
