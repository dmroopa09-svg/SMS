CAMPAIGN MANAGER — SMS FEATURES
================================

The features the dialer already has and SMS lacks. Built from the design review
and the dialer console, so the concepts and the words match what people already
know.


RUN ORDER
---------
    CM_01_Settings_And_Lifecycle.sql   settings, run statuses, stop and confirm
    CM_02_Expiry_And_Progress.sql      expiry sweep, run progress

Both are guarded and safe to re-run.


WHAT THIS GIVES
---------------
    SMS_Campaign_Settings     rate, window, batch size, expiry behaviour
    SMS_Run_Status            seven run states including Stopping and TimeSuspended
    SMS_Service_Instance      per-instance heartbeat, used to confirm a stop

    usp_SMS_RequestStop       set the flag
    usp_SMS_ConfirmStop       decide whether it has actually stopped
    usp_SMS_Heartbeat         called by every service instance
    usp_SMS_GetServiceHealth  the services panel
    usp_SMS_ExpireRun         apply the expiry setting
    usp_SMS_SweepExpiredRuns  timer-driven; finds runs whose window has closed
    usp_SMS_GetRunProgress    the Contact Lists equivalent


STOP IS TWO STATES, NOT ONE
---------------------------
    Stopping   flag set; services still finishing claimed batches
    Stopped    confirmed idle

Pressing stop sets a flag. Services finish the batch they hold, which takes
seconds to a minute, and messages are still going out during that time.

Showing "Stopped" immediately would be a lie the operator can see through — they
watch the sent count keep rising, conclude the stop failed, and escalate.
"Stopping — 2 of 3 confirmed" is accurate and calm.

CONFIRMATION NEEDS BOTH CHECKS

  nothing in flight    no row for this run is in a claimed state
  services alive       every service has heartbeated SINCE the stop was
                       requested, proving it is running and has had a chance to
                       see the flag

The second matters more than it looks. A dead service has nothing in flight —
trivially, because it is not doing anything. Without the heartbeat check that is
indistinguishable from having stopped properly, and the UI would report a
successful stop on a service that had actually crashed.

INSTANCEID MUST BE UNIQUE PER PROCESS, not per machine. Machine name plus
process id, or a GUID at startup. If two instances on one server share an id
they overwrite each other's heartbeat and the confirmation counts one service
where there are two.


EXPIRY
------
    campaign identifies   9,000
    throttle              1,000 per hour
    window                08:00 - 20:00
    by 20:00              8,000 sent, 1,000 never reached

Three options, set per campaign:

    Expire         close them unsent, with a reason        DEFAULT
    CarryForward   move into tomorrow's window
    Remove         discard entirely

EXPIRE IS THE DEFAULT FOR A REASON. Tomorrow's run selects on the same criteria,
so anyone still eligible is picked up again anyway. CarryForward risks the same
person being queued twice — once carried, once freshly selected — and the two
rows belong to different runs, so they have different idempotency keys and
nothing catches it.

CarryForward is the option that needs care, not the safe one.

Expired is a SEPARATE STATUS from Blocked and Failed. Nothing was wrong with the
message and nothing failed; the day ended. Keeping it separate is what makes the
reporting honest:

    "8,000 sent, 1,000 expired"   a healthy campaign meeting its throttle
    "8,000 sent, 1,000 failed"    an incident

Same numbers, entirely different response.


⚠ THE SWEEP AND TIME ZONES
--------------------------
The window is per RECIPIENT, not per run. A nationwide run is still inside the
window for California when it has closed for New York. Sweeping the whole run at
20:00 Eastern would expire messages that are legal for another three hours.

The sweep therefore waits until the window has closed in Pacific, the latest
continental zone. Conservative: a few messages sit slightly longer than needed,
none are expired early.

A tighter version would expire per zone as each closes. More correct, more
complex, and worth doing only if the difference turns out to matter.

The sweep uses AT TIME ZONE rather than a fixed offset, so daylight saving is
handled. A fixed offset would sweep an hour early for several weeks after each
transition.


RATE SETTINGS
-------------
    MaxPerMinute   smooths the send so a campaign does not empty its queue in
                   thirty seconds then sit idle
    MaxPerHour     the throttle that produces the expiry scenario above
    MaxPerDay      total ceiling
    BatchSize      how many a service claims at once

BATCHSIZE IS ALSO THE STOP-PRECISION DIAL. A claimed batch runs to completion,
so the worst overshoot after pressing stop is one batch per running instance.

    batch 500, 1 instance    up to 500 more may send
    batch 100, 3 instances   up to 300 more may send
    batch  25, 3 instances   up to  75 more may send

Small batch, precise stop, more round trips. Large batch, faster, coarser stop.
Exposed to the operator deliberately — a campaign where stopping precisely
matters can be set low before it starts.


RUN PROGRESS MIRRORS THE DIALER
-------------------------------
usp_SMS_GetRunProgress returns records available, records pending, status and
percentage — the same columns as the Contact Lists screen, deliberately. Anyone
who can read that console can read this.

PercentComplete counts everything TERMINAL, not only successes. A run that
blocked half its messages for compliance reasons is still finished, and showing
50% would suggest it had stalled.


TIMESUSPENDED
-------------
Worth carrying across from the dialer. It distinguishes "waiting for the window
to open" from "stopped" and from "broken".

A nationwide campaign started in the evening has most of its messages deferred
until tomorrow morning. That is correct behaviour — but without this status it
is indistinguishable from a campaign that has stalled, and someone will
investigate an incident that is not one.


WHAT IS NOT HERE
----------------
Account selection. That is the EOS and RM logic and it belongs with whoever owns
it — it should be wrapped, not rewritten.

The UI screens. These procedures are what the screens call; the screens
themselves follow the WebApp patterns and are better written by someone who
knows them.


BEFORE WIRING THE SERVICES
--------------------------
Every service needs to call usp_SMS_Heartbeat on every cycle, passing a stable
unique InstanceId. Without it the stop confirmation cannot work — it has no way
to tell a service that has stopped from one that has died.
