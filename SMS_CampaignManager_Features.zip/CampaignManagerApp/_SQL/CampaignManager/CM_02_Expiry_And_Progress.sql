/* ============================================================================
   CAMPAIGN MANAGER — EXPIRY AND RUN PROGRESS
   ============================================================================

   Expiry is what happens to messages still unsent when the window closes. The
   dialer already does this; the Contact Lists screen shows it directly — one
   list active with records pending, the rest expired at 100%.

   THE SCENARIO
       campaign identifies   9,000
       throttle              1,000 per hour
       window                08:00 - 20:00
       by 20:00              8,000 sent, 1,000 never reached

   Those thousand cannot stay queued. The window has closed and tomorrow is a
   different run against freshly evaluated criteria.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ============================================================================
   1. usp_SMS_ExpireRun

   Applies the campaign's expiry setting to whatever is left.

     1 Expire        close unsent, with a reason               (default)
     2 CarryForward  move into tomorrow's window
     3 Remove        discard from the queue

   WHY EXPIRE IS THE DEFAULT
   -------------------------
   Tomorrow's run selects on the same criteria, so anyone still eligible is
   picked up again anyway. Carrying forward risks the same person being queued
   twice — once carried, once freshly selected — and the two rows have different
   idempotency keys because they belong to different runs, so nothing catches it.

   CarryForward is therefore the option that needs care, not the safe one.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_ExpireRun', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_ExpireRun;
GO

CREATE PROCEDURE dbo.usp_SMS_ExpireRun
    @QueueMstId  BIGINT,
    @ExpiredBy   NVARCHAR(100) = 'system',
    @OverrideAction TINYINT = NULL   -- NULL: use the campaign's setting
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Now    DATETIME2 = SYSUTCDATETIME();
    DECLARE @Action TINYINT;
    DECLARE @CampaignId INT;

    SELECT @CampaignId = Campaign_Mstr_ID
    FROM   dbo.SMS_Queue_Mst
    WHERE  ID = @QueueMstId;

    SELECT @Action = ISNULL(@OverrideAction,
                            ISNULL((SELECT ExpiryAction
                                    FROM dbo.SMS_Campaign_Settings
                                    WHERE Campaign_Mstr_ID = @CampaignId), 1));

    /* Only pre-dispatch states are affected. Anything already handed to the
       provider is out of our hands and must not be relabelled — a Sent message
       marked Expired would make the reporting wrong in both directions. */
    DECLARE @Pending TABLE (Status TINYINT);
    INSERT INTO @Pending VALUES (0),(2),(7);     -- Init, Eligible, Deferred

    DECLARE @Affected INT = 0;

    IF @Action = 1          /* Expire */
    BEGIN
        UPDATE d
        SET    d.SMSStatus        = 10,          -- Expired
               d.ComplianceReason = 'Send window closed before this message could be sent.',
               d.RowUpdatedDt     = @Now
        FROM   dbo.SMS_Queue_Detail d
        WHERE  d.SMSQueue_Mst_ID = @QueueMstId
          AND  d.SMSStatus IN (SELECT Status FROM @Pending);

        SET @Affected = @@ROWCOUNT;
    END
    ELSE IF @Action = 2     /* CarryForward */
    BEGIN
        /* Reset to Init so tomorrow's evaluation is fresh. Between today and
           tomorrow the recipient may have replied STOP, the state rule may have
           changed, or the account may have paid — carrying an old decision
           forward would act on stale facts. */
        UPDATE d
        SET    d.SMSStatus        = 0,
               d.NextAttemptUtc   = NULL,
               d.ComplianceReason = NULL,
               d.RowUpdatedDt     = @Now
        FROM   dbo.SMS_Queue_Detail d
        WHERE  d.SMSQueue_Mst_ID = @QueueMstId
          AND  d.SMSStatus IN (SELECT Status FROM @Pending);

        SET @Affected = @@ROWCOUNT;
    END
    ELSE IF @Action = 3     /* Remove */
    BEGIN
        DELETE d
        FROM   dbo.SMS_Queue_Detail d
        WHERE  d.SMSQueue_Mst_ID = @QueueMstId
          AND  d.SMSStatus IN (SELECT Status FROM @Pending);

        SET @Affected = @@ROWCOUNT;
    END

    /* CarryForward leaves the run open for tomorrow. The other two finish it. */
    UPDATE dbo.SMS_Queue_Mst
    SET    RunStatus = CASE WHEN @Action = 2 THEN 6      -- TimeSuspended
                            ELSE 4 END                    -- Completed
    WHERE  ID = @QueueMstId
      AND  RunStatus IN (1, 2, 6);

    SELECT @QueueMstId AS QueueMstId,
           @Action     AS ActionApplied,
           @Affected   AS MessagesAffected,
           CASE @Action WHEN 1 THEN 'Expired'
                        WHEN 2 THEN 'Carried forward'
                        WHEN 3 THEN 'Removed' END AS ActionName;
END
GO


/* ============================================================================
   2. usp_SMS_SweepExpiredRuns

   Called on a timer. Finds runs whose window has closed and applies expiry.

   ⚠ THE WINDOW IS PER RECIPIENT, NOT PER RUN.
   A nationwide run is still inside the window for California when it has closed
   for New York. Sweeping the whole run at 20:00 Eastern would expire messages
   that are perfectly legal for another three hours.

   So the sweep runs when the window has closed in the LAST zone the run has
   recipients in. The conservative version below uses Pacific, which is the
   latest of the continental zones — a run is only swept once even Pacific has
   closed.

   A tighter version would expire per zone as each closes. That is more correct
   and more complex; worth doing only if the difference matters in practice.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_SweepExpiredRuns', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_SweepExpiredRuns;
GO

CREATE PROCEDURE dbo.usp_SMS_SweepExpiredRuns
    @NowUtc DATETIME2 = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @NowUtc = ISNULL(@NowUtc, SYSUTCDATETIME());

    /* Pacific local time. AT TIME ZONE handles daylight saving, which a fixed
       offset would not — and getting it wrong here means sweeping an hour early
       for several weeks after each transition. */
    DECLARE @PacificNow DATETIME2 =
        CAST(@NowUtc AT TIME ZONE 'UTC' AT TIME ZONE 'Pacific Standard Time' AS DATETIME2);

    DECLARE @PacificHour INT = DATEPART(HOUR, @PacificNow);

    DECLARE @Swept TABLE (QueueMstId BIGINT, Affected INT);

    DECLARE @RunId BIGINT;

    DECLARE run_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT m.ID
        FROM   dbo.SMS_Queue_Mst m
        LEFT   JOIN dbo.SMS_Campaign_Settings s
               ON s.Campaign_Mstr_ID = m.Campaign_Mstr_ID
        WHERE  m.RunStatus IN (1, 6)             -- Running or TimeSuspended
          AND  @PacificHour >= ISNULL(s.WindowEndHour, 21)
          AND  EXISTS (SELECT 1 FROM dbo.SMS_Queue_Detail d
                       WHERE d.SMSQueue_Mst_ID = m.ID
                         AND d.SMSStatus IN (0, 2, 7));

    OPEN run_cursor;
    FETCH NEXT FROM run_cursor INTO @RunId;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC dbo.usp_SMS_ExpireRun @QueueMstId = @RunId, @ExpiredBy = 'sweep';
        INSERT INTO @Swept (QueueMstId, Affected) VALUES (@RunId, NULL);
        FETCH NEXT FROM run_cursor INTO @RunId;
    END

    CLOSE run_cursor;
    DEALLOCATE run_cursor;

    SELECT COUNT(*) AS RunsSwept FROM @Swept;
END
GO


/* ============================================================================
   3. usp_SMS_GetRunProgress

   The Contact Lists equivalent — what the operator sees per run.

   Deliberately mirrors the dialer's columns: records available, records
   pending, status, percentage. Anyone who reads that console can read this.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_GetRunProgress', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_GetRunProgress;
GO

CREATE PROCEDURE dbo.usp_SMS_GetRunProgress
    @CampaignMstrId INT = NULL,
    @TopRuns        INT = 20
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (@TopRuns)
        m.ID                        AS RunId,
        m.Campaign_Mstr_ID          AS CampaignId,
        m.RunTime                   AS StartTime,
        rs.Status                   AS RunStatus,

        COUNT(d.ID)                 AS RecordsAvailable,

        /* Pending: not yet reached a terminal state. The number an operator
           watches fall. */
        SUM(CASE WHEN d.SMSStatus IN (0,2,3,4,6,7,8) THEN 1 ELSE 0 END)
                                    AS RecordsPending,

        SUM(CASE WHEN d.SMSStatus IN (4,5) THEN 1 ELSE 0 END)  AS Sent,
        SUM(CASE WHEN d.SMSStatus = 5      THEN 1 ELSE 0 END)  AS Delivered,
        SUM(CASE WHEN d.SMSStatus = 1      THEN 1 ELSE 0 END)  AS Blocked,
        SUM(CASE WHEN d.SMSStatus = 7      THEN 1 ELSE 0 END)  AS Deferred,
        SUM(CASE WHEN d.SMSStatus = 10     THEN 1 ELSE 0 END)  AS Expired,
        SUM(CASE WHEN d.SMSStatus IN (6,9) THEN 1 ELSE 0 END)  AS Failed,

        /* Percentage complete, matching the dialer's column. Counts everything
           terminal, not only successes — a run that blocked half its messages
           for compliance reasons is still finished. */
        CASE WHEN COUNT(d.ID) = 0 THEN 0
             ELSE CAST(ROUND(
                 100.0 * SUM(CASE WHEN d.SMSStatus IN (1,5,9,10) THEN 1 ELSE 0 END)
                 / COUNT(d.ID), 0) AS INT)
        END                         AS PercentComplete

    FROM   dbo.SMS_Queue_Mst m
    LEFT   JOIN dbo.SMS_Queue_Detail d ON d.SMSQueue_Mst_ID = m.ID
    LEFT   JOIN dbo.SMS_Run_Status  rs ON rs.ID = m.RunStatus
    WHERE  (@CampaignMstrId IS NULL OR m.Campaign_Mstr_ID = @CampaignMstrId)
    GROUP  BY m.ID, m.Campaign_Mstr_ID, m.RunTime, rs.Status
    ORDER  BY m.RunTime DESC;
END
GO
