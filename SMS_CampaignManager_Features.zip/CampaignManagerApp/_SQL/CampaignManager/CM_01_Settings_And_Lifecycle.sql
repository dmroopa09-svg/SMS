/* ============================================================================
   CAMPAIGN MANAGER — SMS SETTINGS AND RUN LIFECYCLE
   ============================================================================

   Two things:
     1. Per-campaign SMS settings  — rate, window, expiry behaviour
     2. Run lifecycle              — start, stop, and confirming the stop

   Safe to run more than once.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ============================================================================
   1. SMS_Campaign_Settings

   One row per campaign. Everything an operator can configure that affects how
   the run behaves.

   Separate from Campaign_Mstr so the voice campaign table is untouched and so
   these can be added to without a change that anything else reads.
   ============================================================================ */

IF OBJECT_ID('dbo.SMS_Campaign_Settings', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SMS_Campaign_Settings (
        Campaign_Mstr_ID      INT           NOT NULL
            CONSTRAINT PK_SMS_Campaign_Settings PRIMARY KEY,

        /* ---- Rate ----
           Three ceilings, all optional. The tightest one applies.

           PerMinute smooths the send so a campaign does not empty its queue in
           the first thirty seconds and then sit idle. PerHour is the one that
           produces the expiry scenario — 9,000 identified at 1,000 an hour over
           a twelve hour window leaves work undone. PerDay is the total ceiling.
        */
        MaxPerMinute          INT           NULL,
        MaxPerHour            INT           NULL,
        MaxPerDay             INT           NULL,

        /* ---- Batch ----
           How many rows a service claims at once.

           This is also the stop-precision dial. A claimed batch runs to
           completion, so the worst overshoot after pressing stop is one batch
           per running instance. Small batch, precise stop, more round trips.
           Large batch, faster, coarser stop.

           Exposed to the operator deliberately: a campaign where stopping
           precisely matters can be set low before it starts.
        */
        BatchSize             INT           NOT NULL
            CONSTRAINT DF_SCS_BatchSize DEFAULT (100),

        /* ---- Window ----
           Campaign-level window in the RECIPIENT's local time. Narrows the
           state rule; it can never widen it. A campaign set 07:00-22:00 in a
           state permitting 08:00-21:00 sends 08:00-21:00.
        */
        WindowStartHour       TINYINT       NOT NULL
            CONSTRAINT DF_SCS_WinStart DEFAULT (8),
        WindowEndHour         TINYINT       NOT NULL
            CONSTRAINT DF_SCS_WinEnd DEFAULT (21),

        /* ---- Expiry ----
           What happens to messages still unsent when the window closes.
             1 Expire       close them unsent. The default.
             2 CarryForward move to the next day's window.
             3 Remove       discard from the queue.

           Expire is the default because the same criteria run again tomorrow
           will re-select anyone still eligible. Carrying forward risks the same
           person being queued twice — once carried, once freshly selected.
        */
        ExpiryAction          TINYINT       NOT NULL
            CONSTRAINT DF_SCS_ExpiryAction DEFAULT (1),

        /* ---- Sender ----
           Clients need their own registered number so the carrier displays the
           right business name.
        */
        SenderNumberId        INT           NULL,

        /* ---- Template ---- */
        SmsTemplateId         INT           NULL,

        /* ---- Audit ---- */
        CreatedBy             NVARCHAR(100) NULL,
        CreatedUtc            DATETIME2     NOT NULL
            CONSTRAINT DF_SCS_Created DEFAULT SYSUTCDATETIME(),
        UpdatedBy             NVARCHAR(100) NULL,
        UpdatedUtc            DATETIME2     NULL,

        CONSTRAINT CK_SCS_Window CHECK (WindowEndHour > WindowStartHour),
        CONSTRAINT CK_SCS_Batch  CHECK (BatchSize BETWEEN 1 AND 5000),
        CONSTRAINT CK_SCS_Expiry CHECK (ExpiryAction IN (1,2,3))
    );

    PRINT 'Created SMS_Campaign_Settings';
END
GO


/* ============================================================================
   2. Run lifecycle statuses

   Revised from the earlier draft to separate Stopping from Stopped.

     0  Pending         generated, not started
     1  Running         claims permitted
     2  Stopping        stop requested; services still draining   <-- NEW
     3  Stopped         confirmed idle
     4  Completed       all messages terminal
     5  Cancelled       stopped permanently
     6  TimeSuspended   outside the window; waiting, not broken    <-- NEW

   WHY STOPPING AND STOPPED ARE DIFFERENT
   --------------------------------------
   Pressing stop sets a flag. Services finish the batch they hold, which takes
   seconds to a minute. During that time messages are still going out.

   Showing "Stopped" immediately would be a lie the operator can see through —
   they watch the sent count rise after stopping, conclude it did not work, and
   escalate. Showing "Stopping — 2 of 3 confirmed" is accurate and calm.

   WHY TIMESUSPENDED MATTERS
   -------------------------
   A nationwide campaign started in the evening has most of its messages
   deferred to tomorrow morning. That is correct behaviour, but without a status
   for it the campaign is indistinguishable from one that has stalled.
   ============================================================================ */

IF OBJECT_ID('dbo.SMS_Run_Status', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SMS_Run_Status (
        ID          TINYINT      NOT NULL CONSTRAINT PK_SMS_Run_Status PRIMARY KEY,
        Status      VARCHAR(30)  NOT NULL,
        Description NVARCHAR(200) NULL
    );

    INSERT INTO dbo.SMS_Run_Status (ID, Status, Description) VALUES
      (0,'Pending',      'Generated, not yet started'),
      (1,'Running',      'Actively sending'),
      (2,'Stopping',     'Stop requested; services finishing claimed work'),
      (3,'Stopped',      'Confirmed idle; nothing in flight'),
      (4,'Completed',    'All messages reached a terminal state'),
      (5,'Cancelled',    'Stopped permanently'),
      (6,'TimeSuspended','Outside the send window; waiting for it to open');

    PRINT 'Created SMS_Run_Status';
END
GO


/* ============================================================================
   2b. SMSStatus — Expired

   Distinct from Blocked and from Failed. Nothing was wrong with the message and
   nothing failed; the send window closed before its turn came.

   Keeping it separate is what makes the reporting honest. "8,000 sent, 1,000
   expired" is a healthy campaign meeting its throttle. "8,000 sent, 1,000
   failed" is an incident. Same numbers, entirely different response.
   ============================================================================ */

IF NOT EXISTS (SELECT 1 FROM dbo.SMSStatus WHERE ID = 10)
    INSERT INTO dbo.SMSStatus (ID, Status) VALUES (10, 'Expired');
GO


/* ============================================================================
   3. SMS_Service_Instance

   One row per running INSTANCE, not per service. With three delivery instances
   there are three rows.

   This is how a stop gets confirmed. The queue tells us whether anything is in
   flight; this tells us whether the services are alive and have seen the stop.
   Both are needed:

     - a dead service trivially has nothing in flight, which would otherwise
       look identical to having stopped properly
     - a live service that has not yet re-read its config may still claim
   ============================================================================ */

IF OBJECT_ID('dbo.SMS_Service_Instance', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SMS_Service_Instance (
        InstanceId        VARCHAR(100)  NOT NULL
            CONSTRAINT PK_SMS_Service_Instance PRIMARY KEY,
        ServiceName       VARCHAR(50)   NOT NULL,
        MachineName       VARCHAR(100)  NULL,
        StartedUtc        DATETIME2     NOT NULL,
        LastHeartbeatUtc  DATETIME2     NOT NULL,

        /* What it did on its last cycle. Lets the UI show activity rather than
           only liveness. */
        LastCycleUtc      DATETIME2     NULL,
        LastCycleClaimed  INT           NULL,

        /* The run it last worked on, if any. */
        CurrentRunId      BIGINT        NULL
    );

    CREATE INDEX IX_SSI_Service ON dbo.SMS_Service_Instance (ServiceName, LastHeartbeatUtc);
    PRINT 'Created SMS_Service_Instance';
END
GO


/* ============================================================================
   4. usp_SMS_RequestStop

   Sets the flag. Does NOT wait, and does not claim the run has stopped.

   Idempotent: stopping a stopping run is not an error, which matters because
   an operator who sees no immediate change will click again.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_RequestStop', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_RequestStop;
GO

CREATE PROCEDURE dbo.usp_SMS_RequestStop
    @QueueMstId BIGINT,
    @RequestedBy NVARCHAR(100),
    @Reason      NVARCHAR(300) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.SMS_Queue_Mst
    SET    RunStatus     = 2,                    -- Stopping
           StoppedBy     = @RequestedBy,
           StoppedUtc    = SYSUTCDATETIME(),
           StoppedReason = @Reason
    WHERE  ID = @QueueMstId
      AND  RunStatus IN (0, 1, 6);               -- Pending, Running, TimeSuspended

    /* Immediately useful to the operator: what is still moving, and what will
       now never send. */
    SELECT
        SUM(CASE WHEN SMSStatus IN (3,8)   THEN 1 ELSE 0 END) AS InFlight,
        SUM(CASE WHEN SMSStatus IN (0,2,7) THEN 1 ELSE 0 END) AS WillNotSend,
        SUM(CASE WHEN SMSStatus IN (4,5)   THEN 1 ELSE 0 END) AS AlreadySent
    FROM dbo.SMS_Queue_Detail
    WHERE SMSQueue_Mst_ID = @QueueMstId;
END
GO


/* ============================================================================
   5. usp_SMS_ConfirmStop

   Decides whether a Stopping run has actually stopped, and promotes it if so.

   Two conditions, both required:

     NOTHING IN FLIGHT   no row for this run is in a claimed state
     SERVICES ALIVE      every service has heartbeated since the stop was
                         requested, proving it is running and has had the
                         chance to see the flag

   The second condition is what stops a crashed service being mistaken for a
   stopped one. A dead service has nothing in flight — trivially, because it is
   not doing anything — and without the heartbeat check that reads as success.

   Called on a timer by Campaign Manager, not by the services.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_ConfirmStop', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_ConfirmStop;
GO

CREATE PROCEDURE dbo.usp_SMS_ConfirmStop
    @QueueMstId          BIGINT,
    @HeartbeatStaleAfterSeconds INT = 120
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @StoppedUtc DATETIME2;
    DECLARE @RunStatus  TINYINT;

    SELECT @StoppedUtc = StoppedUtc, @RunStatus = RunStatus
    FROM   dbo.SMS_Queue_Mst
    WHERE  ID = @QueueMstId;

    IF @RunStatus <> 2   -- not Stopping; nothing to confirm
    BEGIN
        SELECT @RunStatus AS RunStatus, CAST(0 AS BIT) AS Confirmed,
               'Run is not in Stopping state.' AS Note;
        RETURN;
    END

    DECLARE @InFlight INT;
    SELECT @InFlight = COUNT(*)
    FROM   dbo.SMS_Queue_Detail
    WHERE  SMSQueue_Mst_ID = @QueueMstId
      AND  SMSStatus IN (3, 8);                  -- Queued, Evaluating

    /* Services expected to be participating. A service with no live instance at
       all is reported separately rather than silently ignored. */
    DECLARE @Services TABLE (ServiceName VARCHAR(50));
    INSERT INTO @Services VALUES ('Campaign'), ('Compliance'), ('Delivery');

    DECLARE @TotalServices INT = (SELECT COUNT(*) FROM @Services);

    DECLARE @Confirmed INT;
    SELECT @Confirmed = COUNT(DISTINCT i.ServiceName)
    FROM   dbo.SMS_Service_Instance i
    INNER  JOIN @Services s ON s.ServiceName = i.ServiceName
    WHERE  i.LastHeartbeatUtc >= @StoppedUtc
      AND  DATEDIFF(SECOND, i.LastHeartbeatUtc, SYSUTCDATETIME()) <= @HeartbeatStaleAfterSeconds;

    IF @InFlight = 0 AND @Confirmed = @TotalServices
    BEGIN
        UPDATE dbo.SMS_Queue_Mst
        SET    RunStatus = 3                     -- Stopped
        WHERE  ID = @QueueMstId
          AND  RunStatus = 2;

        SELECT 3 AS RunStatus, CAST(1 AS BIT) AS Confirmed,
               @InFlight AS InFlight, @Confirmed AS ServicesConfirmed,
               @TotalServices AS ServicesExpected,
               'Stop confirmed.' AS Note;
    END
    ELSE
    BEGIN
        SELECT 2 AS RunStatus, CAST(0 AS BIT) AS Confirmed,
               @InFlight AS InFlight, @Confirmed AS ServicesConfirmed,
               @TotalServices AS ServicesExpected,
               CASE
                   WHEN @InFlight > 0
                       THEN CAST(@InFlight AS VARCHAR(20)) + ' message(s) still in flight.'
                   ELSE 'Waiting for service confirmation: '
                        + CAST(@Confirmed AS VARCHAR(5)) + ' of '
                        + CAST(@TotalServices AS VARCHAR(5)) + '.'
               END AS Note;
    END
END
GO


/* ============================================================================
   6. usp_SMS_Heartbeat

   Called by every service instance on every cycle. Upsert on InstanceId.

   InstanceId should be stable for the life of the process and unique across
   instances — machine name plus process id works, or a GUID generated at
   startup. It must NOT be just the machine name, or two instances on one server
   overwrite each other and the stop confirmation counts one where there are two.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_Heartbeat', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_Heartbeat;
GO

CREATE PROCEDURE dbo.usp_SMS_Heartbeat
    @InstanceId    VARCHAR(100),
    @ServiceName   VARCHAR(50),
    @MachineName   VARCHAR(100) = NULL,
    @LastClaimed   INT          = 0,
    @CurrentRunId  BIGINT       = NULL
AS
BEGIN
    SET NOCOUNT ON;

    MERGE dbo.SMS_Service_Instance AS t
    USING (SELECT @InstanceId AS InstanceId) AS s
       ON t.InstanceId = s.InstanceId
    WHEN MATCHED THEN
        UPDATE SET LastHeartbeatUtc = SYSUTCDATETIME(),
                   LastCycleUtc     = SYSUTCDATETIME(),
                   LastCycleClaimed = @LastClaimed,
                   CurrentRunId     = @CurrentRunId
    WHEN NOT MATCHED THEN
        INSERT (InstanceId, ServiceName, MachineName, StartedUtc,
                LastHeartbeatUtc, LastCycleUtc, LastCycleClaimed, CurrentRunId)
        VALUES (@InstanceId, @ServiceName, @MachineName, SYSUTCDATETIME(),
                SYSUTCDATETIME(), SYSUTCDATETIME(), @LastClaimed, @CurrentRunId);
END
GO


/* ============================================================================
   7. usp_SMS_GetServiceHealth

   What the UI shows for the services panel.

   "Not responding" is the one that earns its place. A service that is enabled
   but silent has died, and nothing else on a dashboard surfaces that — the
   queue simply stops moving, which looks like having no work.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_GetServiceHealth', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_GetServiceHealth;
GO

CREATE PROCEDURE dbo.usp_SMS_GetServiceHealth
    @StaleAfterSeconds INT = 120
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ServiceName,
        COUNT(*) AS InstanceCount,
        SUM(CASE WHEN DATEDIFF(SECOND, LastHeartbeatUtc, SYSUTCDATETIME()) <= @StaleAfterSeconds
                 THEN 1 ELSE 0 END) AS LiveInstances,
        MAX(LastHeartbeatUtc) AS MostRecentHeartbeat,
        SUM(ISNULL(LastCycleClaimed, 0)) AS ClaimedLastCycle,
        CASE
            WHEN SUM(CASE WHEN DATEDIFF(SECOND, LastHeartbeatUtc, SYSUTCDATETIME()) <= @StaleAfterSeconds
                          THEN 1 ELSE 0 END) = 0 THEN 'Not responding'
            WHEN SUM(CASE WHEN DATEDIFF(SECOND, LastHeartbeatUtc, SYSUTCDATETIME()) <= @StaleAfterSeconds
                          THEN 1 ELSE 0 END) < COUNT(*) THEN 'Degraded'
            ELSE 'Healthy'
        END AS Health
    FROM dbo.SMS_Service_Instance
    GROUP BY ServiceName
    ORDER BY ServiceName;
END
GO
