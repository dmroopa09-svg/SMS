using System;
using System.Collections.Generic;

namespace CampaignManager.DTO.Sms.Messaging
{
    /// <summary>
    /// Topic names, in one place.
    ///
    /// Every service that publishes or consumes must use these constants rather
    /// than string literals. A typo in a topic name does not fail — the producer
    /// writes happily to a topic nobody reads, and the message is simply lost
    /// with no error anywhere.
    /// </summary>
    public static class SmsTopics
    {
        /// <summary>Campaign publishes here when a batch is ready for evaluation.</summary>
        public const string CampaignToCompliance = "sms.campaign.ready";

        /// <summary>Compliance publishes here when messages are cleared to send.</summary>
        public const string ComplianceToScheduler = "sms.compliance.approved";

        /// <summary>Scheduler publishes here when a message's send time has arrived.</summary>
        public const string SchedulerToDelivery = "sms.scheduler.due";

        /// <summary>Delivery publishes outcomes; status service consumes.</summary>
        public const string DeliveryToStatus = "sms.delivery.result";
    }

    /// <summary>
    /// Base for every SMS message on the bus.
    ///
    /// CarriesId rather than data. The design discussion settled on passing a
    /// minimal payload and having each service read what it needs from the
    /// database. That is the right call: a message carrying a copy of the
    /// recipient's details is stale the moment it is written, and if someone
    /// replies STOP while the message sits in a partition, a self-contained
    /// payload has no way to learn that.
    ///
    /// CorrelationId is separate from the queue id on purpose. It follows one
    /// logical message across every service and every topic, so a support
    /// question ("what happened to this person's message?") is one search rather
    /// than a join across four services' logs.
    /// </summary>
    public abstract class SmsMessageBase
    {
        /// <summary>SMS_Queue_Detail.ID — the row every service reads from.</summary>
        public long QueueDetailId { get; set; }

        /// <summary>SMS_Queue_Mst.ID — the run this belongs to.</summary>
        public long QueueMstId { get; set; }

        public int CampaignMstrId { get; set; }

        /// <summary>Follows this message end to end. Generate once, never change.</summary>
        public string CorrelationId { get; set; } = "";

        /// <summary>When the publishing service emitted this. Always UTC.</summary>
        public DateTime PublishedUtc { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Which service published it. Useful when a message appears somewhere
        /// unexpected and you need to know who put it there.
        /// </summary>
        public string PublishedBy { get; set; } = "";

        /// <summary>
        /// Increment when the message shape changes in a way consumers must
        /// notice. Lets a consumer reject what it does not understand instead of
        /// silently misreading it.
        /// </summary>
        public int SchemaVersion { get; set; } = 1;
    }

    /// <summary>
    /// Campaign -> Compliance. "These rows are ready to be evaluated."
    ///
    /// Sent as a BATCH rather than one message per recipient. At five hundred
    /// thousand a day, one Kafka message per SMS is five hundred thousand
    /// messages, each triggering its own database round trip on the consumer
    /// side. A batch of identifiers costs one message and one query.
    /// </summary>
    public sealed class CampaignReadyMessage
    {
        public long QueueMstId { get; set; }
        public int CampaignMstrId { get; set; }
        public string CorrelationId { get; set; } = "";
        public DateTime PublishedUtc { get; set; } = DateTime.UtcNow;
        public string PublishedBy { get; set; } = "";
        public int SchemaVersion { get; set; } = 1;

        /// <summary>
        /// Row identifiers to evaluate. Compliance reads the detail from the
        /// database; nothing about the recipient travels on the bus.
        /// </summary>
        public List<long> QueueDetailIds { get; set; } = new();

        /// <summary>Total rows in this run, so a consumer can report progress.</summary>
        public int TotalInRun { get; set; }
    }

    /// <summary>
    /// Compliance -> Scheduler. "These are cleared; here is when each may go."
    ///
    /// Approved and deferred travel together rather than on separate topics. The
    /// scheduler needs both — one set to release now, one to hold — and
    /// splitting them would mean correlating two streams to reconstruct what
    /// compliance decided about a single run.
    ///
    /// Blocked messages are NOT published. They are terminal, written to the row
    /// with a reason, and nothing downstream needs to know.
    /// </summary>
    public sealed class ComplianceApprovedMessage
    {
        public long QueueMstId { get; set; }
        public int CampaignMstrId { get; set; }
        public string CorrelationId { get; set; } = "";
        public DateTime PublishedUtc { get; set; } = DateTime.UtcNow;
        public string PublishedBy { get; set; } = "";
        public int SchemaVersion { get; set; } = 1;

        /// <summary>Clear to send immediately.</summary>
        public List<long> ApprovedNow { get; set; } = new();

        /// <summary>Clear to send later, each with the earliest permitted instant.</summary>
        public List<DeferredItem> Deferred { get; set; } = new();

        /// <summary>Counts only, for monitoring. The rows carry the reasons.</summary>
        public int BlockedCount { get; set; }
    }

    public sealed class DeferredItem
    {
        public long QueueDetailId { get; set; }

        /// <summary>
        /// Earliest UTC instant this may be sent. Already accounts for the
        /// recipient's local window and daylight saving — the scheduler should
        /// treat it as final and not recompute it.
        /// </summary>
        public DateTime NotBeforeUtc { get; set; }
    }

    /// <summary>
    /// Scheduler -> Delivery. "Send these now."
    /// </summary>
    public sealed class DeliveryDueMessage
    {
        public long QueueMstId { get; set; }
        public int CampaignMstrId { get; set; }
        public string CorrelationId { get; set; } = "";
        public DateTime PublishedUtc { get; set; } = DateTime.UtcNow;
        public string PublishedBy { get; set; } = "";
        public int SchemaVersion { get; set; } = 1;

        public List<long> QueueDetailIds { get; set; } = new();
    }

    /// <summary>
    /// Delivery -> Status. What the provider said.
    /// </summary>
    public sealed class DeliveryResultMessage
    {
        public long QueueDetailId { get; set; }
        public string CorrelationId { get; set; } = "";
        public DateTime PublishedUtc { get; set; } = DateTime.UtcNow;
        public string PublishedBy { get; set; } = "";
        public int SchemaVersion { get; set; } = 1;

        public bool Accepted { get; set; }

        /// <summary>Webex transid. Delivery receipts key on this.</summary>
        public string? ProviderMessageId { get; set; }

        public string? ResponseCode { get; set; }
        public string? ResponseMessage { get; set; }
    }
}
