/* ============================================================================
   SMS SERVICE RUNTIME CONTROL
   ============================================================================

   Lets an operator stop a service, or change how fast it runs, from the UI —
   with no restart and no deployment.

   WHY A TABLE RATHER THAN appsettings
   -----------------------------------
   Configuration in appsettings.json requires a redeploy to change and cannot be
   touched by an operator. The requirement is that campaigns can be stopped at
   any time and the interval changed whenever needed, which means the setting has
   to live somewhere the UI can write and the service re-reads while running.

   One row per service. Each worker reads its own row at the top of every cycle
   — a single-row indexed read, negligible even at a one-second interval.

   HOW STOPPING BEHAVES
   --------------------
   Setting IsEnabled = 0 does NOT kill anything mid-flight. The worker finishes
   the batch it is holding, records those results, and then idles. Abandoning a
   claimed batch would leave rows stranded in an in-progress state with nothing
   to reclaim them.

   So "stop" means "stop taking new work", which is what an operator actually
   wants and what keeps the data consistent.
   ============================================================================ */

IF OBJECT_ID('dbo.Sms_Service_Control', 'U') IS NOT NULL
    DROP TABLE dbo.Sms_Service_Control;
GO

CREATE TABLE dbo.Sms_Service_Control (
    ServiceName          VARCHAR(50)   NOT NULL
        CONSTRAINT PK_Sms_Service_Control PRIMARY KEY,

    /* 0 stops the service taking new work. In-flight work still completes. */
    IsEnabled            BIT           NOT NULL
        CONSTRAINT DF_SSC_IsEnabled DEFAULT (1),

    /* Seconds to wait between cycles when there IS work. */
    PollIntervalSeconds  INT           NOT NULL
        CONSTRAINT DF_SSC_Poll DEFAULT (1),

    /* Seconds to wait when the last cycle found nothing. Larger than the busy
       interval on purpose — polling an empty queue every second all night is a
       needless query every second all night. */
    IdleIntervalSeconds  INT           NOT NULL
        CONSTRAINT DF_SSC_Idle DEFAULT (15),

    /* Rows claimed per cycle. Raise for throughput, lower to reduce the amount
       of work at risk if the process dies mid-batch. */
    BatchSize            INT           NOT NULL
        CONSTRAINT DF_SSC_Batch DEFAULT (500),

    /* Optional ceiling on messages dispatched per second, where the service
       calls an external provider. NULL means no limit applied here. */
    MaxPerSecond         INT           NULL,

    /* Set by the service so the UI can show whether it is actually alive. A
       service that is enabled but whose heartbeat is minutes old has died
       without anyone noticing — which is otherwise invisible. */
    LastHeartbeatUtc     DATETIME2     NULL,
    LastCycleUtc         DATETIME2     NULL,
    LastCycleProcessed   INT           NULL,
    InstanceCount        INT           NULL,

    /* Audit — a stopped service is an operational decision worth attributing. */
    UpdatedBy            NVARCHAR(100) NULL,
    UpdatedAt            DATETIME2     NOT NULL
        CONSTRAINT DF_SSC_UpdatedAt DEFAULT SYSUTCDATETIME(),
    StoppedReason        NVARCHAR(300) NULL
);
GO

INSERT INTO dbo.Sms_Service_Control
    (ServiceName, IsEnabled, PollIntervalSeconds, IdleIntervalSeconds, BatchSize, MaxPerSecond, UpdatedBy)
VALUES
    ('Campaign',   1, 5,  30, 1000, NULL,  'seed'),
    ('Compliance', 1, 1,  15,  500, NULL,  'seed'),
    ('Scheduler',  1, 10, 30,  500, NULL,  'seed'),
    ('Delivery',   1, 1,  10,  200, 20,    'seed');
GO

/* Delivery carries MaxPerSecond because it is the only service that talks to
   Webex, and the provider limit applies there.

   Note that this is a PER-INSTANCE limit. Two delivery instances at 20 each
   send 40 per second. If the provider ceiling is a hard 20 across the account,
   either run one delivery instance or divide the limit between them. */


/* ----------------------------------------------------------------------------
   UI OPERATIONS
   ---------------------------------------------------------------------------- */

-- Stop a service. Takes effect within one cycle; in-flight work completes.
-- UPDATE dbo.Sms_Service_Control
-- SET IsEnabled = 0, StoppedReason = 'Paused by operator', UpdatedBy = @user, UpdatedAt = SYSUTCDATETIME()
-- WHERE ServiceName = 'Campaign';

-- Restart it.
-- UPDATE dbo.Sms_Service_Control
-- SET IsEnabled = 1, StoppedReason = NULL, UpdatedBy = @user, UpdatedAt = SYSUTCDATETIME()
-- WHERE ServiceName = 'Campaign';

-- Change pacing. No restart needed.
-- UPDATE dbo.Sms_Service_Control
-- SET PollIntervalSeconds = 5, BatchSize = 200, UpdatedBy = @user, UpdatedAt = SYSUTCDATETIME()
-- WHERE ServiceName = 'Delivery';


/* ----------------------------------------------------------------------------
   MONITORING
   ---------------------------------------------------------------------------- */

-- What the UI should show. A service enabled but silent for minutes is dead.
SELECT
    ServiceName,
    IsEnabled,
    PollIntervalSeconds,
    BatchSize,
    LastHeartbeatUtc,
    DATEDIFF(SECOND, LastHeartbeatUtc, SYSUTCDATETIME()) AS SecondsSinceHeartbeat,
    CASE
        WHEN IsEnabled = 0 THEN 'Stopped'
        WHEN LastHeartbeatUtc IS NULL THEN 'Never started'
        WHEN DATEDIFF(SECOND, LastHeartbeatUtc, SYSUTCDATETIME())
             > (PollIntervalSeconds + IdleIntervalSeconds + 60) THEN 'Not responding'
        ELSE 'Running'
    END AS HealthState,
    LastCycleProcessed,
    StoppedReason,
    UpdatedBy,
    UpdatedAt
FROM dbo.Sms_Service_Control
ORDER BY ServiceName;
GO
