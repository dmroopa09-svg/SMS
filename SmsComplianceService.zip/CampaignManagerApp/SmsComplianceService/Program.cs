using CampaignManager.Common.Sms.Compliance;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SmsComplianceService.Configuration;
using SmsComplianceService.Workers;

var builder = Host.CreateApplicationBuilder(args);

var connectionString =
    builder.Configuration.GetConnectionString("GD_Data")
    ?? throw new InvalidOperationException(
        "ConnectionStrings:GD_Data is not configured. The service cannot start without it.");

// ---------------------------------------------------------------------------
// Runtime control — lets the UI stop the service and change its pacing without
// a restart. Registered as a singleton because it caches, and one cache per
// process is the point.
// ---------------------------------------------------------------------------
builder.Services.AddSingleton(sp => new ServiceControlReader(
    connectionString,
    "Compliance",
    sp.GetRequiredService<ILogger<ServiceControlReader>>()));

// ---------------------------------------------------------------------------
// Compliance lookups. Both cache their table in memory and are read for every
// message, so they are singletons — a per-message query against a table that
// changes twice a year would be the single largest cost in the service.
// ---------------------------------------------------------------------------
builder.Services.AddSingleton<IZipTimeZoneLookup>(sp => new SqlZipTimeZoneLookup(
    connectionString, sp.GetService<ILogger<SqlZipTimeZoneLookup>>()));

builder.Services.AddSingleton<IStateTcpaRuleProvider>(sp => new SqlStateTcpaRuleProvider(
    connectionString, sp.GetService<ILogger<SqlStateTcpaRuleProvider>>()));

// ---------------------------------------------------------------------------
// Decision logic. Scoped so each cycle gets a clean instance.
// ---------------------------------------------------------------------------
builder.Services.AddScoped<RecipientTimeZoneResolver>();
builder.Services.AddScoped<SmsComplianceEvaluator>();
builder.Services.AddScoped<StateAwareComplianceGate>();
builder.Services.AddScoped<ComplianceProcessor>();

// ---------------------------------------------------------------------------
// Adapters against SMS_Queue_Detail.
//
// NOT INCLUDED YET — see the README. These are the three pieces that bind the
// service to the queue table, and they depend on decisions still open: which
// database the queue lives in, and whether work arrives over Kafka or is read
// directly. Register whichever implementations you write:
//
//   builder.Services.AddScoped<IComplianceWorkSource,    SqlComplianceWorkSource>();
//   builder.Services.AddScoped<IComplianceResultSink,    SqlComplianceResultSink>();
//   builder.Services.AddScoped<IDeferredMessageReleaser, SqlDeferredReleaser>();
//
// The service will not start without them; that is deliberate rather than
// starting and silently doing nothing.
// ---------------------------------------------------------------------------

builder.Services.AddHostedService<ComplianceWorker>();

var host = builder.Build();
await host.RunAsync();
