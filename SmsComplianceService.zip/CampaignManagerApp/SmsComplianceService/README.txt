SMS COMPLIANCE SERVICE — separate project
==========================================

A standalone worker service. References the existing CampaignManager.* projects
rather than duplicating anything, as directed.


WHERE IT SITS
-------------
    CampaignManagerApp/
      CampaignManager.Common/          referenced — compliance decision logic
      CampaignManager.Models/          referenced — entities
      CampaignManager.DTO/             referenced — shared Kafka contracts
      CampaignManager.Interfaces/      referenced
      SmsComplianceService/            THIS PROJECT
        Program.cs
        appsettings.json
        Configuration/ServiceControlReader.cs
        Workers/ComplianceWorker.cs

Add the shared contracts file to CampaignManager.DTO under Sms/Messaging/.
It belongs there, not here — every service needs it.


RUN THIS FIRST
--------------
    _SQL/002_Sms_Service_Control.sql

Creates the table that lets the UI stop services and change their pacing. The
service will not take work until its row exists.


STOP AND CONFIGURE FROM THE UI
------------------------------
One row per service in dbo.Sms_Service_Control:

    IsEnabled             0 stops the service taking new work
    PollIntervalSeconds   wait between cycles when there is work
    IdleIntervalSeconds   wait when the last cycle found nothing
    BatchSize             rows claimed per cycle
    MaxPerSecond          dispatch ceiling, for services calling a provider

The worker re-reads this every cycle, so changes take effect within seconds. No
restart, no deployment.

HOW STOPPING BEHAVES — worth being precise about, because the obvious
implementation is wrong. Setting IsEnabled = 0 does NOT abandon work in flight.
The worker finishes the batch it is holding, writes those decisions, and then
idles. Killing a claimed batch mid-way would leave rows in an in-progress state
with nothing to reclaim them, needing manual repair.

So "stop" means "stop taking new work". That is what an operator actually wants,
and it is the only version that leaves the data consistent.

The service also heartbeats WHILE STOPPED. Without that, "stopped deliberately"
and "crashed" look identical on a monitoring screen — the most common way an
outage goes unnoticed.


THE MONITORING QUERY
--------------------
At the bottom of 002_Sms_Service_Control.sql. It derives a health state:

    Stopped          IsEnabled = 0
    Never started    no heartbeat recorded
    Not responding   enabled, but the heartbeat is older than its own interval
    Running          heartbeat current

"Not responding" is the useful one. A service that is enabled but silent has
died, and nothing else surfaces that.


WHAT COLLEAGUES NEED FOR THE OTHER SERVICES
-------------------------------------------
Share CampaignManager.DTO/Sms/Messaging/SmsMessageContracts.cs with whoever
builds campaign, scheduler and delivery. Everything below comes from that file.

TOPICS — use the constants in SmsTopics, never string literals. A typo in a
topic name does not fail: the producer writes happily to a topic nobody reads
and the message is lost with no error anywhere.

    sms.campaign.ready       campaign   -> compliance
    sms.compliance.approved  compliance -> scheduler
    sms.scheduler.due        scheduler  -> delivery
    sms.delivery.result      delivery   -> status

MESSAGES CARRY IDS, NOT DATA. This was settled in the design discussion and it
is right. A message carrying a copy of the recipient's details is stale the
moment it is written — if someone replies STOP while it sits in a partition, a
self-contained payload has no way to learn that. Each service reads current
state from the database.

BATCH, DO NOT SEND ONE PER RECIPIENT. At five hundred thousand a day, one Kafka
message per SMS is five hundred thousand messages, each triggering its own
database round trip on the consumer side. CampaignReadyMessage carries a list of
row ids for exactly this reason.

CORRELATIONID FOLLOWS ONE MESSAGE END TO END. Generate it once in campaign and
pass it through unchanged. It turns "what happened to this person's message?"
from a join across four services' logs into a single search.

EVERY SERVICE NEEDS ITS OWN CONTROL ROW. The requirement to stop campaigns at
any time and change the interval from the UI applies to all of them, not just
compliance. ServiceControlReader is small and self-contained — copy it, or lift
it into CampaignManager.Common so all four share one implementation. The second
is better.


WHAT IS NOT BUILT YET
---------------------
Three adapters binding the service to SMS_Queue_Detail:

    IComplianceWorkSource       fetch a batch of rows awaiting evaluation
    IComplianceResultSink       write decisions back in one batched update
    IDeferredMessageReleaser    move due deferred rows back to evaluable

They are missing because they depend on two decisions that are still open:

  1. WHICH DATABASE the queue lives in. The design discussion agreed queue data
     would move to a separate database; the tables are currently in GD_Data.
     Until that is settled the connection and any cross-database join are
     unknown.

  2. WHETHER work arrives over Kafka or is read directly. The interfaces are
     satisfied by either — a Kafka consumer and a batched claim query both fit —
     so the decision can be made late, but it has to be made before these are
     written.

The service will not start without them registered. That is deliberate: starting
and silently processing nothing is worse than failing to start.


ONE THING TO SETTLE BEFORE THE ADAPTERS
---------------------------------------
SMSStatus has no value for "deferred", but the Time_Range rule action is QUEUE,
so deferral is an expected outcome with nowhere to sit.

    leaving it at Init makes it indistinguishable from a row never evaluated,
    so compliance re-scans the whole backlog every cycle

    moving it to Queued risks delivery sending it before the window opens,
    which is the failure the rule exists to prevent

It needs a status value AND a next-attempt datetime column. The timestamp
matters as much as the status — without it nothing knows when to reconsider the
message.


AFTER THIS
----------
Scheduler and delivery, per the direction given. Both follow the same shape:
their own project, their own control row, consuming one topic and publishing the
next. The scheduler's job is small — hold deferred messages until NotBeforeUtc
and publish them — because compliance has already computed that instant and it
should be treated as final rather than recomputed.
