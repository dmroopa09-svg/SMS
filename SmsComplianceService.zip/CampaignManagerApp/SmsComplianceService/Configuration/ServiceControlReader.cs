using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace SmsComplianceService.Configuration
{
    /// <summary>Current control settings for one service.</summary>
    public sealed class ServiceControl
    {
        public bool IsEnabled { get; init; } = true;
        public int PollIntervalSeconds { get; init; } = 1;
        public int IdleIntervalSeconds { get; init; } = 15;
        public int BatchSize { get; init; } = 500;
        public int? MaxPerSecond { get; init; }
        public string? StoppedReason { get; init; }

        /// <summary>Used when the control row cannot be read. See the note in the reader.</summary>
        public static ServiceControl SafeDefault => new()
        {
            IsEnabled = false,
            StoppedReason = "Control row unreadable; service held."
        };
    }

    /// <summary>
    /// Reads dbo.Sms_Service_Control so an operator can stop the service or
    /// change its pacing from the UI without a restart.
    ///
    /// Cached for a few seconds rather than read on every single loop. At a
    /// one-second interval an uncached read is 86,400 queries a day for a row
    /// that changes perhaps twice a month — but the cache is deliberately short,
    /// because "stop" needs to mean stop within seconds, not minutes.
    ///
    /// IF THE ROW CANNOT BE READ, THE SERVICE HOLDS rather than continues on the
    /// last known settings. A database it cannot reach is also the database it
    /// would be writing compliance decisions to, so carrying on would mean
    /// processing work it cannot record. Stopping is the honest response.
    /// </summary>
    public sealed class ServiceControlReader
    {
        private static readonly TimeSpan CacheFor = TimeSpan.FromSeconds(5);

        private readonly string _connectionString;
        private readonly string _serviceName;
        private readonly ILogger<ServiceControlReader> _logger;

        private ServiceControl _cached = new();
        private DateTime _cachedAtUtc = DateTime.MinValue;
        private bool _lastEnabledState = true;

        public ServiceControlReader(
            string connectionString, string serviceName, ILogger<ServiceControlReader> logger)
        {
            _connectionString = connectionString;
            _serviceName = serviceName;
            _logger = logger;
        }

        public async Task<ServiceControl> GetAsync(CancellationToken ct = default)
        {
            if (DateTime.UtcNow - _cachedAtUtc < CacheFor)
                return _cached;

            const string sql = @"
SELECT IsEnabled, PollIntervalSeconds, IdleIntervalSeconds, BatchSize,
       MaxPerSecond, StoppedReason
FROM   dbo.Sms_Service_Control
WHERE  ServiceName = @svc;";

            try
            {
                await using var conn = new SqlConnection(_connectionString);
                await conn.OpenAsync(ct);

                await using var cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@svc", _serviceName);

                await using var reader = await cmd.ExecuteReaderAsync(ct);

                if (!await reader.ReadAsync(ct))
                {
                    _logger.LogError(
                        "No control row for service '{Service}'. Holding until one exists.",
                        _serviceName);

                    _cached = ServiceControl.SafeDefault;
                    _cachedAtUtc = DateTime.UtcNow;
                    return _cached;
                }

                var control = new ServiceControl
                {
                    IsEnabled = reader.GetBoolean(0),
                    PollIntervalSeconds = Clamp(reader.GetInt32(1), 1, 3600),
                    IdleIntervalSeconds = Clamp(reader.GetInt32(2), 1, 3600),
                    BatchSize = Clamp(reader.GetInt32(3), 1, 10000),
                    MaxPerSecond = reader.IsDBNull(4) ? null : reader.GetInt32(4),
                    StoppedReason = reader.IsDBNull(5) ? null : reader.GetString(5)
                };

                // Log transitions, not the steady state. An operator stopping a
                // service is worth a line; the service being enabled for the
                // ten-thousandth consecutive cycle is not.
                if (control.IsEnabled != _lastEnabledState)
                {
                    if (control.IsEnabled)
                        _logger.LogWarning("Service '{Service}' ENABLED.", _serviceName);
                    else
                        _logger.LogWarning(
                            "Service '{Service}' STOPPED. Reason: {Reason}",
                            _serviceName, control.StoppedReason ?? "(none given)");

                    _lastEnabledState = control.IsEnabled;
                }

                _cached = control;
                _cachedAtUtc = DateTime.UtcNow;
                return control;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Could not read control row for '{Service}'; holding.", _serviceName);

                _cached = ServiceControl.SafeDefault;
                _cachedAtUtc = DateTime.UtcNow;
                return _cached;
            }
        }

        /// <summary>
        /// Records that this instance is alive and what it just did. The UI uses
        /// the heartbeat to distinguish "stopped deliberately" from "died".
        /// </summary>
        public async Task HeartbeatAsync(int processedLastCycle, CancellationToken ct = default)
        {
            const string sql = @"
UPDATE dbo.Sms_Service_Control
SET    LastHeartbeatUtc   = SYSUTCDATETIME(),
       LastCycleUtc       = SYSUTCDATETIME(),
       LastCycleProcessed = @processed
WHERE  ServiceName = @svc;";

            try
            {
                await using var conn = new SqlConnection(_connectionString);
                await conn.OpenAsync(ct);

                await using var cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@svc", _serviceName);
                cmd.Parameters.AddWithValue("@processed", processedLastCycle);

                await cmd.ExecuteNonQueryAsync(ct);
            }
            catch (Exception ex)
            {
                // A failed heartbeat must not stop the service. It only affects
                // what the monitoring screen shows.
                _logger.LogWarning(ex, "Heartbeat failed for '{Service}'.", _serviceName);
            }
        }

        private static int Clamp(int value, int min, int max)
            => value < min ? min : (value > max ? max : value);
    }
}
