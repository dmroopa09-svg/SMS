using System;
using System.Threading;
using System.Threading.Tasks;
using CampaignManager.Common.Sms.Compliance;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SmsComplianceService.Configuration;

namespace SmsComplianceService.Workers
{
    /// <summary>
    /// Runs the compliance evaluation loop.
    ///
    /// STOPPING IS COOPERATIVE, NOT ABRUPT.
    /// When an operator sets IsEnabled = 0, this finishes the batch it is
    /// currently holding, writes those decisions, and then idles. It does not
    /// abandon claimed rows — those would be stranded in an in-progress state
    /// with nothing to reclaim them, and would need manual repair.
    ///
    /// So "stop" means "stop taking new work". That is what an operator wants
    /// and it is the only version that leaves the data consistent.
    ///
    /// The control row is re-read every cycle, so interval and batch size
    /// changes take effect without a restart.
    /// </summary>
    public sealed class ComplianceWorker : BackgroundService
    {
        private const string ServiceName = "Compliance";

        private readonly IServiceProvider _services;
        private readonly ServiceControlReader _control;
        private readonly ILogger<ComplianceWorker> _logger;

        public ComplianceWorker(
            IServiceProvider services,
            ServiceControlReader control,
            ILogger<ComplianceWorker> logger)
        {
            _services = services;
            _control = control;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Compliance service started.");

            var wasStopped = false;

            while (!stoppingToken.IsCancellationRequested)
            {
                var control = await _control.GetAsync(stoppingToken);
                var processed = 0;

                if (!control.IsEnabled)
                {
                    if (!wasStopped)
                    {
                        _logger.LogWarning(
                            "Compliance is stopped by operator. Reason: {Reason}",
                            control.StoppedReason ?? "(none given)");
                        wasStopped = true;
                    }

                    // Heartbeat while stopped so the UI can tell "stopped on
                    // purpose" from "crashed". Without this the two look
                    // identical on the monitoring screen.
                    await _control.HeartbeatAsync(0, stoppingToken);
                    await Wait(TimeSpan.FromSeconds(control.IdleIntervalSeconds), stoppingToken);
                    continue;
                }

                if (wasStopped)
                {
                    _logger.LogWarning("Compliance resumed by operator.");
                    wasStopped = false;
                }

                try
                {
                    using var scope = _services.CreateScope();
                    var processor = scope.ServiceProvider.GetRequiredService<ComplianceProcessor>();

                    // Once started, this batch runs to completion even if the
                    // operator stops the service mid-way. The next loop will
                    // see IsEnabled = 0 and take no more work.
                    var result = await processor.RunOnceAsync(control.BatchSize, stoppingToken);
                    processed = result.Evaluated;

                    if (result.DidWork)
                    {
                        _logger.LogInformation(
                            "Compliance cycle: evaluated={Evaluated} allowed={Allowed} " +
                            "deferred={Deferred} blocked={Blocked} released={Released}",
                            result.Evaluated, result.Allowed, result.Deferred,
                            result.Blocked, result.Released);
                    }

                    await _control.HeartbeatAsync(processed, stoppingToken);

                    var interval = result.DidWork
                        ? control.PollIntervalSeconds
                        : control.IdleIntervalSeconds;

                    await Wait(TimeSpan.FromSeconds(interval), stoppingToken);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Compliance cycle failed; backing off.");
                    await _control.HeartbeatAsync(processed, stoppingToken);

                    // Back off harder than the normal idle so a persistent fault
                    // does not hammer the database in a tight failure loop.
                    await Wait(TimeSpan.FromSeconds(Math.Max(control.IdleIntervalSeconds, 30)),
                               stoppingToken);
                }
            }

            _logger.LogInformation("Compliance service stopping.");
        }

        private static async Task Wait(TimeSpan delay, CancellationToken ct)
        {
            try { await Task.Delay(delay, ct); }
            catch (OperationCanceledException) { }
        }
    }
}
