import { useCallback, useEffect, useState } from 'react';
import { Activity, Users, CheckCircle2, AlertTriangle, RefreshCw, X, Coffee } from 'lucide-react';
import { apiClient } from '../api/client';
import type { DashboardMetricsDto, ProcessUserTaskMetricsDto } from '../types';
import { presenceApi, parseUtc, formatMinutes, type TeamPresence, type PresenceStatus } from '../api/presence';

const PRESENCE_REFRESH_MS = 30_000;

const STATUS_STYLE: Record<PresenceStatus, { label: string; className: string }> = {
  Online: { label: 'Online', className: 'bg-emerald-50 text-emerald-600' },
  Idle: { label: 'Idle', className: 'bg-amber-50 text-amber-600' },
  OnBreak: { label: 'On Break', className: 'bg-sky-50 text-sky-600' },
  Offline: { label: 'Offline', className: 'bg-zinc-100 text-zinc-500' },
};

const formatTime = (d: Date | null) =>
  d ? d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) : '-';
import { cn } from '../types';
import { useAuth } from '../contexts/AuthContext';

export default function Dashboard() {
  const { isAuthenticated } = useAuth();
  const [metrics, setMetrics] = useState<DashboardMetricsDto | null>(null);
  const [presence, setPresence] = useState<TeamPresence | null>(null);
  const [presenceProcessId, setPresenceProcessId] = useState<number | null>(null);
  const [presenceStatusFilter, setPresenceStatusFilter] = useState<PresenceStatus | 'All'>('All');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [selectedProcessName, setSelectedProcessName] = useState<string | null>(null);
  const [selectedProcessId, setSelectedProcessId] = useState<number | null>(null);
  const [userMetrics, setUserMetrics] = useState<ProcessUserTaskMetricsDto[] | null>(null);
  const [metricsLoading, setMetricsLoading] = useState(false);
  const targetColumns =
    userMetrics?.flatMap(x =>
      Object.keys(x.targetIndicators || {})
    ) || [];

  const uniqueTargetColumns = [...new Set(targetColumns)];

  useEffect(() => {
    if (isAuthenticated) {
      loadData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  // User Activity refreshes on its own every 30s (and when its process filter changes) -
  // the rest of the dashboard is not reloaded for it.
  const loadPresence = useCallback(async () => {
    try {
      setPresence(await presenceApi.team(presenceProcessId));
    } catch (err) {
      console.error('Failed to load user activity:', err);
    }
  }, [presenceProcessId]);

  useEffect(() => {
    if (!isAuthenticated) return;
    loadPresence();
    const id = window.setInterval(() => {
      if (document.visibilityState === 'visible') loadPresence();
    }, PRESENCE_REFRESH_MS);
    return () => window.clearInterval(id);
  }, [isAuthenticated, loadPresence]);

  const handleProcessClick = async (processId: number, processName: string) => {
    setSelectedProcessId(processId);
    setSelectedProcessName(processName);
    setMetricsLoading(true);

    try {
      const data = await apiClient.getUserMetrics(processId);
      setUserMetrics(data);
    } catch (err) {
      console.error("Failed to load user metrics:", err);
      setUserMetrics([]);
    } finally {
      setMetricsLoading(false);
    }
  };

  const loadData = async () => {
    try {
      setError(null);
      setIsLoading(true);
      const [metricsData, presenceData] = await Promise.all([
        apiClient.getDashboardMetrics(),
        presenceApi.team(presenceProcessId).catch(() => null),
      ]);
      setMetrics(metricsData);
      setPresence(presenceData);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      // If it's a 401, the auth context will handle it automatically
      if (error instanceof Error && (error as any).status === 401) {
        // Auth error - will be handled by AuthContext, user will be redirected to login
        setError('Your session has expired. Please log in again.');
        return;
      }
      setError(error instanceof Error ? error.message : 'Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen from-zinc-50 via-white to-zinc-50 p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-center h-64">
          <div className="w-8 h-8 border-4 border-zinc-100 border-t-blue-600 rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen from-zinc-50 via-white to-zinc-50 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                <Activity className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-black tracking-tight text-zinc-900">Dashboard</h1>
                <p className="text-sm text-zinc-500 mt-1 font-medium">Overview of operations and performance</p>
              </div>
            </div>
          </div>
        <div className="flex flex-col items-center justify-center h-64 bg-white border border-zinc-100 rounded-xl p-8">
          <AlertTriangle className="w-12 h-12 text-amber-500 mb-4" />
          <p className="text-lg font-bold text-zinc-900 mb-2">Unable to load dashboard data</p>
          <p className="text-sm text-zinc-500 mb-6 text-center max-w-md">{error}</p>
          <button
            onClick={loadData}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all"
          >
            <RefreshCw className="w-4 h-4" />
            Retry
          </button>
        </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-6 from-zinc-50 via-white to-zinc-50 p-6 bg-white h-full overflow-auto scrollbar-thin 
            [scrollbar-width:thin] ">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tight text-zinc-900">Dashboard</h1>
              <p className="text-sm text-zinc-500 mt-1 font-medium">Overview of operations and performance</p>
            </div>
          </div>
        </div>

        {/* Metrics Cards */}
{metrics && (
  /* Changed lg:grid-cols-6 to lg:grid-cols-7 and xl:grid-cols-7 */
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-6">
    
    {/* Total Tasks Card */}
    <div className="bg-gradient-to-br from-[#fffbf5] via-[#ffffff] to-[#ffffff] rounded-2xl border border-zinc-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Total Tasks</span>
        <Activity className="w-5 h-5 text-orange-600" />
      </div>
      <p className="text-4xl font-semibold text-zinc-900">{metrics.totalTasks.toLocaleString()}</p>
      <p className="text-xs text-orange-400 mt-2 font-medium">
        {metrics.pendingTasks} pending
      </p>
    </div>

    {/* Assigned Today Card */}
    <div className="bg-gradient-to-br from-[#f8f5ff] via-[#ffffff] to-[#ffffff] rounded-2xl border border-zinc-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Assigned Today</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none">
          <path d="M12 12C14.21 12 16 10.21 16 8C16 5.79 14.21 4 12 4C9.79 4 8 5.79 8 8C8 10.21 9.79 12 12 12Z" stroke="#4f46e5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M4.3 19.5C5.35 16.54 8.42 14.5 12 14.5C15.58 14.5 18.65 16.54 19.7 19.5" stroke="#4f46e5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z" stroke="#4f46e5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </div>
      <p className="text-4xl font-semibold text-zinc-900">
        {metrics.assignedPendingToday.toLocaleString()}
      </p>
      <p className="text-xs text-indigo-400 mt-2 font-medium">
        {metrics.assignedPendingToday > 0 ? 'Assigned to agents' : 'No new assignments'}
      </p>
    </div>

    {/* InProgress Today Card */}
    <div className="bg-gradient-to-br from-[#fff6fc] via-[#ffffff] to-[#ffffff] rounded-2xl border border-zinc-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">InProgress Today</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none">
          <g clipPath="url(#clip0_4418_10076)">
            <path d="M16.5 9.5L12.3 13.7L10.7 11.3L7.5 14.5" stroke="#bd17b4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M14.5 9.5H16.5V11.5" stroke="#bd17b4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z" stroke="#bd17b4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          </g>
          <defs>
            <clipPath id="clip0_4418_10076">
              <rect width="24" height="24" fill="white"/>
            </clipPath>
          </defs>
        </svg>
      </div>
      <p className="text-4xl font-semibold text-zinc-900">{metrics.inProgressTasks.toLocaleString()}</p>
      <p className="text-xs text-purple-400 mt-2 font-medium">
        Avg speed: {metrics.todayPerformance.averageSpeed.toFixed(1)}
      </p>
    </div>

    {/* Completed Today Card */}
    <div className="bg-gradient-to-br from-[#f5fffb] via-[#ffffff] to-[#ffffff] rounded-2xl border border-zinc-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Completed Today</span>
        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
      </div>
      <p className="text-4xl font-semibold text-zinc-900">{metrics.completedToday.toLocaleString()}</p>
      <p className="text-xs text-emerald-400 mt-2 font-medium">
        Avg speed: {metrics.todayPerformance.averageSpeed.toFixed(1)}
      </p>
    </div>

    {/* Cancelled Tasks Card */}
    <div className="bg-gradient-to-br from-[#fff5f5] via-[#ffffff] to-[#ffffff] rounded-2xl border border-zinc-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Cancelled Tasks</span>
        <AlertTriangle className="w-5 h-5 text-red-600" />
      </div>
      <p className="text-4xl font-semibold text-zinc-900">{metrics.blockedTasks.toLocaleString()}</p>
      <p className="text-xs text-red-400 mt-2 font-medium">
        Requires attention
      </p>
    </div>

    {/* Active Users Card */}
    <div className="bg-gradient-to-br from-[#f5f8ff] via-[#ffffff] to-[#ffffff] rounded-2xl border border-zinc-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Active Users</span>
        <Users className="w-5 h-5 text-blue-600" />
      </div>
      <p className="text-4xl font-semibold text-zinc-900">{presence ? presence.summary.online : metrics.activeUsers}</p>
      <p className="text-xs text-blue-400 mt-2 font-medium">
        {presence
          ? `${presence.summary.idle} idle · ${presence.summary.onBreak} on break`
          : `${metrics.idleUsers} idle`}
      </p>
    </div>

    {/* Reworks Pending Card */}
    <div className="bg-gradient-to-br from-[#fffff5] via-[#ffffff] to-[#ffffff] rounded-2xl border border-zinc-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Reworks Pending</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none">
          <path d="M13.67 7.50977C13.17 7.35977 12.62 7.25977 12 7.25977C9.24 7.25977 7 9.49977 7 12.2598C7 15.0198 9.24 17.2598 12 17.2598C14.76 17.2598 17 15.0198 17 12.2598C17 11.2298 16.69 10.2798 16.16 9.47977" stroke="#c7b704" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M14.38 7.65024L12.72 5.74023" stroke="oklch(90.5% 0.182 98.111)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M14.38 7.65039L12.44 9.07039" stroke="oklch(90.5% 0.182 98.111)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M2 14V15C2 20 4 22 9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9" stroke="#c7b704" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </div>
      <p className="text-4xl font-semibold text-zinc-900">{metrics.reworkPendingTasks.toLocaleString()}</p>
      <p className="text-xs text-yellow-300 mt-2 font-medium">
        {metrics.reworkPendingTasks > 0 ? 'Needs attention' : 'No pending reworks'}
  </p>
</div>

  </div>
)}

{/* Process Metrics */}
{metrics && metrics.processMetrics.length > 0 && (
  <div className="bg-white rounded-2xl shadow-sm border border-zinc-100 overflow-hidden">
    <div className="p-6 border-b border-zinc-100">
      <h2 className="text-xl font-black text-zinc-900">Process Metrics</h2>
    </div>
    <div className="overflow-x-auto">
      <table className="w-full text-left">
        <thead>
          <tr className="border-b border-zinc-100">
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Process</th>
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Total</th>
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Pending</th>
            {/* Added Header Column */}
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Assigned Today</th>
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">InProgress</th>
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Completed Today</th>
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Cancelled</th>
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Assigned Users</th>
            <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Reworks Pending</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-zinc-50">
          {metrics.processMetrics.map((pm) => (
            <tr key={pm.processId} className="hover:bg-zinc-50/50 group transition-colors">
              <td
                className="px-6 py-4 font-semibold text-sm text-zinc-900 cursor-pointer hover:underline"
                onClick={() => handleProcessClick(pm.processId, pm.processName)}
              >
                <span className="inline-block max-w-xs overflow-hidden text-ellipsis whitespace-nowrap bg-blue-50 text-blue-600 group-hover:bg-blue-100 px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest mr-2">
                  {pm.processName}
                </span>
              </td>
              <td className="px-6 py-4 text-right text-sm font-bold text-zinc-600">{pm.totalTasks}</td>
              <td className="px-6 py-4 text-right text-sm font-bold text-zinc-600">{pm.pendingTasks}</td>
              {/* Added Data Value Row Cell styled with matching Indigo accents */}
              <td className="px-6 py-4 text-right text-sm font-bold text-indigo-600">{pm.assignedPendingToday}</td>
              <td className="px-6 py-4 text-right text-sm font-bold text-zinc-600">{pm.inProgressTasks}</td>
              <td className="px-6 py-4 text-right text-sm font-bold text-emerald-600">{pm.completedToday}</td>
              <td className="px-6 py-4 text-right text-sm font-bold text-red-600">{pm.blockedTasks}</td>
              <td className="px-6 py-4 text-right text-sm font-bold text-blue-600">
                {pm.assignedUsersCount ?? 0}
              </td>
              <td className="px-6 py-4 text-right text-sm font-bold text-yellow-400">{pm.reworkPendingTasks}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
)}


        {/* User Activity */}
        {presence && (
          <div className="bg-white rounded-2xl shadow-sm border border-zinc-100 overflow-hidden">
            <div className="p-6 border-b border-zinc-100">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-black text-zinc-900">User Activity</h2>
                  <p className="text-xs text-zinc-400 mt-1">
                    Live · refreshes every 30s · Idle after {presence.thresholds.idleAfterMinutes}m without input in the Tasks app
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-sm">
                  {([
                    ['All', 'All', 'text-zinc-700', presence.users.length],
                    ['Online', 'Online', 'text-emerald-600', presence.summary.online],
                    ['Idle', 'Idle', 'text-amber-600', presence.summary.idle],
                    ['OnBreak', 'On Break', 'text-sky-600', presence.summary.onBreak],
                    ['Offline', 'Offline', 'text-zinc-600', presence.summary.offline],
                  ] as const).map(([key, label, color, count]) => (
                    <button
                      key={key}
                      onClick={() => setPresenceStatusFilter(key)}
                      className={cn(
                        'px-2.5 py-1 rounded-lg font-bold transition-colors',
                        presenceStatusFilter === key ? 'bg-zinc-100' : 'hover:bg-zinc-50',
                      )}
                    >
                      <span className="text-zinc-400">{label}: </span>
                      <span className={color}>{count}</span>
                    </button>
                  ))}
                  <select
                    value={presenceProcessId ?? ''}
                    onChange={(e) => setPresenceProcessId(e.target.value ? Number(e.target.value) : null)}
                    className="px-3 py-1.5 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg outline-none"
                  >
                    <option value="">All my processes</option>
                    {(metrics?.processMetrics ?? []).map((pm) => (
                      <option key={pm.processId} value={pm.processId}>
                        {pm.processName}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={loadPresence}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 hover:bg-zinc-50"
                    title="Refresh now"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-zinc-100">
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">User</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Status</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Working On</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Session</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Completed Today</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Active Tasks</th>
                    <th className="px-6 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Tasks / Hr</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-50">
                  {presence.users
                    .filter((u) => presenceStatusFilter === 'All' || u.status === presenceStatusFilter)
                    .map((u) => {
                      const style = STATUS_STYLE[u.status] ?? STATUS_STYLE.Offline;
                      const sessionStart = parseUtc(u.sessionStartUtc);
                      const lastSeen = parseUtc(u.lastSeenUtc);
                      return (
                        <tr key={u.userId} className="hover:bg-zinc-50/50 transition-colors">
                          <td className="px-6 py-4 font-bold text-zinc-900">{u.username}</td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <span className={cn('px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest', style.className)}>
                                {style.label}
                              </span>
                              {u.status === 'OnBreak' && (
                                <span className={cn('flex items-center gap-1 text-xs font-medium', u.breakExceeded ? 'text-red-600' : 'text-zinc-500')}>
                                  <Coffee className="w-3.5 h-3.5" />
                                  {u.breakReason} · {formatMinutes(u.breakMinutes)}
                                  {u.breakAllowedMinutes ? ` / ${formatMinutes(u.breakAllowedMinutes)}` : ''}
                                  {u.breakExceeded && ' · exceeded'}
                                </span>
                              )}
                              {u.status === 'Idle' && (
                                <span className="text-xs font-medium text-amber-600">{formatMinutes(u.idleMinutes)}</span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-zinc-600">{u.processName ?? '-'}</td>
                          <td className="px-6 py-4 text-xs text-zinc-500">
                            {u.status === 'Offline'
                              ? lastSeen ? `Last seen ${lastSeen.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}` : 'Not seen yet'
                              : `Since ${formatTime(sessionStart)}`}
                          </td>
                          <td className="px-6 py-4 text-right font-bold text-emerald-600">{u.completedToday}</td>
                          <td className="px-6 py-4 text-right font-bold text-zinc-600">{u.activeTasks}</td>
                          <td className="px-6 py-4 text-right font-bold text-zinc-600">
                            {u.tasksPerHour != null ? u.tasksPerHour.toFixed(1) : '-'}
                          </td>
                        </tr>
                      );
                    })}
                  {presence.users.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-6 py-10 text-center text-sm text-zinc-400">
                        No users in your processes.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

      {/* Half-Canvas for User Metrics */}
{selectedProcessId && (
  <div className="fixed inset-0 z-50 flex">
    {/* Overlay */}
    <div
      className="fixed inset-0 bg-black/30 z-1"
      onClick={() => setSelectedProcessId(null)}
    />

    {/* Panel */}
    <div className="ml-auto w-3/4 max-h-[calc(100vh-20px)] bg-white rounded-2xl shadow-sm border border-zinc-100 overflow-hidden m-2 flex flex-col z-2">
      <div className="flex items-center justify-between p-6 border-b border-zinc-100 bg-zinc-50/50">
        <div className="flex flex-col gap-1">
          {selectedProcessName && (
            <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-zinc-900 leading-none">
            User Metrics  
          </h2>
            <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-md text-[11px] font-bold border border-blue-200">
              {selectedProcessName}
            </span>
              {/* <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">
                Process:
              </span> */}
             
            </div>
          )}
        </div>
        <button
          onClick={() => setSelectedProcessId(null)}
          className="p-2 hover:bg-zinc-200/50 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-zinc-500" />
        </button>
      </div>


      {metricsLoading ? (
        <div className="flex items-center justify-center h-full">
          <div className="w-8 h-8 border-4 border-zinc-100 border-t-blue-600 rounded-full animate-spin" />
        </div>
      ) : userMetrics && userMetrics.length > 0 ? (
        <div className="overflow-x-auto max-h-[calc(100vh-20px)] overflow-y-auto scrollbar-thin [scrollbar-width:thin]">
<table className="w-full text-left border border-zinc-100 rounded-lg">
  <thead>
    <tr className="bg-zinc-50 border-b border-zinc-100">
      <th className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest">User</th>
      <th className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest text-right">Pending</th>
      {/* Added Header Column */}
      <th className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest text-right">Assigned Today</th>
      <th className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest text-right">InProgress</th>
      <th className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest text-right">Completed</th>
      <th className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest text-right">Cancelled</th>
      <th className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest text-right">Reworks</th>
      {uniqueTargetColumns.map(col => (
        <th
          key={col}
          className="px-4 py-2 text-[10px] font-semibold text-zinc-400 uppercase tracking-widest text-right"
        >
          {col}
        </th>
      ))}
    </tr>
  </thead>
  <tbody className="divide-y divide-zinc-100">
    {userMetrics.map((u) => (
      <tr key={u.userId} className="hover:bg-zinc-50 transition-colors">
        <td className="px-4 py-2 font-semibold text-sm text-zinc-900">{u.username}</td>
        <td className="px-4 py-2 text-right text-sm text-zinc-600">{u.pending}</td>
        {/* Added Data Value Row Cell styled with matching Indigo accents */}
        <td className="px-4 py-2 text-right text-sm font-bold text-indigo-600">{u.assignedPendingToday}</td>
        <td className="px-4 py-2 text-right text-sm text-amber-600">{u.inProgress}</td>
        <td className="px-4 py-2 text-right text-sm text-emerald-600">{u.completed}</td>
        <td className="px-4 py-2 text-right text-sm text-red-600">{u.cancelled}</td>
        <td className="px-4 py-2 text-right text-sm text-red-600">{u.pendingReworks}</td>
        {uniqueTargetColumns.map((col) => {
          const getStatusColor = (columnName: string) => {
            const name = columnName.toLowerCase();
            if (name.includes('out of target')) return 'text-red-600';
            if (name.includes('in warning')) return 'text-amber-500';
            if (name.includes('in target')) return 'text-emerald-600';
            return 'text-blue-600';
          };

          return (
            <td
              key={col}
              className={`px-4 py-2 text-right text-sm font-semibold ${getStatusColor(col)}`}
            >
              {u.targetIndicators?.[col] ?? 0}
            </td>
          );
        })}
      </tr>
    ))}
  </tbody>
</table>
        </div>
      ) : (
        <p className="text-center text-zinc-500 mt-10">No tasks found for this process.</p>
      )}
    </div>
  </div>
)}
      </div>
    </div>
  );
}
