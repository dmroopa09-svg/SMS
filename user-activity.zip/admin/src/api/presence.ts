import { apiClient } from "./client";

// get is protected on BaseApiService; call it directly (TypeScript-only restriction).
const client = apiClient as unknown as {
  get<T>(url: string): Promise<T>;
};

/** apiClient's base URL already ends in /api. */
const BASE = "/presence";

export type PresenceStatus = "Online" | "Idle" | "OnBreak" | "Offline";

export interface TeamPresenceUser {
  userId: number;
  username: string;
  status: PresenceStatus;
  processId: number | null;
  processName: string | null;
  idleMinutes: number | null;
  breakReason: string | null;
  breakMinutes: number | null;
  breakAllowedMinutes: number | null;
  breakExceeded: boolean;
  sessionStartUtc: string | null;
  lastSeenUtc: string | null;
  completedToday: number;
  activeTasks: number;
  tasksPerHour: number | null;
}

export interface TeamPresence {
  users: TeamPresenceUser[];
  summary: { online: number; idle: number; onBreak: number; offline: number };
  thresholds: { idleAfterMinutes: number; offlineAfterSeconds: number };
  generatedUtc: string;
}

export const presenceApi = {
  team: (processId?: number | null) =>
    client.get<TeamPresence>(`${BASE}/team${processId ? `?processId=${processId}` : ""}`),
};

/** Server sends UTC without a zone marker; treat it as UTC. */
export function parseUtc(value: string | null | undefined): Date | null {
  if (!value) return null;
  const d = new Date(/[zZ]|[+-]\d{2}:\d{2}$/.test(value) ? value : `${value}Z`);
  return isNaN(d.getTime()) ? null : d;
}

export function formatMinutes(min: number | null | undefined): string {
  if (min == null) return "";
  if (min < 60) return `${min}m`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
}
