/*
  UserPresence - one live row per user, written by the agent app's heartbeat (every 60s).

  All times are UTC and come from SQL Server (SYSUTCDATETIME), never from the browser, so
  India-time PCs and the Central-time server can't disagree. "Idle" is measured from the
  agent's last mouse/keyboard input in the Tasks app, sent as "seconds ago" and converted
  here - the PC's clock is never trusted.
*/
IF OBJECT_ID('dbo.UserPresence', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.UserPresence
    (
        UserId            INT        NOT NULL CONSTRAINT PK_UserPresence PRIMARY KEY,
        ProcessId         INT        NULL,                  -- process selected in the agent app
        SessionStartUtc   DATETIME2  NOT NULL,              -- first heartbeat of this sitting
        LastHeartbeatUtc  DATETIME2  NOT NULL,
        LastInputUtc      DATETIME2  NOT NULL,              -- last mouse/keyboard in the Tasks app
        IsTabVisible      BIT        NOT NULL CONSTRAINT DF_UserPresence_Visible DEFAULT (1),
        SignedOutUtc      DATETIME2  NULL                   -- set on sign-out, cleared by the next heartbeat
    );

    CREATE INDEX IX_UserPresence_Heartbeat ON dbo.UserPresence (LastHeartbeatUtc) INCLUDE (ProcessId);
END
GO

/*
  OPTIONAL CLEAN-UP - review before running.
  Open breaks older than 16 hours are leftovers (e.g. "Auto-started due to inactivity" rows from May
  that were never ended). The dashboard already ignores them, but closing them keeps reports honest.

  SELECT Id, UserId, ProcessId, ReasonId, StartTime, Comment
  FROM dbo.UserBreakLogs
  WHERE EndTime IS NULL AND StartTime < DATEADD(HOUR, -16, GETDATE());

  -- UPDATE dbo.UserBreakLogs
  -- SET EndTime = StartTime, DurationMs = 0, Status = 'abandoned'
  -- WHERE EndTime IS NULL AND StartTime < DATEADD(HOUR, -16, GETDATE());
*/
