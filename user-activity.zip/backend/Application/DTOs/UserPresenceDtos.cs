namespace GTXH.OMC.Application.DTOs;

public static class PresenceStatuses
{
    public const string Online = "Online";
    public const string Idle = "Idle";
    public const string OnBreak = "OnBreak";
    public const string Offline = "Offline";
}

/// <summary>Sent by the agent app every 60 seconds.</summary>
public class PresenceHeartbeatRequest
{
    /// <summary>Process selected in the agent app (null on screens without one).</summary>
    public int? ProcessId { get; set; }

    /// <summary>Seconds since the last mouse/keyboard input in the Tasks app. Converted on the server - the PC clock is never used.</summary>
    public int IdleSeconds { get; set; }

    public bool IsTabVisible { get; set; } = true;
}

/// <summary>Idle/Offline limits used for one process.</summary>
public class PresenceThresholdsDto
{
    public int IdleAfterMinutes { get; set; }
    public int OfflineAfterSeconds { get; set; }
}

public class TeamPresenceUserDto
{
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;

    /// <summary>Online | Idle | OnBreak | Offline</summary>
    public string Status { get; set; } = PresenceStatuses.Offline;

    public int? ProcessId { get; set; }
    public string? ProcessName { get; set; }

    /// <summary>Minutes since last input (Idle) - null otherwise.</summary>
    public int? IdleMinutes { get; set; }

    // On break
    public string? BreakReason { get; set; }
    public int? BreakMinutes { get; set; }
    public int? BreakAllowedMinutes { get; set; }
    public bool BreakExceeded { get; set; }

    public DateTime? SessionStartUtc { get; set; }
    public DateTime? LastSeenUtc { get; set; }

    public int CompletedToday { get; set; }
    public int ActiveTasks { get; set; }

    /// <summary>Tasks completed per hour of today's session.</summary>
    public decimal? TasksPerHour { get; set; }
}

public class TeamPresenceSummaryDto
{
    public int Online { get; set; }
    public int Idle { get; set; }
    public int OnBreak { get; set; }
    public int Offline { get; set; }
}

public class TeamPresenceDto
{
    public List<TeamPresenceUserDto> Users { get; set; } = new();
    public TeamPresenceSummaryDto Summary { get; set; } = new();
    public PresenceThresholdsDto Thresholds { get; set; } = new();
    public DateTime GeneratedUtc { get; set; }
}
