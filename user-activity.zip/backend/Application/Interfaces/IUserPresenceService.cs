using GTXH.OMC.Application.DTOs;

namespace GTXH.OMC.Application.Interfaces;

public interface IUserPresenceService
{
    /// <summary>Agent app heartbeat. userId always comes from the token.</summary>
    Task HeartbeatAsync(int userId, PresenceHeartbeatRequest request, CancellationToken ct = default);

    /// <summary>Marks the user Offline straight away (sign-out) instead of waiting for heartbeats to stop.</summary>
    Task SignOutAsync(int userId, CancellationToken ct = default);

    /// <summary>
    /// Live status of everyone in the viewer's processes.
    /// restrictToAssignedProcesses = manager/supervisor: only processes in their UserProcessPermissions.
    /// </summary>
    Task<TeamPresenceDto> GetTeamAsync(int viewerUserId, bool restrictToAssignedProcesses, int? processId, CancellationToken ct = default);
}

/// <summary>
/// Where the Idle / Offline limits come from. Today: defaults. Next step: ProcessReasonPolicy -
/// only this implementation changes, nothing that calls it.
/// </summary>
public interface IPresenceThresholdProvider
{
    Task<PresenceThresholdsDto> GetAsync(int? processId, CancellationToken ct = default);
}
