using System.Security.Claims;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GTXH.OMC.API.Controllers;

/// <summary>
///   POST api/presence/heartbeat     agent app, every 60s     { processId, idleSeconds, isTabVisible }
///   POST api/presence/signout       agent app, on sign-out
///   GET  api/presence/team?processId=20   admin dashboard (scoped by UserProcessPermissions)
/// The user is always taken from the token, never from the request body.
/// </summary>
[ApiController]
[Route("api/presence")]
[Authorize(AuthenticationSchemes = "Bearer")]
public class UserPresenceController : ControllerBase
{
    private readonly IUserPresenceService _service;
    private readonly ILogger<UserPresenceController> _logger;

    public UserPresenceController(IUserPresenceService service, ILogger<UserPresenceController> logger)
    {
        _service = service;
        _logger = logger;
    }

    [HttpPost("heartbeat")]
    public async Task<IActionResult> Heartbeat([FromBody] PresenceHeartbeatRequest request, CancellationToken ct)
    {
        if (!TryGetUserId(out var userId)) return Unauthorized();
        try
        {
            await _service.HeartbeatAsync(userId, request ?? new PresenceHeartbeatRequest(), ct);
            return NoContent();
        }
        catch (Exception ex)
        {
            // Never noisy for the agent - a missed heartbeat just means the next one counts.
            _logger.LogWarning(ex, "Heartbeat failed for user {UserId}", userId);
            return StatusCode(500, Error("SERVER_ERROR", "Heartbeat failed"));
        }
    }

    [HttpPost("signout")]
    public async Task<IActionResult> SignOutPresence(CancellationToken ct)
    {
        if (!TryGetUserId(out var userId)) return Unauthorized();
        try
        {
            await _service.SignOutAsync(userId, ct);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Presence sign-out failed for user {UserId}", userId);
            return NoContent(); // sign-out must never be blocked by this
        }
    }

    [HttpGet("team")]
    public async Task<ActionResult<TeamPresenceDto>> Team([FromQuery] int? processId, CancellationToken ct)
    {
        if (!TryGetUserId(out var userId)) return Unauthorized();
        try
        {
            return Ok(await _service.GetTeamAsync(userId, IsManagerOrSupervisor(), processId, ct));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting team presence");
            return StatusCode(500, Error("SERVER_ERROR", "An error occurred while retrieving user activity"));
        }
    }

    // ------------------------------------------------------------------------------------

    private static object Error(string code, string message) => new { error = new { code, message } };

    private bool TryGetUserId(out int userId)
    {
        var claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return int.TryParse(claim, out userId);
    }

    /// <summary>Same rule as DashboardController: RoleId 2 = Manager, 6 = Supervisor.</summary>
    private bool IsManagerOrSupervisor()
    {
        var roleClaim = User.FindFirst(ClaimTypes.Role)?.Value ?? User.FindFirst("roleId")?.Value;
        return int.TryParse(roleClaim, out var roleId) && (roleId == 2 || roleId == 6);
    }
}
