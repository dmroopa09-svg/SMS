# Live User Activity: agent app heartbeat and admin dashboard

## 1. SQL
Run `sql/01_UserPresence.sql`. It also contains an optional clean-up (commented out) for old breaks that were never ended. Review those rows before running it.

## 2. Backend (GTXH.OMC)

| File | Goes to |
|---|---|
| `Application/DTOs/UserPresenceDtos.cs` | GTXH.OMC.Application/DTOs |
| `Application/Interfaces/IUserPresenceService.cs` | GTXH.OMC.Application/Interfaces |
| `Application/Services/UserPresenceService.cs` | GTXH.OMC.Application/Services |
| `API/Controllers/UserPresenceController.cs` | GTXH.OMC.API/Controllers |

Add to **Program.cs**:
```csharp
builder.Services.AddScoped<IPresenceThresholdProvider, DefaultPresenceThresholdProvider>();
builder.Services.AddScoped<IUserPresenceService, UserPresenceService>();
```

Endpoints (the user always comes from the token):

| Method | Route | Use |
|---|---|---|
| POST | `api/presence/heartbeat` | Agent app, every 60 seconds |
| POST | `api/presence/signout` | Agent app, on sign-out |
| GET | `api/presence/team?processId=` | Admin dashboard. Managers and supervisors only see users in their processes |

## 3. Agent app (agentCs_frontend)
- `src/services/presenceService.ts` and `src/hooks/usePresenceHeartbeat.ts` are new.
- **App.tsx** needs 3 small edits:

```tsx
// imports
import { usePresenceHeartbeat } from "./hooks/usePresenceHeartbeat";
import { presenceService } from "./services/presenceService";

// right after: useSessionKeepAlive(isAuthenticated, 60_000);
// (lastActivityRef is declared above it, so this order works)
usePresenceHeartbeat(isAuthenticated && !!user, selectedProcess?.id, lastActivityRef);

// handleLogoutConfirm - mark Offline before logging out
const handleLogoutConfirm = async (reason: string) => {
  setIsLogoutModalOpen(false);
  setLogoutInfo({ time: Date.now(), reason });
  addToast(`Signed out: ${reason}`);
  await presenceService.signOut();
  await logout();
};
```

## 4. Admin app
- `src/api/presence.ts` is new.
- Replace `Dashboard.tsx` (the dashboard page) with this one.

## How a status is decided (server side, same for every viewer)

| Status | Rule |
|---|---|
| Offline | No heartbeat for 3+ minutes, or the agent signed out, or no heartbeat ever |
| On Break | An open break in `UserBreakLogs` from the last 16 hours. Shows the reason, minutes, the allowed limit, and "exceeded" in red |
| Idle | No mouse or keyboard input **in the Tasks app** for 5+ minutes |
| Online | Everything else |

**Thresholds:** they live in `DefaultPresenceThresholdProvider`, as 5 minutes Idle and 3 minutes Offline. The next step swaps that one class for one that reads `ProcessReasonPolicy`; nothing else changes.

**Clocks:** heartbeat times use SQL's UTC clock. Break times and Completed Today use the app server's clock, the same one that writes those columns. The agent PC's clock is never trusted.
