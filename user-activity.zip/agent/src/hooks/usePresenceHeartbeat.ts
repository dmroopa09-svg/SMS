import { useEffect, useRef, type MutableRefObject } from "react";
import { presenceService } from "../services/presenceService";

/**
 * Tells the server every 60s that this agent is here, which process they're on, and how long
 * since their last mouse/keyboard input in this app (read from the same ref the inactivity
 * timer uses - no new listeners, no re-renders).
 *
 * Also sends one straight away on: sign-in, process switch, and returning to the tab - so the
 * supervisor's dashboard flips back to Online within seconds instead of a minute.
 */
export function usePresenceHeartbeat(
  enabled: boolean,
  processId: number | undefined,
  lastActivityRef: MutableRefObject<number>,
  intervalMs = 60_000,
) {
  const processRef = useRef(processId);
  processRef.current = processId;

  useEffect(() => {
    if (!enabled) return;

    let inFlight = false;
    const beat = () => {
      if (inFlight) return;
      inFlight = true;
      presenceService
        .heartbeat({
          processId: processRef.current || undefined,
          idleSeconds: Math.max(0, Math.floor((Date.now() - lastActivityRef.current) / 1000)),
          isTabVisible: document.visibilityState === "visible",
        })
        .catch(() => {
          /* a missed beat is fine - the next one counts */
        })
        .finally(() => {
          inFlight = false;
        });
    };

    beat();
    const id = window.setInterval(beat, intervalMs);

    const onVisible = () => {
      if (document.visibilityState === "visible") beat();
    };
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [enabled, intervalMs, lastActivityRef]);

  // Process switched: report it now rather than at the next tick.
  useEffect(() => {
    if (!enabled || !processId) return;
    presenceService
      .heartbeat({
        processId,
        idleSeconds: Math.max(0, Math.floor((Date.now() - lastActivityRef.current) / 1000)),
        isTabVisible: document.visibilityState === "visible",
      })
      .catch(() => {});
  }, [enabled, processId, lastActivityRef]);
}
