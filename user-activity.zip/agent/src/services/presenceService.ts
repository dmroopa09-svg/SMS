import { apiClient } from "./api";

/** Agent app endpoints include /api (API_BASE_URL ends in /Backend). */
const BASE = "/api/presence";

export const presenceService = {
  heartbeat: (body: { processId?: number; idleSeconds: number; isTabVisible: boolean }) =>
    apiClient.post<void>(`${BASE}/heartbeat`, body),

  /** Marks the agent Offline immediately. Never blocks sign-out. */
  signOut: () => apiClient.post<void>(`${BASE}/signout`, {}).catch(() => {}),
};
