PHASE 1 — CAMPAIGN SERVICE
==========================

Turns a campaign into queue rows. Everything downstream consumes what this
produces, so nothing else can be tested until it works.


WHAT IS HERE
------------
    _SQL/Phase1/P1_01_Generation.sql   staging table, resumable merge, run summary
    Sms.Core/Campaign/IAccountSource.cs the seam for the EOS and RM logic
    Sms.Core/Campaign/MessageBuilder.cs merge fields and segment counting

Account selection itself is NOT here. It exists already in Santosh's code, is
non-trivial, and reaches across systems. IAccountSource is the interface an
implementation wraps it behind — the existing procedures should be called, not
reimplemented.


GENERATION IS RESUMABLE, AND THAT IS THE POINT
----------------------------------------------
Bulk-copy into staging, then merge into SMS_Queue_Detail skipping any
idempotency key already present.

If generation dies at 300,000 of 500,000, re-running inserts only the missing
200,000. Nothing is duplicated because the keys match; nothing is lost because
the NOT EXISTS finds what is already there.

This is what the run-scoped idempotency key from Phase 0 buys. Without it a
failed generation leaves an arbitrary subset written with no way to tell which,
and the only safe response is to delete the run and start again.

Two levels of deduplication, because duplicates arise two ways:

    ROW_NUMBER   the same key twice within one batch — account selection
                 returning a person under two records
    NOT EXISTS   the key already in the table — a re-run

Without the first, the insert fails on its own duplicates before it reaches the
table.


GENERATION DOES NOT START THE RUN
---------------------------------
Rows are created at Init and the run is left Pending. Nothing claims them until
an operator presses start.

Deliberate: it gives a chance to look at the count and the exclusions before any
message goes out. A criteria mistake that selects 2 million instead of 200,000
is recoverable at this point and not recoverable ten minutes later.


THE SEGMENT BUDGET IS 78 CHARACTERS, NOT 160
--------------------------------------------
The Webex Connect flow appends opt-out and help text after our message — roughly
82 characters in the current configuration:

    Reply "STOP" to Stop getting these messages
    Reply "HELP" to Go to a contact agent

This is invisible from our side. The arithmetic, verified against GSM-7 rules:

    template  70 chars  ->  152 billed  ->  1 segment
    template  78 chars  ->  160 billed  ->  1 segment     <-- the real ceiling
    template  79 chars  ->  161 billed  ->  2 segments
    template 140 chars  ->  222 billed  ->  2 segments

So a template that looks comfortable at 140 characters costs double. On a run of
half a million that is half a million extra segments, charged, with nothing in
our data showing why.

Worse, a realistic message:

    "Hi, JOHN SMITH, Your MERCY HEALTH medical bill is ready. View at
     mychart.org/abc"                          80 chars -> 2 segments

    same message with one curly apostrophe     82 chars -> 3 segments

One character — visually near-identical to a straight quote, and the kind Word
inserts automatically — triples the cost by forcing the whole message to UCS-2,
where the limit drops from 160 to 70.

WHAT TO DO ABOUT IT
  - show the remaining budget while a template is being written, counting the
    appended characters
  - warn when a non-GSM character appears, naming it
  - confirm the exact appended text against the flow; 82 is measured from a
    screenshot, not from the configuration


MESSAGE BUILDING FAILS CLOSED
-----------------------------
A template needing {{guarantor}} with no value produces a failure, not
"Hi, , Your medical bill is ready".

The recipient of a half-built message cannot tell it was a bug. It damages trust
in every message that follows, and in a collections context it invites a
complaint about the message rather than a payment.

Merge fields are double-braced, matching the existing templates.


WHAT STILL NEEDS WRITING
------------------------
1. An IAccountSource implementation for EOS and one for RM, wrapping Santosh's
   procedures. This is the main piece of Phase 1 work.

2. The generation orchestrator: stream accounts, build messages, bulk-copy to
   staging, call the merge, finalise. The shape is settled; it is mechanical
   once IAccountSource exists.

3. Whatever supplies merge values. Account selection has to return them
   alongside the account, since building the message needs guarantor name,
   provider name and link per recipient.


TWO THINGS STILL UNANSWERED FROM PHASE 0
----------------------------------------
Both block finishing Phase 1 rather than starting it.

1. WHICH DATABASE the queue lives in. Affects the connection used for bulk copy
   and whether the merge crosses a database boundary. Cheaper to decide now than
   after four services are wired.

2. KAFKA AS SIGNAL OR QUEUE. The campaign service publishes the first message,
   so this has to be settled before that line is written. The architecture
   document argues for signal — it is the only shape giving a genuine
   mid-campaign stop.


BEFORE ASKING SANTOSH
---------------------
Worth knowing what to ask for, so one conversation covers it:

  - the procedures for EOS and RM account selection, and their parameters
  - whether they return merge values (guarantor name, provider, link) or only
    account identifiers
  - whether both patient and guarantor phone, state and zip come back, since the
    time zone fallback needs both
  - roughly how long they take on a large campaign, which decides whether
    generation can be synchronous or has to report progress
