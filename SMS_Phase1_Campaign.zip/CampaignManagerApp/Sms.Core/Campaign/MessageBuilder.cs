using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Sms.Core.Campaign
{
    public sealed class BuiltMessage
    {
        public string Text { get; init; } = "";
        public int SegmentCount { get; init; }
        public bool IsUnicode { get; init; }

        /// <summary>The character that forced UCS-2, if any. Named so it can be fixed.</summary>
        public char? UnicodeCulprit { get; init; }
    }

    public sealed class MessageBuildFailure
    {
        public string Reason { get; init; } = "";
        public IReadOnlyList<string> MissingFields { get; init; } = Array.Empty<string>();
    }

    /// <summary>
    /// Turns a template plus an account's values into the message that will be sent.
    ///
    /// FAILS CLOSED. A template needing {{guarantor}} with no guarantor value
    /// produces a failure, not "Hi, , your bill is ready". The recipient of a
    /// half-built message cannot tell it was a bug, and it damages trust in
    /// every message that follows.
    /// </summary>
    public static class MessageBuilder
    {
        /// <summary>
        /// Double braces, matching the existing templates:
        ///     Hi, {{guarantor}}, Your {{provider}} medical bill is ready...
        /// </summary>
        private static readonly Regex MergeField =
            new(@"\{\{([A-Za-z0-9_]+)\}\}", RegexOptions.Compiled);

        public static bool TryBuild(
            string templateBody,
            IReadOnlyDictionary<string, string> values,
            SegmentBudget budget,
            out BuiltMessage message,
            out MessageBuildFailure? failure)
        {
            message = default!;
            failure = null;

            if (string.IsNullOrWhiteSpace(templateBody))
            {
                failure = new MessageBuildFailure { Reason = "Template body is empty." };
                return false;
            }

            var required = MergeField.Matches(templateBody)
                .Select(m => m.Groups[1].Value)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            var missing = required
                .Where(f => !values.TryGetValue(f, out var v) || string.IsNullOrWhiteSpace(v))
                .ToList();

            if (missing.Count > 0)
            {
                failure = new MessageBuildFailure
                {
                    Reason = $"Missing merge value(s): {string.Join(", ", missing)}",
                    MissingFields = missing
                };
                return false;
            }

            var text = MergeField.Replace(templateBody, m =>
            {
                var field = m.Groups[1].Value;
                return values.TryGetValue(field, out var v) ? v : m.Value;
            });

            var seg = SegmentCalculator.Calculate(text, budget);

            message = new BuiltMessage
            {
                Text = text,
                SegmentCount = seg.SegmentCount,
                IsUnicode = seg.IsUnicode,
                UnicodeCulprit = seg.Culprit
            };

            return true;
        }

        /// <summary>Field names a template requires, for validating it at design time.</summary>
        public static IReadOnlyList<string> RequiredFields(string templateBody)
            => string.IsNullOrWhiteSpace(templateBody)
                ? Array.Empty<string>()
                : MergeField.Matches(templateBody)
                    .Select(m => m.Groups[1].Value)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();
    }

    /// <summary>
    /// How many characters the provider adds that we never see.
    ///
    /// The Webex Connect flow appends opt-out and help instructions after our
    /// message body — roughly eighty characters in the current configuration:
    ///
    ///     Reply "STOP" to Stop getting these messages
    ///     Reply "HELP" to Go to a contact agent
    ///
    /// This is invisible from our side. A template that looks like a comfortable
    /// 140 characters goes out at 220, which is two segments, charged
    /// separately. On a run of half a million that doubles the cost, silently,
    /// and nothing in our data would show it.
    ///
    /// Configured rather than hardcoded because it is flow configuration and can
    /// differ per client flow. Confirm the exact text before setting it.
    /// </summary>
    public sealed class SegmentBudget
    {
        public int ProviderAppendedCharacters { get; init; }

        /// <summary>Assumes nothing is appended. Only correct if the flow has been checked.</summary>
        public static SegmentBudget None => new() { ProviderAppendedCharacters = 0 };

        /// <summary>
        /// The current Connect flow, measured from the received message. Verify
        /// against the flow rather than trusting this figure — it is an estimate
        /// from a screenshot, not a measurement.
        /// </summary>
        public static SegmentBudget WebexDefault => new() { ProviderAppendedCharacters = 82 };
    }

    public sealed class SegmentResult
    {
        public int SegmentCount { get; init; }
        public bool IsUnicode { get; init; }
        public int BilledCharacters { get; init; }
        public char? Culprit { get; init; }
    }

    /// <summary>
    /// Works out how many segments a message costs, including provider-appended text.
    ///
    /// Carriers bill per segment. GSM-7 gives 160 characters in one segment and
    /// 153 per part once split; anything outside that character set forces UCS-2
    /// at 70 and 67.
    ///
    /// The most common way a message unexpectedly costs double is a curly
    /// quotation mark pasted from Word. A single one drops the limit from 160 to
    /// 70, and it is visually almost identical to a straight quote.
    /// </summary>
    public static class SegmentCalculator
    {
        private const string GsmBasic =
            "@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞ ÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?" +
            "¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà";

        /// <summary>These cost two GSM-7 characters each, not one.</summary>
        private const string GsmExtended = "^{}\\[~]|€";

        public static SegmentResult Calculate(string text, SegmentBudget budget)
        {
            text ??= "";

            var units = 0;
            char? culprit = null;

            foreach (var ch in text)
            {
                if (GsmBasic.IndexOf(ch) >= 0) units += 1;
                else if (GsmExtended.IndexOf(ch) >= 0) units += 2;
                else { culprit = ch; break; }
            }

            if (culprit == null)
            {
                var total = units + budget.ProviderAppendedCharacters;
                var segments = total <= 160 ? 1 : (int)Math.Ceiling(total / 153.0);

                return new SegmentResult
                {
                    SegmentCount = Math.Max(segments, 1),
                    IsUnicode = false,
                    BilledCharacters = total
                };
            }

            // UCS-2 counts UTF-16 code units, so an emoji is two.
            var ucsTotal = text.Length + budget.ProviderAppendedCharacters;
            var ucsSegments = ucsTotal <= 70 ? 1 : (int)Math.Ceiling(ucsTotal / 67.0);

            return new SegmentResult
            {
                SegmentCount = Math.Max(ucsSegments, 1),
                IsUnicode = true,
                BilledCharacters = ucsTotal,
                Culprit = culprit
            };
        }

        /// <summary>
        /// Characters left for template text before a second segment is charged.
        ///
        /// Show this when a template is being written. With the current flow
        /// appending ~82 characters, the real single-segment budget is about 78
        /// — not 160, which is what someone counting by eye will assume.
        /// </summary>
        public static int SingleSegmentBudget(SegmentBudget budget, bool unicode = false)
            => Math.Max(0, (unicode ? 70 : 160) - budget.ProviderAppendedCharacters);
    }
}
