using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Sms.Core.Campaign
{
    /// <summary>One account selected for a campaign, with everything needed to build its message.</summary>
    public sealed class AccountRecord
    {
        public long AccountId { get; init; }
        public long? AccountInfoId { get; init; }
        public int? SystemId { get; init; }

        // ---- Guarantor contact ----
        public string? Mobile { get; init; }
        public string? StateCode { get; init; }
        public string? ZipCode { get; init; }

        // ---- Patient contact ----
        // Held separately because the time zone fallback chain depends on whose
        // number is being texted. Guarantor phone falls back to patient zip and
        // the reverse — so both are needed even when only one is being used.
        public string? PatientMobile { get; init; }
        public string? PatientStateCode { get; init; }
        public string? PatientZipCode { get; init; }

        /// <summary>
        /// Values for the template's merge fields, keyed by field name without
        /// braces — "guarantor", "provider", "link".
        ///
        /// Whatever supplies these must supply ALL of them. A missing value is
        /// treated as a failure rather than an empty string, because sending
        /// "Hi, , Your medical bill is ready" is worse than not sending.
        /// </summary>
        public Dictionary<string, string> MergeValues { get; init; } = new();
    }

    /// <summary>Which system a campaign draws its accounts from.</summary>
    public enum AccountSourceSystem
    {
        Eos = 1,
        Rm = 2
    }

    /// <summary>
    /// Supplies the accounts for a campaign.
    ///
    /// THIS IS THE SEAM FOR THE EXISTING EOS AND RM SELECTION LOGIC. That logic
    /// already exists, is non-trivial, and reaches across systems — it should be
    /// wrapped, not rewritten. An implementation of this interface is expected to
    /// call the existing stored procedures rather than reimplement their rules.
    ///
    /// STREAMS RATHER THAN RETURNS A LIST. Half a million AccountRecords in
    /// memory at once is avoidable, and avoiding it is the difference between a
    /// service that runs in 200MB and one that runs in several gigabytes. The
    /// caller writes each chunk to staging and moves on.
    /// </summary>
    public interface IAccountSource
    {
        AccountSourceSystem System { get; }

        /// <summary>
        /// Yields accounts in chunks. Each chunk is written to staging before the
        /// next is read, so memory stays flat regardless of run size.
        /// </summary>
        IAsyncEnumerable<IReadOnlyList<AccountRecord>> StreamAccountsAsync(
            int campaignMstrId,
            int chunkSize,
            CancellationToken ct = default);

        /// <summary>
        /// How many accounts the criteria select, without fetching them.
        ///
        /// Used to show a count before generation runs, so an operator sees
        /// "this will create 480,000 messages" and can stop if that is wrong.
        /// Returns null where counting is as expensive as fetching.
        /// </summary>
        Task<int?> CountAsync(int campaignMstrId, CancellationToken ct = default);
    }
}
