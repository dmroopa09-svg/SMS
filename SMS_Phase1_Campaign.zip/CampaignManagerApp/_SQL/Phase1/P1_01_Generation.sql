/* ============================================================================
   SMS PLATFORM — PHASE 1: QUEUE GENERATION
   ============================================================================

   Generating a run means writing up to half a million rows. Two properties
   matter more than speed:

     RESUMABLE   if generation dies at 300,000 of 500,000, re-running inserts
                 only the missing 200,000 rather than starting again or
                 producing duplicates

     BOUNDED     memory and transaction size stay flat regardless of run size

   Both come from the same mechanism: bulk-copy into a staging table, then merge
   into the real table skipping anything whose idempotency key already exists.

   WHY NOT INSERT ROW BY ROW
   -------------------------
   At 500,000 rows a per-row insert is 500,000 round trips. It also cannot be
   resumed — a failure halfway leaves an arbitrary subset written with no way to
   tell which.

   WHY NOT ONE BULK INSERT STRAIGHT INTO SMS_Queue_Detail
   ------------------------------------------------------
   A duplicate key anywhere fails the whole batch, losing everything. Staging
   lets duplicates be filtered out rather than aborting the operation.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ============================================================================
   1. Staging table

   Deliberately has NO indexes and NO constraints. It exists to receive a bulk
   copy as fast as possible; every index would be maintained during the load for
   no benefit, since the data is read once and discarded.

   SessionId keeps concurrent generations separate. Two campaigns generating at
   the same time share this table, and without it one would consume the other's
   rows.
   ============================================================================ */

IF OBJECT_ID('dbo.SMS_Queue_Detail_Stage', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SMS_Queue_Detail_Stage (
        SessionId        UNIQUEIDENTIFIER NOT NULL,
        SMSQueue_Mst_ID  BIGINT           NOT NULL,
        AccountID        BIGINT           NOT NULL,
        Account_Info_ID  BIGINT           NULL,
        SystemID         INT              NULL,
        Mobile           VARCHAR(20)      NULL,
        StateCode        VARCHAR(2)       NULL,
        ZipCode          VARCHAR(10)      NULL,
        PatMobile        VARCHAR(20)      NULL,
        PatStateCode     VARCHAR(2)       NULL,
        PatZipCode       VARCHAR(10)      NULL,
        MessageText      NVARCHAR(MAX)    NULL,
        IdempotencyKey   CHAR(64)         NOT NULL,
        SegmentCount     INT              NULL
    );

    PRINT 'Created SMS_Queue_Detail_Stage';
END
GO


/* ============================================================================
   2. usp_SMS_MergeStagedRows

   Moves staged rows into SMS_Queue_Detail, skipping any whose idempotency key
   is already present.

   THE NOT EXISTS IS WHAT MAKES GENERATION RESUMABLE. Re-running after a failure
   re-stages everything and inserts only what is missing. Nothing is duplicated
   and nothing is lost.

   Two levels of deduplication, because there are two ways a duplicate arises:

     ROW_NUMBER   the same key appearing twice within this batch, which happens
                  when account selection returns a person twice
     NOT EXISTS   the key already in the table, which happens on a re-run

   Without the first, the insert fails on its own duplicates before reaching the
   table.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_MergeStagedRows', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_MergeStagedRows;
GO

CREATE PROCEDURE dbo.usp_SMS_MergeStagedRows
    @SessionId  UNIQUEIDENTIFIER,
    @QueueMstId BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Now      DATETIME2 = SYSUTCDATETIME();
    DECLARE @Staged   INT;
    DECLARE @Inserted INT;

    SELECT @Staged = COUNT(*)
    FROM   dbo.SMS_Queue_Detail_Stage
    WHERE  SessionId = @SessionId;

    ;WITH Deduped AS (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY IdempotencyKey ORDER BY AccountID) AS rn
        FROM   dbo.SMS_Queue_Detail_Stage
        WHERE  SessionId = @SessionId
    )
    INSERT INTO dbo.SMS_Queue_Detail
        (SMSQueue_Mst_ID, AccountID, Account_Info_ID, SystemID,
         Mobile, StateCode, ZipCode, PatMobile, PatStateCode, PatZipCode,
         MessageText, IdempotencyKey, SMSStatus, AttemptCount, RowUpdatedDt)
    SELECT
        s.SMSQueue_Mst_ID, s.AccountID, s.Account_Info_ID, s.SystemID,
        s.Mobile, s.StateCode, s.ZipCode, s.PatMobile, s.PatStateCode, s.PatZipCode,
        s.MessageText, s.IdempotencyKey,
        0,          -- Init: awaiting compliance
        0,
        @Now
    FROM   Deduped s
    WHERE  s.rn = 1
      AND  NOT EXISTS (
             SELECT 1
             FROM   dbo.SMS_Queue_Detail d
             WHERE  d.IdempotencyKey = s.IdempotencyKey
           );

    SET @Inserted = @@ROWCOUNT;

    DELETE FROM dbo.SMS_Queue_Detail_Stage WHERE SessionId = @SessionId;

    /* Staged minus inserted is not an error — on a re-run it is exactly the
       work already done. Returned so the caller can report it honestly rather
       than appearing to have lost rows. */
    SELECT @Staged   AS StagedRows,
           @Inserted AS InsertedRows,
           @Staged - @Inserted AS SkippedAsDuplicate;
END
GO


/* ============================================================================
   3. usp_SMS_FinaliseRun

   Called when generation completes. Records the true total and moves the run to
   Pending, ready for an operator to start it.

   GENERATION DOES NOT START THE RUN. Rows exist but nothing claims them until
   someone presses start. This is deliberate: it gives a chance to look at what
   was produced — the count, the exclusions — before any message goes out.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_FinaliseRun', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_FinaliseRun;
GO

CREATE PROCEDURE dbo.usp_SMS_FinaliseRun
    @QueueMstId BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Total INT;

    SELECT @Total = COUNT(*)
    FROM   dbo.SMS_Queue_Detail
    WHERE  SMSQueue_Mst_ID = @QueueMstId;

    UPDATE dbo.SMS_Queue_Mst
    SET    RunStatus = 0            -- Pending; an operator starts it
    WHERE  ID = @QueueMstId
      AND  RunStatus = 0;

    SELECT @QueueMstId AS QueueMstId, @Total AS TotalRows;
END
GO


/* ============================================================================
   4. usp_SMS_GetRunSummary

   What the UI shows after generation, and while a run is in progress.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_GetRunSummary', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_GetRunSummary;
GO

CREATE PROCEDURE dbo.usp_SMS_GetRunSummary
    @QueueMstId BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT m.ID, m.Campaign_Mstr_ID, m.RunTime, m.RunStatus,
           m.StoppedBy, m.StoppedUtc, m.StoppedReason
    FROM   dbo.SMS_Queue_Mst m
    WHERE  m.ID = @QueueMstId;

    SELECT s.Status AS StatusName, d.SMSStatus, COUNT(*) AS Rows
    FROM   dbo.SMS_Queue_Detail d
    LEFT   JOIN dbo.SMSStatus s ON s.ID = d.SMSStatus
    WHERE  d.SMSQueue_Mst_ID = @QueueMstId
    GROUP  BY s.Status, d.SMSStatus
    ORDER  BY d.SMSStatus;

    /* Why messages were blocked or deferred, most common first. This is the
       answer to "why did only 40,000 of 50,000 go out?" and without it that
       question needs a developer. */
    SELECT TOP (20) d.ComplianceReason, COUNT(*) AS Rows
    FROM   dbo.SMS_Queue_Detail d
    WHERE  d.SMSQueue_Mst_ID = @QueueMstId
      AND  d.ComplianceReason IS NOT NULL
    GROUP  BY d.ComplianceReason
    ORDER  BY COUNT(*) DESC;
END
GO
