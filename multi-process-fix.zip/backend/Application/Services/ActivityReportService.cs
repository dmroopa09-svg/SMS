using System.Data;
using System.Globalization;
using System.Text.Json;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Core.Enums;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace GTXH.OMC.Application.Services;

/// <summary>
/// Attendance + breaks + breaches + output, per user, for any date range.
///
/// Dates are work dates in each process's time zone (US Central by default). UserBreakLogs and
/// Tasks.CompletedDate are written with the app server's DateTime.Now, so each row is shifted onto
/// its process's clock before it is bucketed into a day - a 7:30 PM IST break lands on the right
/// US work day whatever time zone the server is in.
///
/// "Sign-off for the day" is stored as a break that lasts until the next login; it is left out of
/// every break total (it would add 14+ hours per day) and kept in the Breaks detail sheet.
/// </summary>
public class ActivityReportService : IActivityReportService
{
    private const int MaxRangeDays = 400;
    private const int MaxDetailRows = 200_000;
    private const string SignOffReasonCode = "signoff";

    private readonly ApplicationDbContext _db;
    private readonly IWorkPolicyService _policy;
    private readonly ILogger<ActivityReportService> _logger;

    public ActivityReportService(ApplicationDbContext db, IWorkPolicyService policy, ILogger<ActivityReportService> logger)
    {
        _db = db;
        _policy = policy;
        _logger = logger;
    }

    public async Task<ActivityReportDto> GetReportAsync(int viewerUserId, bool restrictToAssignedProcesses,
        ActivityReportRequest request, CancellationToken ct = default)
    {
        // ---- 0. Range ---------------------------------------------------------------------------
        var from = ParseDate(request.FromDate, "From date");
        var to = ParseDate(request.ToDate, "To date");
        if (to < from) throw new ArgumentException("To date must be on or after From date");
        if ((to - from).TotalDays > MaxRangeDays) throw new ArgumentException($"Pick a range of {MaxRangeDays} days or less");

        var groupBy = (request.GroupBy ?? "day").ToLowerInvariant() switch
        {
            "week" => "week",
            "month" => "month",
            _ => "day",
        };

        var report = new ActivityReportDto
        {
            FromDate = from.ToString("yyyy-MM-dd"),
            ToDate = to.ToString("yyyy-MM-dd"),
            GroupBy = groupBy,
        };

        var userFilter = request.UserIds is { Count: > 0 } ? request.UserIds.ToHashSet() : null;
        var reasonTypeFilter = request.ReasonTypes is { Count: > 0 } ? request.ReasonTypes.ToHashSet() : null;

        await using var conn = new SqlConnection(_db.Database.GetConnectionString());
        await conn.OpenAsync(ct);

        // ---- 1. Processes in scope --------------------------------------------------------------
        var processes = await LoadScopeProcessesAsync(conn, viewerUserId, restrictToAssignedProcesses, request.ProcessIds, ct);
        if (processes.Count == 0) return report;
        var processJson = JsonSerializer.Serialize(processes.Keys);

        // Offset from each process's clock to the app server clock (DateTime.Now - process now).
        var offsets = new Dictionary<int, TimeSpan>();
        foreach (var pid in processes.Keys)
        {
            var settings = await _policy.GetSettingsAsync(pid, ct);
            var tz = WorkPolicyService.ResolveTimeZone(settings.TimeZoneId);
            var procNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tz);
            offsets[pid] = TimeSpan.FromMinutes(Math.Round((DateTime.Now - procNow).TotalMinutes));
        }
        DateTime ToProcessTime(int pid, DateTime serverClock) => serverClock - offsets.GetValueOrDefault(pid);

        // Generous window on the server clock; rows are filtered precisely after shifting.
        var windowFrom = from.AddDays(-2);
        var windowTo = to.AddDays(3);
        bool InRange(DateTime d) => d >= from && d <= to;

        // ---- 2. Users in scope -------------------------------------------------------------------
        var scopeUserIds = await ReadIntsAsync(conn, @"
            SELECT DISTINCT UserId FROM dbo.UserProcessPermissions
            WHERE ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@P))", ct, ("@P", processJson));

        var activeIds = scopeUserIds.Count == 0
            ? new HashSet<int>()
            : (await _db.Users.AsNoTracking()
                    .Where(u => scopeUserIds.Contains(u.UserId) && u.Status == UserStatus.Active)
                    .Select(u => u.UserId)
                    .ToListAsync(ct))
                .ToHashSet();

        var userProcesses = new Dictionary<int, HashSet<int>>();
        void LinkUser(int uid, int pid)
        {
            if (!userProcesses.TryGetValue(uid, out var set)) userProcesses[uid] = set = new HashSet<int>();
            set.Add(pid);
        }
        await using (var cmd = new SqlCommand(@"
            SELECT UserId, ProcessId FROM dbo.UserProcessPermissions
            WHERE ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@P))", conn))
        {
            cmd.Parameters.Add("@P", SqlDbType.NVarChar, -1).Value = processJson;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                var uid = r.GetInt32(0);
                if (activeIds.Contains(uid)) LinkUser(uid, r.GetInt32(1));
            }
        }

        // ---- 3. Attendance ------------------------------------------------------------------------
        var attendance = new List<(int UserId, int ProcessId, DateTime Date, DateTime First, DateTime? Last)>();
        await using (var cmd = new SqlCommand(@"
            SELECT UserId, ProcessId, WorkDate, FirstLoginAt, LastLogoutAt
            FROM dbo.UserDailyAttendance
            WHERE WorkDate >= @From AND WorkDate <= @To
              AND ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@P))", conn))
        {
            cmd.Parameters.Add("@From", SqlDbType.Date).Value = from;
            cmd.Parameters.Add("@To", SqlDbType.Date).Value = to;
            cmd.Parameters.Add("@P", SqlDbType.NVarChar, -1).Value = processJson;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                var row = (r.GetInt32(0), r.GetInt32(1), r.GetDateTime(2).Date, r.GetDateTime(3), r.IsDBNull(4) ? (DateTime?)null : r.GetDateTime(4));
                if (userFilter != null && !userFilter.Contains(row.Item1)) continue;
                attendance.Add(row);
                LinkUser(row.Item1, row.Item2);
            }
        }

        // ---- 4. Breaks ----------------------------------------------------------------------------
        var breaks = new List<BreakRow>();
        await using (var cmd = new SqlCommand(@"
            SELECT b.Id, b.UserId, b.ProcessId, b.ReasonId, r.ReasonCode, r.ReasonLabel, r.ReasonType,
                   b.StartTime, b.EndTime, b.AllowedDurationMin, b.Status, b.Comment
            FROM dbo.UserBreakLogs b
            LEFT JOIN dbo.ReasonMaster r ON r.ReasonId = b.ReasonId
            WHERE b.StartTime >= @WinFrom AND b.StartTime < @WinTo
              AND b.ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@P))", conn) { CommandTimeout = 120 })
        {
            cmd.Parameters.Add("@WinFrom", SqlDbType.DateTime2).Value = windowFrom;
            cmd.Parameters.Add("@WinTo", SqlDbType.DateTime2).Value = windowTo;
            cmd.Parameters.Add("@P", SqlDbType.NVarChar, -1).Value = processJson;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                var pid = r.GetInt32(2);
                var start = ToProcessTime(pid, r.GetDateTime(7));
                if (!InRange(start.Date)) continue;
                var uid = r.GetInt32(1);
                if (userFilter != null && !userFilter.Contains(uid)) continue;

                var reasonType = r.IsDBNull(6) ? 0 : Convert.ToInt32(r.GetValue(6));
                if (reasonTypeFilter != null && !reasonTypeFilter.Contains(reasonType)) continue;

                DateTime? end = r.IsDBNull(8) ? null : ToProcessTime(pid, r.GetDateTime(8));
                var allowed = r.IsDBNull(9) ? (int?)null : Convert.ToInt32(r.GetValue(9));
                int? minutes = end.HasValue ? (int)Math.Max(0, Math.Round((end.Value - start).TotalMinutes)) : null;
                var code = r.IsDBNull(4) ? string.Empty : Convert.ToString(r.GetValue(4)) ?? string.Empty;

                breaks.Add(new BreakRow
                {
                    Id = r.GetInt32(0),
                    UserId = uid,
                    ProcessId = pid,
                    ReasonId = r.IsDBNull(3) ? 0 : r.GetInt32(3),
                    ReasonLabel = r.IsDBNull(5) ? "Unknown" : Convert.ToString(r.GetValue(5)) ?? "Unknown",
                    ReasonType = reasonType,
                    IsSignOff = code.Equals(SignOffReasonCode, StringComparison.OrdinalIgnoreCase),
                    Start = start,
                    End = end,
                    Minutes = minutes,
                    Allowed = allowed,
                    OverLimit = allowed is > 0 && minutes > allowed,
                    Status = r.IsDBNull(10) ? null : Convert.ToString(r.GetValue(10)),
                    Comment = r.IsDBNull(11) ? null : Convert.ToString(r.GetValue(11)),
                });
                LinkUser(uid, pid);
            }
        }

        // ---- 5. Breaches --------------------------------------------------------------------------
        var breaches = new List<BreachRow>();
        await using (var cmd = new SqlCommand(@"
            SELECT b.BreachId, b.UserId, b.ProcessId, b.WorkDate, b.BreachType, rm.ReasonLabel, b.Details,
                   b.ExceededMinutes, b.Status, b.AgentComment, du.Username, b.DecisionComment
            FROM dbo.PolicyBreaches b
            LEFT JOIN dbo.ReasonMaster rm ON rm.ReasonId = b.ReasonId
            LEFT JOIN dbo.Users du        ON du.UserId = b.DecidedByUserId
            WHERE b.WorkDate >= @From AND b.WorkDate <= @To
              AND b.ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@P))", conn))
        {
            cmd.Parameters.Add("@From", SqlDbType.Date).Value = from;
            cmd.Parameters.Add("@To", SqlDbType.Date).Value = to;
            cmd.Parameters.Add("@P", SqlDbType.NVarChar, -1).Value = processJson;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                var uid = r.GetInt32(1);
                if (userFilter != null && !userFilter.Contains(uid)) continue;
                breaches.Add(new BreachRow
                {
                    Id = Convert.ToInt64(r.GetValue(0)),
                    UserId = uid,
                    ProcessId = r.GetInt32(2),
                    Date = r.GetDateTime(3).Date,
                    Type = Convert.ToString(r.GetValue(4)) ?? string.Empty,
                    Reason = r.IsDBNull(5) ? null : Convert.ToString(r.GetValue(5)),
                    Details = r.IsDBNull(6) ? null : Convert.ToString(r.GetValue(6)),
                    Exceeded = r.IsDBNull(7) ? null : Convert.ToInt32(r.GetValue(7)),
                    Status = Convert.ToString(r.GetValue(8)) ?? string.Empty,
                    AgentComment = r.IsDBNull(9) ? null : Convert.ToString(r.GetValue(9)),
                    DecidedBy = r.IsDBNull(10) ? null : Convert.ToString(r.GetValue(10)),
                    DecisionComment = r.IsDBNull(11) ? null : Convert.ToString(r.GetValue(11)),
                });
                LinkUser(uid, r.GetInt32(2));
            }
        }

        // ---- 6. Tasks completed per user per work day --------------------------------------------
        var tasks = new Dictionary<(int UserId, DateTime Date), int>();
        var offsetJson = JsonSerializer.Serialize(offsets.Select(o => new { p = o.Key, o = (int)o.Value.TotalMinutes }));
        await using (var cmd = new SqlCommand(@"
            SELECT t.AssignedUserId, CAST(DATEADD(MINUTE, -o.OffsetMin, t.CompletedDate) AS DATE) AS D, COUNT(*)
            FROM dbo.Tasks t
            JOIN OPENJSON(@Offsets) WITH (ProcessId INT '$.p', OffsetMin INT '$.o') o ON o.ProcessId = t.ProcessId
            WHERE t.Status = 'Completed'
              AND t.AssignedUserId IS NOT NULL
              AND t.CompletedDate >= @WinFrom AND t.CompletedDate < @WinTo
            GROUP BY t.AssignedUserId, CAST(DATEADD(MINUTE, -o.OffsetMin, t.CompletedDate) AS DATE)", conn) { CommandTimeout = 120 })
        {
            cmd.Parameters.Add("@Offsets", SqlDbType.NVarChar, -1).Value = offsetJson;
            cmd.Parameters.Add("@WinFrom", SqlDbType.DateTime2).Value = windowFrom;
            cmd.Parameters.Add("@WinTo", SqlDbType.DateTime2).Value = windowTo;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                var uid = r.GetInt32(0);
                var d = r.GetDateTime(1).Date;
                if (!InRange(d)) continue;
                if (userFilter != null && !userFilter.Contains(uid)) continue;
                tasks[(uid, d)] = tasks.GetValueOrDefault((uid, d)) + r.GetInt32(2);
            }
        }

        // ---- 7. Names -----------------------------------------------------------------------------
        // People who worked in these processes during the range count too, even if they were only
        // lent to the process for a while and are no longer assigned (or are now inactive).
        foreach (var a in attendance) LinkUser(a.UserId, a.ProcessId);
        foreach (var b in breaks) LinkUser(b.UserId, b.ProcessId);
        foreach (var x in breaches) LinkUser(x.UserId, x.ProcessId);

        var allUserIds = userProcesses.Keys
            .Concat(tasks.Keys.Select(k => k.UserId))
            .Where(uid => userFilter == null || userFilter.Contains(uid))
            .ToHashSet();
        var names = await LoadUserNamesAsync(conn, allUserIds, ct);

        // ---- 8. Daily rows ------------------------------------------------------------------------
        var daily = new Dictionary<(int UserId, DateTime Date), DailyAcc>();
        DailyAcc Day(int uid, DateTime d)
        {
            if (!daily.TryGetValue((uid, d), out var acc)) daily[(uid, d)] = acc = new DailyAcc();
            return acc;
        }

        foreach (var a in attendance)
        {
            var acc = Day(a.UserId, a.Date);
            if (acc.First == null || a.First < acc.First) acc.First = a.First;
            if (a.Last.HasValue && (acc.Last == null || a.Last > acc.Last)) acc.Last = a.Last;
        }
        foreach (var b in breaks.Where(b => !b.IsSignOff))
        {
            var acc = Day(b.UserId, b.Start.Date);
            if (b.ReasonType == 2)
            {
                acc.InactivityEvents++;
                acc.InactivityMinutes += b.Minutes ?? 0;
            }
            else
            {
                acc.Breaks++;
                acc.BreakMinutes += b.Minutes ?? 0;
                if (b.OverLimit) acc.OverLimit++;
            }
        }
        foreach (var x in breaches)
        {
            var acc = Day(x.UserId, x.Date);
            acc.Breaches++;
            if (x.Type == BreachTypes.LateLogin) { acc.Late = true; acc.LateMinutes += x.Exceeded ?? 0; }
            if (x.Type == BreachTypes.EarlyLogout) acc.Early = true;
        }
        foreach (var t in tasks) Day(t.Key.UserId, t.Key.Date).Tasks += t.Value;

        foreach (var ((uid, d), acc) in daily.OrderBy(k => k.Key.Date).ThenBy(k => names.GetValueOrDefault(k.Key.UserId)))
        {
            report.Daily.Add(new UserDailyRowDto
            {
                UserId = uid,
                Username = names.GetValueOrDefault(uid) ?? $"User {uid}",
                WorkDate = d.ToString("yyyy-MM-dd"),
                FirstLogin = acc.First?.ToString("HH:mm"),
                LastLogout = acc.Last?.ToString("HH:mm"),
                Hours = acc.Hours,
                LateLogin = acc.Late,
                EarlyLogout = acc.Early,
                Breaks = acc.Breaks,
                BreakMinutes = acc.BreakMinutes,
                OverLimitBreaks = acc.OverLimit,
                InactivityMinutes = acc.InactivityMinutes,
                Breaches = acc.Breaches,
                TasksCompleted = acc.Tasks,
            });
        }

        // ---- 9. Per-user summary ------------------------------------------------------------------
        // Lookups once, so a year x hundreds of users stays linear.
        var dailyByUser = daily.ToLookup(k => k.Key.UserId, k => k.Value);
        var breaksByUser = breaks.Where(b => !b.IsSignOff).ToLookup(b => b.UserId);
        var breachesByUser = breaches.ToLookup(b => b.UserId);

        foreach (var uid in allUserIds.OrderBy(id => names.GetValueOrDefault(id)))
        {
            var days = dailyByUser[uid].ToList();
            var present = days.Where(dd => dd.IsPresent).ToList();
            var userBreaks = breaksByUser[uid].ToList();
            var userBreaches = breachesByUser[uid].ToList();
            var hourDays = present.Where(dd => dd.Hours.HasValue).ToList();
            var completed = days.Sum(dd => dd.Tasks);

            var row = new UserActivitySummaryRowDto
            {
                UserId = uid,
                Username = names.GetValueOrDefault(uid) ?? $"User {uid}",
                Processes = string.Join(", ", (userProcesses.GetValueOrDefault(uid) ?? new HashSet<int>())
                    .Select(pid => processes.GetValueOrDefault(pid) ?? pid.ToString()).OrderBy(n => n)),
                DaysPresent = present.Count,
                AvgFirstLogin = AvgTime(present.Where(dd => dd.First.HasValue).Select(dd => dd.First!.Value.TimeOfDay)),
                AvgLastLogout = AvgTime(present.Where(dd => dd.Last.HasValue).Select(dd => dd.Last!.Value.TimeOfDay)),
                AvgHoursPerDay = hourDays.Count > 0 ? Math.Round(hourDays.Average(dd => dd.Hours!.Value), 1) : null,
                LateLogins = days.Count(dd => dd.Late),
                LateMinutes = days.Sum(dd => dd.LateMinutes),
                EarlyLogouts = days.Count(dd => dd.Early),
                Breaks = days.Sum(dd => dd.Breaks),
                BreakMinutes = days.Sum(dd => dd.BreakMinutes),
                OverLimitBreaks = days.Sum(dd => dd.OverLimit),
                InactivityEvents = days.Sum(dd => dd.InactivityEvents),
                InactivityMinutes = days.Sum(dd => dd.InactivityMinutes),
                Breaches = userBreaches.Count,
                PendingBreaches = userBreaches.Count(b => b.Status == BreachStatuses.Pending),
                ApprovedBreaches = userBreaches.Count(b => b.Status == BreachStatuses.Approved || b.Status == BreachStatuses.AutoApproved),
                RejectedBreaches = userBreaches.Count(b => b.Status == BreachStatuses.Rejected),
                TasksCompleted = completed,
                TasksPerDay = present.Count > 0 ? Math.Round((decimal)completed / present.Count, 1) : null,
            };
            var nonInactivity = userBreaks.Where(b => b.ReasonType != 2 && b.Minutes.HasValue).ToList();
            row.AvgBreakMinutes = nonInactivity.Count > 0 ? Math.Round((decimal)nonInactivity.Average(b => b.Minutes!.Value), 1) : null;

            foreach (var g in userBreaks.GroupBy(b => b.ReasonId))
                row.ByReason[g.Key] = new ReasonStatDto { Count = g.Count(), Minutes = g.Sum(b => b.Minutes ?? 0) };

            report.Users.Add(row);
        }

        report.Reasons = breaks.Where(b => !b.IsSignOff)
            .GroupBy(b => b.ReasonId)
            .Select(g => new ReasonColumnDto { ReasonId = g.Key, Label = g.First().ReasonLabel, ReasonType = g.First().ReasonType })
            .OrderBy(r => r.ReasonType).ThenBy(r => r.Label)
            .ToList();

        // ---- 10. Trend ----------------------------------------------------------------------------
        DateTime Bucket(DateTime d) => groupBy switch
        {
            "week" => d.AddDays(-(((int)d.DayOfWeek + 6) % 7)), // Monday
            "month" => new DateTime(d.Year, d.Month, 1),
            _ => d,
        };
        string Label(DateTime b) => groupBy switch
        {
            "week" => $"Wk of {b:MMM d}",
            "month" => b.ToString("MMM yyyy", CultureInfo.InvariantCulture),
            _ => b.ToString("MMM d", CultureInfo.InvariantCulture),
        };

        var buckets = new SortedDictionary<DateTime, ActivityTrendPointDto>();
        for (var d = Bucket(from); d <= to; d = groupBy == "month" ? d.AddMonths(1) : d.AddDays(groupBy == "week" ? 7 : 1))
            buckets[d] = new ActivityTrendPointDto
            {
                Period = groupBy == "month" ? d.ToString("yyyy-MM") : d.ToString("yyyy-MM-dd"),
                Label = Label(d),
            };

        var presentPerBucket = new Dictionary<DateTime, HashSet<int>>();
        foreach (var ((uid, d), acc) in daily)
        {
            if (!buckets.TryGetValue(Bucket(d), out var p)) continue;
            p.Breaks += acc.Breaks;
            p.BreakMinutes += acc.BreakMinutes;
            p.Breaches += acc.Breaches;
            p.LateLogins += acc.Late ? 1 : 0;
            p.TasksCompleted += acc.Tasks;
            if (acc.IsPresent)
            {
                if (!presentPerBucket.TryGetValue(Bucket(d), out var set)) presentPerBucket[Bucket(d)] = set = new HashSet<int>();
                set.Add(uid);
            }
        }
        foreach (var (b, set) in presentPerBucket) buckets[b].UsersPresent = set.Count;
        report.Trend = buckets.Values.ToList();

        // ---- 11. KPIs -----------------------------------------------------------------------------
        var presentDays = daily.Values.Where(dd => dd.IsPresent).ToList();
        report.Kpis = new ActivityKpisDto
        {
            UsersInScope = report.Users.Count,
            UsersPresent = daily.Where(k => k.Value.IsPresent).Select(k => k.Key.UserId).Distinct().Count(),
            PersonDays = presentDays.Count,
            AvgFirstLogin = AvgTime(presentDays.Where(dd => dd.First.HasValue).Select(dd => dd.First!.Value.TimeOfDay)),
            LateLogins = daily.Values.Count(dd => dd.Late),
            EarlyLogouts = daily.Values.Count(dd => dd.Early),
            Breaks = daily.Values.Sum(dd => dd.Breaks),
            BreakMinutes = daily.Values.Sum(dd => dd.BreakMinutes),
            OverLimitBreaks = daily.Values.Sum(dd => dd.OverLimit),
            InactivityEvents = daily.Values.Sum(dd => dd.InactivityEvents),
            InactivityMinutes = daily.Values.Sum(dd => dd.InactivityMinutes),
            Breaches = breaches.Count,
            PendingBreaches = breaches.Count(b => b.Status == BreachStatuses.Pending),
            TasksCompleted = daily.Values.Sum(dd => dd.Tasks),
        };

        // ---- 12. Details (export) -----------------------------------------------------------------
        if (request.IncludeDetails)
        {
            report.Breaks = breaks
                .OrderBy(b => b.Start)
                .Take(MaxDetailRows)
                .Select(b => new BreakDetailRowDto
                {
                    BreakLogId = b.Id,
                    UserId = b.UserId,
                    Username = names.GetValueOrDefault(b.UserId) ?? $"User {b.UserId}",
                    ProcessName = processes.GetValueOrDefault(b.ProcessId),
                    Reason = b.IsSignOff ? $"{b.ReasonLabel} (not counted)" : b.ReasonLabel,
                    ReasonTypeName = b.ReasonType switch { 1 => "Break", 2 => "Inactivity", 3 => "Delay", _ => "Other" },
                    Start = b.Start.ToString("yyyy-MM-dd HH:mm"),
                    End = b.End?.ToString("yyyy-MM-dd HH:mm"),
                    Minutes = b.Minutes,
                    AllowedMinutes = b.Allowed,
                    OverLimit = b.OverLimit,
                    Status = b.Status,
                    Comment = b.Comment,
                })
                .ToList();

            report.Breaches = breaches
                .OrderBy(b => b.Date).ThenBy(b => names.GetValueOrDefault(b.UserId))
                .Take(MaxDetailRows)
                .Select(b => new BreachDetailRowDto
                {
                    BreachId = b.Id,
                    UserId = b.UserId,
                    Username = names.GetValueOrDefault(b.UserId) ?? $"User {b.UserId}",
                    ProcessName = processes.GetValueOrDefault(b.ProcessId),
                    WorkDate = b.Date.ToString("yyyy-MM-dd"),
                    BreachType = b.Type,
                    Reason = b.Reason,
                    Details = b.Details,
                    ExceededMinutes = b.Exceeded,
                    Status = b.Status,
                    AgentComment = b.AgentComment,
                    DecidedBy = b.DecidedBy,
                    DecisionComment = b.DecisionComment,
                })
                .ToList();

            report.Truncated = breaks.Count > MaxDetailRows || breaches.Count > MaxDetailRows;
        }

        return report;
    }

    // =========================================================================================

    private static async Task<Dictionary<int, string>> LoadScopeProcessesAsync(SqlConnection conn, int viewerUserId,
        bool restricted, List<int>? requested, CancellationToken ct)
    {
        var requestedJson = requested is { Count: > 0 } ? JsonSerializer.Serialize(requested) : null;

        await using var cmd = new SqlCommand(@"
            SELECT p.ProcessId, p.ProcessName
            FROM dbo.Processes p
            WHERE (@Restrict = 0 OR p.ProcessId IN (SELECT ProcessId FROM dbo.UserProcessPermissions WHERE UserId = @Viewer))
              AND (@Requested IS NULL OR p.ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@Requested)))", conn);
        cmd.Parameters.Add("@Restrict", SqlDbType.Bit).Value = restricted;
        cmd.Parameters.Add("@Viewer", SqlDbType.Int).Value = viewerUserId;
        cmd.Parameters.Add("@Requested", SqlDbType.NVarChar, -1).Value = (object?)requestedJson ?? DBNull.Value;

        var map = new Dictionary<int, string>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct))
            map[r.GetInt32(0)] = r.IsDBNull(1) ? $"Process {r.GetInt32(0)}" : r.GetString(1);
        return map;
    }

    private static async Task<Dictionary<int, string>> LoadUserNamesAsync(SqlConnection conn, IEnumerable<int> ids, CancellationToken ct)
    {
        var map = new Dictionary<int, string>();
        var list = ids.ToList();
        if (list.Count == 0) return map;

        await using var cmd = new SqlCommand(@"
            SELECT UserId, Username FROM dbo.Users
            WHERE UserId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@Ids))", conn);
        cmd.Parameters.Add("@Ids", SqlDbType.NVarChar, -1).Value = JsonSerializer.Serialize(list);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct))
            map[r.GetInt32(0)] = r.IsDBNull(1) ? $"User {r.GetInt32(0)}" : r.GetString(1);
        return map;
    }

    private static async Task<List<int>> ReadIntsAsync(SqlConnection conn, string sql, CancellationToken ct,
        params (string Name, string Value)[] parameters)
    {
        await using var cmd = new SqlCommand(sql, conn);
        foreach (var (name, value) in parameters)
            cmd.Parameters.Add(name, SqlDbType.NVarChar, -1).Value = value;
        var list = new List<int>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(r.GetInt32(0));
        return list;
    }

    private static DateTime ParseDate(string? value, string label) =>
        DateTime.TryParseExact(value, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d)
            ? d.Date
            : throw new ArgumentException($"{label} is required (yyyy-MM-dd)");

    private static string? AvgTime(IEnumerable<TimeSpan> times)
    {
        var list = times.ToList();
        if (list.Count == 0) return null;
        var avg = TimeSpan.FromMinutes(Math.Round(list.Average(t => t.TotalMinutes)));
        return $"{(int)avg.TotalHours:00}:{avg.Minutes:00}";
    }

    private sealed class BreakRow
    {
        public int Id, UserId, ProcessId, ReasonId, ReasonType;
        public string ReasonLabel = string.Empty;
        public bool IsSignOff, OverLimit;
        public DateTime Start;
        public DateTime? End;
        public int? Minutes, Allowed;
        public string? Status, Comment;
    }

    private sealed class BreachRow
    {
        public long Id;
        public int UserId, ProcessId;
        public DateTime Date;
        public string Type = string.Empty, Status = string.Empty;
        public string? Reason, Details, AgentComment, DecidedBy, DecisionComment;
        public int? Exceeded;
    }

    private sealed class DailyAcc
    {
        public DateTime? First, Last;
        public bool Late, Early;
        public int LateMinutes, Breaks, BreakMinutes, OverLimit, InactivityEvents, InactivityMinutes, Breaches, Tasks;

        public bool IsPresent => First.HasValue || Breaks > 0 || InactivityEvents > 0 || Tasks > 0;

        public decimal? Hours =>
            First.HasValue && Last.HasValue && Last > First
                ? Math.Round((decimal)(Last.Value - First.Value).TotalHours, 1)
                : null;
    }
}
