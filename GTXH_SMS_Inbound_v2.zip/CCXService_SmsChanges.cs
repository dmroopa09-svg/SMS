// =============================================================================
// CCXService — SMS CHANGES
//
// ContactCenterAPI/Services/CCXService.cs
//
// Confirmed from the data: SMS arrives as channelType = "social".
// 92 rows were already in CCX_CallLog. None were posted to Artiva.
//
// Three changes:
//   1. Route social tasks away from the call path
//   2. Write them to CCX_SMSLog instead
//   3. Artiva post written and ready, behind a config flag
// =============================================================================


// -----------------------------------------------------------------------------
// 1. ADD THESE FIELDS
// -----------------------------------------------------------------------------

private readonly ICCX_SMSLog_Service _ccx_smsLog_Service;
private readonly HashSet<string> _smsChannelTypes;
private readonly bool _postSmsToArtiva;


// -----------------------------------------------------------------------------
// 2. ADD TO THE CONSTRUCTOR
//    (after the existing service resolutions and after _config is set)
// -----------------------------------------------------------------------------

/*
    _ccx_smsLog_Service = scope.ServiceProvider.GetRequiredService<ICCX_SMSLog_Service>();

    // Confirmed as "social" from the data. Kept in config rather than
    // hardcoded so a second channel can be added without a rebuild.
    _smsChannelTypes = new HashSet<string>(
        _config.GetSection("Webex:SmsChannelTypes").Get<string[]>() ?? new[] { "social" },
        StringComparer.OrdinalIgnoreCase);

    // OFF until the SMS endpoint on the Artiva side is confirmed. With it off,
    // rows are still captured and wrapup codes still resolved — only the post
    // is skipped. Turning it on is one setting.
    _postSmsToArtiva = _config.GetValue("Webex:PostSmsToArtiva", false);
*/


private bool IsSmsTask(string? channelType)
    => !string.IsNullOrWhiteSpace(channelType)
       && _smsChannelTypes.Contains(channelType);


// -----------------------------------------------------------------------------
// 3. SPLIT THE LIST IN ProcessTasks_V2
//
//    Insert immediately after:
//        List<Tasks> distinctTask = tasks.DistinctBy(task => task.id).ToList();
//
//    One choke point, so it covers BOTH routes — the Kafka subscription and
//    EodProces. Filtering in the GraphQL would only cover EodProces and the
//    subscription would keep feeding social tasks into the call path.
// -----------------------------------------------------------------------------

/*
    var smsTasks  = distinctTask.Where(t => IsSmsTask(t.channelType)).ToList();
    var callTasks = distinctTask.Where(t => !IsSmsTask(t.channelType)).ToList();

    if (smsTasks.Count > 0)
    {
        _appLogger.Log(LogLevel.Information, 0, "", null,
            (state, ex) => $"Routing {smsTasks.Count} SMS task(s) to CCX_SMSLog");

        await ProcessSmsTasks(smsTasks);
    }

    if (callTasks.Count == 0)
        return;

    distinctTask = callTasks;   // everything below now sees calls only
*/


// -----------------------------------------------------------------------------
// 4. THE SMS PATH
//
//    Mirrors ProcessTasks_V2 where the behaviour should match, and drops what
//    only applies to voice.
// -----------------------------------------------------------------------------

public async Task ProcessSmsTasks(List<Tasks> smsTasks)
{
    if (smsTasks == null || smsTasks.Count == 0)
        return;

    try
    {
        // Same mapping the call path uses. Point 4 says follow the same wrapup
        // rules, so this is the same dictionary rather than a second copy that
        // could drift.
        Dictionary<string, string> call_TermCodes =
            await _oDS_CallService.GetAllCall_TermCode();

        // Accounts, where the task carries one. Confirmed from the data that
        // most SMS tasks do not — the AccountID global is not set on the SMS
        // flow. Those are captured and simply not posted, exactly as the call
        // path does when AccountID is 0.
        var distinctAccountIds = smsTasks
            .SelectMany(t => long.TryParse(t.accountId?.value, out var id) && id > 0
                             ? new[] { id } : Array.Empty<long>())
            .Distinct()
            .ToList();

        Dictionary<long?, AccountInfo> accInfoForTasks = new();

        if (distinctAccountIds.Count > 0)
        {
            List<AccountInfo> accInfos =
                await _accInfo_Service.GetAccountInfoByIds(distinctAccountIds, true);

            accInfoForTasks = accInfos
                .Where(c => c.ID != null)
                .ToDictionary(c => c.ID, c => c);
        }

        foreach (var item in smsTasks)
        {
            try
            {
                if (item == null || string.IsNullOrEmpty(item.id))
                    continue;

                var smsLog = BuildSmsLog(item);

                // Point 4 — translate the wrapup code exactly as calls do.
                string artivaWrapupCode = string.Empty;
                if (!string.IsNullOrEmpty(smsLog.LastWrapupCodeName)
                    && call_TermCodes.TryGetValue(smsLog.LastWrapupCodeName, out var mapped))
                {
                    artivaWrapupCode = mapped.Trim();
                }

                // Direction on SMS is "inbound" or "outdial" — NOT "outbound".
                // Confirmed from the data. Anything comparing to "outbound"
                // would silently never match.
                bool isInbound = "inbound".Equals(smsLog.Direction, StringComparison.OrdinalIgnoreCase);

                if (!CanProcessSms(smsLog, isInbound))
                {
                    // Not finished yet, or waiting on a wrapup code. Same
                    // reasoning as canProcess on the call side — posting now
                    // would send an outcome that has not been decided.
                    smsLog.SMSLogStatus = (byte)callLogStatusEnum.Wait;
                    smsLog.RowUpdateDT = DateTime.Now;
                    await _ccx_smsLog_Service.UpsertSmsLog(smsLog);
                    continue;
                }

                // AccountID missing is normal for SMS today. Capture the row,
                // skip the post. Identical to the call path, which wraps its
                // whole Artiva block in if (csllLog.AccountID > 0).
                if (smsLog.AccountID > 0
                    && accInfoForTasks.TryGetValue(Convert.ToInt64(smsLog.AccountID), out var accInfo)
                    && accInfo != null)
                {
                    // ⚠ The account id Artiva wants depends on SystemID, and is
                    // NOT the DBID_LeadAccount form used when sending TO Webex.
                    // Different destination, different rule. Copied from the
                    // call path so the two cannot drift.
                    int systemId = Convert.ToInt32(accInfo.SystemID);
                    string accountid = systemId == 1
                        ? Convert.ToString(accInfo.AccountID)     // RM
                        : accInfo.SelfPayID ?? "";

                    string phonenum = (isInbound ? smsLog.Origin : smsLog.Destination)
                                      ?.Replace("+1", "")?.Replace("-", "") ?? "";

                    string notes = (isInbound ? "SMS received from: " : "SMS sent to: ")
                                   + phonenum + ";";

                    if (!string.IsNullOrEmpty(smsLog.LastAgentName))
                        notes += " Last Agent:" + smsLog.LastAgentName + ";";

                    if (!string.IsNullOrEmpty(artivaWrapupCode))
                        notes += " Wrapup Code:" + artivaWrapupCode + ";";

                    string agent = smsLog.LastAgentName;
                    if (string.IsNullOrEmpty(agent))
                        agent = smsLog.AgentName;
                    if (string.IsNullOrEmpty(agent))
                        agent = "smsapi";

                    // ⚠ TermCode has no SMS equivalent yet.
                    //
                    // On calls it comes from cpaStatus — LIVE_VOICE, ABANDONED,
                    // MEDIA_MANAGER_INTERNAL_ERROR — which says whether the call
                    // connected. A text has no such state, and cpaStatus is NULL
                    // on every SMS row.
                    //
                    // Left blank rather than borrowing a voice code: sending
                    // SUCCESS would tell Artiva a call connected.
                    string termCode = "";

                    RM_CallData rmData = new RM_CallData()
                    {
                        AcctId        = accountid,
                        TermCode      = termCode,
                        OUTCOME       = artivaWrapupCode ?? "",
                        PhoneNumber   = phonenum,
                        Direction     = smsLog.Direction ?? "",
                        Agent         = agent,
                        CallStartDate = smsLog.CreatedTime?.ToString("MM/dd/yyyy"),
                        CallStartTime = smsLog.CreatedTime?.ToString("HH:mm:ss"),
                        CallEndDate   = smsLog.EndedTime?.ToString("MM/dd/yyyy"),
                        CallEndTime   = smsLog.EndedTime?.ToString("HH:mm:ss"),
                        CiscoCallId   = smsLog.InteractionID
                    };

                    RM_NoteData rmNote = new RM_NoteData()
                    {
                        AcctId   = accountid,
                        NoteDate = smsLog.EndedTime?.ToString("MM/dd/yyyy"),
                        NoteTime = smsLog.EndedTime?.ToString("HH:mm:ss"),
                        user     = agent,
                        NoteText = notes,
                        NoteType = "S"
                    };

                    WebexData webexData = new WebexData
                    {
                        callData = rmData,
                        noteData = rmNote
                    };

                    if (_postSmsToArtiva)
                    {
                        // ⚠ POINTS AT THE SAME ENDPOINT AS CALLS.
                        //
                        // Madan said the SMS side will be a different API on the
                        // same port and IP. Until that exists, this records an
                        // SMS as a CALL on the account — which is the exact
                        // problem the channel split was made to stop.
                        //
                        // So the flag defaults to false. Change the method here
                        // when the SMS endpoint is confirmed.
                        var resp = await _artivaCCX.UpdateWebexData(systemId, webexData);

                        smsLog.SMSLogStatus = resp.Item1
                            ? (byte)callLogStatusEnum.Success
                            : (byte)callLogStatusEnum.Error;

                        if (resp.Item2.Length > 50)   // probably an error message
                        {
                            var eventId = new EventId(4005, "CCXService>ProcessSmsTasks");
                            _appLogger.Log(LogLevel.Error, eventId, "",
                                new Exception(resp.Item2),
                                (state, exception) =>
                                    $"Artiva error for SMS taskid: {item.id} : {exception?.Message} | {state} {DateTime.UtcNow:u}");
                        }

                        smsLog.ArtivaStatus = Truncate(resp.Item2, 50);
                    }
                    else
                    {
                        smsLog.SMSLogStatus = (byte)callLogStatusEnum.Wait;
                        smsLog.ArtivaStatus = "SMS Artiva post disabled";
                    }
                }
                else
                {
                    // No account on the task. Captured, not posted.
                    smsLog.SMSLogStatus = (byte)callLogStatusEnum.None;
                    smsLog.ArtivaStatus = "No AccountID on task";
                }

                smsLog.RowUpdateDT = DateTime.Now;
                await _ccx_smsLog_Service.UpsertSmsLog(smsLog);
            }
            catch (Exception ex)
            {
                var eventId = new EventId(4003, "CCXService>ProcessSmsTasks");
                _appLogger.Log(LogLevel.Error, eventId, "", ex,
                    (state, exception) =>
                        $"Exception for SMS taskid: {item.id} : {exception?.Message} | {state} {DateTime.UtcNow:u}");
            }
        }
    }
    catch (Exception ex)
    {
        var eventId = new EventId(4004, "CCXService>ProcessSmsTasks_Outer");
        _appLogger.Log(LogLevel.Error, eventId, "", ex,
            (state, exception) =>
                $"Exception for SMS batch: {exception?.Message} | {state} {DateTime.UtcNow:u}");
        throw;
    }
}


/// <summary>
/// Whether an SMS interaction is finished enough to report.
///
/// Mirrors canProcess on the call side, minus the cpaStatus check — that is
/// voice-only and is NULL on every SMS row.
/// </summary>
private bool CanProcessSms(CCX_SMSLog smsLog, bool isInbound)
{
    if (string.IsNullOrEmpty(smsLog.Status)
        || !smsLog.Status.Equals("ended", StringComparison.OrdinalIgnoreCase))
    {
        return false;
    }

    // An inbound message that reached an agent has no outcome until they wrap
    // it up. The data shows one row with a NULL agent AND a NULL wrapup, so
    // this genuinely happens.
    if (isInbound
        && !string.IsNullOrEmpty(smsLog.LastAgentID)
        && string.IsNullOrEmpty(smsLog.LastWrapupCodeName))
    {
        return false;
    }

    return true;
}


// -----------------------------------------------------------------------------
// 5. BUILD THE ROW
//
//    Same Central-time conversion as SaveCallLog, so CCX_SMSLog and
//    CCX_CallLog can be read together without converting one of them.
// -----------------------------------------------------------------------------

private CCX_SMSLog BuildSmsLog(Tasks taskInfo)
{
    var centralZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");

    DateTime? startTime = null, endedTime = null;

    if (long.TryParse(Convert.ToString(taskInfo.createdTime), out var lCreate))
        startTime = TimeZoneInfo.ConvertTimeFromUtc(
            DateTimeOffset.FromUnixTimeMilliseconds(lCreate).UtcDateTime, centralZone);

    if (long.TryParse(Convert.ToString(taskInfo.endedTime), out var lEnd))
        endedTime = TimeZoneInfo.ConvertTimeFromUtc(
            DateTimeOffset.FromUnixTimeMilliseconds(lEnd).UtcDateTime, centralZone);

    int accId = 0;
    int.TryParse(taskInfo.accountId?.value, out accId);

    return new CCX_SMSLog
    {
        InteractionID      = taskInfo.id,
        AccountID          = accId,
        DBID               = taskInfo.dbId?.value,
        CreatedTime        = startTime,
        EndedTime          = endedTime,
        Status             = taskInfo.status,
        ChannelType        = taskInfo.channelType,
        Direction          = taskInfo.direction,
        Origin             = taskInfo.origin,
        Destination        = taskInfo.destination,
        TotalDuration      = taskInfo.totalDuration,
        LastWrapupCodeName = taskInfo.lastWrapupCodeName,
        LastWrapUpCodeId   = taskInfo.lastWrapUpCodeId,
        LastAgentID        = taskInfo.lastAgent?.id,
        LastAgentName      = taskInfo.lastAgent?.name,
        AgentID            = taskInfo.owner?.id,
        AgentName          = taskInfo.owner?.name,
        LastEntryPointId   = taskInfo.lastEntryPoint?.id,
        LastEntryPointName = taskInfo.lastEntryPoint?.name,
        LastQueueId        = taskInfo.lastQueue?.id,
        LastQueueName      = taskInfo.lastQueue?.name,
        TerminationReason  = taskInfo.terminationReason,
        TerminatingEnd     = taskInfo.terminatingEnd,
        RowInsertDT        = DateTime.Now,
        RowUpdateDT        = DateTime.Now,
        SMSLogStatus       = (byte)callLogStatusEnum.None
    };
}
