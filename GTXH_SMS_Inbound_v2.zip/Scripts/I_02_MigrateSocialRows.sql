/* ============================================================================
   MIGRATE THE 92 SOCIAL ROWS OUT OF CCX_CallLog
   ============================================================================

   Copy first, verify, then delete. All in one transaction, so a failure at any
   point leaves CCX_CallLog exactly as it was.

   ⚠ RUN Scripts/I_01_CCX_SMSLog.sql FIRST — this needs the table to exist.

   None of these rows were posted to Artiva (CallLogStatus = 0 on all 92), so
   nothing downstream has seen them and there is nothing to unwind.
   ============================================================================ */

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* ---------------------------------------------------------------------------
   1. What we are about to move.
   --------------------------------------------------------------------------- */
PRINT '--- before ---';

SELECT   ChannelType, COUNT(*) AS Rows,
         SUM(CASE WHEN CallLogStatus <> 0 THEN 1 ELSE 0 END) AS PostedToArtiva
FROM     dbo.CCX_CallLog WITH (NOLOCK)
WHERE    ChannelType = 'social'
GROUP BY ChannelType;

/* If PostedToArtiva is anything other than 0, STOP and check with Madan before
   continuing — those accounts have call records that came from an SMS. */
GO


BEGIN TRAN;

DECLARE @SourceCount INT, @Inserted INT, @Deleted INT;

SELECT @SourceCount = COUNT(*)
FROM   dbo.CCX_CallLog
WHERE  ChannelType = 'social';

/* ---------------------------------------------------------------------------
   2. Copy into CCX_SMSLog.

   NOT EXISTS on InteractionID so re-running is safe — the unique index would
   reject a second copy anyway, but this fails quietly rather than loudly.

   Call-only columns are deliberately not carried across. RingingDuration in
   particular has real-looking values on these rows (2014, 2515, 3305) which
   mean nothing for a text message; copying them would preserve a number that
   invites someone to trust it.
   --------------------------------------------------------------------------- */
INSERT INTO dbo.CCX_SMSLog
(
    InteractionID, AccountID, DBID,
    CreatedTime, EndedTime, Status, ChannelType, Direction,
    Origin, Destination, TotalDuration,
    LastWrapupCodeName, LastWrapUpCodeId,
    LastAgentID, LastAgentName, AgentID, AgentName,
    LastEntryPointId, LastEntryPointName, LastQueueId, LastQueueName,
    TerminationReason, TerminatingEnd,
    ArtivaStatus, SMSLogStatus,
    RowInsertDT, RowUpdateDT
)
SELECT
    c.InteractionID, c.AccountID, c.DBID,
    c.CreatedTime, c.EndedTime, c.Status, c.ChannelType, c.Direction,
    c.Origin, c.Destination, c.TotalDuration,
    c.LastWrapupCodeName, c.LastWrapUpCodeId,
    c.LastAgentID, c.LastAgentName, c.AgentID, c.AgentName,
    c.LastEntryPointId, c.LastEntryPointName, c.LastQueueId, c.LastQueueName,
    c.TerminationReason, c.TerminatingEnd,
    c.ArtivaStatus, c.CallLogStatus,
    c.RowInsertDT, c.RowUpdateDT
FROM   dbo.CCX_CallLog c
WHERE  c.ChannelType = 'social'
  AND  NOT EXISTS (SELECT 1 FROM dbo.CCX_SMSLog s
                   WHERE s.InteractionID = c.InteractionID);

SET @Inserted = @@ROWCOUNT;

/* ---------------------------------------------------------------------------
   3. Verify EVERY source row now exists in the new table before deleting.

   Counting inserts is not enough — a re-run inserts 0 but the rows may still
   all be there. This checks the actual condition that makes the delete safe.
   --------------------------------------------------------------------------- */
IF EXISTS (
    SELECT 1
    FROM   dbo.CCX_CallLog c
    WHERE  c.ChannelType = 'social'
      AND  NOT EXISTS (SELECT 1 FROM dbo.CCX_SMSLog s
                       WHERE s.InteractionID = c.InteractionID)
)
BEGIN
    ROLLBACK;
    RAISERROR('Not every social row was copied. Nothing deleted, nothing changed.', 16, 1);
    RETURN;
END

/* ---------------------------------------------------------------------------
   4. Now delete.
   --------------------------------------------------------------------------- */
DELETE FROM dbo.CCX_CallLog
WHERE  ChannelType = 'social';

SET @Deleted = @@ROWCOUNT;

COMMIT;

PRINT '--- done ---';
PRINT 'Source rows : ' + CAST(@SourceCount AS VARCHAR(10));
PRINT 'Inserted    : ' + CAST(@Inserted AS VARCHAR(10)) + '  (0 on a re-run is expected)';
PRINT 'Deleted     : ' + CAST(@Deleted AS VARCHAR(10));
GO


/* ---------------------------------------------------------------------------
   5. Confirm.
   --------------------------------------------------------------------------- */
PRINT '--- after ---';

SELECT 'CCX_CallLog social (should be 0)' AS Check_, COUNT(*) AS Rows
FROM   dbo.CCX_CallLog WITH (NOLOCK) WHERE ChannelType = 'social'
UNION ALL
SELECT 'CCX_SMSLog total', COUNT(*) FROM dbo.CCX_SMSLog WITH (NOLOCK);

SELECT   Direction, COUNT(*) AS Rows,
         SUM(CASE WHEN AccountID > 0 THEN 1 ELSE 0 END) AS WithAccount,
         SUM(CASE WHEN LastWrapupCodeName IS NOT NULL THEN 1 ELSE 0 END) AS WithWrapup
FROM     dbo.CCX_SMSLog WITH (NOLOCK)
GROUP BY Direction;
GO
