/* ============================================================================
   CCX_SMSLog — inbound and outbound SMS interactions from Webex
   ============================================================================

   Point 3: "See if we can add it to another table for received SMS
             (Like CCX_Calllog)"

   Deliberately mirrors CCX_CallLog so the existing processing shape carries
   over, MINUS the columns that only mean something for a voice call:

       dropped   RingingDuration, QueueDuration, HoldDuration, WrapupDuration,
                 ConnectDuration, SelfServiceDuration, PostCallDuration,
                 PausedDuration, cpaStatus, TerminationType, AbandonedType,
                 all Callback* columns, all FeedbackSurvey* columns

   None of those apply to a text message, and carrying them would leave a table
   that is mostly NULL and invites someone to fill them with something wrong.

   KEPT: the identity, routing, wrapup and Artiva-status columns — everything
   the CALLDATA/NOTES posting actually reads.

   Safe to run more than once.
   ============================================================================ */

SET NOCOUNT ON;
GO

IF OBJECT_ID('dbo.CCX_SMSLog', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.CCX_SMSLog (
        ID                  BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_CCX_SMSLog PRIMARY KEY,

        /* Webex task id. Same meaning as CCX_CallLog.InteractionID. */
        InteractionID       VARCHAR(50)   NOT NULL,

        AccountID           INT           NULL,
        DBID                VARCHAR(20)   NULL,

        CreatedTime         DATETIME      NULL,
        EndedTime           DATETIME      NULL,

        Status              VARCHAR(50)   NULL,
        ChannelType         VARCHAR(50)   NULL,
        Direction           VARCHAR(20)   NULL,

        /* For inbound, Origin is the patient's number.
           For outbound, Destination is. */
        Origin              VARCHAR(50)   NULL,
        Destination         VARCHAR(50)   NULL,

        /* The message text, if Webex returns it. */
        MessageText         NVARCHAR(MAX) NULL,

        TotalDuration       INT           NULL,

        /* Point 4 — the wrapup code, same rules as calls. */
        LastWrapupCodeName  VARCHAR(100)  NULL,
        LastWrapUpCodeId    VARCHAR(50)   NULL,

        LastAgentID         VARCHAR(50)   NULL,
        LastAgentName       VARCHAR(100)  NULL,
        AgentID             VARCHAR(50)   NULL,
        AgentName           VARCHAR(100)  NULL,

        LastEntryPointId    VARCHAR(50)   NULL,
        LastEntryPointName  VARCHAR(100)  NULL,
        LastQueueId         VARCHAR(50)   NULL,
        LastQueueName       VARCHAR(100)  NULL,

        TerminationReason   VARCHAR(100)  NULL,
        TerminatingEnd      VARCHAR(50)   NULL,

        /* Set when the recipient replied STOP. Point 1 of the inbound list is
           Santosh's, but the flag lives with the message that caused it. */
        IsOptOut            BIT           NOT NULL
            CONSTRAINT DF_CCXSMS_IsOptOut DEFAULT (0),

        /* Same meaning as on CCX_CallLog — how the Artiva post went. */
        ArtivaStatus        VARCHAR(50)   NULL,
        SMSLogStatus        TINYINT       NOT NULL
            CONSTRAINT DF_CCXSMS_Status DEFAULT (0),

        RowInsertDT         DATETIME      NOT NULL
            CONSTRAINT DF_CCXSMS_Insert DEFAULT (GETDATE()),
        RowUpdateDT         DATETIME      NULL
    );

    /* One row per Webex task. Reprocessing the same task must update, not
       duplicate — the same guarantee CCX_CallLog relies on. */
    CREATE UNIQUE INDEX UQ_CCXSMS_InteractionID
        ON dbo.CCX_SMSLog (InteractionID);

    CREATE INDEX IX_CCXSMS_Pending
        ON dbo.CCX_SMSLog (SMSLogStatus, RowUpdateDT);

    CREATE INDEX IX_CCXSMS_Account
        ON dbo.CCX_SMSLog (AccountID, CreatedTime);

    PRINT 'Created CCX_SMSLog';
END
GO

PRINT '--- verify ---';
SELECT name, is_unique FROM sys.indexes
WHERE object_id = OBJECT_ID('dbo.CCX_SMSLog') AND name IS NOT NULL;
GO
