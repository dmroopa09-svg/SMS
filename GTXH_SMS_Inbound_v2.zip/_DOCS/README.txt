SMS INBOUND — POINTS 2, 3, 4
============================

CONFIRMED FROM THE DATA
-----------------------
    channelType   = "social"   (not "sms")
    rows already in CCX_CallLog = 92, first seen 2026-07-15
    CallLogStatus = 0 on ALL of them  ->  none were posted to Artiva
    Direction     = "inbound" or "outdial"   (NOT "outbound")
    AccountID     = 0 and DBID = NULL on every row
    wrapup codes  ARE present: Right Party Contacted, No Answer,
                  Wrong Number, EPALS Application, Third Party Contact

The good news to report: nothing bad reached any account. Nothing to unwind.


RUN ORDER
---------
    1. Scripts/I_01_CCX_SMSLog.sql        create the table
    2. Add the entity, interface, service (CCX_SMSLog_Entity_And_Service.cs)
       - register in DI:      services.AddScoped<ICCX_SMSLog_Service, CCX_SMSLog_Service>()
       - add to GD_Context:   public DbSet<CCX_SMSLog> CCX_SMSLog { get; set; }
    3. Scripts/I_02_MigrateSocialRows.sql move the 92 rows
    4. Apply CCXService_SmsChanges.cs
    5. appsettings:

           "Webex": {
             "SmsChannelTypes": [ "social" ],
             "PostSmsToArtiva": false
           }

Step 3 can run before or after step 4 — the migration only touches existing
rows, the code change only affects new ones.


THE MIGRATION IS COPY, VERIFY, THEN DELETE
------------------------------------------
All in one transaction. It re-checks that EVERY social row exists in
CCX_SMSLog before deleting anything, and rolls back if not.

Counting inserts would not be enough — a re-run inserts 0 rows but they may
still all be present. The check tests the actual condition that makes the
delete safe.

Call-only columns are deliberately NOT carried over. RingingDuration in
particular has real-looking values on these rows (2014, 2515, 3305) which mean
nothing for a text message. Copying them preserves a number that invites
someone to trust it.


THE SPLIT GOES IN ProcessTasks_V2
---------------------------------
Not in the GraphQL query. Filtering channelType there would only cover
EodProces — the Kafka subscription fetches by task id and would keep feeding
social tasks into the call path.

One check at the top of ProcessTasks_V2 covers both routes.


ACCOUNTID — HANDLED THE SAME WAY AS CALLS
-----------------------------------------
The call path wraps its entire Artiva block in:

    if (csllLog.AccountID > 0)

so a call with no account is captured and simply not posted. SMS now does the
same, with ArtivaStatus = "No AccountID on task" so it is visible why.

Given AccountID is 0 on all 92 existing rows, that is the normal case today,
not the exception.


ARTIVA POST — WRITTEN AND READY, FLAG OFF
-----------------------------------------
The full posting path is there: account id resolution by SystemID, CALLDATA,
NOTES, error logging, ArtivaStatus. Same shape as the call path.

    "Webex": { "PostSmsToArtiva": false }

With it off, rows are still captured and wrapup codes still resolved — only the
post is skipped.

⚠ IT CURRENTLY POINTS AT UpdateWebexData, THE CALL ENDPOINT. Madan said SMS
will be a different API on the same port and IP. Turning the flag on before
that endpoint exists would record every SMS as a CALL on the account — the
exact thing the channel split was made to stop.

When the endpoint is ready: change the one method call, then flip the flag.


TWO THINGS STILL OPEN FOR MADAN
-------------------------------
1. TermCode for SMS.
   Calls send it from cpaStatus (LIVE_VOICE, ABANDONED,
   MEDIA_MANAGER_INTERNAL_ERROR) — whether the call connected. cpaStatus is
   NULL on every SMS row and a text has no equivalent state.

   Left blank rather than borrowing a voice code, because sending SUCCESS would
   tell Artiva a call connected.

2. The SMS Artiva endpoint itself.


VERIFY AFTER
------------
    SELECT ChannelType, COUNT(*) FROM CCX_CallLog WITH (NOLOCK)
    WHERE ChannelType = 'social' GROUP BY ChannelType;
    -- expect zero rows

    SELECT Direction, COUNT(*) FROM CCX_SMSLog GROUP BY Direction;
    -- expect the 92, split inbound / outdial

Then watch that CCX_CallLog stops gaining social rows while CCX_SMSLog gains
them.
