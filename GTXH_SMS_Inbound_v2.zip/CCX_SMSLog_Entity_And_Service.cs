// =============================================================================
// SUPPORTING PIECES
//
// CampaignManager.Models/Entities/CCX_SMSLog.cs
// CampaignManager.Services/Repo/CCX_SMSLog_Service.cs
// CampaignManager.Interfaces/IRepo/ICCX_SMSLog_Service.cs
//
// Mirrors CCX_CallLog and its service so the pattern is familiar, minus the
// call-only columns.
// =============================================================================

// ---------- Entity ----------

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CampaignManager.Models.Entities
{
    [Table("CCX_SMSLog")]
    public class CCX_SMSLog
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long ID { get; set; }

        /// <summary>Webex task id. Unique — reprocessing updates, never duplicates.</summary>
        [Required]
        [StringLength(50)]
        public string InteractionID { get; set; } = "";

        public int? AccountID { get; set; }

        [StringLength(20)]
        public string? DBID { get; set; }

        public DateTime? CreatedTime { get; set; }
        public DateTime? EndedTime { get; set; }

        [StringLength(50)]  public string? Status { get; set; }
        [StringLength(50)]  public string? ChannelType { get; set; }
        [StringLength(20)]  public string? Direction { get; set; }

        /// <summary>Inbound: the patient's number. Outbound: our sending number.</summary>
        [StringLength(50)]  public string? Origin { get; set; }
        [StringLength(50)]  public string? Destination { get; set; }

        public string? MessageText { get; set; }

        public int? TotalDuration { get; set; }

        [StringLength(100)] public string? LastWrapupCodeName { get; set; }
        [StringLength(50)]  public string? LastWrapUpCodeId { get; set; }

        [StringLength(50)]  public string? LastAgentID { get; set; }
        [StringLength(100)] public string? LastAgentName { get; set; }
        [StringLength(50)]  public string? AgentID { get; set; }
        [StringLength(100)] public string? AgentName { get; set; }

        [StringLength(50)]  public string? LastEntryPointId { get; set; }
        [StringLength(100)] public string? LastEntryPointName { get; set; }
        [StringLength(50)]  public string? LastQueueId { get; set; }
        [StringLength(100)] public string? LastQueueName { get; set; }

        [StringLength(100)] public string? TerminationReason { get; set; }
        [StringLength(50)]  public string? TerminatingEnd { get; set; }

        /// <summary>Set when the recipient replied STOP.</summary>
        public bool IsOptOut { get; set; }

        [StringLength(50)]  public string? ArtivaStatus { get; set; }

        /// <summary>Same values as CCX_CallLog.CallLogStatus (callLogStatusEnum).</summary>
        public byte SMSLogStatus { get; set; }

        public DateTime RowInsertDT { get; set; }
        public DateTime? RowUpdateDT { get; set; }
    }
}


// ---------- Interface ----------

namespace CampaignManager.Interfaces.IRepo
{
    public interface ICCX_SMSLog_Service
    {
        Task<long> UpsertSmsLog(CCX_SMSLog smsLog);
        Task<CCX_SMSLog?> GetByInteractionId(string interactionId, bool notrack = false);
        Task<List<CCX_SMSLog>> GetPendingToProcess();
    }
}


// ---------- Service ----------

namespace CampaignManager.Services.Repo
{
    public class CCX_SMSLog_Service : Repository<CCX_SMSLog>, ICCX_SMSLog_Service
    {
        public CCX_SMSLog_Service(GD_Context context) : base(context) { }

        /// <summary>
        /// Insert or update, keyed on InteractionID.
        ///
        /// UPSERT RATHER THAN INSERT because the same Webex task arrives more
        /// than once — the Kafka subscription fires on task events, and
        /// EodProces re-reads the whole day. An insert-only version would
        /// duplicate every message that gets seen twice.
        ///
        /// The unique index on InteractionID is the backstop if two instances
        /// race here.
        /// </summary>
        public async Task<long> UpsertSmsLog(CCX_SMSLog smsLog)
        {
            var existing = await _context.CCX_SMSLog
                .FirstOrDefaultAsync(x => x.InteractionID == smsLog.InteractionID);

            if (existing == null)
            {
                smsLog.RowInsertDT = DateTime.Now;
                await _context.CCX_SMSLog.AddAsync(smsLog);
                await _context.SaveChangesAsync();
                return smsLog.ID;
            }

            // Only overwrite what Webex actually sent. A later event with an
            // empty wrapup code must not erase one we already have — that is the
            // same guard UpdateCallLog uses on LastWrapupCodeName.
            existing.Status        = smsLog.Status ?? existing.Status;
            existing.EndedTime     = smsLog.EndedTime ?? existing.EndedTime;
            existing.Origin        = smsLog.Origin ?? existing.Origin;
            existing.Destination   = smsLog.Destination ?? existing.Destination;
            existing.MessageText   = smsLog.MessageText ?? existing.MessageText;
            existing.TotalDuration = smsLog.TotalDuration ?? existing.TotalDuration;

            if (!string.IsNullOrEmpty(smsLog.LastWrapupCodeName))
            {
                existing.LastWrapupCodeName = smsLog.LastWrapupCodeName;
                existing.LastWrapUpCodeId   = smsLog.LastWrapUpCodeId;
            }

            existing.LastAgentID       = smsLog.LastAgentID ?? existing.LastAgentID;
            existing.LastAgentName     = smsLog.LastAgentName ?? existing.LastAgentName;
            existing.AgentID           = smsLog.AgentID ?? existing.AgentID;
            existing.AgentName         = smsLog.AgentName ?? existing.AgentName;
            existing.LastEntryPointId  = smsLog.LastEntryPointId ?? existing.LastEntryPointId;
            existing.LastEntryPointName= smsLog.LastEntryPointName ?? existing.LastEntryPointName;
            existing.LastQueueId       = smsLog.LastQueueId ?? existing.LastQueueId;
            existing.LastQueueName     = smsLog.LastQueueName ?? existing.LastQueueName;
            existing.TerminationReason = smsLog.TerminationReason ?? existing.TerminationReason;
            existing.TerminatingEnd    = smsLog.TerminatingEnd ?? existing.TerminatingEnd;

            if (smsLog.IsOptOut)
                existing.IsOptOut = true;      // never un-set an opt-out

            existing.ArtivaStatus = smsLog.ArtivaStatus ?? existing.ArtivaStatus;
            existing.SMSLogStatus = smsLog.SMSLogStatus;
            existing.RowUpdateDT  = DateTime.Now;

            await _context.SaveChangesAsync();
            return existing.ID;
        }

        public async Task<CCX_SMSLog?> GetByInteractionId(string interactionId, bool notrack = false)
        {
            var query = _context.CCX_SMSLog.Where(x => x.InteractionID == interactionId);
            if (notrack) query = query.AsNoTracking();
            return await query.FirstOrDefaultAsync();
        }

        /// <summary>
        /// Rows waiting on something — an unfinished interaction, a missing
        /// wrapup code, or an Artiva post that has not happened yet.
        /// </summary>
        public async Task<List<CCX_SMSLog>> GetPendingToProcess()
        {
            return await _context.CCX_SMSLog
                .FromSqlRaw(@"SELECT * FROM CCX_SMSLog WITH (NOLOCK)
                              WHERE SMSLogStatus IN (0, 2)
                                AND RowInsertDT  >= DATEADD(DAY, -7, GETDATE())
                                AND (RowUpdateDT IS NULL
                                     OR RowUpdateDT < DATEADD(MINUTE, -15, GETDATE()))
                              ORDER BY ID")
                .ToListAsync();
        }
    }
}


// ---------- Register in Program.cs / DI ----------
//
//     builder.Services.AddScoped<ICCX_SMSLog_Service, CCX_SMSLog_Service>();
//
// ---------- Add to GD_Context ----------
//
//     public DbSet<CCX_SMSLog> CCX_SMSLog { get; set; }
