/* ============================================================================
   RUN THIS FIRST — it answers point 2 and decides everything else
   ============================================================================

   The Webex taskDetails query returns channelType on every task, and NONE of
   the queries in CallData_Service filter on it:

       GetData      filters by task id only
       GetAllCalls  filters by date range only - no channel filter at all

   So if SMS interactions exist in the org, EodProces has been pulling them into
   CCX_CallLog alongside calls. This shows whether that is happening.
   ============================================================================ */

/* ---------------------------------------------------------------------------
   1. What channel types are already in CCX_CallLog?

   Anything that is not telephony is a non-call interaction that has been
   logged as a call.
   --------------------------------------------------------------------------- */
SELECT   ChannelType,
         COUNT(*)              AS Rows,
         MIN(CreatedTime)      AS FirstSeen,
         MAX(CreatedTime)      AS LastSeen,
         SUM(CASE WHEN Direction = 'inbound'  THEN 1 ELSE 0 END) AS Inbound,
         SUM(CASE WHEN Direction = 'outbound' THEN 1 ELSE 0 END) AS Outbound
FROM     dbo.CCX_CallLog WITH (NOLOCK)
WHERE    CreatedTime >= DATEADD(MONTH, -3, GETDATE())
GROUP BY ChannelType
ORDER BY COUNT(*) DESC;


/* ---------------------------------------------------------------------------
   2. If anything non-telephony appears above, look at a few rows.

   This tells you what an SMS task actually looks like — which call-specific
   fields are empty, and whether a wrapup code comes through.
   --------------------------------------------------------------------------- */
SELECT TOP (20)
       InteractionID, ChannelType, Direction, Origin, Destination,
       CreatedTime, EndedTime, Status,
       LastWrapupCodeName, LastWrapUpCodeId,
       LastAgentID, LastAgentName,
       AccountID, DBID,
       cpaStatus,            -- call-only, expect NULL for SMS
       RingingDuration,      -- call-only
       HoldDuration,         -- call-only
       ArtivaStatus, CallLogStatus
FROM   dbo.CCX_CallLog WITH (NOLOCK)
WHERE  ChannelType IS NOT NULL
  AND  ChannelType <> 'telephony'
ORDER  BY CreatedTime DESC;


/* ---------------------------------------------------------------------------
   3. Have any of those been posted to Artiva as CALL data?

   CallLogStatus 1 = Success means UpdateWebexData ran and Artiva was told an
   SMS was a call. Those accounts now have a call record that never happened.
   --------------------------------------------------------------------------- */
SELECT   ChannelType, CallLogStatus, COUNT(*) AS Rows
FROM     dbo.CCX_CallLog WITH (NOLOCK)
WHERE    ChannelType IS NOT NULL
  AND    ChannelType <> 'telephony'
GROUP BY ChannelType, CallLogStatus
ORDER BY ChannelType, CallLogStatus;
