// =============================================================================
// CCXService — SPLIT SMS OUT OF THE CALL PATH
//
// ContactCenterAPI/Services/CCXService.cs
//
// Point 2: stop CCX_CallLog capturing SMS
// Point 3: put SMS in CCX_SMSLog instead
// Point 4: wrapup code follows the same rules, posted to Artiva
//
// THE KEY THING: there is no separate Webex API for SMS. taskDetails already
// returns every channel and every query in CallData_Service ignores
// channelType — GetData filters by task id, GetAllCalls by date range only.
// So SMS tasks have been arriving all along and ProcessTasks_V2 has been
// writing them into CCX_CallLog as if they were calls.
//
// Run Scripts/I_00_CheckChannelTypes.sql before any of this — it shows whether
// that is actually happening and what channelType SMS arrives as.
// =============================================================================

// -----------------------------------------------------------------------------
// STEP 1 — add this to CCXService
//
// Which channelType means SMS is NOT guessed here. It comes from configuration,
// because the value Webex uses has not been confirmed and hardcoding a guess
// would silently route everything the wrong way.
//
// appsettings:
//     "Webex": { "SmsChannelTypes": [ "sms" ] }
//
// Run I_00 first, look at what actually appears in the ChannelType column, and
// put those values here.
// -----------------------------------------------------------------------------

private readonly HashSet<string> _smsChannelTypes;

// in the constructor, after _config is set:
//
//     _smsChannelTypes = new HashSet<string>(
//         _config.GetSection("Webex:SmsChannelTypes").Get<string[]>() ?? new[] { "sms" },
//         StringComparer.OrdinalIgnoreCase);

private bool IsSmsTask(string? channelType)
    => !string.IsNullOrWhiteSpace(channelType)
       && _smsChannelTypes.Contains(channelType);


// -----------------------------------------------------------------------------
// STEP 2 — split the list at the top of ProcessTasks_V2
//
// Put this immediately after:
//     List<Tasks> distinctTask = tasks.DistinctBy(task => task.id).ToList();
//
// One choke point, so it catches BOTH paths — the Kafka subscription and
// EodProces. Filtering in the GraphQL query would only cover EodProces and
// would leave the Kafka path still writing SMS into CCX_CallLog.
// -----------------------------------------------------------------------------

/*
    var smsTasks  = distinctTask.Where(t => IsSmsTask(t.channelType)).ToList();
    var callTasks = distinctTask.Where(t => !IsSmsTask(t.channelType)).ToList();

    if (smsTasks.Count > 0)
    {
        _appLogger.Log(LogLevel.Information, 0, "", null,
            (state, ex) => $"Routing {smsTasks.Count} SMS task(s) to CCX_SMSLog");

        await ProcessSmsTasks(smsTasks);
    }

    if (callTasks.Count == 0)
        return;

    distinctTask = callTasks;   // everything below this line now sees calls only
*/


// -----------------------------------------------------------------------------
// STEP 3 — the SMS path
//
// Deliberately much smaller than ProcessTasks_V2. An SMS has no ring duration,
// no hold, no CPA status, no callback and no feedback survey — carrying that
// shape across would produce a method that is mostly checks that never fire.
// -----------------------------------------------------------------------------

public async Task ProcessSmsTasks(List<Tasks> smsTasks)
{
    if (smsTasks == null || smsTasks.Count == 0)
        return;

    try
    {
        // Same wrapup mapping the call path uses. Point 4 says to follow the
        // same rules, so this is the same dictionary, not a second copy.
        Dictionary<string, string> call_TermCodes =
            await _oDS_CallService.GetAllCall_TermCode();

        var taskIds = smsTasks.Select(t => t.id).ToList();

        // Accounts, for the Artiva post.
        var distinctAccountIds = smsTasks
            .SelectMany(t => long.TryParse(t.accountId?.value, out var id)
                             ? new[] { id } : Array.Empty<long>())
            .Distinct()
            .ToList();

        List<AccountInfo> accInfos =
            await _accInfo_Service.GetAccountInfoByIds(distinctAccountIds, true);

        var accInfoForTasks = accInfos
            .Where(c => c.ID != null)
            .ToDictionary(c => c.ID, c => c);

        foreach (var item in smsTasks)
        {
            try
            {
                if (item == null || string.IsNullOrEmpty(item.id))
                    continue;

                var smsLog = BuildSmsLog(item);

                // Point 4 — translate the wrapup code exactly as calls do.
                string artivaWrapupCode = string.Empty;
                if (!string.IsNullOrEmpty(smsLog.LastWrapupCodeName)
                    && call_TermCodes.TryGetValue(smsLog.LastWrapupCodeName, out var mapped))
                {
                    artivaWrapupCode = mapped.Trim();
                }

                bool isInbound = "inbound".Equals(smsLog.Direction, StringComparison.OrdinalIgnoreCase);

                // Only post once the interaction has ended and, for an inbound
                // message that reached an agent, once a wrapup code exists.
                // Same reasoning as canProcess on the call side: posting early
                // sends an outcome that has not been decided yet.
                bool ended = "ended".Equals(smsLog.Status, StringComparison.OrdinalIgnoreCase);
                bool awaitingWrapup = isInbound
                                      && !string.IsNullOrEmpty(smsLog.LastAgentID)
                                      && string.IsNullOrEmpty(smsLog.LastWrapupCodeName);

                if (!ended || awaitingWrapup)
                {
                    smsLog.SMSLogStatus = (byte)callLogStatusEnum.Wait;
                    await _ccx_smsLog_Service.UpsertSmsLog(smsLog);
                    continue;
                }

                if (smsLog.AccountID > 0
                    && accInfoForTasks.TryGetValue(Convert.ToInt64(smsLog.AccountID), out var accInfo)
                    && accInfo != null)
                {
                    // ⚠ THE ACCOUNT ID SENT TO ARTIVA DEPENDS ON SystemID.
                    // This is NOT the DBID_LeadAccount form used for Webex —
                    // different destination, different rule. Copied from the
                    // call path so the two cannot drift.
                    int systemId = Convert.ToInt32(accInfo.SystemID);
                    string accountid = systemId == 1
                        ? Convert.ToString(accInfo.AccountID)     // RM
                        : accInfo.SelfPayID ?? "";

                    string phonenum = (isInbound ? smsLog.Origin : smsLog.Destination)
                                      ?.Replace("+1", "")?.Replace("-", "") ?? "";

                    string notes = (isInbound ? "SMS received from: " : "SMS sent to: ")
                                   + phonenum + ";";

                    if (!string.IsNullOrEmpty(smsLog.LastAgentName))
                        notes += " Last Agent:" + smsLog.LastAgentName + ";";

                    if (!string.IsNullOrEmpty(artivaWrapupCode))
                        notes += " Wrapup Code:" + artivaWrapupCode + ";";

                    string agent = smsLog.AgentName;
                    if (string.IsNullOrEmpty(agent))
                        agent = "smsapi";

                    // ⚠ TermCode has no SMS equivalent yet.
                    //
                    // On calls it comes from cpaStatus — LIVE_VOICE, ABANDONED,
                    // MEDIA_MANAGER_INTERNAL_ERROR — which describes whether the
                    // call connected. SMS has no such thing.
                    //
                    // Left blank rather than reusing a voice code, because
                    // sending SUCCESS would tell Artiva a call connected.
                    // CONFIRM WITH MADAN what TermCode an SMS should carry.
                    string termCode = "";

                    RM_CallData rmData = new RM_CallData()
                    {
                        AcctId        = accountid,
                        TermCode      = termCode,
                        OUTCOME       = artivaWrapupCode ?? "",
                        PhoneNumber   = phonenum,
                        Direction     = smsLog.Direction ?? "",
                        Agent         = agent,
                        CallStartDate = smsLog.CreatedTime?.ToString("MM/dd/yyyy"),
                        CallStartTime = smsLog.CreatedTime?.ToString("HH:mm:ss"),
                        CallEndDate   = smsLog.EndedTime?.ToString("MM/dd/yyyy"),
                        CallEndTime   = smsLog.EndedTime?.ToString("HH:mm:ss"),
                        CiscoCallId   = smsLog.InteractionID
                    };

                    RM_NoteData rmNote = new RM_NoteData()
                    {
                        AcctId   = accountid,
                        NoteDate = smsLog.EndedTime?.ToString("MM/dd/yyyy"),
                        NoteTime = smsLog.EndedTime?.ToString("HH:mm:ss"),
                        user     = agent,
                        NoteText = notes,
                        NoteType = "S"
                    };

                    var webexData = new WebexData { callData = rmData, noteData = rmNote };

                    // ⚠ SAME ENDPOINT AS CALLS FOR NOW.
                    //
                    // Madan said "this will be different API for Artiva but port
                    // and IP will be same". Until that endpoint exists, posting
                    // here would record an SMS as a CALL on the account.
                    //
                    // So this is deliberately NOT called yet. Uncomment only once
                    // the SMS endpoint is available.
                    //
                    // var resp = await _artivaCCX.UpdateWebexData(systemId, webexData);
                    //
                    // smsLog.SMSLogStatus = resp.Item1
                    //     ? (byte)callLogStatusEnum.Success
                    //     : (byte)callLogStatusEnum.Error;
                    // smsLog.ArtivaStatus = Truncate(resp.Item2, 50);

                    smsLog.SMSLogStatus = (byte)callLogStatusEnum.Wait;
                    smsLog.ArtivaStatus = "Awaiting SMS Artiva endpoint";
                }

                smsLog.RowUpdateDT = DateTime.Now;
                await _ccx_smsLog_Service.UpsertSmsLog(smsLog);
            }
            catch (Exception ex)
            {
                var eventId = new EventId(4003, "CCXService>ProcessSmsTasks");
                _appLogger.Log(LogLevel.Error, eventId, "", ex,
                    (state, exception) =>
                        $"Exception for SMS taskid: {item.id} : {exception?.Message} | {state} {DateTime.UtcNow:u}");
            }
        }
    }
    catch (Exception ex)
    {
        var eventId = new EventId(4004, "CCXService>ProcessSmsTasks_Outer");
        _appLogger.Log(LogLevel.Error, eventId, "", ex,
            (state, exception) =>
                $"Exception for SMS batch: {exception?.Message} | {state} {DateTime.UtcNow:u}");
        throw;
    }
}


// -----------------------------------------------------------------------------
// STEP 4 — build the row
//
// Same time zone handling as SaveCallLog: Webex sends epoch milliseconds, and
// CCX_CallLog stores Central. Keeping SMS on the same basis means the two
// tables can be read together without converting one of them.
// -----------------------------------------------------------------------------

private CCX_SMSLog BuildSmsLog(Tasks taskInfo)
{
    var centralZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");

    DateTime? startTime = null, endedTime = null;

    if (long.TryParse(Convert.ToString(taskInfo.createdTime), out var lCreate))
        startTime = TimeZoneInfo.ConvertTimeFromUtc(
            DateTimeOffset.FromUnixTimeMilliseconds(lCreate).UtcDateTime, centralZone);

    if (long.TryParse(Convert.ToString(taskInfo.endedTime), out var lEnd))
        endedTime = TimeZoneInfo.ConvertTimeFromUtc(
            DateTimeOffset.FromUnixTimeMilliseconds(lEnd).UtcDateTime, centralZone);

    int accId = 0;
    int.TryParse(taskInfo.accountId?.value, out accId);

    return new CCX_SMSLog
    {
        InteractionID      = taskInfo.id,
        AccountID          = accId,
        DBID               = taskInfo.dbId?.value,
        CreatedTime        = startTime,
        EndedTime          = endedTime,
        Status             = taskInfo.status,
        ChannelType        = taskInfo.channelType,
        Direction          = taskInfo.direction,
        Origin             = taskInfo.origin,
        Destination        = taskInfo.destination,
        TotalDuration      = taskInfo.totalDuration,
        LastWrapupCodeName = taskInfo.lastWrapupCodeName,
        LastWrapUpCodeId   = taskInfo.lastWrapUpCodeId,
        LastAgentID        = taskInfo.lastAgent?.id,
        LastAgentName      = taskInfo.lastAgent?.name,
        AgentID            = taskInfo.owner?.id,
        AgentName          = taskInfo.owner?.name,
        LastEntryPointId   = taskInfo.lastEntryPoint?.id,
        LastEntryPointName = taskInfo.lastEntryPoint?.name,
        LastQueueId        = taskInfo.lastQueue?.id,
        LastQueueName      = taskInfo.lastQueue?.name,
        TerminationReason  = taskInfo.terminationReason,
        TerminatingEnd     = taskInfo.terminatingEnd,
        RowInsertDT        = DateTime.Now,
        RowUpdateDT        = DateTime.Now,
        SMSLogStatus       = (byte)callLogStatusEnum.None
    };
}
