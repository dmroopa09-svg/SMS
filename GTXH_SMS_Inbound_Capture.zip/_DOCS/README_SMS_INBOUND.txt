INBOUND SMS — POINTS 2, 3, 4
============================

    2. Stop CCX_CallLog capturing SMS
    3. Put SMS in its own table
    4. Wrapup code follows the same rules, posted to Artiva


>>> THE ANSWER TO "IS THERE A WEBEX API FOR SMS?" <<<
=====================================================
No separate API is needed. taskDetails already returns EVERY channel and
returns channelType on each task.

And none of the queries filter on it:

    GetData       filters by task id only
    GetAllCalls   filters by date range only — no channel filter at all

So SMS tasks have been arriving all along, and ProcessTasks_V2 has been writing
them into CCX_CallLog as if they were calls. That IS point 2 — it is not
hypothetical.


RUN THIS FIRST
--------------
    Scripts/I_00_CheckChannelTypes.sql

Query 1 shows what channel types are already in CCX_CallLog. Anything that is
not telephony is a non-call interaction logged as a call.

Query 3 is the one to look at closely: it shows whether any of those were POSTED
TO ARTIVA as call data. CallLogStatus = 1 means UpdateWebexData ran and an
account now has a call record for something that was never a call.

⚠ DO NOT SET Webex:SmsChannelTypes UNTIL YOU HAVE RUN THIS. The value Webex
uses for SMS is not confirmed, and guessing it routes everything the wrong way —
either SMS keeps landing in CCX_CallLog, or real calls get diverted into
CCX_SMSLog.


FILES
-----
    Scripts/I_00_CheckChannelTypes.sql    run first
    Scripts/I_01_CCX_SMSLog.sql           the new table
    CCXService_SmsChanges.cs              the split, and the SMS path
    CCX_SMSLog_Entity_And_Service.cs      entity, interface, repository


WHY THE SPLIT IS IN ProcessTasks_V2, NOT THE GRAPHQL
----------------------------------------------------
Filtering channelType in the query would only cover EodProces. The Kafka
subscription path (ProcesKafkaMsgs) fetches by task id, so it would keep
delivering SMS into the call path.

One check at the top of ProcessTasks_V2 covers both routes. Single choke point,
nothing to keep in step.


CCX_SMSLog DROPS THE CALL-ONLY COLUMNS
--------------------------------------
Gone: RingingDuration, QueueDuration, HoldDuration, WrapupDuration,
ConnectDuration, SelfServiceDuration, PostCallDuration, PausedDuration,
cpaStatus, TerminationType, AbandonedType, all Callback*, all FeedbackSurvey*.

None of those mean anything for a text message. Carrying them would leave a
table that is mostly NULL and invites someone to fill a column with something
that looks plausible and is wrong.

Kept: identity, routing, wrapup, and the Artiva status columns — everything the
CALLDATA/NOTES posting actually reads.

UPSERT ON InteractionID, not insert. The same Webex task arrives more than once
(the subscription fires on events, EodProces re-reads the whole day). An
insert-only version would duplicate every message seen twice. The unique index
is the backstop.

A later event with an EMPTY wrapup code never erases one already stored — same
guard UpdateCallLog uses. And an opt-out flag is never un-set.


⚠ TWO THINGS DELIBERATELY NOT DONE
==================================

1. THE ARTIVA POST IS COMMENTED OUT.

   Madan said "this will be different API for Artiva but port and IP will be
   same". That endpoint does not exist yet.

   Posting to UpdateWebexData in the meantime would record every SMS as a CALL
   on the account — the exact problem point 2 exists to stop. So the row is
   written with ArtivaStatus = "Awaiting SMS Artiva endpoint" and the post is
   left for when the endpoint is ready.

2. TermCode IS LEFT BLANK.

   On calls it comes from cpaStatus — LIVE_VOICE, ABANDONED,
   MEDIA_MANAGER_INTERNAL_ERROR — which describes whether the call connected.
   SMS has no equivalent.

   Sending SUCCESS would tell Artiva a call connected. Left empty rather than
   reusing a voice code.

   ASK MADAN: what TermCode should an SMS carry? It is a different axis from
   OUTCOME — one is "did it connect", the other is "what was the result".


THE ACCOUNT ID RULE IS DIFFERENT FROM THE WEBEX ONE
---------------------------------------------------
Artiva wants:

    SystemID 1 (RM)  ->  accInfo.AccountID
    otherwise        ->  accInfo.SelfPayID

That is NOT the DBID_LeadAccount form used when sending TO Webex. Different
destination, different rule. Both are correct in their own direction — copied
from the call path so the two cannot drift.


ORDER OF WORK
-------------
1. Run I_00. Find out what channelType SMS actually is, and whether SMS has
   already been posted to Artiva as calls.
2. Run I_01 to create the table.
3. Add the entity, interface, service; register in DI and GD_Context.
4. Set Webex:SmsChannelTypes from what I_00 showed.
5. Add the split to ProcessTasks_V2 and the SMS path.
6. Watch CCX_SMSLog fill and CCX_CallLog stop taking non-telephony rows.
7. Only then wire the Artiva post, once that endpoint exists.
