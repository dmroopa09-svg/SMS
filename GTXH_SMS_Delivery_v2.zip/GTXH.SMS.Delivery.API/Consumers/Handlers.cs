using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Services;
using GTXH.SMS.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTXH.SMS.Delivery.API.Consumers;

/// <summary>ReadyToSend → provider submit (or discard if cancelled).</summary>
public sealed class ReadyToSendHandler(DeliveryService service)
    : KafkaJsonHandler<ReadyToSendEvent>
{
    public override string Topic => Topics.ReadyToSend;
    public override string GroupId => "delivery-ready";

    protected override Task HandleAsync(string key, ReadyToSendEvent message, CancellationToken cancellationToken) =>
        service.HandleReadyAsync(message, cancellationToken);
}
