namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Paces submissions so this instance does not exceed the provider's per-second
/// ceiling.
///
/// Kafka hands messages to the consumer as fast as it can read them. Without
/// pacing, a backlog of 10,000 ReadyToSend events becomes 10,000 near-
/// simultaneous HTTP calls, and the consequence is throttling or suspension of
/// the account — which stops every campaign, not just this one.
///
/// ⚠ THIS IS PER INSTANCE, NOT GLOBAL. Three delivery instances at 10/second
/// each send 30/second. If the provider ceiling is a hard account-wide figure,
/// either divide it by the expected instance count or run one instance.
///
/// A genuinely global limit needs a shared counter — Redis is already in the
/// solution and would do it — but that is worth doing only once the real
/// provider limit is known, rather than guessing at a number to enforce.
/// </summary>
public sealed class DeliveryRateLimiter : IDisposable
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly int _minGapMs;
    private DateTime _lastSendUtc = DateTime.MinValue;

    public DeliveryRateLimiter(DeliveryOptions options)
    {
        var perSecond = Math.Max(1, options.MaxPerSecond);
        _minGapMs = 1000 / perSecond;
    }

    public async Task WaitAsync(CancellationToken ct)
    {
        await _gate.WaitAsync(ct);
        try
        {
            var elapsed = (int)(DateTime.UtcNow - _lastSendUtc).TotalMilliseconds;
            var wait = _minGapMs - elapsed;
            if (wait > 0)
                await Task.Delay(wait, ct);

            _lastSendUtc = DateTime.UtcNow;
        }
        finally
        {
            _gate.Release();
        }
    }

    public void Dispose() => _gate.Dispose();
}
