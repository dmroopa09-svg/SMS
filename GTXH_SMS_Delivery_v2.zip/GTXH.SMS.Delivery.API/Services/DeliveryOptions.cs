namespace GTXH.SMS.Delivery.API.Services;

/// <summary>Delivery configuration. Bound from the "Delivery" section.</summary>
public sealed class DeliveryOptions
{
    public const string SectionName = "Delivery";

    /// <summary>Base URL, e.g. https://hooks.us.webexconnect.io/</summary>
    public string BaseUrl { get; set; } = "";

    /// <summary>
    /// Relative path to the flow trigger, e.g. events/OA3ZL2N9FJ
    ///
    /// From settings for now, per the design discussion. Once flows are split
    /// per client this moves to the campaign — the FROM number is currently
    /// hardcoded inside the flow, so one flow means one sender number for
    /// every client.
    /// </summary>
    public string FlowTriggerPath { get; set; } = "";

    /// <summary>
    /// When true, NOTHING is sent. DEFAULTS TO TRUE, so a deployment that
    /// forgets to configure delivery cannot message real people.
    /// </summary>
    public bool DryRun { get; set; } = true;

    /// <summary>
    /// When set, EVERY message goes to this number regardless of the recipient.
    /// The client-side twin of the filter on the Webex side — two independent
    /// nets rather than one.
    ///
    /// The intended recipient is logged each time, so a test can still verify
    /// the right person WOULD have been messaged.
    /// </summary>
    public string? RedirectAllToNumber { get; set; }

    /// <summary>
    /// Hard ceiling on submissions in this process's lifetime. 0 = no limit.
    /// A loop bug cannot exceed it regardless of queue size. Reset by restart.
    /// </summary>
    public int MaxSendsPerProcess { get; set; } = 25;

    /// <summary>
    /// ⚠ PER INSTANCE, NOT GLOBAL. Three instances at 10 each send 30/second.
    /// If the provider ceiling is account-wide, divide it or run one instance.
    /// </summary>
    public int MaxPerSecond { get; set; } = 10;

    /// <summary>Attempts before a message is given up on and marked Failed.</summary>
    public int MaxAttempts { get; set; } = 3;

    public int TimeoutSeconds { get; set; } = 30;

    // ---- retry worker ----

    /// <summary>
    /// Disabling this means transient failures are never retried and those
    /// messages never send. Only turn it off knowing that.
    /// </summary>
    public bool RetryEnabled { get; set; } = true;

    public int RetryPollSeconds { get; set; } = 30;

    /// <summary>
    /// How long after a failed attempt before retrying. A flat delay rather than
    /// exponential backoff — the failures being retried here are provider blips
    /// measured in seconds, and a growing delay would mostly serve to push
    /// messages past their send window.
    /// </summary>
    public int RetryBackoffSeconds { get; set; } = 120;

    public int RetryBatchSize { get; set; } = 50;

    /// <summary>
    /// A claimed row older than this is reclaimable — recovers work from an
    /// instance that died mid-retry. Must be comfortably longer than the worst
    /// realistic send, or a slow send gets retried while still in flight.
    /// </summary>
    public int RetryClaimTimeoutSeconds { get; set; } = 300;
}
