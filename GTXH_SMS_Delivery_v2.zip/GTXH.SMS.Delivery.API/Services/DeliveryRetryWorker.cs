using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Retries messages that compliance released but delivery never successfully
/// submitted.
///
/// WHY THIS HAS TO EXIST
/// ---------------------
/// Without it, a transient failure is a silent loss.
///
/// When Webex times out or returns a 5xx, DeliveryService leaves the row at
/// Pending and deliberately does NOT write a submission row, so a retry remains
/// possible. But nothing was retrying it: compliance had already released the
/// hold and moved on, and the Kafka message was consumed. Those rows sat at
/// Pending forever, looking queued, never moving, with nothing reporting a
/// problem.
///
/// A provider blip of a few seconds would have quietly stranded every message
/// in flight at that moment.
///
/// WHAT IT PICKS UP
/// ----------------
///   LifecycleState = ReadyForDelivery   compliance released it
///   Sent_Timestamp_UTC is null          never successfully sent
///   no row in SMS_Delivery_Submission   no terminal outcome recorded
///   attempts < MaxAttempts              not exhausted
///   last attempt older than the backoff  (or never attempted)
///   campaign still Ready or Running     a stopped campaign is not resumed
///
/// The last condition matters: a campaign stopped an hour ago must not start
/// sending again because its retries matured.
///
/// It also covers a case that is not a failure at all — an event Kafka never
/// delivered, or one lost because the consumer died before committing. Those
/// rows look identical from here, and the same sweep recovers them.
/// </summary>
public sealed class DeliveryRetryWorker(
    IServiceScopeFactory scopeFactory,
    DeliveryOptions options,
    ILogger<DeliveryRetryWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!options.RetryEnabled)
        {
            logger.LogWarning(
                "Delivery retry worker is DISABLED. Transient failures will not be retried "
                + "and those messages will never send.");
            return;
        }

        logger.LogInformation(
            "Delivery retry worker started. Every {Poll}s, backoff {Backoff}s, max {Max} attempts.",
            options.RetryPollSeconds, options.RetryBackoffSeconds, options.MaxAttempts);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var retried = await RunOnceAsync(stoppingToken);

                if (retried > 0)
                    logger.LogInformation("Retried {Count} message(s).", retried);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Delivery retry sweep failed.");
            }

            try
            {
                await Task.Delay(TimeSpan.FromSeconds(options.RetryPollSeconds), stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }

        logger.LogInformation("Delivery retry worker stopping.");
    }

    private async Task<int> RunOnceAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DeliveryDbContext>();
        var delivery = scope.ServiceProvider.GetRequiredService<DeliveryService>();

        var candidates = await ClaimAsync(db, ct);
        if (candidates.Count == 0)
            return 0;

        var retried = 0;

        foreach (var c in candidates)
        {
            if (ct.IsCancellationRequested)
                break;

            // Rebuild the event from the row. HandleReadyAsync re-checks
            // everything — idempotency, campaign state, content — so a row that
            // became ineligible since it was claimed is handled correctly
            // without duplicating those checks here.
            var evt = new ReadyToSendEvent
            {
                MessageId = c.MessageId,
                CampaignQueueId = c.CampaignQueueId,
                CampaignId = c.CampaignId,
                Phone = c.Phone ?? "",
                Account_Info_ID = c.AccountInfoId,
                TemplateId = c.TemplateId,
                ProducerService = ProducerServices.Delivery,
                IdempotencyKey = $"{c.MessageId}:Ready"   // same key as the original
            };

            await delivery.HandleReadyAsync(evt, ct);
            retried++;
        }

        return retried;
    }

    /// <summary>
    /// Claims rows atomically so two instances never retry the same message.
    ///
    /// Uses ClaimedAt on SMS_Queue_Detail, which already exists. A row whose
    /// ClaimedAt is older than the stale window is reclaimable — that recovers
    /// work from an instance that died mid-retry.
    ///
    /// READPAST makes a second instance skip rows the first holds rather than
    /// queue behind them, so instances stay independent.
    /// </summary>
    private async Task<List<RetryCandidate>> ClaimAsync(DeliveryDbContext db, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var backoffCutoff = now.AddSeconds(-options.RetryBackoffSeconds);
        var staleClaimCutoff = now.AddSeconds(-options.RetryClaimTimeoutSeconds);

        var readyForDelivery = (byte)MessageLifecycleState.ReadyForDelivery;
        var stateReady = (byte)CampaignState.Ready;
        var stateRunning = (byte)CampaignState.Running;

        return await db.Database
            .SqlQuery<RetryCandidate>($"""
                UPDATE TOP ({options.RetryBatchSize}) d
                SET    d.ClaimedAt = {now}
                OUTPUT inserted.ID                AS MessageId,
                       inserted.SMSQueue_Mst_ID   AS CampaignQueueId,
                       inserted.Phone             AS Phone,
                       inserted.Account_Info_ID   AS AccountInfoId,
                       m.Campaign_Mstr_ID         AS CampaignId,
                       m.TemplateId               AS TemplateId
                FROM   dbo.SMS_Queue_Detail AS d WITH (ROWLOCK, UPDLOCK, READPAST)
                INNER  JOIN dbo.SMS_Queue_Mst AS m
                       ON m.ID = d.SMSQueue_Mst_ID
                LEFT   JOIN dbo.SMS_Delivery_Submission AS s
                       ON s.MessageId = d.ID
                OUTER  APPLY (
                       SELECT COUNT(*)              AS Attempts,
                              MAX(a.AttemptedAtUtc) AS LastAttempt
                       FROM   dbo.SMS_Delivery_Attempt AS a
                       WHERE  a.MessageId = d.ID
                ) AS att
                WHERE  d.LifecycleState     = {readyForDelivery}
                  AND  d.Sent_Timestamp_UTC IS NULL
                  AND  s.ID                 IS NULL
                  AND  m.State IN ({stateReady}, {stateRunning})
                  AND  ISNULL(att.Attempts, 0) < {options.MaxAttempts}
                  AND  (att.LastAttempt IS NULL OR att.LastAttempt <= {backoffCutoff})
                  AND  (d.ClaimedAt IS NULL OR d.ClaimedAt <= {staleClaimCutoff})
                """)
            .ToListAsync(ct);
    }

    /// <summary>Shape returned by the claim. Names must match the OUTPUT aliases.</summary>
    public sealed class RetryCandidate
    {
        public long MessageId { get; set; }
        public long CampaignQueueId { get; set; }
        public string? Phone { get; set; }
        public long? AccountInfoId { get; set; }
        public int CampaignId { get; set; }
        public int TemplateId { get; set; }
    }
}
