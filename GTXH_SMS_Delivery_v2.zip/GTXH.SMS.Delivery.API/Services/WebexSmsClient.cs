using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace GTXH.SMS.Delivery.API.Services;

public sealed class WebexSendResult
{
    public bool Accepted { get; init; }

    /// <summary>Webex transid. Delivery receipts key on this.</summary>
    public string? ProviderMessageId { get; init; }

    public string? ResponseCode { get; init; }
    public string? ResponseMessage { get; init; }

    /// <summary>Whether retrying could plausibly succeed.</summary>
    public bool IsTransient { get; init; }

    public int DurationMs { get; init; }

    public static WebexSendResult Ok(string? id, string? code, int ms) => new()
    { Accepted = true, ProviderMessageId = id, ResponseCode = code, DurationMs = ms };

    public static WebexSendResult Transient(string msg, string? code, int ms) => new()
    { Accepted = false, ResponseMessage = msg, ResponseCode = code, IsTransient = true, DurationMs = ms };

    public static WebexSendResult Permanent(string msg, string? code, int ms) => new()
    { Accepted = false, ResponseMessage = msg, ResponseCode = code, IsTransient = false, DurationMs = ms };
}

public sealed class WebexSendRequest
{
    public string SmsId { get; init; } = "";
    public string Phone { get; init; } = "";
    public string MessageText { get; init; } = "";
    public string? ZipCode { get; init; }
    public string? LeadAccountNumber { get; init; }
    public string? AccountId { get; init; }
}

public interface IWebexSmsClient
{
    Task<WebexSendResult> SendAsync(WebexSendRequest request, CancellationToken ct);
}

/// <summary>
/// Posts to a Webex Connect flow trigger.
///
/// THE CONTRACT BELOW IS OBSERVED, NOT GUESSED. It matches a request made by
/// hand in Postman that delivered a real message:
///
///     POST https://hooks.us.webexconnect.io/events/{flowTriggerId}
///     {
///       "SMSID":   "0712222",
///       "SMSTEXT": "Hello ...",
///       "Phone":   "7134002666",
///       "ZIPCODE": "77478",
///       "DBID_LeadAccountNumber": "..."
///     }
///
///     -> { "response": [ { "code": "1002",
///                          "description": "Queued",
///                          "transid": "80462c1e-..." } ] }
///
/// WHAT "QUEUED" DOES NOT MEAN. Code 1002 confirms Connect accepted the request.
/// It does NOT mean the carrier accepted it, and it does NOT mean a handset
/// received it. Reporting it as delivered would overstate every figure the
/// system produces. Real delivery is only known from a receipt, which needs the
/// Notify URL configured on the SMS node — it currently is not.
///
/// ⚠ THE TRIGGER URL IS THE ONLY CREDENTIAL. Signature validation is switched
/// off on the flow, so anyone holding this URL can send arbitrary text from the
/// registered business number. Treat it as a secret.
/// </summary>
public sealed class WebexSmsClient(
    HttpClient http,
    DeliveryOptions options,
    ILogger<WebexSmsClient> logger) : IWebexSmsClient
{
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public async Task<WebexSendResult> SendAsync(WebexSendRequest request, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();

        var payload = new WebexPayload
        {
            SMSID = request.SmsId,
            SMSTEXT = request.MessageText,
            Phone = request.Phone,
            ZIPCODE = request.ZipCode,
            DBID_LeadAccountNumber = request.LeadAccountNumber,
            AccountID = request.AccountId
        };

        var json = JsonSerializer.Serialize(payload, JsonOpts);
        using var content = new StringContent(json, Encoding.UTF8, "application/json");

        HttpResponseMessage response;
        try
        {
            response = await http.PostAsync(options.FlowTriggerPath, content, ct);
        }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested)
        {
            sw.Stop();
            // The dangerous case: the message MAY have been sent and the
            // acknowledgement lost. Retrying could duplicate — which is exactly
            // why the idempotency key is enforced before we get here.
            logger.LogWarning(
                "Webex timed out for ***{Last4}. The message MAY have been sent; "
                + "a retry could duplicate it.", Last4(request.Phone));
            return WebexSendResult.Transient("Request timed out.", null, (int)sw.ElapsedMilliseconds);
        }
        catch (HttpRequestException ex)
        {
            sw.Stop();
            return WebexSendResult.Transient("Transport failure: " + ex.Message, null, (int)sw.ElapsedMilliseconds);
        }

        var body = await SafeReadAsync(response, ct);
        sw.Stop();
        var ms = (int)sw.ElapsedMilliseconds;

        if (!response.IsSuccessStatusCode)
        {
            var status = (int)response.StatusCode;

            // 429 and 5xx may succeed later. Other 4xx will not — a malformed
            // request or a rejected credential does not improve with time.
            var transient = status == (int)HttpStatusCode.TooManyRequests || status >= 500;

            logger.LogWarning(
                "Webex HTTP {Status} for ***{Last4}: {Body}",
                status, Last4(request.Phone), Truncate(body, 200));

            return transient
                ? WebexSendResult.Transient($"HTTP {status}: {Truncate(body, 500)}", status.ToString(), ms)
                : WebexSendResult.Permanent($"HTTP {status}: {Truncate(body, 500)}", status.ToString(), ms);
        }

        WebexResponse? parsed;
        try
        {
            parsed = JsonSerializer.Deserialize<WebexResponse>(body);
        }
        catch
        {
            // HTTP 200 with an unreadable body. The message probably went;
            // treating it as a failure would retry and duplicate. Accept it — but
            // without a transid no delivery receipt can ever be matched to it.
            logger.LogWarning(
                "Webex accepted ***{Last4} but the response could not be parsed: {Body}",
                Last4(request.Phone), Truncate(body, 200));
            return WebexSendResult.Ok(null, null, ms);
        }

        var first = parsed?.Response is { Length: > 0 } ? parsed.Response[0] : null;
        if (first is null)
            return WebexSendResult.Ok(null, null, ms);

        // 1002 "Queued" is the only code confirmed from testing.
        if (first.Code == "1002")
            return WebexSendResult.Ok(first.TransId, first.Code, ms);

        // Anything else is uncatalogued. Treated as TRANSIENT so a genuinely
        // temporary condition is retried — bounded by the attempt cap, so a
        // permanent failure costs a few tries rather than looping forever.
        //
        // Run the query in Scripts/UnknownResponseCodes.sql occasionally to see
        // what has actually been returned, and tighten this as codes are known.
        logger.LogWarning(
            "Webex returned uncatalogued code {Code} ({Description}) for ***{Last4}. "
            + "Treated as transient.",
            first.Code, first.Description, Last4(request.Phone));

        return WebexSendResult.Transient(
            $"Provider code {first.Code}: {first.Description}", first.Code, ms);
    }

    private static async Task<string> SafeReadAsync(HttpResponseMessage r, CancellationToken ct)
    {
        try { return await r.Content.ReadAsStringAsync(ct); }
        catch { return ""; }
    }

    private static string Truncate(string? s, int max)
        => string.IsNullOrEmpty(s) ? "" : (s.Length > max ? s[..max] : s);

    /// <summary>
    /// Last four digits only. Full numbers in logs are patient contact details,
    /// and logs usually have wider access than the database does.
    /// </summary>
    private static string Last4(string? phone)
        => string.IsNullOrEmpty(phone) || phone.Length < 4 ? "****" : phone[^4..];

    private sealed class WebexPayload
    {
        [JsonPropertyName("SMSID")] public string SMSID { get; set; } = "";
        [JsonPropertyName("SMSTEXT")] public string SMSTEXT { get; set; } = "";
        [JsonPropertyName("Phone")] public string Phone { get; set; } = "";
        [JsonPropertyName("ZIPCODE")] public string? ZIPCODE { get; set; }
        [JsonPropertyName("DBID_LeadAccountNumber")] public string? DBID_LeadAccountNumber { get; set; }

        // Added per the design discussion so the status callback can be matched
        // back to an account without a second lookup.
        [JsonPropertyName("AccountID")] public string? AccountID { get; set; }
    }

    private sealed class WebexResponse
    {
        [JsonPropertyName("response")] public WebexResponseItem[]? Response { get; set; }
    }

    private sealed class WebexResponseItem
    {
        [JsonPropertyName("code")] public string? Code { get; set; }
        [JsonPropertyName("description")] public string? Description { get; set; }
        [JsonPropertyName("transid")] public string? TransId { get; set; }
    }
}

/// <summary>
/// Sends nothing and reports success. THE DEFAULT, so a misconfigured
/// deployment cannot message real people by accident.
/// </summary>
public sealed class DryRunSmsClient(ILogger<DryRunSmsClient> logger) : IWebexSmsClient
{
    public Task<WebexSendResult> SendAsync(WebexSendRequest request, CancellationToken ct)
    {
        logger.LogInformation(
            "[DRY RUN] would send {Chars} chars to ***{Last4}. NOTHING WAS SENT.",
            request.MessageText?.Length ?? 0,
            request.Phone.Length >= 4 ? request.Phone[^4..] : "****");

        return Task.FromResult(WebexSendResult.Ok(
            "dryrun-" + Guid.NewGuid().ToString("N")[..12], "1002", 0));
    }
}
