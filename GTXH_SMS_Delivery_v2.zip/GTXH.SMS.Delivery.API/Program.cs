using GTXH.SMS.Delivery.API.Consumers;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Delivery.API.Services;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddSmsMessaging(builder.Configuration);
builder.Services.AddKafkaHandler<ReadyToSendHandler>();

var conn = builder.Configuration.GetConnectionString("DeliveryDb");

builder.Services.AddDbContext<DeliveryDbContext>(options =>
    options.UseSqlServer(
        conn,
        sql => sql.UseCompatibilityLevel(110)));

var deliveryOptions = new DeliveryOptions();
builder.Configuration.GetSection(DeliveryOptions.SectionName).Bind(deliveryOptions);
builder.Services.AddSingleton(deliveryOptions);

// Singleton so the same pacing applies across every consumed message.
builder.Services.AddSingleton<DeliveryRateLimiter>();

// ---------------------------------------------------------------------------
// DRY RUN IS THE DEFAULT.
//
// Delivery is the only service that talks to a live API which sends the instant
// it is called. A deployment that forgets to configure it should fail to send,
// not send to real people.
// ---------------------------------------------------------------------------
if (deliveryOptions.DryRun)
{
    builder.Services.AddSingleton<IWebexSmsClient, DryRunSmsClient>();
}
else
{
    if (string.IsNullOrWhiteSpace(deliveryOptions.BaseUrl)
        || string.IsNullOrWhiteSpace(deliveryOptions.FlowTriggerPath))
    {
        // Refuse to start rather than start in a state where every send fails in
        // a way that looks like a provider problem.
        throw new InvalidOperationException(
            "Delivery:DryRun is false but BaseUrl or FlowTriggerPath is not configured. "
            + "Set both, or leave DryRun true.");
    }

    builder.Services.AddHttpClient<IWebexSmsClient, WebexSmsClient>(c =>
    {
        c.BaseAddress = new Uri(deliveryOptions.BaseUrl);
        c.Timeout = TimeSpan.FromSeconds(deliveryOptions.TimeoutSeconds);
    });
}

builder.Services.AddScoped<DeliveryService>();
builder.Services.AddHostedService<DeliveryRetryWorker>();

var host = builder.Build();

// Startup banner. The difference between dry run and live is the difference
// between a test and messaging patients, and it should never be something
// someone has to go and check.
var log = host.Services.GetRequiredService<ILogger<Program>>();

if (deliveryOptions.DryRun)
{
    log.LogWarning("DELIVERY IS IN DRY RUN. No messages will be sent.");
}
else
{
    log.LogWarning(
        "DELIVERY IS LIVE. Endpoint {Url}{Path}, max {Max} sends this process, {Rate}/second.",
        deliveryOptions.BaseUrl, deliveryOptions.FlowTriggerPath,
        deliveryOptions.MaxSendsPerProcess, deliveryOptions.MaxPerSecond);

    if (!string.IsNullOrWhiteSpace(deliveryOptions.RedirectAllToNumber))
        log.LogWarning(
            "TEST REDIRECT ACTIVE — every message goes to {Number} regardless of recipient.",
            deliveryOptions.RedirectAllToNumber);
    else
        log.LogWarning("NO TEST REDIRECT — messages will go to REAL RECIPIENTS.");
}

host.Run();
