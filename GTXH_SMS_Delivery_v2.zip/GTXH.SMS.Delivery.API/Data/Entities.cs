using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GTXH.SMS.Delivery.API.Data;

/// <summary>
/// One row per LOGICAL MESSAGE that reached a terminal delivery outcome.
/// UNIQUE on IdempotencyKey — this is the guard that stops a replayed
/// ReadyToSend becoming a second text.
///
/// Compliance publishes BEFORE it persists the hold as Released, so a crash
/// there republishes after the claim timeout. Kafka also redelivers on
/// rebalance. Both are normal, both arrive here, and this index is what stops
/// them reaching a real person twice.
///
/// TRANSIENT failures are deliberately NOT written here — see
/// DeliveryAttemptEntity. Writing one would permanently block the retry.
/// </summary>
[Table("SMS_Delivery_Submission")]
public sealed class DeliverySubmissionEntity
{
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long ID { get; set; }

    [Required]
    [StringLength(100)]
    public string IdempotencyKey { get; set; } = "";

    public long MessageId { get; set; }
    public long CampaignQueueId { get; set; }
    public int CampaignId { get; set; }

    [StringLength(15)]
    public string? Phone { get; set; }

    /// <summary>Webex transid. Delivery receipts key on this.</summary>
    [StringLength(128)]
    public string? ProviderMessageId { get; set; }

    [StringLength(20)]
    public string? ResponseCode { get; set; }

    [StringLength(1000)]
    public string? ResponseMessage { get; set; }

    public bool Succeeded { get; set; }

    [StringLength(100)]
    public string? InstanceId { get; set; }

    public int DurationMs { get; set; }

    public DateTime SubmittedAtUtc { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// One row per ATTEMPT, including the transient failures that never reach the
/// submission table.
///
/// WHY THIS IS SEPARATE FROM SUBMISSION, and why both are needed:
///
///   Submission   at most ONE row per message. Unique. The idempotency guard.
///   Attempt      MANY rows per message. No unique constraint. The history.
///
/// The retry worker counts rows here to know how many times a message has been
/// tried, and reads the newest to know when to try again. Putting transient
/// failures in the submission table instead would block the retry permanently —
/// the guard would fire on our own earlier failure.
///
/// It is also the only place that answers "why did this fail?" for anything
/// other than the last attempt.
/// </summary>
[Table("SMS_Delivery_Attempt")]
public sealed class DeliveryAttemptEntity
{
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long ID { get; set; }

    public long MessageId { get; set; }
    public long CampaignQueueId { get; set; }

    public int AttemptNumber { get; set; }

    public bool Succeeded { get; set; }

    /// <summary>True when the failure is worth retrying.</summary>
    public bool IsTransient { get; set; }

    [StringLength(20)]
    public string? ResponseCode { get; set; }

    [StringLength(1000)]
    public string? ResponseMessage { get; set; }

    [StringLength(128)]
    public string? ProviderMessageId { get; set; }

    [StringLength(100)]
    public string? InstanceId { get; set; }

    public int DurationMs { get; set; }

    public DateTime AttemptedAtUtc { get; set; } = DateTime.UtcNow;
}
