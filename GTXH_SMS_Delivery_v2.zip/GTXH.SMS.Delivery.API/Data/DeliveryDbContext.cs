using GTXH.SMS.Common;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Data;

public sealed class DeliveryDbContext(DbContextOptions<DeliveryDbContext> options) : DbContext(options)
{
    /// <summary>SMS_Queue_Detail — message text, phone and zip live here.</summary>
    public DbSet<CampaignMemberEntity> CampaignMembers => Set<CampaignMemberEntity>();

    /// <summary>SMS_Queue_Mst — campaign state, checked before every send.</summary>
    public DbSet<CampaignQueueEntity> CampaignQueue => Set<CampaignQueueEntity>();

    /// <summary>At most one row per message. The idempotency guard.</summary>
    public DbSet<DeliverySubmissionEntity> Submissions => Set<DeliverySubmissionEntity>();

    /// <summary>Many rows per message. History, and the retry counter.</summary>
    public DbSet<DeliveryAttemptEntity> Attempts => Set<DeliveryAttemptEntity>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CampaignMemberEntity>(e =>
        {
            e.ToTable("SMS_Queue_Detail");
            e.HasKey(x => x.ID);
            e.Property(x => x.Status).HasConversion<byte>();
            e.Property(x => x.LifecycleState).HasConversion<byte>();
        });

        modelBuilder.Entity<CampaignQueueEntity>(e =>
        {
            e.ToTable("SMS_Queue_Mst");
            e.HasKey(x => x.ID);
            e.Property(x => x.State).HasConversion<byte>();
        });

        modelBuilder.Entity<DeliverySubmissionEntity>(e =>
        {
            e.ToTable("SMS_Delivery_Submission");
            e.HasKey(x => x.ID);

            // THE GUARD. A second submission of the same logical message fails
            // at the database rather than becoming a second text.
            e.HasIndex(x => x.IdempotencyKey).IsUnique();

            e.HasIndex(x => x.MessageId);
            e.HasIndex(x => x.ProviderMessageId);
        });

        modelBuilder.Entity<DeliveryAttemptEntity>(e =>
        {
            e.ToTable("SMS_Delivery_Attempt");
            e.HasKey(x => x.ID);

            // Deliberately NOT unique — many attempts per message is the point.
            e.HasIndex(x => new { x.MessageId, x.AttemptedAtUtc });
        });
    }
}
