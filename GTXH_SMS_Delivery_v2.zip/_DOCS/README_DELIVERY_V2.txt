DELIVERY SERVICE — with retry
=============================

Replaces the earlier delivery zip entirely. Do not apply both.


RUN FIRST
---------
    Scripts/D_01_Delivery_Tables.sql

Creates TWO tables. The split is the important part:

    SMS_Delivery_Submission   at most ONE row per message. UNIQUE on
                              IdempotencyKey. Stops a replayed ReadyToSend
                              becoming a second text.

    SMS_Delivery_Attempt      MANY rows per message. No unique constraint.
                              History, and the counter the retry worker reads.

Transient failures go ONLY to the attempt table. Writing one into the
submission table would permanently block the retry — the guard would fire on our
own earlier failure.


⚠ ONE THING TO CONFIRM BEFORE BUILDING
--------------------------------------
DeliveryRetryWorker uses ProducerServices.Delivery when rebuilding the event.
Compliance uses ProducerServices.Compliance, so the type exists — but confirm it
has a Delivery member. If not, use whatever the equivalent is.

Everything else was checked against the enums you sent. All members used exist:
    CampaignMemberStatus  Emitted, Pending, Skipped
    CampaignState         Ready, Running
    MessageLifecycleState Submitted, Failed, ReadyForDelivery,
                          TerminatedCompliance, RejectedEligibility


=============================================================================
WHAT CHANGED FROM THE FIRST VERSION
=============================================================================

1. RETRY WORKER — the gap that mattered
---------------------------------------
Previously a transient failure left the row at Pending and NOTHING retried it.
Compliance had already released the hold and moved on; the Kafka message was
consumed. Those rows sat forever, looking queued, never moving, with nothing
reporting a problem.

A provider blip of a few seconds would have quietly stranded every message in
flight at that moment.

DeliveryRetryWorker sweeps for:
    LifecycleState = ReadyForDelivery      compliance released it
    Sent_Timestamp_UTC is null             never successfully sent
    no submission row                      no terminal outcome
    attempts < MaxAttempts                 not exhausted
    last attempt older than the backoff
    campaign still Ready or Running        a stopped campaign is not resumed

That last condition matters: a campaign stopped an hour ago must not start
sending again because its retries matured.

It also recovers a case that is not a failure at all — an event Kafka never
delivered, or one lost because the consumer died before committing. Those rows
look identical from here and the same sweep picks them up.

CLAIMING is atomic, using ClaimedAt on SMS_Queue_Detail with UPDLOCK/READPAST,
so two instances never retry the same message. A claim older than
RetryClaimTimeoutSeconds is reclaimable, which recovers work from an instance
that died mid-retry.

BACKOFF IS FLAT (120s), not exponential. The failures being retried here are
provider blips measured in seconds; a growing delay would mostly serve to push
messages past their send window.


2. LIFECYCLE STATES NOW SET
---------------------------
    accepted by provider   -> Submitted (6)
    terminal failure       -> Failed (8)
    transient, retryable   -> stays ReadyForDelivery (10)

Previously a sent row still read ReadyForDelivery, which made the pipeline state
ambiguous and would have confused the retry sweep.


3. MAXATTEMPTS IS NO LONGER DEAD CONFIG
---------------------------------------
It was read and never used, because there was no retry loop to bound. It now
does what it says: after MaxAttempts the message is marked Failed and the retry
worker stops picking it up.


4. TERMINATED MESSAGES CANNOT BE SENT
-------------------------------------
A row at TerminatedCompliance or RejectedEligibility is refused even if a stale
event for it is replayed. Compliance decided that message must not go out, and a
replay should not undo that.


5. DIAGNOSTICS QUERY CORRECTED
------------------------------
The earlier version checked h.Status = 2 for released holds. HoldStatus.Released
is 1 — 2 is Terminated. That query would have shown terminated holds and hidden
the real problem. Fixed, and every enum value is now spelled out at the top of
the script.


=============================================================================
SAFETY — UNCHANGED, AND STILL THE DEFAULT
=============================================================================

Three independent brakes, because the cost of getting this wrong is a message to
a real patient.

1. DryRun = true by default. Sends nothing.
2. RedirectAllToNumber sends everything to one handset regardless of recipient —
   the client-side twin of the Webex-side filter. The intended recipient is
   logged each time, so a test can still verify the right person WOULD have been
   messaged.
3. MaxSendsPerProcess = 25. A loop bug cannot exceed it. Reset by restarting.

The startup banner states the mode loudly, including a warning when there is NO
redirect and messages will reach real recipients.

RECOMMENDED FIRST LIVE TEST
    DryRun              false
    RedirectAllToNumber your own handset
    MaxSendsPerProcess  5
    MaxPerSecond        1


=============================================================================
STILL OUTSTANDING — NOT CODE
=============================================================================

NOTIFY URL IS EMPTY
    No delivery receipts arrive at all, so nothing ever reaches Delivered (7).
    Everything stops at Submitted (6). Until it is set, delivery RATE is not
    measurable — only submission rate.

    Note what code 1002 "Queued" does and does not mean: Connect accepted the
    request. Not that the carrier accepted it, and not that a handset received
    it. Reporting it as delivered would overstate every figure the system
    produces.

CORRELATION ID UNTESTED
    If two instances process the same replayed event at the same instant, both
    may call the provider before either writes the submission row. The loser
    logs a warning saying a duplicate may have gone out.

    Only provider-side deduplication closes that fully. The Connect SMS node has
    an unused Correlation ID field. Sending the same value twice and counting
    what arrives settles it in five minutes, and the answer decides whether that
    residual risk can be closed or has to be accepted explicitly.

FROM NUMBER IS HARDCODED IN THE FLOW
    So one flow means one sender number for every client. A Connect-side change,
    not code. FlowTriggerPath is in settings for now and moves to the campaign
    once flows are split per client.

THE "25 LIMIT" IS AMBIGUOUS
    Implemented as MaxSendsPerProcess = 25, reading it as a testing cap. If it
    meant 25 per API call, or 25 per second at the Webex account, that is a
    different control. Worth one line of confirmation before going live.


=============================================================================
HOW TO TEST
=============================================================================

1. Run D_01_Delivery_Tables.sql
2. DryRun = true. Confirm rows move to Submitted with dryrun- transids.
3. THE REPLAY TEST — publish the same ReadyToSend event twice. The second must
   log "Duplicate ReadyToSend ignored" and produce exactly ONE submission row.
   This single test proves the guard works and is worth running before anything
   goes near production volume.
4. THE RETRY TEST — set FlowTriggerPath to a bad value so sends fail, let a
   message fail, then fix the path. Within RetryBackoffSeconds the retry worker
   should pick it up and succeed. Query 4 in D_02_Diagnostics.sql shows what is
   pending retry.
5. DryRun = false, RedirectAllToNumber to your handset, MaxSendsPerProcess = 5.
6. Run the diagnostics — query 2 must always return zero rows.

THE FILTER'S BLIND SPOT: because everything arrives at one handset, the handset
cannot tell you the RIGHT person would have got the RIGHT message. Queue three
recipients with visibly different names, then check each row's MessageText
against what arrived. A drifted merge — everyone getting the first recipient's
name — is invisible otherwise.
