/* ============================================================================
   DELIVERY DIAGNOSTICS
   ============================================================================
   Enum values used below, from GTXH.SMS.Common:

     MessageLifecycleState  New=0 Eligible=1 RejectedEligibility=2 Held=3
                            Ready=4 TerminatedCompliance=5 Submitted=6
                            Delivered=7 Failed=8 ComplianceWait=9
                            ReadyForDelivery=10

     HoldStatus             Held=0 Released=1 Terminated=2 Releasing=3

     CampaignState          Draft=0 Ready=1 Running=2 Paused=3 Cancelled=4
                            Archived=5 Completed=6
   ============================================================================ */

/* ---------------------------------------------------------------------------
   1. Recent submissions
   --------------------------------------------------------------------------- */
SELECT TOP (50)
       s.MessageId, s.Phone, s.Succeeded, s.ResponseCode, s.ResponseMessage,
       s.ProviderMessageId, s.DurationMs, s.InstanceId, s.SubmittedAtUtc
FROM   dbo.SMS_Delivery_Submission s
ORDER  BY s.SubmittedAtUtc DESC;


/* ---------------------------------------------------------------------------
   2. THE ONE THAT MATTERS — did anyone get messaged twice?

   Must always return zero rows. The unique index makes a duplicate submission
   impossible, so anything here means a row was created by a path that bypassed
   it.
   --------------------------------------------------------------------------- */
SELECT   MessageId, COUNT(*) AS Submissions
FROM     dbo.SMS_Delivery_Submission
GROUP BY MessageId
HAVING   COUNT(*) > 1;


/* ---------------------------------------------------------------------------
   3. Same PERSON messaged twice today.

   Different from the above: this catches one person reached through two
   different queue rows, which the idempotency key cannot see because they are
   different logical messages.
   --------------------------------------------------------------------------- */
SELECT   s.Phone, COUNT(*) AS Sends,
         MIN(s.SubmittedAtUtc) AS FirstSend, MAX(s.SubmittedAtUtc) AS LastSend
FROM     dbo.SMS_Delivery_Submission s
WHERE    s.Succeeded = 1
  AND    s.SubmittedAtUtc >= CAST(CAST(SYSUTCDATETIME() AS DATE) AS DATETIME2)
GROUP BY s.Phone
HAVING   COUNT(*) > 1
ORDER BY COUNT(*) DESC;


/* ---------------------------------------------------------------------------
   4. What the retry worker will pick up on its next sweep.

   Rows compliance released that have no terminal outcome yet.
   --------------------------------------------------------------------------- */
SELECT   d.ID AS MessageId, d.Phone, d.RowUpdatedDt, d.ClaimedAt,
         ISNULL(att.Attempts, 0) AS Attempts,
         att.LastAttempt,
         d.ResponseMessage
FROM     dbo.SMS_Queue_Detail d
INNER    JOIN dbo.SMS_Queue_Mst m ON m.ID = d.SMSQueue_Mst_ID
LEFT     JOIN dbo.SMS_Delivery_Submission s ON s.MessageId = d.ID
OUTER    APPLY (SELECT COUNT(*) AS Attempts, MAX(a.AttemptedAtUtc) AS LastAttempt
                FROM dbo.SMS_Delivery_Attempt a WHERE a.MessageId = d.ID) att
WHERE    d.LifecycleState = 10            -- ReadyForDelivery
  AND    d.Sent_Timestamp_UTC IS NULL
  AND    s.ID IS NULL
  AND    m.State IN (1, 2)                -- Ready, Running
ORDER BY d.RowUpdatedDt;


/* ---------------------------------------------------------------------------
   5. Messages that exhausted their retries.

   These will NOT be picked up again. A rising count means something systemic —
   a bad flow trigger id, a rejected credential, a provider outage.
   --------------------------------------------------------------------------- */
SELECT   d.ID AS MessageId, d.Phone, d.ResponseCode, d.ResponseMessage,
         ISNULL(att.Attempts, 0) AS Attempts, d.RowUpdatedDt
FROM     dbo.SMS_Queue_Detail d
OUTER    APPLY (SELECT COUNT(*) AS Attempts
                FROM dbo.SMS_Delivery_Attempt a WHERE a.MessageId = d.ID) att
WHERE    d.LifecycleState = 8             -- Failed
ORDER BY d.RowUpdatedDt DESC;


/* ---------------------------------------------------------------------------
   6. Uncatalogued provider response codes.

   Only 1002 (Queued) is confirmed. Everything else is treated as transient so a
   genuinely temporary condition is retried. Run this occasionally and tighten
   WebexSmsClient as codes are identified.
   --------------------------------------------------------------------------- */
SELECT   ResponseCode,
         COUNT(*)                    AS Occurrences,
         SUM(CAST(Succeeded AS INT)) AS Succeeded,
         MIN(AttemptedAtUtc)         AS FirstSeen,
         MAX(AttemptedAtUtc)         AS LastSeen,
         MAX(ResponseMessage)        AS ExampleMessage
FROM     dbo.SMS_Delivery_Attempt
WHERE    ResponseCode IS NOT NULL AND ResponseCode <> '1002'
GROUP BY ResponseCode
ORDER BY COUNT(*) DESC;


/* ---------------------------------------------------------------------------
   7. Compliance released it but delivery never saw it.

   NOTE HoldStatus.Released = 1, not 2. (2 is Terminated — an earlier version of
   this query had it wrong and would have shown terminated holds instead.)

   A non-empty result older than a few minutes means events are published but
   not consumed: wrong topic, wrong group id, or the consumer is not running.
   The retry worker now covers this, so a persistent result here means the retry
   worker is not running either.
   --------------------------------------------------------------------------- */
SELECT TOP (50) h.MessageId, h.Phone, h.SendAt, h.UpdatedAt
FROM   dbo.SMS_Compliance_holds h
LEFT   JOIN dbo.SMS_Delivery_Attempt a ON a.MessageId = h.MessageId
WHERE  h.Status = 1                       -- Released
  AND  a.ID IS NULL
  AND  h.UpdatedAt < DATEADD(MINUTE, -5, SYSUTCDATETIME())
ORDER  BY h.UpdatedAt DESC;


/* ---------------------------------------------------------------------------
   8. Full pipeline state for one campaign queue.
   --------------------------------------------------------------------------- */
DECLARE @QueueId INT = 2;   -- change me

SELECT   d.LifecycleState,
         CASE d.LifecycleState
              WHEN 0 THEN 'New'          WHEN 1 THEN 'Eligible'
              WHEN 2 THEN 'RejectedEligibility'
              WHEN 3 THEN 'Held'         WHEN 4 THEN 'Ready'
              WHEN 5 THEN 'TerminatedCompliance'
              WHEN 6 THEN 'Submitted'    WHEN 7 THEN 'Delivered'
              WHEN 8 THEN 'Failed'       WHEN 9 THEN 'ComplianceWait'
              WHEN 10 THEN 'ReadyForDelivery'
              ELSE 'unknown' END AS StateName,
         COUNT(*) AS Rows,
         SUM(CASE WHEN d.Sent_Timestamp_UTC IS NOT NULL THEN 1 ELSE 0 END) AS Sent
FROM     dbo.SMS_Queue_Detail d
WHERE    d.SMSQueue_Mst_ID = @QueueId
GROUP BY d.LifecycleState
ORDER BY d.LifecycleState;
