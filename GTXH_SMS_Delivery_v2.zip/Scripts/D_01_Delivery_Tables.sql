/* ============================================================================
   DELIVERY TABLES
   ============================================================================

   TWO tables, and the split matters:

     SMS_Delivery_Submission   at most ONE row per message. UNIQUE on
                               IdempotencyKey. The guard that stops a replayed
                               ReadyToSend becoming a second text.

     SMS_Delivery_Attempt      MANY rows per message. No unique constraint.
                               History, and the counter the retry worker reads.

   Transient failures go ONLY to the attempt table. Writing one into the
   submission table would permanently block the retry - the guard would fire on
   our own earlier failure.

   Safe to run more than once.
   ============================================================================ */

SET NOCOUNT ON;
GO

IF OBJECT_ID('dbo.SMS_Delivery_Submission', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SMS_Delivery_Submission (
        ID                 BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_SMS_Delivery_Submission PRIMARY KEY,
        IdempotencyKey     VARCHAR(100)   NOT NULL,
        MessageId          BIGINT         NOT NULL,
        CampaignQueueId    BIGINT         NOT NULL,
        CampaignId         INT            NOT NULL,
        Phone              VARCHAR(15)    NULL,
        ProviderMessageId  NVARCHAR(128)  NULL,
        ResponseCode       VARCHAR(20)    NULL,
        ResponseMessage    NVARCHAR(1000) NULL,
        Succeeded          BIT            NOT NULL
            CONSTRAINT DF_SMSDS_Succeeded DEFAULT (0),
        InstanceId         VARCHAR(100)   NULL,
        DurationMs         INT            NOT NULL
            CONSTRAINT DF_SMSDS_DurationMs DEFAULT (0),
        SubmittedAtUtc     DATETIME2      NOT NULL
            CONSTRAINT DF_SMSDS_SubmittedAt DEFAULT SYSUTCDATETIME()
    );
    PRINT 'Created SMS_Delivery_Submission';
END
GO

/* THE GUARD. Without this the whole design leaks duplicates. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'UQ_SMSDS_IdempotencyKey'
                 AND object_id = OBJECT_ID('dbo.SMS_Delivery_Submission'))
BEGIN
    CREATE UNIQUE INDEX UQ_SMSDS_IdempotencyKey
        ON dbo.SMS_Delivery_Submission (IdempotencyKey);
    PRINT 'Created UQ_SMSDS_IdempotencyKey';
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSDS_MessageId'
                 AND object_id = OBJECT_ID('dbo.SMS_Delivery_Submission'))
    CREATE INDEX IX_SMSDS_MessageId ON dbo.SMS_Delivery_Submission (MessageId);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSDS_ProviderMessageId'
                 AND object_id = OBJECT_ID('dbo.SMS_Delivery_Submission'))
    CREATE INDEX IX_SMSDS_ProviderMessageId
        ON dbo.SMS_Delivery_Submission (ProviderMessageId)
        WHERE ProviderMessageId IS NOT NULL;
GO


IF OBJECT_ID('dbo.SMS_Delivery_Attempt', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SMS_Delivery_Attempt (
        ID                 BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_SMS_Delivery_Attempt PRIMARY KEY,
        MessageId          BIGINT         NOT NULL,
        CampaignQueueId    BIGINT         NOT NULL,
        AttemptNumber      INT            NOT NULL,
        Succeeded          BIT            NOT NULL
            CONSTRAINT DF_SMSDA_Succeeded DEFAULT (0),
        IsTransient        BIT            NOT NULL
            CONSTRAINT DF_SMSDA_IsTransient DEFAULT (0),
        ResponseCode       VARCHAR(20)    NULL,
        ResponseMessage    NVARCHAR(1000) NULL,
        ProviderMessageId  NVARCHAR(128)  NULL,
        InstanceId         VARCHAR(100)   NULL,
        DurationMs         INT            NOT NULL
            CONSTRAINT DF_SMSDA_DurationMs DEFAULT (0),
        AttemptedAtUtc     DATETIME2      NOT NULL
            CONSTRAINT DF_SMSDA_AttemptedAt DEFAULT SYSUTCDATETIME()
    );

    /* The retry worker reads this per message to count attempts and find the
       most recent one. Deliberately NOT unique. */
    CREATE INDEX IX_SMSDA_Message ON dbo.SMS_Delivery_Attempt (MessageId, AttemptedAtUtc);

    PRINT 'Created SMS_Delivery_Attempt';
END
GO

/* Supports the retry claim, which filters on LifecycleState and looks for rows
   with no send timestamp. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSQD_RetryScan'
                 AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
BEGIN
    CREATE INDEX IX_SMSQD_RetryScan
        ON dbo.SMS_Queue_Detail (LifecycleState, SMSQueue_Mst_ID)
        INCLUDE (Phone, Account_Info_ID, ClaimedAt, Sent_Timestamp_UTC);
    PRINT 'Created IX_SMSQD_RetryScan';
END
GO

PRINT '--- verify ---';
SELECT OBJECT_NAME(object_id) AS TableName, name AS IndexName, is_unique
FROM   sys.indexes
WHERE  object_id IN (OBJECT_ID('dbo.SMS_Delivery_Submission'),
                     OBJECT_ID('dbo.SMS_Delivery_Attempt'))
  AND  name IS NOT NULL
ORDER  BY TableName, IndexName;
GO
