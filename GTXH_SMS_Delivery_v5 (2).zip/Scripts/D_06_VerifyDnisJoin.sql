/* ============================================================================
   VERIFY THE DNIS JOIN
   ============================================================================
   Run this BEFORE testing. It shows exactly what the code will resolve for
   each campaign, so a wrong or missing number is visible here rather than in
   a message someone receives.
   ============================================================================ */

/* ---------------------------------------------------------------------------
   1. What the code will send as CampaignPHNumber.

   Same join as LoadCampaignAsync in DeliveryService.
   --------------------------------------------------------------------------- */
SELECT   m.ID                AS CampaignQueueId,
         m.Campaign_Mstr_ID,
         m.State,
         m.ExternalQueueID,
         d.ID                AS DnisId,
         d.DNIS              AS OutboundNumber,
         d.Name              AS DnisName,
         d.IsActive,
         CASE WHEN d.ID IS NULL THEN 'NO MATCH - will send without CampaignPHNumber'
              WHEN d.IsActive = 0 THEN 'INACTIVE - will send without CampaignPHNumber'
              ELSE 'ok' END  AS Result
FROM     dbo.SMS_Queue_Mst m
LEFT     JOIN dbo.Dnis d
         ON  CAST(d.ID AS VARCHAR(50)) = CAST(m.ExternalQueueID AS VARCHAR(50))
         AND d.IsActive = 1
WHERE    m.State IN (1, 2)          -- Ready, Running
ORDER BY m.ID;


/* ---------------------------------------------------------------------------
   2. Campaigns that will send WITHOUT an outbound number.

   Either ExternalQueueID is empty, or it points at a row that does not exist
   or is inactive. Each one is a campaign whose recipients see whatever number
   the Webex flow falls back to.
   --------------------------------------------------------------------------- */
SELECT   m.ID, m.Campaign_Mstr_ID, m.State, m.ExternalQueueID
FROM     dbo.SMS_Queue_Mst m
LEFT     JOIN dbo.Dnis d
         ON  CAST(d.ID AS VARCHAR(50)) = CAST(m.ExternalQueueID AS VARCHAR(50))
         AND d.IsActive = 1
WHERE    m.State IN (1, 2)
  AND    d.ID IS NULL
ORDER BY m.ID;


/* ---------------------------------------------------------------------------
   3. The Dnis table itself.
   --------------------------------------------------------------------------- */
SELECT ID, DNIS, Name, IsActive, DbId, LastUpdDate
FROM   dbo.Dnis
ORDER  BY ID;


/* ---------------------------------------------------------------------------
   4. ⚠ IS ExternalQueueID REALLY THE DNIS ID?

   Worth one look before trusting it. In the sample data:

       SMS_Queue_Mst.ID 2   ExternalQueueID = 1     -> Dnis.ID 1, SAMS Club
       SMS_Queue_Mst.ID 5   ExternalQueueID = 602
       SMS_Queue_Mst.ID 6   ExternalQueueID = 603
       SMS_Queue_Mst.ID 17  ExternalQueueID = 59

   Only ExternalQueueID = 1 matches a Dnis row in the sample. If 602, 603 and
   59 have no match, either those campaigns are not configured yet, or
   ExternalQueueID means something else for them.

   This counts how many actually resolve.
   --------------------------------------------------------------------------- */
SELECT   COUNT(*)                                        AS TotalCampaigns,
         SUM(CASE WHEN d.ID IS NOT NULL THEN 1 ELSE 0 END) AS Resolved,
         SUM(CASE WHEN d.ID IS NULL     THEN 1 ELSE 0 END) AS Unresolved
FROM     dbo.SMS_Queue_Mst m
LEFT     JOIN dbo.Dnis d
         ON  CAST(d.ID AS VARCHAR(50)) = CAST(m.ExternalQueueID AS VARCHAR(50))
         AND d.IsActive = 1;
