/* ============================================================================
   VERIFY LeadAccountId
   ============================================================================
   Shows exactly what delivery will send as LeadAccountId. Same join the code
   uses.

   Rule: DBID_LeadAccount        e.g. ARTEO1_11397189

   ⚠ Account_Info.LeadAccount is NOT SMS_Queue_Detail.AccountID.
     They are different numbers on the same row:

         LeadAccount 11397189   AccountID 4805913
         LeadAccount 31332366   AccountID 16835775

     Using the wrong one produces an id that looks plausible and matches
     nothing on the receiving side.
   ============================================================================ */

SELECT   d.ID                       AS MessageId,
         d.AccountID                AS QueueAccountID,
         ai.LeadAccount,
         ai.DBID,
         CASE WHEN ai.DBID IS NULL OR LTRIM(RTRIM(ai.DBID)) = ''
              THEN COALESCE(NULLIF(LTRIM(RTRIM(ai.LeadAccount)), ''),
                            CAST(d.AccountID AS VARCHAR(30)))
              ELSE ai.DBID + '_' +
                   COALESCE(NULLIF(LTRIM(RTRIM(ai.LeadAccount)), ''),
                            CAST(d.AccountID AS VARCHAR(30)))
         END                        AS LeadAccountId,
         CASE WHEN ai.ID IS NULL                            THEN 'NO Account_Info ROW'
              WHEN ai.DBID IS NULL OR LTRIM(RTRIM(ai.DBID)) = ''        THEN 'DBID EMPTY - unprefixed'
              WHEN ai.LeadAccount IS NULL
                OR LTRIM(RTRIM(ai.LeadAccount)) = ''        THEN 'LeadAccount EMPTY - using AccountID'
              ELSE 'ok' END         AS Result
FROM     dbo.SMS_Queue_Detail d
LEFT     JOIN dbo.Account_Info ai ON ai.ID = d.Account_Info_ID
ORDER BY d.ID;


/* ---------------------------------------------------------------------------
   Anything that will NOT send a clean DBID_LeadAccount.
   Empty here is what you want.
   --------------------------------------------------------------------------- */
SELECT   d.ID AS MessageId, d.AccountID, d.Account_Info_ID,
         ai.LeadAccount, ai.DBID
FROM     dbo.SMS_Queue_Detail d
LEFT     JOIN dbo.Account_Info ai ON ai.ID = d.Account_Info_ID
WHERE    ai.ID IS NULL
   OR    ai.DBID IS NULL        OR LTRIM(RTRIM(ai.DBID)) = ''
   OR    ai.LeadAccount IS NULL OR LTRIM(RTRIM(ai.LeadAccount)) = ''
ORDER BY d.ID;


/* ---------------------------------------------------------------------------
   How often LeadAccount and AccountID actually differ.

   If they always differ, the distinction is real and getting it wrong would
   have broken every message.
   --------------------------------------------------------------------------- */
SELECT   SUM(CASE WHEN CAST(ai.LeadAccount AS VARCHAR(30))
                     = CAST(d.AccountID AS VARCHAR(30)) THEN 1 ELSE 0 END) AS Same,
         SUM(CASE WHEN CAST(ai.LeadAccount AS VARCHAR(30))
                    <> CAST(d.AccountID AS VARCHAR(30)) THEN 1 ELSE 0 END) AS Different,
         COUNT(*) AS Total
FROM     dbo.SMS_Queue_Detail d
INNER    JOIN dbo.Account_Info ai ON ai.ID = d.Account_Info_ID;
