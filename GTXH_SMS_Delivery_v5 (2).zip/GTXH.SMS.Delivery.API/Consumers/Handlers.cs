using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Services;
using GTXH.SMS.Messaging;

namespace GTXH.SMS.Delivery.API.Consumers;

/// <summary>ReadyToSend from compliance -> submit to the provider.</summary>
public sealed class ReadyToSendHandler(DeliveryService service)
    : KafkaJsonHandler<ReadyToSendEvent>
{
    public override string Topic => Topics.ReadyToSend;
    public override string GroupId => "delivery-ready";

    protected override Task HandleAsync(string key, ReadyToSendEvent message, CancellationToken cancellationToken) =>
        service.HandleReadyAsync(message, cancellationToken);
}
