using GTXH.SMS.Common;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Data;

public sealed class DeliveryDbContext(DbContextOptions<DeliveryDbContext> options) : DbContext(options)
{
    /// <summary>SMS_Queue_Detail — message text, phone, zip.</summary>
    public DbSet<CampaignMemberEntity> CampaignMembers => Set<CampaignMemberEntity>();

    /// <summary>SMS_Queue_Mst — campaign state and outbound number.</summary>
    public DbSet<CampaignQueueEntity> CampaignQueue => Set<CampaignQueueEntity>();

    /// <summary>SMS_Delivery_Submission — duplicate guard and send record.</summary>
    public DbSet<DeliverySubmissionEntity> Submissions => Set<DeliverySubmissionEntity>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CampaignMemberEntity>(e =>
        {
            e.ToTable("SMS_Queue_Detail");
            e.HasKey(x => x.ID);
            e.Property(x => x.Status).HasConversion<byte>();
            e.Property(x => x.LifecycleState).HasConversion<byte>();
        });

        modelBuilder.Entity<CampaignQueueEntity>(e =>
        {
            e.ToTable("SMS_Queue_Mst");
            e.HasKey(x => x.ID);
            e.Property(x => x.State).HasConversion<byte>();
        });

        modelBuilder.Entity<DeliverySubmissionEntity>(e =>
        {
            e.ToTable("SMS_Delivery_Submission");
            e.HasKey(x => x.ID);
            e.HasIndex(x => x.MessageId).IsUnique();   // the duplicate guard
        });
    }
}
