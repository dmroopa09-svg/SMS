using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GTXH.SMS.Delivery.API.Data;

/// <summary>
/// One row per message we tried to send. Maps to SMS_Delivery_Submission.
///
/// TWO JOBS:
///
///   1. MessageId has a UNIQUE INDEX. Inserting before we send means a repeat
///      of the same message fails at the database rather than becoming a
///      second text.
///
///   2. The Status API updates this row when Webex reports back —
///      UpdateConnectResponse does UPDATE SMS_Delivery_Submission WHERE
///      MessageId AND CampaignQueueId AND Phone. If delivery does not insert
///      the row, that update matches nothing.
/// </summary>
[Table("SMS_Delivery_Submission")]
public sealed class DeliverySubmissionEntity
{
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long ID { get; set; }

    /// <summary>SMS_Queue_Detail.ID. UNIQUE — this is the duplicate guard.</summary>
    public long MessageId { get; set; }

    public long CampaignQueueId { get; set; }
    public int CampaignId { get; set; }

    [StringLength(15)]
    public string? Phone { get; set; }

    /// <summary>Webex transid, returned when the message is accepted.</summary>
    [StringLength(128)]
    public string? ProviderMessageId { get; set; }

    /// <summary>1002 when queued. Later overwritten by the Status API.</summary>
    [StringLength(20)]
    public string? ResponseCode { get; set; }

    [StringLength(1000)]
    public string? ResponseMessage { get; set; }

    public bool Succeeded { get; set; }

    [StringLength(100)]
    public string? InstanceId { get; set; }

    public int DurationMs { get; set; }

    public DateTime SubmittedAtUtc { get; set; } = DateTime.UtcNow;
}
