using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace GTXH.SMS.Delivery.API.Services;

public sealed class WebexSendResult
{
    public bool Accepted { get; init; }
    public string? ProviderMessageId { get; init; }
    public string? ResponseCode { get; init; }
    public string? ResponseMessage { get; init; }
    public int DurationMs { get; init; }

    public static WebexSendResult Ok(string? id, string? code, int ms) =>
        new() { Accepted = true, ProviderMessageId = id, ResponseCode = code, DurationMs = ms };

    public static WebexSendResult Failed(string msg, string? code, int ms) =>
        new() { Accepted = false, ResponseMessage = msg, ResponseCode = code, DurationMs = ms };
}

public sealed class WebexSendRequest
{
    public string SmsId { get; init; } = "";
    public string Phone { get; init; } = "";
    public string MessageText { get; init; } = "";
    public string? ZipCode { get; init; }
    public string? AccountInfoId { get; init; }
    public string? LeadAccountId { get; init; }

    /// <summary>Outbound number (DNIS), mapped in the campaign.</summary>
    public string? CampaignPhoneNumber { get; init; }
}

public interface IWebexSmsClient
{
    Task<WebexSendResult> SendAsync(WebexSendRequest request, CancellationToken ct);
}

/// <summary>
/// POSTs to the Webex Connect flow trigger.
///
///     POST https://hooks.us.webexconnect.io/events/OA3ZL2N9FJ
///     {
///       "SMSID":            SMS_Queue_Detail.ID
///       "SMSTEXT":          SMS_Queue_Detail.MessageText
///       "Phone":            SMS_Queue_Detail.Phone
///       "ZipCode":          SMS_Queue_Detail.ZipCode
///       "Account_Info_ID":  SMS_Queue_Detail.Account_Info_ID
///       "LeadAccountId":    SMS_Queue_Detail.AccountID
///       "CampaignPHNumber": outbound number from the campaign
///     }
///
///     -> { "response": [ { "code": "1002",
///                          "description": "Queued",
///                          "transid": "53924091-..." } ] }
///
/// Code 1002 means Connect ACCEPTED the request. It does not mean the carrier
/// took it, and it does not mean a handset received it — that arrives later as
/// a delivery receipt with code 7500.
/// </summary>
public sealed class WebexSmsClient(
    HttpClient http,
    DeliveryOptions options,
    ILogger<WebexSmsClient> logger) : IWebexSmsClient
{
    private static readonly JsonSerializerOptions JsonOpts =
        new() { DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull };

    public async Task<WebexSendResult> SendAsync(WebexSendRequest request, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();

        var payload = new WebexPayload
        {
            SMSID = request.SmsId,
            SMSTEXT = request.MessageText,
            Phone = request.Phone,
            ZipCode = request.ZipCode,
            Account_Info_ID = request.AccountInfoId,
            LeadAccountId = request.LeadAccountId,
            CampaignPHNumber = request.CampaignPhoneNumber
        };

        using var content = new StringContent(
            JsonSerializer.Serialize(payload, JsonOpts), Encoding.UTF8, "application/json");

        HttpResponseMessage response;
        try
        {
            response = await http.PostAsync(options.FlowTriggerPath, content, ct);
        }
        catch (Exception ex)
        {
            sw.Stop();
            logger.LogWarning(ex, "Webex call failed for ***{Last4}.", Last4(request.Phone));
            return WebexSendResult.Failed(ex.Message, null, (int)sw.ElapsedMilliseconds);
        }

        var body = await SafeReadAsync(response, ct);
        sw.Stop();
        var ms = (int)sw.ElapsedMilliseconds;

        if (!response.IsSuccessStatusCode)
        {
            var status = (int)response.StatusCode;
            logger.LogWarning("Webex HTTP {Status} for ***{Last4}: {Body}",
                status, Last4(request.Phone), Truncate(body, 200));
            return WebexSendResult.Failed($"HTTP {status}: {Truncate(body, 500)}",
                status.ToString(), ms);
        }

        WebexResponse? parsed;
        try { parsed = JsonSerializer.Deserialize<WebexResponse>(body); }
        catch
        {
            // HTTP 200 but unreadable. The message probably went — treating it
            // as a failure would be worse than accepting it without a transid.
            logger.LogWarning("Webex accepted ***{Last4} but the body did not parse.",
                Last4(request.Phone));
            return WebexSendResult.Ok(null, null, ms);
        }

        var first = parsed?.Response is { Length: > 0 } ? parsed.Response[0] : null;
        if (first is null) return WebexSendResult.Ok(null, null, ms);

        if (first.Code == "1002")
            return WebexSendResult.Ok(first.TransId, first.Code, ms);

        // Any other code. 1002 is the only accepted code we have seen; the rest
        // are recorded so the list can be filled in as they appear.
        logger.LogWarning("Webex returned code {Code} ({Description}) for ***{Last4}.",
            first.Code, first.Description, Last4(request.Phone));

        return WebexSendResult.Failed(
            $"Provider code {first.Code}: {first.Description}", first.Code, ms);
    }

    private static async Task<string> SafeReadAsync(HttpResponseMessage r, CancellationToken ct)
    { try { return await r.Content.ReadAsStringAsync(ct); } catch { return ""; } }

    private static string Truncate(string? s, int max)
        => string.IsNullOrEmpty(s) ? "" : (s.Length > max ? s[..max] : s);

    /// <summary>Last four digits only — full numbers are patient contact details.</summary>
    private static string Last4(string? phone)
        => string.IsNullOrEmpty(phone) || phone.Length < 4 ? "****" : phone[^4..];

    private sealed class WebexPayload
    {
        [JsonPropertyName("SMSID")] public string SMSID { get; set; } = "";
        [JsonPropertyName("SMSTEXT")] public string SMSTEXT { get; set; } = "";
        [JsonPropertyName("Phone")] public string Phone { get; set; } = "";
        [JsonPropertyName("ZipCode")] public string? ZipCode { get; set; }
        [JsonPropertyName("Account_Info_ID")] public string? Account_Info_ID { get; set; }
        [JsonPropertyName("LeadAccountId")] public string? LeadAccountId { get; set; }
        [JsonPropertyName("CampaignPHNumber")] public string? CampaignPHNumber { get; set; }
    }

    private sealed class WebexResponse
    { [JsonPropertyName("response")] public WebexResponseItem[]? Response { get; set; } }

    private sealed class WebexResponseItem
    {
        [JsonPropertyName("code")] public string? Code { get; set; }
        [JsonPropertyName("description")] public string? Description { get; set; }
        [JsonPropertyName("transid")] public string? TransId { get; set; }
    }
}

/// <summary>Sends nothing. The default, so a misconfigured service cannot message anyone.</summary>
public sealed class DryRunSmsClient(ILogger<DryRunSmsClient> logger) : IWebexSmsClient
{
    public Task<WebexSendResult> SendAsync(WebexSendRequest request, CancellationToken ct)
    {
        logger.LogInformation("[DRY RUN] would send to ***{Last4}. NOTHING WAS SENT.",
            request.Phone.Length >= 4 ? request.Phone[^4..] : "****");

        return Task.FromResult(WebexSendResult.Ok(
            "dryrun-" + Guid.NewGuid().ToString("N")[..12], "1002", 0));
    }
}
