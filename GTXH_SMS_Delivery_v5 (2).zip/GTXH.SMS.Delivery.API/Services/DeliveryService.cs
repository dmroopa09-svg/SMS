using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Consumes ReadyToSend from Kafka and submits the message to Webex.
///
/// FIVE STEPS, IN THIS ORDER:
///
///   1  Is the campaign still Ready or Running?      (the stop switch)
///   2  Insert a row in SMS_Delivery_Submission       (the duplicate guard)
///   3  Load the message text and phone from the queue row
///   4  POST to the Webex flow trigger
///   5  Write the outcome to both tables
///
/// Nothing else. No retry, no background workers, no extra lifecycle states.
/// </summary>
public sealed class DeliveryService(
    DeliveryDbContext db,
    IWebexSmsClient client,
    DeliveryOptions options,
    DeliveryRateLimiter rateLimiter,
    ILogger<DeliveryService> logger)
{
    private static int _sentThisProcess;

    private readonly string _instanceId =
        $"{Environment.MachineName}:{Environment.ProcessId}";

    public async Task HandleReadyAsync(ReadyToSendEvent message, CancellationToken ct)
    {
        var campaignQueueId = message.CampaignQueueId ?? 0;

        // -----------------------------------------------------------------
        // STEP 1 — the stop switch, and the outbound number.
        //
        // One query returns both. The campaign state is read EVERY message,
        // never cached — if someone stops a campaign, the very next message
        // must see it.
        //
        // The outbound number comes from the Dnis table, joined on
        // SMS_Queue_Mst.ExternalQueueID = Dnis.ID. Both are cast to varchar in
        // the join because ExternalQueueID is a string on the entity while
        // Dnis.ID is numeric — casting means the types cannot mismatch.
        //
        // LEFT JOIN, so a campaign with no matching DNIS still returns its
        // state. Losing the stop switch because a number is missing would be
        // far worse than sending without CampaignPHNumber.
        // -----------------------------------------------------------------
        var campaign = await LoadCampaignAsync((int)campaignQueueId, ct);

        if (campaign is null)
        {
            logger.LogWarning("Campaign queue {Id} not found; message {MessageId} not sent.",
                campaignQueueId, message.MessageId);
            return;
        }

        var state = (CampaignState)campaign.State;

        if (state is not (CampaignState.Ready or CampaignState.Running))
        {
            logger.LogInformation("Campaign {Id} is {State}; message {MessageId} not sent.",
                campaignQueueId, state, message.MessageId);
            return;
        }

        if (string.IsNullOrWhiteSpace(campaign.OutboundNumber))
        {
            // Not fatal — the field is simply omitted from the payload. But it
            // means the recipient sees whatever number the flow falls back to,
            // so it is worth seeing in the log rather than discovering later.
            logger.LogWarning(
                "No active DNIS for campaign {Id} (ExternalQueueID {Ext}). "
                + "Sending without CampaignPHNumber.",
                campaignQueueId, campaign.ExternalQueueID);
        }

        // -----------------------------------------------------------------
        // STEP 2 — the duplicate guard.
        //
        // We insert the submission row BEFORE sending. MessageId has a unique
        // index, so a second attempt for the same message fails here and we
        // stop — before the provider is called.
        //
        // Delivery genuinely receives the same message twice: Kafka redelivers
        // on a consumer rebalance, and compliance republishes if it crashes
        // between publishing and saving. Without this guard, that becomes a
        // second text to a real patient.
        //
        // The row is also what the Status API updates later — its
        // UpdateConnectResponse does UPDATE SMS_Delivery_Submission WHERE
        // MessageId AND CampaignQueueId AND Phone, so if we do not insert it,
        // that update matches nothing.
        // -----------------------------------------------------------------
        var member = await LoadMessageAsync(message.MessageId, ct);

        if (member is null)
        {
            logger.LogWarning("Queue row {MessageId} not found.", message.MessageId);
            return;
        }

        var submission = new DeliverySubmissionEntity
        {
            MessageId = message.MessageId,
            CampaignQueueId = campaignQueueId,
            CampaignId = message.CampaignId,
            Phone = member.Phone,
            InstanceId = _instanceId,
            SubmittedAtUtc = DateTime.UtcNow
        };

        try
        {
            db.Submissions.Add(submission);
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex) when (IsDuplicate(ex))
        {
            logger.LogInformation(
                "Message {MessageId} already submitted; duplicate ignored.", message.MessageId);
            return;
        }

        // -----------------------------------------------------------------
        // STEP 3 — content checks.
        //
        // Message text comes from the queue row, not from the Kafka event. The
        // row is current; the event is a snapshot from when it was published.
        // -----------------------------------------------------------------
        if (string.IsNullOrWhiteSpace(member.MessageText))
        {
            await RecordFailureAsync(submission, member.ID, null, "MESSAGE_TEXT_EMPTY", ct);
            return;
        }

        var phone = member.Phone ?? message.Phone;
        if (string.IsNullOrWhiteSpace(phone))
        {
            await RecordFailureAsync(submission, member.ID, null, "PHONE_MISSING", ct);
            return;
        }

        // Testing brake. PER PROCESS — two people running the service at once
        // get two ceilings, which is what caused the unexpected volume before.
        if (options.MaxSendsPerProcess > 0
            && Interlocked.Increment(ref _sentThisProcess) > options.MaxSendsPerProcess)
        {
            logger.LogError("Process send ceiling of {Max} reached; {MessageId} not sent.",
                options.MaxSendsPerProcess, message.MessageId);

            await RecordFailureAsync(submission, member.ID, null, "PROCESS_SEND_CEILING", ct);
            return;
        }

        // -----------------------------------------------------------------
        // STEP 4 — send.
        // -----------------------------------------------------------------
        var destination = phone;

        if (!string.IsNullOrWhiteSpace(options.RedirectAllToNumber))
        {
            logger.LogWarning(
                "TEST REDIRECT: {MessageId} intended for ***{Last4} sent to {Redirect}.",
                message.MessageId, phone.Length >= 4 ? phone[^4..] : "****",
                options.RedirectAllToNumber);

            destination = options.RedirectAllToNumber!;
        }

        await rateLimiter.WaitAsync(ct);

        var result = await client.SendAsync(new WebexSendRequest
        {
            SmsId = member.ID.ToString(),
            Phone = destination,
            MessageText = member.MessageText!,
            ZipCode = member.ZipCode,
            AccountInfoId = member.AccountInfoId?.ToString(),

            // DBID_AccountID, matching the rule Acqueon already uses.
            // Example: ARTEO1_4805913
            LeadAccountId = member.LeadAccountId,
            // Outbound number (DNIS) from the Dnis table. Null when no active
            // row matched — WebexSmsClient omits null fields, so the payload
            // simply has no CampaignPHNumber.
            CampaignPhoneNumber = campaign.OutboundNumber
        }, ct);

        // -----------------------------------------------------------------
        // STEP 5 — record the outcome in BOTH tables.
        // -----------------------------------------------------------------
        if (result.Accepted)
            await RecordAcceptedAsync(submission, member.ID, result, ct);
        else
            await RecordFailureAsync(submission, member.ID, result,
                                     result.ResponseMessage ?? "SEND_FAILED", ct);
    }

    // =====================================================================

    /// <summary>
    /// Webex accepted the message. Code 1002 "Queued".
    ///
    /// NOTE WHAT THIS DOES NOT MEAN: Connect took the request. It does not mean
    /// the carrier accepted it, and it does not mean a handset received it.
    /// That only arrives later, as a delivery receipt with code 7500.
    /// </summary>
    private async Task RecordAcceptedAsync(
        DeliverySubmissionEntity submission,
        long messageId,
        WebexSendResult result,
        CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var code = result.ResponseCode;          // 1002
        var providerId = result.ProviderMessageId;   // Webex transid

        submission.ProviderMessageId = providerId;
        submission.ResponseCode = code;
        submission.ResponseMessage = "Queued";
        submission.Succeeded = true;
        submission.DurationMs = result.DurationMs;
        await db.SaveChangesAsync(ct);

        // The queue row records WHAT HAPPENED. The transid is NOT copied here —
        // it lives once, in the submission row, and the two tables are already
        // joined by SMS_Delivery_Submission.MessageId = SMS_Queue_Detail.ID.
        //
        // Storing the same fact twice means it can disagree with itself: if a
        // receipt updates one copy and not the other, there are two answers and
        // no way to tell which is right.
        await db.CampaignMembers
            .Where(m => m.ID == messageId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LifecycleState, MessageLifecycleState.Submitted)
                .SetProperty(m => m.Status, CampaignMemberStatus.Emitted)
                .SetProperty(m => m.ResponseCode, code)
                .SetProperty(m => m.ResponseMessage, "Queued")
                .SetProperty(m => m.Sent_Timestamp_UTC, now)
                .SetProperty(m => m.RowUpdatedDt, now), ct);

        logger.LogInformation("Sent {MessageId}, transid {TransId}, {Ms}ms",
            messageId, providerId, result.DurationMs);
    }

    /// <summary>
    /// The send did not happen. Terminal — retry is disabled, so nothing will
    /// pick this up again.
    /// </summary>
    private async Task RecordFailureAsync(
        DeliverySubmissionEntity submission,
        long messageId,
        WebexSendResult? result,
        string reason,
        CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var code = result?.ResponseCode;
        var text = Truncate(reason, 1000);

        submission.ResponseCode = code;
        submission.ResponseMessage = text;
        submission.Succeeded = false;
        submission.DurationMs = result?.DurationMs ?? 0;
        await db.SaveChangesAsync(ct);

        await db.CampaignMembers
            .Where(m => m.ID == messageId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LifecycleState, MessageLifecycleState.Failed)
                .SetProperty(m => m.Status, CampaignMemberStatus.Skipped)
                .SetProperty(m => m.ResponseCode, code)
                .SetProperty(m => m.ResponseMessage, text)
                .SetProperty(m => m.RowUpdatedDt, now), ct);

        logger.LogWarning("Message {MessageId} failed: {Reason}", messageId, reason);
    }

    /// <summary>SQL Server unique index / primary key violation.</summary>
    private static bool IsDuplicate(DbUpdateException ex) =>
        ex.InnerException is Microsoft.Data.SqlClient.SqlException sql
        && (sql.Number == 2601 || sql.Number == 2627);

    private static string Truncate(string? s, int max)
        => string.IsNullOrEmpty(s) ? "" : (s.Length > max ? s[..max] : s);

    /// <summary>
    /// Campaign state and outbound number in one query.
    ///
    /// The join is SMS_Queue_Mst.ExternalQueueID -> Dnis.ID. ExternalQueueID is
    /// a string on the entity and Dnis.ID is numeric, so both sides are cast to
    /// varchar — that way a type difference cannot break the join silently.
    ///
    /// IsActive = 1 so a retired number is never used. A campaign whose DNIS is
    /// inactive returns a null number rather than no row, because the LEFT JOIN
    /// keeps the state — and the state is what stops sending.
    /// </summary>
    private async Task<CampaignSendInfo?> LoadCampaignAsync(int campaignQueueId, CancellationToken ct)
    {
        var rows = await db.Database
            .SqlQuery<CampaignSendInfo>($"""
                SELECT TOP 1
                       CAST(m.State AS TINYINT)             AS State,
                       CAST(m.ExternalQueueID AS VARCHAR(50)) AS ExternalQueueID,
                       CAST(d.DNIS AS VARCHAR(20))          AS OutboundNumber
                FROM   dbo.SMS_Queue_Mst AS m
                LEFT   JOIN dbo.Dnis AS d
                       ON  CAST(d.ID AS VARCHAR(50)) = CAST(m.ExternalQueueID AS VARCHAR(50))
                       AND d.IsActive = 1
                WHERE  m.ID = {campaignQueueId}
                """)
            .ToListAsync(ct);

        return rows.FirstOrDefault();
    }

    /// <summary>What STEP 1 needs. Types match the CASTs in the query above.</summary>
    public sealed class CampaignSendInfo
    {
        public byte State { get; set; }
        public string? ExternalQueueID { get; set; }
        public string? OutboundNumber { get; set; }
    }

    /// <summary>
    /// The queue row plus the DBID that belongs with its account.
    ///
    /// LeadAccountId is sent to Webex as DBID_LeadAccount — the same rule
    /// Acqueon uses. Example: ARTEO1_11397189.
    ///
    /// ⚠ LeadAccount IS NOT SMS_Queue_Detail.AccountID. They are different
    /// numbers on the same row — LeadAccount 11397189 against AccountID
    /// 4805913. Using the wrong one produces an id that looks plausible and
    /// matches nothing on their side.
    ///
    /// The DBID lives on Account_Info, not on the queue row and not on the DNIS.
    /// It is joined through SMS_Queue_Detail.Account_Info_ID = Account_Info.ID.
    ///
    /// LEFT JOIN, because Account_Info_ID can be missing. When it is, the
    /// account number is sent unprefixed rather than the message being dropped —
    /// and a warning is logged, because an unprefixed id may not match on their
    /// side.
    /// </summary>
    private async Task<MessageRow?> LoadMessageAsync(long messageId, CancellationToken ct)
    {
        var rows = await db.Database
            .SqlQuery<MessageRow>($"""
                SELECT TOP 1
                       CAST(d.ID AS BIGINT)                    AS ID,
                       CAST(d.Phone AS VARCHAR(15))            AS Phone,
                       CAST(d.ZipCode AS VARCHAR(50))          AS ZipCode,
                       CAST(d.MessageText AS NVARCHAR(MAX))    AS MessageText,
                       CAST(d.Account_Info_ID AS BIGINT)       AS AccountInfoId,
                       CAST(d.AccountID AS BIGINT)             AS AccountId,
                       CAST(ai.LeadAccount AS VARCHAR(30))     AS LeadAccount,
                       CAST(ai.DBID AS VARCHAR(20))            AS Dbid
                FROM   dbo.SMS_Queue_Detail AS d
                LEFT   JOIN dbo.Account_Info AS ai
                       ON ai.ID = d.Account_Info_ID
                WHERE  d.ID = {messageId}
                """)
            .ToListAsync(ct);

        var row = rows.FirstOrDefault();

        if (row is not null && string.IsNullOrWhiteSpace(row.Dbid))
        {
            logger.LogWarning(
                "No DBID for message {MessageId} (Account_Info_ID {AccountInfoId}). "
                + "Sending LeadAccountId unprefixed as {LeadAccountId}.",
                messageId, row.AccountInfoId, row.LeadAccountId);
        }
        else if (row is not null && string.IsNullOrWhiteSpace(row.LeadAccount))
        {
            logger.LogWarning(
                "No LeadAccount on Account_Info for message {MessageId}; falling back to "
                + "the queue row AccountID. Sending {LeadAccountId}.",
                messageId, row.LeadAccountId);
        }

        return row;
    }

    /// <summary>What the send needs. Types match the CASTs in the query above.</summary>
    public sealed class MessageRow
    {
        public long ID { get; set; }
        public string? Phone { get; set; }
        public string? ZipCode { get; set; }
        public string? MessageText { get; set; }
        public long? AccountInfoId { get; set; }
        /// <summary>SMS_Queue_Detail.AccountID — NOT the lead account.</summary>
        public long AccountId { get; set; }

        /// <summary>
        /// Account_Info.LeadAccount. A DIFFERENT number from AccountID above —
        /// e.g. LeadAccount 11397189 against AccountID 4805913 on the same row.
        /// This is the one Webex expects.
        /// </summary>
        public string? LeadAccount { get; set; }

        /// <summary>Account_Info.DBID, e.g. ARTEO1 or ARTR.</summary>
        public string? Dbid { get; set; }

        /// <summary>
        /// DBID_LeadAccount, matching the rule Acqueon uses. e.g. ARTEO1_11397189
        ///
        /// Falls back to the bare lead account when there is no DBID, and to the
        /// queue row's AccountID only when there is no Account_Info row at all —
        /// so something identifiable is always sent rather than an empty field.
        /// </summary>
        public string LeadAccountId
        {
            get
            {
                var account = string.IsNullOrWhiteSpace(LeadAccount)
                    ? AccountId.ToString()
                    : LeadAccount!;

                return string.IsNullOrWhiteSpace(Dbid)
                    ? account
                    : $"{Dbid}_{account}";
            }
        }
    }
}
