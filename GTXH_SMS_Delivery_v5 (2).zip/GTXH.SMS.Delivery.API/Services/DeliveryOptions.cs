namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Delivery settings, bound from the "Delivery" section of appsettings.json.
/// Seven settings, nothing else.
/// </summary>
public sealed class DeliveryOptions
{
    public const string SectionName = "Delivery";

    /// <summary>https://hooks.us.webexconnect.io/</summary>
    public string BaseUrl { get; set; } = "";

    /// <summary>events/OA3ZL2N9FJ — the flow trigger id.</summary>
    public string FlowTriggerPath { get; set; } = "";

    /// <summary>
    /// True = nothing is sent, a fake response is returned instead.
    /// DEFAULTS TO TRUE so a service started without configuration cannot
    /// message real people.
    /// </summary>
    public bool DryRun { get; set; } = true;

    /// <summary>
    /// Sends every message to this number instead of the real recipient.
    /// Used for testing alongside the filter on the Webex side.
    /// </summary>
    public string? RedirectAllToNumber { get; set; }

    /// <summary>
    /// Stops after this many sends in one run of the service. 0 = no limit.
    ///
    /// PER PROCESS, not global — two people running the service at the same
    /// time get one ceiling each.
    /// </summary>
    public int MaxSendsPerProcess { get; set; } = 25;

    /// <summary>Provider limit: 25 messages per second. Also per instance.</summary>
    public int MaxPerSecond { get; set; } = 25;

    public int TimeoutSeconds { get; set; } = 30;
}
