namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Spaces out sends so this instance stays under the provider's 25 per second.
///
/// Kafka hands messages over as fast as it can read them. Without this, a
/// backlog of 10,000 becomes 10,000 near-simultaneous HTTP calls, and the
/// result is Webex throttling or suspending the account — which stops every
/// campaign, not just this one.
///
/// PER INSTANCE, not global. Three instances at 25 each send 75.
/// </summary>
public sealed class DeliveryRateLimiter : IDisposable
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly int _minGapMs;
    private DateTime _lastSendUtc = DateTime.MinValue;

    public DeliveryRateLimiter(DeliveryOptions options)
        => _minGapMs = 1000 / Math.Max(1, options.MaxPerSecond);

    public async Task WaitAsync(CancellationToken ct)
    {
        await _gate.WaitAsync(ct);
        try
        {
            var wait = _minGapMs - (int)(DateTime.UtcNow - _lastSendUtc).TotalMilliseconds;
            if (wait > 0) await Task.Delay(wait, ct);
            _lastSendUtc = DateTime.UtcNow;
        }
        finally { _gate.Release(); }
    }

    public void Dispose() => _gate.Dispose();
}
