using GTXH.SMS.Delivery.API.Consumers;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Delivery.API.Services;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddSmsMessaging(builder.Configuration);
builder.Services.AddKafkaHandler<ReadyToSendHandler>();

builder.Services.AddDbContext<DeliveryDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("DeliveryDb"),
        sql => sql.UseCompatibilityLevel(110)));

var deliveryOptions = new DeliveryOptions();
builder.Configuration.GetSection(DeliveryOptions.SectionName).Bind(deliveryOptions);
builder.Services.AddSingleton(deliveryOptions);
builder.Services.AddSingleton<DeliveryRateLimiter>();

// Dry run is the default. A service started without configuration should fail
// to send, not send to real people.
if (deliveryOptions.DryRun)
{
    builder.Services.AddSingleton<IWebexSmsClient, DryRunSmsClient>();
}
else
{
    if (string.IsNullOrWhiteSpace(deliveryOptions.BaseUrl)
        || string.IsNullOrWhiteSpace(deliveryOptions.FlowTriggerPath))
    {
        throw new InvalidOperationException(
            "Delivery:DryRun is false but BaseUrl or FlowTriggerPath is not set.");
    }

    // Built directly rather than via AddHttpClient, which needs a package this
    // project does not reference. PooledConnectionLifetime stops a long-running
    // process caching DNS forever.
    builder.Services.AddSingleton<IWebexSmsClient>(sp =>
    {
        var handler = new SocketsHttpHandler
        {
            PooledConnectionLifetime = TimeSpan.FromMinutes(5)
        };

        var http = new HttpClient(handler)
        {
            BaseAddress = new Uri(deliveryOptions.BaseUrl),
            Timeout = TimeSpan.FromSeconds(deliveryOptions.TimeoutSeconds)
        };

        return new WebexSmsClient(http, deliveryOptions,
            sp.GetRequiredService<ILogger<WebexSmsClient>>());
    });
}

builder.Services.AddScoped<DeliveryService>();

var host = builder.Build();

var log = host.Services.GetRequiredService<ILogger<Program>>();

if (deliveryOptions.DryRun)
{
    log.LogWarning("DELIVERY IS IN DRY RUN. No messages will be sent.");
}
else
{
    log.LogWarning("DELIVERY IS LIVE. {Url}{Path}, max {Max} sends, {Rate}/second.",
        deliveryOptions.BaseUrl, deliveryOptions.FlowTriggerPath,
        deliveryOptions.MaxSendsPerProcess, deliveryOptions.MaxPerSecond);

    if (!string.IsNullOrWhiteSpace(deliveryOptions.RedirectAllToNumber))
        log.LogWarning("TEST REDIRECT ACTIVE — everything goes to {Number}.",
            deliveryOptions.RedirectAllToNumber);
    else
        log.LogWarning("NO TEST REDIRECT — messages go to REAL RECIPIENTS.");
}

host.Run();
