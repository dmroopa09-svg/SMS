// =============================================================================
// REPLACEMENT FOR StatusService.UpdateConnectResponse
//
// GTXH.SMS.Status.API/Services/StatusService.cs
//
// ⚠ THIS IS MADAN'S FILE. Agree the change before applying it — Santosh is also
//   working in the Status API.
//
// Three statements instead of one, in the same transaction:
//
//   1. SMS_Delivery_Submission   (unchanged, what the method already did)
//   2. SMS_Queue_Detail          (new) so the queue row reaches Delivered
//   3. SMS_Queue_Mst             (new) mark the campaign Completed when every
//                                row is terminal
//
// WHY THE QUEUE ROW UPDATE IS NEEDED
// ----------------------------------
// The method currently updates only the submission table, so SMS_Queue_Detail
// stays at Submitted (6) forever. Since 6 is NOT in the terminal list
// (2, 5, 7, 8), no campaign would ever complete — every one would sit blocked
// by rows at 6.
//
// So the completion check and the queue row update are the same fix. Adding one
// without the other does nothing.
// =============================================================================

public async Task<int> UpdateConnectResponse(
    string MessageId,
    string PhoneNo,
    long CampaignQueueId,
    string? ResponseCode,
    string? ResponseDescription,
    string? TransId)
{
    try
    {
        await using var tx = await _dbContext.Database
            .BeginTransactionAsync(IsolationLevel.ReadCommitted);

        // ---------------------------------------------------------------
        // 1. The submission row — unchanged.
        // ---------------------------------------------------------------
        var affectedRows = await _dbContext.Database
            .ExecuteSqlInterpolatedAsync($"""
            UPDATE [SMS_Delivery_Submission]
            SET
                [ResponseCode]      = {ResponseCode},
                [ResponseMessage]   = {ResponseDescription},
                [ProviderMessageId] = {TransId}
            WHERE
                [MessageId]       = {MessageId}
                AND [CampaignQueueId] = {CampaignQueueId}
                AND [Phone]           = {PhoneNo}
            """);

        // ---------------------------------------------------------------
        // 2. The queue row.
        //
        // LifecycleState only moves on a code we recognise:
        //
        //     7500  ->  Delivered (7)
        //     7282  ->  Failed (8)
        //     other ->  left alone
        //
        // An unrecognised code records the response but does NOT mark the
        // message failed. A code nobody has catalogued might mean "in
        // progress", and marking it Failed on a guess would both misreport the
        // message and complete the campaign early.
        // ---------------------------------------------------------------
        await _dbContext.Database
            .ExecuteSqlInterpolatedAsync($"""
            UPDATE [SMS_Queue_Detail]
            SET
                [ResponseCode]    = {ResponseCode},
                [ResponseMessage] = {ResponseDescription},
                [LifecycleState]  = CASE
                                        WHEN {ResponseCode} = '7500' THEN 7
                                        WHEN {ResponseCode} = '7282' THEN 8
                                        ELSE [LifecycleState]
                                    END,
                [RowUpdatedDt]    = SYSUTCDATETIME()
            WHERE
                [ID] = {MessageId}
            """);

        // ---------------------------------------------------------------
        // 3. Complete the campaign when nothing is left running.
        //
        // Terminal states, per the agreed list:
        //     2  RejectedEligibility
        //     5  TerminatedCompliance
        //     7  Delivered
        //     8  Failed
        //
        // Submitted (6) is deliberately NOT terminal — it means the provider
        // took the message but no receipt has come back yet.
        //
        // GUARDED ON State IN (1, 2) so only a Ready or Running campaign can be
        // completed. Without that, a campaign someone Paused or Cancelled would
        // silently flip to Completed as its last receipt arrived, which would
        // undo an operator's decision.
        //
        // Runs on every receipt, but only affects a row on the last one — the
        // NOT EXISTS is false until then. Cheap with an index on
        // (SMSQueue_Mst_ID, LifecycleState).
        // ---------------------------------------------------------------
        var completed = await _dbContext.Database
            .ExecuteSqlInterpolatedAsync($"""
            UPDATE m
            SET
                [State]     = 6,
                [UpdatedDt] = SYSUTCDATETIME()
            FROM [SMS_Queue_Mst] AS m
            WHERE
                m.[ID] = {CampaignQueueId}
                AND m.[State] IN (1, 2)
                AND NOT EXISTS (
                    SELECT 1
                    FROM   [SMS_Queue_Detail] AS d
                    WHERE  d.[SMSQueue_Mst_ID] = {CampaignQueueId}
                      AND  d.[LifecycleState] NOT IN (2, 5, 7, 8)
                )
            """);

        await tx.CommitAsync();

        if (completed > 0)
        {
            _logger.LogInformation(
                "Campaign queue {CampaignQueueId} completed — every message reached a "
                + "terminal state.", CampaignQueueId);
        }

        return affectedRows;
    }
    catch (Exception ex)
    {
        _logger.LogError(
            ex,
            "Failed to update SMS status. MessageId: {MessageId}, TransId: {TransId}",
            MessageId,
            TransId);

        return 0;
    }
}
