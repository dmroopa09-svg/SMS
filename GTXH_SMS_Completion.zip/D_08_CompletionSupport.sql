/* ============================================================================
   SUPPORT FOR CAMPAIGN COMPLETION
   ============================================================================
   The completion check runs on EVERY delivery receipt:

       NOT EXISTS (SELECT 1 FROM SMS_Queue_Detail
                   WHERE SMSQueue_Mst_ID = @id
                     AND LifecycleState NOT IN (2,5,7,8))

   Without an index that is a scan of every row in the campaign, on every
   receipt. With one it stops at the first non-terminal row it finds - which on
   a running campaign is almost immediately.

   Safe to run more than once.
   ============================================================================ */

SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSQD_Completion'
                 AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
BEGIN
    CREATE INDEX IX_SMSQD_Completion
        ON dbo.SMS_Queue_Detail (SMSQueue_Mst_ID, LifecycleState);
    PRINT 'Created IX_SMSQD_Completion';
END
GO


/* ============================================================================
   VERIFY - what is blocking each campaign from completing
   ============================================================================ */

SELECT   m.ID              AS CampaignQueueId,
         m.State,
         COUNT(d.ID)       AS TotalRows,
         SUM(CASE WHEN d.LifecycleState IN (2,5,7,8) THEN 1 ELSE 0 END) AS Terminal,
         SUM(CASE WHEN d.LifecycleState NOT IN (2,5,7,8) THEN 1 ELSE 0 END) AS Blocking,
         CASE WHEN SUM(CASE WHEN d.LifecycleState NOT IN (2,5,7,8) THEN 1 ELSE 0 END) = 0
              THEN 'ready to complete'
              ELSE 'blocked' END AS Result
FROM     dbo.SMS_Queue_Mst m
LEFT     JOIN dbo.SMS_Queue_Detail d ON d.SMSQueue_Mst_ID = m.ID
WHERE    m.State IN (1, 2)
GROUP BY m.ID, m.State
ORDER BY m.ID;


/* ---------------------------------------------------------------------------
   WHICH states are blocking, and how many.

   Expect to see mostly 6 (Submitted) - those clear as receipts arrive.

   ⚠ WATCH FOR 10 (ReadyForDelivery). Those never sent and no receipt will ever
     arrive for them, so they block the campaign FOREVER unless compliance's
     expiry sweep moves them to 5 (TerminatedCompliance). If this count is not
     falling, that sweep is not doing its job and completion will never happen.
   --------------------------------------------------------------------------- */
SELECT   d.SMSQueue_Mst_ID AS CampaignQueueId,
         d.LifecycleState,
         CASE d.LifecycleState
              WHEN 0  THEN 'New'
              WHEN 1  THEN 'Eligible'
              WHEN 3  THEN 'Held'
              WHEN 4  THEN 'Ready'
              WHEN 6  THEN 'Submitted - waiting on receipt'
              WHEN 9  THEN 'ComplianceWait'
              WHEN 10 THEN 'ReadyForDelivery - NEVER SENT, will block forever'
              ELSE CAST(d.LifecycleState AS VARCHAR(10)) END AS Meaning,
         COUNT(*) AS Rows
FROM     dbo.SMS_Queue_Detail d
INNER    JOIN dbo.SMS_Queue_Mst m ON m.ID = d.SMSQueue_Mst_ID
WHERE    m.State IN (1, 2)
  AND    d.LifecycleState NOT IN (2, 5, 7, 8)
GROUP BY d.SMSQueue_Mst_ID, d.LifecycleState
ORDER BY d.SMSQueue_Mst_ID, d.LifecycleState;
