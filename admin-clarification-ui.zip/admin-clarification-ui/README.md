# Admin app - Clarification screen wired to the oversight API

Replaces two files in GTXH_OMC/frontend (admin.getixsoft.com):

    src/api/clarifications.ts        REPLACE
    src/components/Clarification.tsx REPLACE

App.tsx needs NO change - it already imports { Clarification } and has the
nav item and the "clarification" view wired.

Backend: the clarifications-oversight-omc drop (api/clarifications/team).
Deploy that first or every call 404s.

## One thing to check before running

src/api/clarifications.ts line ~14:

    const http = {
      get:  <T>(url: string) => apiClient.get<T>(url)  as Promise<T>,
      post: <T>(url: string, body?: unknown) => apiClient.post<T>(url, body) as Promise<T>,
    };

If your apiClient uses different method names, change those two lines. Every
call in the file goes through them, so that is the only place to touch.

## What was dead in the old component, now working

  search box          had value="" and no onChange - typed nothing
  process dropdown    had one empty <option>
  Open/Resolved tabs  had onClick={() => {}}
  date inputs         had no value and no onChange
  Respond button      onClick was commented out
  pagination          currentPage never changed
  row click           navigate() was commented out

## What changed on purpose

STATES. The old tabs said Open / Resolved. The backend derives three states and
the agent app uses the same three, so the tabs are now:

    Awaiting QA   waiting on QA - the actual backlog
    Answered      QA replied, agent has something to read
    Closed        no tasks blocked any more
    All

Open/Resolved could not express "QA answered but the agent has not acted", which
is exactly the state a supervisor needs to see.

FILTER OPTIONS COME FROM /summary, not from listProcesses or a user list. The
summary is already scoped server-side, so the dropdowns cannot offer a process
or an agent the caller is not allowed to see. listProcesses is no longer imported.

PAGING IS SERVER-SIDE. The old component fetched everything and sliced in
memory, which stops being viable the moment a superadmin opens it.

## Still to confirm

Role names in the backend scope resolver, and whether Users.SupervisorId /
ManagerId are actually populated - see section 1 of the backend WIRING.md.
If the hierarchy is empty every supervisor sees the "nobody reports to you"
notice, which is correct behaviour but looks like a bug.
