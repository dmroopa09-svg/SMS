import { apiClient } from "./client";

/**
 * Clarification oversight API - supervisors, managers, superadmins.
 *
 * Talks to api/clarifications/team in GTXH.OMC. The agent-facing endpoints at
 * api/clarifications are a different surface and are not used from the admin app.
 */

// ---------------------------------------------------------------------------
// ADAPT THIS ONE BLOCK if apiClient exposes different method names.
// Everything below goes through it, so this is the only place to change.
// ---------------------------------------------------------------------------
const http = {
  get: <T>(url: string) => apiClient.get<T>(url) as Promise<T>,
  post: <T>(url: string, body?: unknown) => apiClient.post<T>(url, body) as Promise<T>,
};

const BASE = "/api/clarifications/team";

// ---------------------------------------------------------------------------
// States. These match the backend exactly - do not invent new strings here,
// the server filters on them.
// ---------------------------------------------------------------------------
export const ClarificationState = {
  All: "All",
  /** Waiting on QA. This is the backlog a supervisor opens the screen to see. */
  AwaitingQa: "AwaitingQa",
  /** QA answered; the agent has something to read. */
  Received: "Received",
  /** No tasks blocked any more. */
  Closed: "Closed",
} as const;

export type ClarificationStateValue =
  (typeof ClarificationState)[keyof typeof ClarificationState];

export const STATE_LABELS: Record<string, string> = {
  All: "All",
  AwaitingQa: "Awaiting QA",
  Received: "Answered",
  Closed: "Closed",
};

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface ClarificationQueueItem {
  ticketId: number;
  processId: number | null;
  processName: string | null;
  state: string;
  createdDate: string;
  lastUpdateDate: string | null;
  raisedByUserId: number | null;
  raisedByName: string | null;
  lastAuditorId: string | null;
  lastAuditorName: string | null;
  taskCount: number;
  blockedTaskCount: number;
  commentCount: number;
  firstQuestion: string | null;
  lastComment: string | null;
  lastCommentBy: string | null;
  /** Hours since the agent's last unanswered message. Null once QA replied. */
  hoursWaiting: number | null;

  /** Client-side only, built in mapRow. Not sent by the server. */
  displayId: string;
}

export interface PagedClarifications {
  items: ClarificationQueueItem[];
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export interface ClarificationComment {
  commentId: number;
  userType: string; // "Agent" | "Auditor"
  userName: string | null;
  comment: string;
  createdDate: string;
}

export interface ClarificationTask {
  taskId: number;
  externalRef: string | null;
  status: string;
  isBlocked: boolean;
  taskData: string | null;
  processId: number;
}

export interface ClarificationThread {
  ticketId: number;
  state: string;
  processName: string | null;
  createdDate: string;
  lastUpdateDate: string | null;
  comments: ClarificationComment[];
  tasks: ClarificationTask[];
}

export interface ClarificationAgentSummary {
  userId: number;
  userName: string | null;
  received: number;
  awaitingQa: number;
  closed: number;
  total: number;
  longestWaitHours: number | null;
}

export interface ClarificationProcessSummary {
  processId: number | null;
  processName: string | null;
  received: number;
  awaitingQa: number;
  closed: number;
  total: number;
}

export interface ClarificationSummary {
  received: number;
  awaitingQa: number;
  closed: number;
  total: number;
  /** AwaitingQa tickets with no reply for more than 24 hours. */
  ageing: number;
  agentsBlocked: number;
  byAgent: ClarificationAgentSummary[];
  byProcess: ClarificationProcessSummary[];
}

export interface ClarificationScope {
  roleName: string;
  allUsers: boolean;
  /**
   * False means this user only sees their own clarifications and belongs on the
   * agent app, not here. The screen shows a notice rather than an empty table.
   */
  isOversight: boolean;
  /** -1 when allUsers is true. */
  visibleAgentCount: number;
  canComment: boolean;
  canResume: boolean;
}

export interface ClarificationQuery {
  state?: string | null;
  agentUserId?: number | null;
  processId?: number | null;
  search?: string | null;
  fromDate?: string | null;
  toDate?: string | null;
  minHoursWaiting?: number | null;
  page?: number;
  pageSize?: number;
  sortKey?: string | null;
  sortDirection?: string | null;
}

// ---------------------------------------------------------------------------
// Calls
// ---------------------------------------------------------------------------

/**
 * Ticket ids are bare numbers on the server. The table wants something that
 * reads as a reference, so it is built here rather than stored - a display
 * format is a presentation concern and should not be in the database.
 */
function mapRow(raw: Omit<ClarificationQueueItem, "displayId">): ClarificationQueueItem {
  return {
    ...raw,
    displayId: `CLR-${String(raw.ticketId).padStart(5, "0")}`,
  };
}

export async function listClarifications(
  query: ClarificationQuery = {},
): Promise<PagedClarifications> {
  const body = {
    state: query.state ?? null,
    agentUserId: query.agentUserId ?? null,
    processId: query.processId ?? null,
    search: query.search ?? null,
    fromDate: query.fromDate ?? null,
    toDate: query.toDate ?? null,
    minHoursWaiting: query.minHoursWaiting ?? null,
    page: query.page ?? 1,
    pageSize: query.pageSize ?? 10,
    sortKey: query.sortKey ?? null,
    sortDirection: query.sortDirection ?? null,
  };

  const res = await http.post<PagedClarifications>(`${BASE}/search`, body);

  return {
    ...res,
    items: (res?.items ?? []).map(mapRow),
  };
}

export function getClarificationThread(ticketId: number): Promise<ClarificationThread> {
  return http.get<ClarificationThread>(`${BASE}/${ticketId}`);
}

export function addClarificationComment(
  ticketId: number,
  comment: string,
): Promise<ClarificationThread> {
  return http.post<ClarificationThread>(`${BASE}/${ticketId}/comments`, { comment });
}

export function resumeClarification(ticketId: number): Promise<ClarificationThread> {
  return http.post<ClarificationThread>(`${BASE}/${ticketId}/resume`);
}

export function getClarificationSummary(): Promise<ClarificationSummary> {
  return http.get<ClarificationSummary>(`${BASE}/summary`);
}

export function getClarificationScope(): Promise<ClarificationScope> {
  return http.get<ClarificationScope>(`${BASE}/scope`);
}

export function listClarificationAgents(): Promise<
  { userId: number; userName: string | null }[]
> {
  return http.get<{ userId: number; userName: string | null }[]>(`${BASE}/agents`);
}
