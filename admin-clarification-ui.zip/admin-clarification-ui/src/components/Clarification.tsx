import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Search,
  SearchCheck,
  X,
  Clock,
  AlertTriangle,
  Users,
  MessageSquare,
  PlayCircle,
  Loader2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../types";
import {
  listClarifications,
  getClarificationThread,
  addClarificationComment,
  resumeClarification,
  getClarificationSummary,
  getClarificationScope,
  ClarificationState,
  STATE_LABELS,
  type ClarificationQueueItem,
  type ClarificationThread,
  type ClarificationSummary,
  type ClarificationScope,
} from "../api/clarifications";

const ITEMS_PER_PAGE = 10;

const STATE_TABS = [
  ClarificationState.AwaitingQa,
  ClarificationState.Received,
  ClarificationState.Closed,
  ClarificationState.All,
] as const;

function formatDateOnly(date: Date) {
  return date.toISOString().split("T")[0];
}

/**
 * The API returns UTC. SQL Server datetime2 carries no offset, so a value can
 * arrive without a trailing Z - appending one makes the browser convert to local
 * time instead of reading it as local and silently shifting by the offset.
 */
function formatDate(value: string | null | undefined) {
  if (!value) return "-";
  const normalized =
    /^\d{4}-\d{2}-\d{2}T/.test(value) && !/[zZ]|[+-]\d{2}:\d{2}$/.test(value)
      ? `${value}Z`
      : value;
  const d = new Date(normalized);
  if (isNaN(d.getTime())) return "-";
  const pad = (n: number) => n.toString().padStart(2, "0");
  let hours = d.getHours();
  const minutes = pad(d.getMinutes());
  const ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12 || 12;
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(hours)}:${minutes} ${ampm}`;
}

function initials(name: string | null | undefined) {
  return (name || "U")
    .split(" ")
    .map((n) => n[0])
    .join("")
    .substring(0, 2)
    .toUpperCase();
}

function stateBadge(state: string) {
  switch (state) {
    case ClarificationState.AwaitingQa:
      return "bg-amber-50 text-amber-700 border-amber-200";
    case ClarificationState.Received:
      return "bg-blue-50 text-blue-600 border-blue-100";
    case ClarificationState.Closed:
      return "bg-emerald-50 text-emerald-600 border-emerald-100";
    default:
      return "bg-slate-50 text-slate-500 border-slate-200";
  }
}

export const Clarification: React.FC = () => {
  const [scope, setScope] = useState<ClarificationScope | null>(null);
  const [summary, setSummary] = useState<ClarificationSummary | null>(null);
  const [items, setItems] = useState<ClarificationQueueItem[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [state, setState] = useState<string>(ClarificationState.AwaitingQa);
  const [processFilter, setProcessFilter] = useState<string>("");
  const [agentFilter, setAgentFilter] = useState<string>("");
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [onlyAgeing, setOnlyAgeing] = useState(false);

  const today = new Date();
  const weekAgo = new Date();
  weekAgo.setDate(today.getDate() - 29);
  const [start, setStart] = useState(formatDateOnly(weekAgo));
  const [end, setEnd] = useState(formatDateOnly(today));
  const [useDates, setUseDates] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [openTicketId, setOpenTicketId] = useState<number | null>(null);

  const searchRef = useRef<HTMLInputElement>(null);

  // Debounce typing so a search does not fire a request per keystroke.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), 350);
    return () => clearTimeout(t);
  }, [searchInput]);

  // Any filter change resets to page 1 - staying on page 4 of a result set that
  // now has two pages shows an empty table and reads as a bug.
  useEffect(() => {
    setCurrentPage(1);
  }, [state, processFilter, agentFilter, search, onlyAgeing, useDates, start, end]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const s = await getClarificationScope();
        if (!cancelled) setScope(s);
      } catch {
        if (!cancelled) setScope(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const loadSummary = useCallback(async () => {
    try {
      const s = await getClarificationSummary();
      setSummary(s);
    } catch {
      setSummary(null);
    }
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await listClarifications({
        state,
        processId: processFilter ? Number(processFilter) : null,
        agentUserId: agentFilter ? Number(agentFilter) : null,
        search: search || null,
        minHoursWaiting: onlyAgeing ? 24 : null,
        ...(useDates && start && end ? { fromDate: start, toDate: end } : {}),
        page: currentPage,
        pageSize: ITEMS_PER_PAGE,
      });
      setItems(res.items);
      setTotalCount(res.totalCount);
      setTotalPages(res.totalPages);
    } catch (e) {
      setLoadError(
        e instanceof Error ? e.message : "Failed to load the clarification queue",
      );
      setItems([]);
      setTotalCount(0);
      setTotalPages(0);
    } finally {
      setLoading(false);
    }
  }, [state, processFilter, agentFilter, search, onlyAgeing, useDates, start, end, currentPage]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    void loadSummary();
  }, [loadSummary]);

  // Ctrl+F focuses the search box rather than opening the browser's find bar,
  // which is what the placeholder already promises.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Filter options come from the summary, which is already scoped server-side.
  // Building them from a full process or user list would offer the caller rows
  // they are not allowed to see.
  const processOptions = useMemo(
    () =>
      (summary?.byProcess ?? [])
        .filter((p) => p.processId != null)
        .map((p) => ({ id: String(p.processId), name: p.processName ?? `Process ${p.processId}` })),
    [summary],
  );

  const agentOptions = useMemo(
    () =>
      (summary?.byAgent ?? []).map((a) => ({
        id: String(a.userId),
        name: a.userName ?? `User ${a.userId}`,
        awaiting: a.awaitingQa,
      })),
    [summary],
  );

  const refreshAll = useCallback(() => {
    void load();
    void loadSummary();
  }, [load, loadSummary]);

  // -----------------------------------------------------------------------

  if (scope && !scope.isOversight) {
    return (
      <div className="min-h-screen p-6">
        <div className="max-w-3xl mx-auto mt-24 bg-white rounded-[32px] border border-slate-200 shadow-soft p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 flex items-center justify-center mx-auto mb-5">
            <AlertTriangle className="w-7 h-7 text-amber-500" />
          </div>
          <h2 className="text-xl font-black text-slate-900 mb-2">
            No team clarifications to show
          </h2>
          <p className="text-sm text-slate-500 font-medium leading-relaxed">
            This screen shows clarifications raised by the agents who report to
            you. Your account{scope.roleName ? ` (${scope.roleName})` : ""} does
            not have anyone reporting to it, so there is nothing here yet.
            <br />
            <br />
            If that looks wrong, ask an administrator to check the supervisor and
            manager fields on your team's user records.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen from-zinc-50 via-white to-zinc-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
              <SearchCheck className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tight text-zinc-900">
                Clarification
              </h1>
              <p className="text-sm text-zinc-500 mt-1 font-medium">
                {scope?.allUsers
                  ? "Clarification requests raised by agents across every process."
                  : "Clarification requests raised by agents on your team while working tasks."}
              </p>
            </div>
          </div>
        </div>

        {/* Summary tiles */}
        {summary && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <SummaryTile
              label="Awaiting QA"
              value={summary.awaitingQa}
              icon={Clock}
              tone="amber"
              active={state === ClarificationState.AwaitingQa}
              onClick={() => setState(ClarificationState.AwaitingQa)}
            />
            <SummaryTile
              label="Answered"
              value={summary.received}
              icon={MessageSquare}
              tone="blue"
              active={state === ClarificationState.Received}
              onClick={() => setState(ClarificationState.Received)}
            />
            <SummaryTile
              label="Closed"
              value={summary.closed}
              icon={SearchCheck}
              tone="emerald"
              active={state === ClarificationState.Closed}
              onClick={() => setState(ClarificationState.Closed)}
            />
            <SummaryTile
              label="Over 24h"
              value={summary.ageing}
              icon={AlertTriangle}
              tone="red"
              active={onlyAgeing}
              onClick={() => {
                setOnlyAgeing((v) => !v);
                setState(ClarificationState.AwaitingQa);
              }}
            />
            <SummaryTile
              label="Agents blocked"
              value={summary.agentsBlocked}
              icon={Users}
              tone="slate"
            />
          </div>
        )}

        {/* Search & Filter Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-zinc-100 p-2 shrink-0">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[260px] max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                ref={searchRef}
                placeholder="Search ticket, process, or message… (Ctrl+F)"
                className="w-full pl-9 pr-10 py-2 text-sm bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-zinc-200 transition-all"
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
              />
              {searchInput && (
                <button
                  type="button"
                  onClick={() => setSearchInput("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-6 h-6 rounded-md flex items-center justify-center text-zinc-400 hover:text-zinc-600 hover:bg-zinc-100"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <select
              value={processFilter}
              onChange={(e) => setProcessFilter(e.target.value)}
              className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium outline-none focus:ring-2 focus:ring-brand min-w-[180px]"
            >
              <option value="">All processes</option>
              {processOptions.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>

            <select
              value={agentFilter}
              onChange={(e) => setAgentFilter(e.target.value)}
              className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium outline-none focus:ring-2 focus:ring-brand min-w-[180px]"
            >
              <option value="">All agents</option>
              {agentOptions.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                  {a.awaiting > 0 ? ` (${a.awaiting})` : ""}
                </option>
              ))}
            </select>

            <div className="flex flex-wrap items-center gap-2">
              <label className="flex items-center gap-2 px-3 h-11 bg-slate-50 border border-slate-200 rounded-full cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={useDates}
                  onChange={(e) => setUseDates(e.target.checked)}
                  className="accent-[#94A142]"
                />
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Dates
                </span>
              </label>

              <div
                className={cn(
                  "flex items-center bg-white border border-zinc-200 rounded-full px-3 h-11 shadow-sm transition",
                  !useDates && "opacity-40 pointer-events-none",
                )}
              >
                <input
                  type="date"
                  value={start}
                  max={end}
                  onChange={(e) => setStart(e.target.value)}
                  className="appearance-none bg-transparent text-sm text-gray-800 outline-none w-[130px] pr-1 cursor-pointer"
                />
                <span className="mx-2 text-gray-400">—</span>
                <input
                  type="date"
                  value={end}
                  min={start}
                  onChange={(e) => setEnd(e.target.value)}
                  className="appearance-none bg-transparent text-sm text-gray-800 outline-none w-[130px] pr-1 cursor-pointer"
                />
              </div>
            </div>

            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl border border-slate-200">
              {STATE_TABS.map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setState(f)}
                  className={cn(
                    "px-3.5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                    state === f
                      ? "bg-white text-brand shadow-sm"
                      : "text-slate-400 hover:text-slate-600",
                  )}
                >
                  {STATE_LABELS[f]}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* clarification table */}
        <div className="bg-white rounded-[32px] border border-slate-200 shadow-soft overflow-hidden">
          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left border-collapse min-w-[1100px]">
              <thead className="sticky top-0 z-10 bg-slate-50">
                <tr className="border-b border-slate-200">
                  {[
                    "Ticket",
                    "Agent",
                    "Process",
                    "Tasks",
                    "Last message",
                    "Status",
                    "Waiting",
                    "Last activity",
                  ].map((h) => (
                    <th
                      key={h}
                      className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest"
                    >
                      {h}
                    </th>
                  ))}
                  <th className="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading && (
                  <tr>
                    <td colSpan={9} className="px-8 py-16 text-center">
                      <Loader2 className="w-6 h-6 text-slate-300 animate-spin mx-auto" />
                    </td>
                  </tr>
                )}

                {!loading && loadError && (
                  <tr>
                    <td colSpan={9} className="px-8 py-16 text-center">
                      <p className="text-sm font-bold text-red-500 mb-3">{loadError}</p>
                      <button
                        type="button"
                        onClick={refreshAll}
                        className="px-4 py-2 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest"
                      >
                        Retry
                      </button>
                    </td>
                  </tr>
                )}

                {!loading && !loadError && items.length === 0 && (
                  <tr>
                    <td colSpan={9} className="px-8 py-16 text-center">
                      <SearchCheck className="w-10 h-10 text-slate-200 mx-auto mb-3" />
                      <p className="text-sm font-bold text-slate-400">
                        No clarifications match these filters
                      </p>
                    </td>
                  </tr>
                )}

                {!loading &&
                  !loadError &&
                  items.map((row, index) => (
                    <motion.tr
                      key={row.ticketId}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.03 }}
                      className="hover:bg-slate-50/80 transition-all group cursor-pointer"
                      onClick={() => setOpenTicketId(row.ticketId)}
                    >
                      <td className="px-6 py-5 whitespace-nowrap">
                        <div className="flex flex-col">
                          <span className="text-sm font-black text-slate-900">
                            {row.displayId}
                          </span>
                          <span className="text-[11px] text-slate-400 font-medium">
                            Created {formatDate(row.createdDate)}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-brand/10 flex items-center justify-center text-brand font-black text-[10px]">
                            {initials(row.raisedByName)}
                          </div>
                          <span className="text-sm font-black text-slate-900 tracking-tight">
                            {row.raisedByName || "-"}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-5">
                        <span className="text-sm font-bold text-slate-600">
                          {row.processName || "-"}
                        </span>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <span className="text-sm font-bold text-slate-600">
                          {row.taskCount}
                        </span>
                        {row.blockedTaskCount > 0 && (
                          <span className="ml-2 text-[10px] font-black uppercase tracking-wider text-amber-600">
                            {row.blockedTaskCount} blocked
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-5 max-w-[260px]">
                        <div className="text-sm font-medium text-slate-600 truncate">
                          {row.lastComment || "—"}
                        </div>
                        {row.lastCommentBy && (
                          <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">
                            Sender: {row.lastCommentBy}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <span
                          className={cn(
                            "px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border",
                            stateBadge(row.state),
                          )}
                        >
                          {STATE_LABELS[row.state] ?? row.state}
                        </span>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        {row.hoursWaiting == null ? (
                          <span className="text-sm text-slate-300">—</span>
                        ) : (
                          <span
                            className={cn(
                              "text-sm font-black",
                              row.hoursWaiting >= 24 ? "text-red-500" : "text-slate-600",
                            )}
                          >
                            {row.hoursWaiting < 1
                              ? "<1h"
                              : `${Math.round(row.hoursWaiting)}h`}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <span className="text-sm font-bold text-slate-600">
                          {formatDate(row.lastUpdateDate)}
                        </span>
                      </td>
                      <td className="px-6 py-5 text-right">
                        <button
                          type="button"
                          className="px-4 py-2 bg-brand text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-brand-dark transition-all shadow-md"
                          onClick={(e) => {
                            e.stopPropagation();
                            setOpenTicketId(row.ticketId);
                          }}
                        >
                          {scope?.canComment ? "Respond" : "View"}
                        </button>
                      </td>
                    </motion.tr>
                  ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {!loading && totalCount > 0 && (
            <div className="flex items-center justify-between px-8 py-5 border-t border-slate-100 bg-slate-50/50">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                {(currentPage - 1) * ITEMS_PER_PAGE + 1}–
                {Math.min(currentPage * ITEMS_PER_PAGE, totalCount)} of {totalCount}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  className="w-9 h-9 rounded-xl border border-slate-200 bg-white flex items-center justify-center text-slate-500 disabled:opacity-30 hover:bg-slate-50"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-black text-slate-600 px-2">
                  {currentPage} / {Math.max(totalPages, 1)}
                </span>
                <button
                  type="button"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((p) => p + 1)}
                  className="w-9 h-9 rounded-xl border border-slate-200 bg-white flex items-center justify-center text-slate-500 disabled:opacity-30 hover:bg-slate-50"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {openTicketId != null && (
          <ThreadModal
            ticketId={openTicketId}
            scope={scope}
            onClose={() => setOpenTicketId(null)}
            onChanged={refreshAll}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

// ===========================================================================

const TONES: Record<string, string> = {
  amber: "bg-amber-50 text-amber-600",
  blue: "bg-blue-50 text-blue-600",
  emerald: "bg-emerald-50 text-emerald-600",
  red: "bg-red-50 text-red-500",
  slate: "bg-slate-100 text-slate-500",
};

const SummaryTile: React.FC<{
  label: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  tone: keyof typeof TONES | string;
  active?: boolean;
  onClick?: () => void;
}> = ({ label, value, icon: Icon, tone, active, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    disabled={!onClick}
    className={cn(
      "bg-white rounded-2xl border p-4 flex items-center gap-3 text-left transition-all",
      active ? "border-brand ring-2 ring-brand/20" : "border-slate-200",
      onClick ? "hover:border-slate-300 cursor-pointer" : "cursor-default",
    )}
  >
    <div
      className={cn(
        "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
        TONES[tone] ?? TONES.slate,
      )}
    >
      <Icon className="w-5 h-5" />
    </div>
    <div className="min-w-0">
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest truncate">
        {label}
      </p>
      <p className="text-xl font-black text-slate-900">{value}</p>
    </div>
  </button>
);

// ===========================================================================

const ThreadModal: React.FC<{
  ticketId: number;
  scope: ClarificationScope | null;
  onClose: () => void;
  onChanged: () => void;
}> = ({ ticketId, scope, onClose, onChanged }) => {
  const [thread, setThread] = useState<ClarificationThread | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const [sending, setSending] = useState(false);
  const [confirmResume, setConfirmResume] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const t = await getClarificationThread(ticketId);
        if (!cancelled) setThread(t);
      } catch (e) {
        if (!cancelled)
          setError(e instanceof Error ? e.message : "Failed to load the thread");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [ticketId]);

  // Escape closes, unless a destructive confirm is showing - that would make it
  // ambiguous whether Escape dismissed the confirm or the whole modal.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (confirmResume) setConfirmResume(false);
      else onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [confirmResume, onClose]);

  const send = async () => {
    const text = reply.trim();
    if (!text || sending) return;
    setSending(true);
    try {
      const t = await addClarificationComment(ticketId, text);
      setThread(t);
      setReply("");
      onChanged();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to send the comment");
    } finally {
      setSending(false);
    }
  };

  const doResume = async () => {
    setSending(true);
    try {
      const t = await resumeClarification(ticketId);
      setThread(t);
      setConfirmResume(false);
      onChanged();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to resume the tasks");
    } finally {
      setSending(false);
    }
  };

  const blockedCount = thread?.tasks.filter((t) => t.isBlocked).length ?? 0;
  const isClosed = thread?.state === ClarificationState.Closed;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 12 }}
        className="bg-white rounded-[28px] border border-slate-200 shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden"
        onClick={(e: React.MouseEvent) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-7 py-5 border-b border-slate-100 flex items-start justify-between shrink-0">
          <div>
            <h3 className="text-lg font-black text-slate-900">
              CLR-{String(ticketId).padStart(5, "0")}
            </h3>
            <p className="text-xs text-slate-400 font-bold mt-0.5">
              {thread?.processName || "—"} · {thread?.tasks.length ?? 0} task(s)
              {blockedCount > 0 && ` · ${blockedCount} blocked`}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar px-7 py-5 space-y-4">
          {loading && (
            <div className="py-16 text-center">
              <Loader2 className="w-6 h-6 text-slate-300 animate-spin mx-auto" />
            </div>
          )}

          {error && (
            <div className="px-4 py-3 bg-red-50 border border-red-100 rounded-xl text-sm font-bold text-red-600">
              {error}
            </div>
          )}

          {!loading &&
            thread?.comments.map((c) => {
              const isAgent = c.userType?.toLowerCase() === "agent";
              return (
                <div
                  key={c.commentId}
                  className={cn("flex gap-3", isAgent ? "" : "flex-row-reverse")}
                >
                  <div
                    className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black shrink-0",
                      isAgent
                        ? "bg-slate-100 text-slate-500"
                        : "bg-brand/10 text-brand",
                    )}
                  >
                    {initials(c.userName)}
                  </div>
                  <div
                    className={cn(
                      "max-w-[75%] rounded-2xl px-4 py-3",
                      isAgent
                        ? "bg-slate-50 border border-slate-100"
                        : "bg-brand/5 border border-brand/10",
                    )}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-slate-700">
                        {c.userName || c.userType}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400">
                        {formatDate(c.createdDate)}
                      </span>
                    </div>
                    <p className="text-sm text-slate-700 whitespace-pre-wrap leading-relaxed">
                      {c.comment}
                    </p>
                  </div>
                </div>
              );
            })}

          {!loading && thread && thread.tasks.length > 0 && (
            <div className="pt-2">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">
                Tasks on this ticket
              </p>
              <div className="flex flex-wrap gap-2">
                {thread.tasks.map((t) => (
                  <span
                    key={t.taskId}
                    className={cn(
                      "px-3 py-1.5 rounded-lg text-[11px] font-bold border",
                      t.isBlocked
                        ? "bg-amber-50 text-amber-700 border-amber-200"
                        : "bg-slate-50 text-slate-500 border-slate-200",
                    )}
                    title={t.isBlocked ? "Blocked awaiting clarification" : t.status}
                  >
                    {t.externalRef || `Task ${t.taskId}`}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {!loading && thread && (
          <div className="border-t border-slate-100 px-7 py-4 shrink-0 space-y-3">
            {isClosed ? (
              <p className="text-xs font-bold text-slate-400 text-center py-2">
                This clarification is closed — no tasks are blocked any more.
              </p>
            ) : (
              <>
                {scope?.canComment && (
                  <div className="flex items-end gap-2">
                    <textarea
                      value={reply}
                      onChange={(e) => setReply(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
                          e.preventDefault();
                          void send();
                        }
                      }}
                      rows={2}
                      placeholder="Add a comment for the agent… (Ctrl+Enter to send)"
                      className="flex-1 px-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl resize-none outline-none focus:bg-white focus:ring-2 focus:ring-brand/20"
                    />
                    <button
                      type="button"
                      onClick={() => void send()}
                      disabled={!reply.trim() || sending}
                      className="px-5 py-2.5 bg-brand text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-brand-dark disabled:opacity-40 transition-all shadow-md"
                    >
                      {sending ? "…" : "Send"}
                    </button>
                  </div>
                )}

                {scope?.canResume && blockedCount > 0 && (
                  <>
                    <div className="h-px bg-slate-100" />
                    {!confirmResume ? (
                      <button
                        type="button"
                        onClick={() => setConfirmResume(true)}
                        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all"
                      >
                        <PlayCircle className="w-4 h-4" />
                        Resume {blockedCount} blocked task(s)
                      </button>
                    ) : (
                      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                        <p className="text-xs font-bold text-amber-800 mb-3 leading-relaxed">
                          {thread.state === ClarificationState.AwaitingQa
                            ? "QA has not replied yet. Resuming unblocks the agent without an answer — they will carry on with the information they already have."
                            : "This will unblock the tasks and return them to the agent's queue."}
                        </p>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => void doResume()}
                            disabled={sending}
                            className="px-4 py-2 bg-amber-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest disabled:opacity-50"
                          >
                            {sending ? "…" : "Yes, resume"}
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmResume(false)}
                            className="px-4 py-2 border border-amber-300 text-amber-700 rounded-lg text-[10px] font-black uppercase tracking-widest"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </>
            )}
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};
