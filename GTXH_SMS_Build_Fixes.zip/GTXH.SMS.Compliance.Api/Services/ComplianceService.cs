using GTXH.SMS.Common;
using GTXH.SMS.Compliance.Api.Data;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text.Json;

namespace GTXH.SMS.Compliance.Api.Services;

public sealed class ComplianceService(
     ComplianceDbContext db,
     IEventPublisher publisher,
     TimeZoneResolver timeZoneResolver,
     ComplianceQuotaService quota,
     IConfiguration configuration,
     ILogger<ComplianceService> logger)
{
    public async Task IngestEligibleAsync(EligibleRecipientEvent message, CancellationToken ct)
    {
        if (await db.Holds.AsNoTracking().AnyAsync(h => h.MessageId == message.MessageId, ct))
            return;

        //Ensure its not processed again
        if (await db.CampaignMembers.AsNoTracking().AnyAsync(k =>
           k.ID == message.MessageId &&
           k.SMSQueue_Mst_ID == message.CampaignQueueId &&
           (k.LifecycleState == MessageLifecycleState.TerminatedCompliance ||
           k.LifecycleState == MessageLifecycleState.ComplianceWait), ct))
            return;

        var campaignQueueId = message.CampaignQueueId ?? 0;
        var quotaMirror = await db.CampaignQueue.FindAsync([(int)campaignQueueId], ct);

        var geo = await timeZoneResolver.ResolveStrictAsync(
            message.ZipCode,
            message.StateCode,
            message.Phone,
            ct);

        if (!geo.Ok)
        {
            await TerminateWithoutHoldAsync(message, geo.ReasonCode ?? "GEO_UNRESOLVED", ct);
            return;
        }

        var stateCode = geo.StateCode!;
        var ianaTz = geo.IanaTimeZone!;

        var stateRule = await LoadActiveStateRuleAsync(stateCode, ct);

        if (stateRule is null)
        {
            await TerminateWithoutHoldAsync(message, "STATE_RULE_NOT_FOUND", ct);
            return;
        }

        if (!stateRule.SmsAllowed)
        {
            await TerminateWithoutHoldAsync(message, "STATE_SMS_NOT_ALLOWED", ct);
            return;
        }

        if (stateRule.AllowedStartHour is null || stateRule.AllowedEndHour is null)
        {
            await TerminateWithoutHoldAsync(message, "STATE_HOURS_NOT_CONFIGURED", ct);
            return;
        }

        // FIX: a hold with no usable template cannot be released — the cast in
        // ReleaseHoldAsync would throw and take down the whole release batch,
        // not just this message. Reject it here where it is one message.
        //
        // EligibleRecipientEvent.TemplateId is a non-nullable int, so only the
        // zero/negative case needs guarding here. HoldEntity.TemplateId IS
        // nullable, which is why ReleaseHoldAsync still checks for null.
        if (message.TemplateId <= 0)
        {
            await TerminateWithoutHoldAsync(message, "TEMPLATE_MISSING", ct);
            return;
        }

        // Calculate when to send message based on compliance and when to expire when not sent
        var sendAt = await CalculateSendAtAsync(ianaTz, stateRule, message.CampaignQueueId, message.Phone, ct);
        var expireAt = CalculateExpireAt(ianaTz, quotaMirror);

        var hold = new HoldEntity
        {
            MessageId = message.MessageId!,
            CampaignQueueId = (long)message.CampaignQueueId,
            CampaignId = message.CampaignId,
            Phone = message.Phone,
            StateCode = stateCode,
            ZipCode = geo.Zip5 ?? message.ZipCode,
            ResolvedTimeZone = ianaTz,
            TemplateId = message.TemplateId,
            Account_Info_ID = message.Account_Info_ID,
            SendAt = sendAt,
            ExpireAt = expireAt,
            Status = HoldStatus.Held
        };
        db.Holds.Add(hold);
        await db.SaveChangesAsync(ct);

        var campmember = await db.CampaignMembers.Where(k =>
            k.ID == message.MessageId &&
            k.SMSQueue_Mst_ID == message.CampaignQueueId
        ).ExecuteUpdateAsync(s => s
                         .SetProperty(a => a.LifecycleState, MessageLifecycleState.ComplianceWait)
                         .SetProperty(a => a.Status, CampaignMemberStatus.Processing)
                         .SetProperty(a => a.EmittedAt, DateTime.UtcNow), ct);   // FIX: was DateTime.Now

        logger.LogInformation(
            "Hold created {MessageId} state={State} tz={Tz} via={Source} sendAt={SendAt}",
            hold.MessageId, stateCode, ianaTz, geo.Source, sendAt);
    }

    // =====================================================================
    // SEND TIME
    // =====================================================================

    /// <summary>
    /// Earliest legal send instant for this recipient, in UTC.
    /// </summary>
    /// <remarks>
    /// DAYLIGHT SAVING — READ BEFORE CHANGING THIS METHOD.
    ///
    /// The previous version built the target time with the offset in force RIGHT
    /// NOW and then applied it to a date that might be tomorrow:
    ///
    ///     var next = new DateTimeOffset(local.Year, local.Month, local.Day,
    ///                                   startHour, 0, 0, local.Offset);
    ///     if (hour >= endHour) next = next.AddDays(1);
    ///
    /// On the two days a year when the offset changes between today and
    /// tomorrow, that produces an instant exactly one hour wrong:
    ///
    ///     America/New_York, window 08:00-21:00
    ///     now  2026-10-31 22:00 EDT (-04:00), so schedule tomorrow 08:00
    ///     built  2026-11-01 08:00 -04:00  ->  12:00Z
    ///     correct 2026-11-01 08:00 -05:00 ->  13:00Z
    ///     12:00Z on Nov 1 in New York is 07:00 local
    ///     -> the message fires an hour BEFORE the legal window opens
    ///
    /// The spring transition fails the other way (09:00 instead of 08:00), which
    /// is merely wrong. The autumn direction is a TCPA breach, it affects every
    /// recipient in that zone, and nothing in any log would explain it.
    ///
    /// The fix is to build the wall-clock time as an UNSPECIFIED DateTime and let
    /// ConvertTimeToUtc look up the offset in force on that specific date.
    /// </remarks>
    private async Task<DateTimeOffset> CalculateSendAtAsync(
        string ianaTz,
        StateTcpARulesEntity rule,
        long? CampaignQueueId,
        string phone,
        CancellationToken ct)
    {
        var now = DateTimeOffset.UtcNow;
        var startHour = rule.AllowedStartHour!.Value;
        var endHour = rule.AllowedEndHour!.Value;

        var tz = TimeZoneResolver.FindTimeZone(ianaTz);
        var local = TimeZoneInfo.ConvertTime(now, tz);
        var hour = local.Hour;
        DateTimeOffset sendAt;

        if (hour >= startHour && hour < endHour)
        {
            sendAt = now;
        }
        else
        {
            // Wall-clock time, with no offset attached yet.
            var wallClock = new DateTime(
                local.Year, local.Month, local.Day,
                startHour, 0, 0, DateTimeKind.Unspecified);

            if (hour >= endHour)
                wallClock = wallClock.AddDays(1);

            sendAt = ToUtcSafe(wallClock, tz);
        }

        ///TODO: MinDays and MaxDays are hanlded based on the Phone Queue which needs to be updated later according to DBID and Others
        if (rule.MinDaysBetweenSms is > 0)
        {
            var lastReleased = await db.Holds.AsNoTracking()
                .Where(h => h.CampaignQueueId == CampaignQueueId
                         && h.Phone == phone
                         && h.Status == HoldStatus.Released)
                .OrderByDescending(h => h.UpdatedAt)
                .Select(h => (DateTimeOffset?)h.UpdatedAt)
                .FirstOrDefaultAsync(ct);

            if (lastReleased is not null)
            {
                var earliest = lastReleased.Value.AddDays(rule.MinDaysBetweenSms.Value);
                if (earliest > sendAt)
                    sendAt = earliest;
            }
        }

        //TODO: Same Rule has above
        if (rule.MaxSmsPerRolling30Days is > 0)
        {
            var windowStart = now.AddDays(-30);
            var recent = await db.Holds.AsNoTracking()
                .Where(h => h.CampaignQueueId == CampaignQueueId
                         && h.Phone == phone
                         && h.Status == HoldStatus.Released
                         && h.UpdatedAt >= windowStart)
                .OrderBy(h => h.UpdatedAt)
                .Select(h => h.UpdatedAt)
                .ToListAsync(ct);

            if (recent.Count >= rule.MaxSmsPerRolling30Days.Value)
            {
                var earliestRetry = recent[0].AddDays(30);
                if (earliestRetry > sendAt)
                    sendAt = earliestRetry;
            }
        }

        return sendAt;
    }

    /// <summary>
    /// Converts a local wall-clock time to UTC, handling both daylight-saving
    /// edge cases rather than assuming every wall-clock time exists exactly once.
    /// </summary>
    private static DateTimeOffset ToUtcSafe(DateTime wallClock, TimeZoneInfo tz)
    {
        var unspecified = DateTime.SpecifyKind(wallClock, DateTimeKind.Unspecified);

        // Spring forward: 02:00-03:00 does not occur on that date. A window start
        // inside the gap has no valid instant, so step past it.
        if (tz.IsInvalidTime(unspecified))
            unspecified = unspecified.AddHours(1);

        // Autumn: the hour occurs twice. ConvertTimeToUtc resolves ambiguous
        // times to standard time, which is the LATER instant — the safe choice
        // when the value represents "earliest permitted".
        return new DateTimeOffset(TimeZoneInfo.ConvertTimeToUtc(unspecified, tz));
    }

    private async Task<StateTcpARulesEntity?> LoadActiveStateRuleAsync(string? stateCode, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(stateCode))
            return null;

        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        return await db.StateTcpARules
            .AsNoTracking()
            .Where(r => r.StateCode == stateCode
                     && r.IsActive
                     && r.EffectiveDate <= today
                     && (r.ExpirationDate == null || r.ExpirationDate >= today))
            .FirstOrDefaultAsync(ct);
    }

    /// <summary>
    /// Expiry for a campaign queue is set to end of local day by default.
    /// </summary>
    /// <remarks>
    /// Carries the SAME daylight-saving fix as CalculateSendAtAsync. The previous
    /// version used localNow.Offset to build an expiry that may fall on the next
    /// day, so holds expired an hour early or late across each transition.
    /// </remarks>
    private DateTimeOffset? CalculateExpireAt(string ianaTz, CampaignQuotaMirrorEntity? mirror)
    {
        var globalEnabled = configuration.GetValue("Compliance:HoldExpiry:Enabled", true);

        //TODO: Need to setup
        var campaignEnabled = mirror?.ExpirePendingEndOfDay ?? true;
        if (!globalEnabled || !campaignEnabled)
            return null;

        var timeText = mirror?.HoldExpireLocalTime
            ?? configuration["Compliance:HoldExpiry:DefaultEndOfDayLocal"]
            ?? "23:59:59";

        if (!TimeSpan.TryParseExact(timeText, @"hh\:mm\:ss", CultureInfo.InvariantCulture, out var tod)
            && !TimeSpan.TryParse(timeText, CultureInfo.InvariantCulture, out tod))
            tod = new TimeSpan(23, 59, 59);

        var tz = TimeZoneResolver.FindTimeZone(ianaTz);
        var localNow = TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, tz);

        var wallClock = new DateTime(
            localNow.Year, localNow.Month, localNow.Day,
            tod.Hours, tod.Minutes, tod.Seconds, DateTimeKind.Unspecified);

        // Compare in local wall-clock terms, not against an offset-bearing value.
        if (wallClock <= localNow.DateTime)
            wallClock = wallClock.AddDays(1);

        return ToUtcSafe(wallClock, tz);
    }

    private async Task TerminateWithoutHoldAsync(EligibleRecipientEvent message, string reason, CancellationToken ct)
    {
        await publisher.PublishAsync(
            Topics.MessageTerminated,
            message.MessageId.ToString()!,
            new MessageTerminatedEvent
            {
                Account_Info_ID = message.Account_Info_ID,
                CampaignQueueId = message.CampaignQueueId,
                CampaignId = message.CampaignId,
                MessageId = message.MessageId,
                ProducerService = ProducerServices.Compliance,
                Phone = message.Phone,
                ReasonCode = reason
            },
            ct);

        logger.LogInformation(
            "Terminated {MessageId} before hold: {Reason} state={State} zip={Zip}",
            message.MessageId, reason, message.StateCode, message.ZipCode);
    }

    private async Task TerminateHoldAsync(HoldEntity hold, string reason, CancellationToken ct)
    {
        hold.Status = HoldStatus.Terminated;
        hold.UpdatedAt = DateTimeOffset.UtcNow;

        await publisher.PublishAsync(
            Topics.MessageTerminated,
            hold.MessageId.ToString(),
            new MessageTerminatedEvent
            {
                Account_Info_ID = hold.Account_Info_ID,
                CampaignQueueId = hold.CampaignQueueId,
                CampaignId = hold.CampaignId,
                MessageId = hold.MessageId,
                ProducerService = ProducerServices.Compliance,
                Phone = hold.Phone,
                ReasonCode = reason
            },
            ct);

        await db.CampaignMembers
                    .Where(a => a.ID == hold.MessageId)
                    .ExecuteUpdateAsync(s => s
                        .SetProperty(a => a.LifecycleState, MessageLifecycleState.TerminatedCompliance)
                        .SetProperty(a => a.Status, CampaignMemberStatus.Expired)
                        .SetProperty(a => a.ResponseMessage, reason)
                        .SetProperty(a => a.EmittedAt, DateTime.UtcNow), ct);   // FIX: was DateTime.Now

        logger.LogWarning("Terminated hold {MessageId}: {Reason}", hold.MessageId, reason);

        await PersistHoldStatusAsync(hold.MessageId, HoldStatus.Terminated, ct);
    }

    /// <summary>
    /// Claim due Held (and stale Releasing) rows exclusively so other instances skip them.
    /// </summary>
    private async Task<List<HoldEntity>> ClaimDueHoldsAsync(
        int batchSize,
        int claimTimeoutSeconds,
        CancellationToken ct)
    {
        var held = (int)HoldStatus.Held;
        var releasing = (int)HoldStatus.Releasing;
        var staleSeconds = claimTimeoutSeconds;

        var claimedIds = await db.Database
         .SqlQuery<long>($"""
            EXEC dbo.USP_ClaimSMSinHoldQueue
                @BatchSize = {batchSize},
                @ClaimTimeoutSeconds = {claimTimeoutSeconds},
                @HeldStatus = {held},
                @ReleasingStatus = {releasing}
            """)
         .ToListAsync(ct);

        if (claimedIds.Count == 0)
            return [];

        return await db.Holds
            .Where(h => claimedIds.Contains(h.MessageId))
            .OrderBy(h => h.SendAt)
            .ToListAsync(ct);
    }

    private async Task ExpireDueHoldsAsync(CancellationToken ct)
    {
        var held = (int)HoldStatus.Held;
        var releasing = (int)HoldStatus.Releasing;
        var nowUtc = DateTimeOffset.UtcNow.UtcDateTime;

        await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted, ct);
        var expiredIds = await db.Database
            .SqlQuery<long>($"""
                ;WITH claim AS (
                    SELECT TOP (500) [MessageId]
                    FROM SMS_Compliance_holds WITH (UPDLOCK, READPAST, ROWLOCK)
                    WHERE [ExpireAt] IS NOT NULL
                      AND [ExpireAt] <= {nowUtc}
                      AND [Status] IN ({held}, {releasing})
                    ORDER BY [ExpireAt]
                )
                UPDATE m
                SET [Status] = {releasing},
                    [ClaimedAt] = {nowUtc},
                    [UpdatedAt] = {nowUtc}
                OUTPUT INSERTED.[MessageId] AS [Value]
                FROM SMS_Compliance_holds AS m
                INNER JOIN claim AS c ON m.[MessageId] = c.[MessageId]
                """)
            .ToListAsync(ct);
        await tx.CommitAsync(ct);

        if (expiredIds.Count == 0)
            return;

        var expired = await db.Holds
            .Where(h => expiredIds.Contains(h.MessageId))
            .ToListAsync(ct);

        foreach (var hold in expired)
            await TerminateHoldAsync(hold, "HOLD_EXPIRED_EOD", ct);

        await db.SaveChangesAsync(ct);
        logger.LogInformation("Expired {Count} holds at end-of-day", expired.Count);
    }

    /// <summary>
    /// Expire EOD → terminate incomplete/blocked → release only fully compliant due holds.
    /// </summary>
    public async Task ReleaseDueAsync(CancellationToken ct)
    {
        await ExpireDueHoldsAsync(ct);

        var intakeBudget = configuration.GetValue("Compliance:DeliveryIntakeBudget", 100);
        var claimTimeoutSeconds = configuration.GetValue("Compliance:ClaimTimeoutSeconds", 120);
        var claimed = await ClaimDueHoldsAsync(intakeBudget, claimTimeoutSeconds, ct);
        if (claimed.Count == 0)
            return;

        var releasable = new List<HoldEntity>();
        var nowUtc = DateTimeOffset.UtcNow;
        foreach (var hold in claimed)
        {
            // Never ReadyToSend before legal SendAt (stale Releasing reclaim must still wait).
            if (hold.SendAt.ToUniversalTime() > DateTimeOffset.UtcNow)
            {
                await UnclaimAsync([hold], ct);
                continue;
            }

            if (string.IsNullOrWhiteSpace(hold.StateCode) || string.IsNullOrWhiteSpace(hold.ResolvedTimeZone))
            {
                await TerminateHoldAsync(hold, "COMPLIANCE_DATA_INCOMPLETE", ct);
                continue;
            }

            if (!TimeZoneResolver.TryValidateIana(hold.ResolvedTimeZone, out _))
            {
                await TerminateHoldAsync(hold, "TIMEZONE_INVALID", ct);
                continue;
            }

            var rule = await LoadActiveStateRuleAsync(hold.StateCode, ct);
            if (rule is null)
            {
                await TerminateHoldAsync(hold, "STATE_RULE_NOT_FOUND", ct);
                continue;
            }

            if (!rule.SmsAllowed)
            {
                await TerminateHoldAsync(hold, "STATE_SMS_NOT_ALLOWED", ct);
                continue;
            }

            releasable.Add(hold);
        }

        if (releasable.Count == 0)
        {
            // Reload claimed rows and persist Terminated in SQL (avoids tracker misses after UPDLOCK claim).
            //
            // Every path in the loop above either unclaims, terminates or adds to
            // releasable, so this should affect ZERO rows. It is kept as a safety
            // net — but a non-zero count means a row was claimed and then silently
            // dropped, and this branch would kill the message with no reason
            // recorded anywhere. Log it loudly rather than absorbing it.
            var claimedIds = claimed.Select(h => h.MessageId).ToList();
            var now = DateTimeOffset.UtcNow;
            var swept = await db.Holds
                .Where(h => claimedIds.Contains(h.MessageId) && h.Status == HoldStatus.Releasing)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(h => h.Status, HoldStatus.Terminated)
                    .SetProperty(h => h.ClaimedAt, (DateTimeOffset?)null)
                    .SetProperty(h => h.UpdatedAt, now), ct);

            if (swept > 0)
                logger.LogError(
                    "Safety net terminated {Count} hold(s) left in Releasing with no decision. "
                    + "These messages were silently discarded — a code path is not accounting "
                    + "for its claimed rows.", swept);

            return;
        }

        var remainingBudget = intakeBudget;
        foreach (var group in releasable.GroupBy(h => (int)h.CampaignQueueId))
        {
            if (remainingBudget <= 0)
            {
                await UnclaimAsync(group.ToList(), ct);
                continue;
            }

            var control = await db.CampaignQueue.FindAsync([group.Key], ct);
            if (!IsReleaseAllowed(control))
            {
                await UnclaimAsync(group.ToList(), ct);
                continue;
            }

            var candidates = group.ToList();
            var want = Math.Min(candidates.Count, remainingBudget);
            var leftover = candidates.Skip(want).ToList();
            if (leftover.Count > 0)
                await UnclaimAsync(leftover, ct);

            var slice = candidates.Take(want).ToList();

            var mirror = await db.CampaignQueue.FindAsync([group.Key], ct)
                ?? new CampaignQuotaMirrorEntity
                {
                    ID = group.Key,
                    Campaign_Mstr_ID = slice[0].CampaignId,
                    Timezone = "UTC"
                };

            mirror.Timezone ??= "UTC";

            var granted = await quota.ReserveUpToAsync(mirror, slice.Count, ct);
            if (granted <= 0)
            {
                await UnclaimAsync(slice, ct);
                continue;
            }

            var toRelease = slice.Take(granted).ToList();
            var denied = slice.Skip(granted).ToList();
            if (denied.Count > 0)
                await UnclaimAsync(denied, ct);

            for (var i = 0; i < toRelease.Count; i++)
                await ReleaseHoldAsync(toRelease[i], null, ct);

            remainingBudget -= toRelease.Count;

            logger.LogInformation(
                "Released {Granted}/{Wanted} holds for campaign {CampaignId}; intakeRemaining={Budget}",
                toRelease.Count, want, group.Key, remainingBudget);
        }
    }

    private async Task PersistHoldStatusAsync(long messageId, HoldStatus status, CancellationToken ct)
    {
        var now = DateTimeOffset.UtcNow;
        await db.Holds
            .Where(h => h.MessageId == messageId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(h => h.Status, status)
                .SetProperty(h => h.ClaimedAt, (DateTime?)null)
                .SetProperty(h => h.UpdatedAt, now), ct);
    }

    private async Task UnclaimAsync(List<HoldEntity> holds, CancellationToken ct)
    {
        foreach (var hold in holds)
        {
            if (hold.Status != HoldStatus.Releasing)
                continue;
            hold.Status = HoldStatus.Held;
            hold.ClaimedAt = null;
            hold.UpdatedAt = DateTimeOffset.UtcNow;

            await PersistHoldStatusAsync(hold.MessageId, HoldStatus.Held, ct);
        }
    }

    /// <summary>
    /// Release the message for delivery.
    /// </summary>
    /// <remarks>
    /// ⚠ THE PUBLISH HAPPENS BEFORE THE STATUS IS PERSISTED, AND THAT IS
    /// DELIBERATE — but it places a requirement on the delivery service.
    ///
    /// If this process dies between the publish and PersistHoldStatusAsync, the
    /// hold stays in Releasing. After ClaimTimeoutSeconds the claim procedure
    /// reclaims it as stale and it is published AGAIN.
    ///
    /// The alternative order — persist, then publish — trades a duplicate for a
    /// LOST message, which is worse. So the event carries a deterministic
    /// IdempotencyKey, and DELIVERY MUST ENFORCE IT: store it with a unique
    /// constraint and check it before calling the provider, not merely log it.
    ///
    /// Without that enforcement, a crash at the wrong moment sends the same SMS
    /// twice — and in a state whose rule is one message per thirty days, a single
    /// duplicate is a breach.
    /// </remarks>
    private async Task ReleaseHoldAsync(HoldEntity hold, string? correlationId, CancellationToken ct)
    {
        // Defensive: IngestEligibleAsync now rejects a missing template, but a
        // hold created before that check existed could still carry null. Throwing
        // here would abort the whole batch, so terminate just this one.
        if (hold.TemplateId is null or <= 0)
        {
            await TerminateHoldAsync(hold, "TEMPLATE_MISSING", ct);
            return;
        }

        hold.Status = HoldStatus.Released;
        hold.UpdatedAt = DateTimeOffset.UtcNow;

        await publisher.PublishAsync(
            Topics.ReadyToSend,
            hold.MessageId.ToString(),
            new ReadyToSendEvent
            {
                CampaignQueueId = hold.CampaignQueueId,
                CampaignId = hold.CampaignId,
                MessageId = hold.MessageId,
                CorrelationId = correlationId,
                ProducerService = ProducerServices.Compliance,
                Account_Info_ID = hold.Account_Info_ID,
                Phone = hold.Phone,
                SendAt = hold.SendAt,
                TemplateId = hold.TemplateId.Value,
                IdempotencyKey = $"{hold.MessageId}:Ready"
            },
            ct);

        await db.CampaignMembers
                  .Where(a => a.ID == hold.MessageId)
                  .ExecuteUpdateAsync(s => s
                      .SetProperty(a => a.LifecycleState, MessageLifecycleState.ReadyForDelivery)
                      .SetProperty(a => a.Status, CampaignMemberStatus.Pending)
                      .SetProperty(a => a.EmittedAt, DateTime.UtcNow), ct);   // FIX: was DateTime.Now

        await PersistHoldStatusAsync(hold.MessageId, HoldStatus.Released, ct);
    }

    private static bool IsReleaseAllowed(CampaignQuotaMirrorEntity? control) =>
      control is null || control.State is CampaignState.Running or CampaignState.Ready;
}
