using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Consumes ReadyToSend and submits to the provider.
///
/// ORDER OF CHECKS, and why it is this order:
///
///   1  idempotency   has this exact message already reached a terminal outcome?
///   2  campaign      is the campaign still Ready or Running?
///   3  row state     does the row exist, and is it still expecting delivery?
///   4  content       is there a message and a phone number?
///   5  ceiling       has this process hit its send limit?
///   6  submit
///
/// Cheap local checks before the network call, and the two that can STOP a send
/// before the two that merely validate it. A stopped campaign should cost
/// nothing.
/// </summary>
public sealed class DeliveryService(
    DeliveryDbContext db,
    IWebexSmsClient client,
    DeliveryOptions options,
    DeliveryRateLimiter rateLimiter,
    ILogger<DeliveryService> logger)
{
    private static int _sentThisProcess;

    private readonly string _instanceId =
        $"{Environment.MachineName}:{Environment.ProcessId}";

    public async Task HandleReadyAsync(ReadyToSendEvent message, CancellationToken ct)
    {
        var key = message.IdempotencyKey ?? $"{message.MessageId}:Ready";

        // ReadyToSendEvent.CampaignQueueId is long?, while the submission and
        // attempt tables store it as long. Resolved once here rather than cast
        // at four separate call sites, where one of them would eventually be
        // missed.
        var campaignQueueId = message.CampaignQueueId ?? 0;

        // -----------------------------------------------------------------
        // 1. IDEMPOTENCY — the check that makes this safe.
        //
        // Compliance publishes BEFORE it persists Released, so a crash there
        // republishes the same event after the claim timeout. Kafka replays on
        // rebalance. Both are normal, both arrive here, and without this check
        // both become a second text to a real person.
        //
        // The cheap read catches the common case; the unique index catches the
        // race where two instances read at the same instant. Both are needed.
        // -----------------------------------------------------------------
        if (await db.Submissions.AsNoTracking().AnyAsync(s => s.IdempotencyKey == key, ct))
        {
            logger.LogInformation(
                "Duplicate ReadyToSend ignored for message {MessageId} (key {Key}).",
                message.MessageId, key);
            return;
        }

        // -----------------------------------------------------------------
        // 2. CAMPAIGN STATE — the stop switch.
        //
        // Re-read per message rather than cached. A campaign stopped thirty
        // seconds ago must not keep sending because a cache has not expired.
        // -----------------------------------------------------------------
        var campaign = await db.CampaignQueue.AsNoTracking()
            .FirstOrDefaultAsync(c => c.ID == (int)campaignQueueId, ct);

        if (campaign is null)
        {
            await RecordSkippedAsync(message, campaignQueueId, key, "CAMPAIGN_NOT_FOUND", ct);
            return;
        }

        if (campaign.State is not (CampaignState.Ready or CampaignState.Running))
        {
            logger.LogInformation(
                "Campaign {CampaignQueueId} is {State}; not sending message {MessageId}.",
                message.CampaignQueueId, campaign.State, message.MessageId);

            await RecordSkippedAsync(message, campaignQueueId, key, $"CAMPAIGN_{campaign.State}", ct);
            return;
        }

        // -----------------------------------------------------------------
        // 3. THE ROW ITSELF
        // -----------------------------------------------------------------
        var member = await db.CampaignMembers.AsNoTracking()
            .FirstOrDefaultAsync(m => m.ID == message.MessageId, ct);

        if (member is null)
        {
            await RecordSkippedAsync(message, campaignQueueId, key, "QUEUE_ROW_NOT_FOUND", ct);
            return;
        }

        if (member.Sent_Timestamp_UTC is not null)
        {
            logger.LogWarning(
                "Message {MessageId} already has Sent_Timestamp_UTC; skipping.", message.MessageId);
            await RecordSkippedAsync(message, campaignQueueId, key, "ALREADY_SENT", ct);
            return;
        }

        // A message compliance terminated must never be sent, even if a stale
        // event for it is replayed.
        if (member.LifecycleState is MessageLifecycleState.TerminatedCompliance
                                  or MessageLifecycleState.RejectedEligibility)
        {
            logger.LogWarning(
                "Message {MessageId} is {State}; refusing to send.",
                message.MessageId, member.LifecycleState);
            await RecordSkippedAsync(message, campaignQueueId, key, $"STATE_{member.LifecycleState}", ct);
            return;
        }

        // -----------------------------------------------------------------
        // 4. CONTENT
        //
        // Message text comes from the ROW, not the event. ReadyToSendEvent does
        // not carry it, which is right: the row is current, the event is a
        // snapshot from whenever it was published.
        // -----------------------------------------------------------------
        if (string.IsNullOrWhiteSpace(member.MessageText))
        {
            await FailAsync(member, key, message, campaignQueueId, "MESSAGE_TEXT_EMPTY", transient: false, ct);
            return;
        }

        var phone = member.Phone ?? message.Phone;
        if (string.IsNullOrWhiteSpace(phone))
        {
            await FailAsync(member, key, message, campaignQueueId, "PHONE_MISSING", transient: false, ct);
            return;
        }

        // -----------------------------------------------------------------
        // 5. PROCESS CEILING — a circuit breaker for testing.
        //
        // A loop bug or a bad query cannot send more than this no matter what
        // the queue contains. Reset by restarting the service.
        // -----------------------------------------------------------------
        if (options.MaxSendsPerProcess > 0)
        {
            var soFar = Interlocked.Increment(ref _sentThisProcess);
            if (soFar > options.MaxSendsPerProcess)
            {
                logger.LogError(
                    "Process send ceiling of {Max} reached. Refusing to submit message {MessageId}. "
                    + "Raise Delivery:MaxSendsPerProcess or restart the service.",
                    options.MaxSendsPerProcess, message.MessageId);

                await RecordSkippedAsync(message, campaignQueueId, key, "PROCESS_SEND_CEILING", ct);
                return;
            }
        }

        // -----------------------------------------------------------------
        // 6. SUBMIT
        // -----------------------------------------------------------------
        var destination = phone;

        if (!string.IsNullOrWhiteSpace(options.RedirectAllToNumber))
        {
            // The intended recipient is logged so a test can still verify the
            // right person WOULD have been messaged — the handset cannot tell
            // you that when everything arrives at one number.
            logger.LogWarning(
                "TEST REDIRECT: message {MessageId} intended for ***{Intended} "
                + "is being sent to {Redirect} instead.",
                message.MessageId,
                phone.Length >= 4 ? phone[^4..] : "****",
                options.RedirectAllToNumber);

            destination = options.RedirectAllToNumber!;
        }

        await rateLimiter.WaitAsync(ct);

        var attemptNumber = await NextAttemptNumberAsync(message.MessageId, ct);

        var result = await client.SendAsync(new WebexSendRequest
        {
            SmsId = message.MessageId.ToString(),
            Phone = destination,
            MessageText = member.MessageText!,
            ZipCode = member.ZipCode,
            LeadAccountNumber = member.Account_Info_ID?.ToString(),
            AccountId = member.AccountID.ToString()
        }, ct);

        // Every attempt is recorded, successful or not. This is what the retry
        // worker counts and what answers "why did this fail?" for anything other
        // than the last try.
        await RecordAttemptAsync(message, campaignQueueId, attemptNumber, result, ct);

        if (result.Accepted)
            await RecordAcceptedAsync(member, key, message, campaignQueueId, result, ct);
        else
            await FailAsync(member, key, message, campaignQueueId,
                            result.ResponseMessage ?? "SEND_FAILED",
                            result.IsTransient, ct, result, attemptNumber);
    }

    // =====================================================================

    private async Task<int> NextAttemptNumberAsync(long messageId, CancellationToken ct)
        => await db.Attempts.AsNoTracking().CountAsync(a => a.MessageId == messageId, ct) + 1;

    private async Task RecordAttemptAsync(
        ReadyToSendEvent message, long campaignQueueId, int attemptNumber,
        WebexSendResult result, CancellationToken ct)
    {
        db.Attempts.Add(new DeliveryAttemptEntity
        {
            MessageId = message.MessageId,
            CampaignQueueId = campaignQueueId,
            AttemptNumber = attemptNumber,
            Succeeded = result.Accepted,
            IsTransient = result.IsTransient,
            ResponseCode = result.ResponseCode,
            ResponseMessage = Truncate(result.ResponseMessage, 1000),
            ProviderMessageId = result.ProviderMessageId,
            InstanceId = _instanceId,
            DurationMs = result.DurationMs,
            AttemptedAtUtc = DateTime.UtcNow
        });

        await db.SaveChangesAsync(ct);
    }

    private async Task RecordAcceptedAsync(
        CampaignMemberEntity member,
        string key,
        ReadyToSendEvent message,
        long campaignQueueId,
        WebexSendResult result,
        CancellationToken ct)
    {
        var now = DateTime.UtcNow;

        // Write the submission FIRST. If the unique index rejects it, another
        // instance won the race and already submitted — in which case this
        // instance must not also mark the row sent.
        try
        {
            db.Submissions.Add(new DeliverySubmissionEntity
            {
                IdempotencyKey = key,
                MessageId = message.MessageId,
                CampaignQueueId = campaignQueueId,
                CampaignId = message.CampaignId,
                Phone = member.Phone,
                ProviderMessageId = result.ProviderMessageId,
                ResponseCode = result.ResponseCode,
                ResponseMessage = "Queued",
                Succeeded = true,
                InstanceId = _instanceId,
                DurationMs = result.DurationMs,
                SubmittedAtUtc = now
            });

            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex) when (IsUniqueViolation(ex))
        {
            logger.LogWarning(
                "Message {MessageId} was submitted concurrently by another instance. "
                + "This submission is discarded. NOTE: the provider was already called by "
                + "this instance too, so a duplicate may have gone out.", message.MessageId);
            return;
        }

        await db.CampaignMembers
            .Where(m => m.ID == member.ID)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.Status, CampaignMemberStatus.Emitted)
                .SetProperty(m => m.LifecycleState, MessageLifecycleState.Submitted)
                .SetProperty(m => m.ResponseCode, result.ResponseCode)
                .SetProperty(m => m.ResponseMessage, "Queued")
                .SetProperty(m => m.Sent_Timestamp_UTC, now)
                .SetProperty(m => m.ClaimedAt, (DateTime?)null)
                .SetProperty(m => m.RowUpdatedDt, now), ct);

        logger.LogInformation(
            "Submitted message {MessageId} transid={TransId} in {Ms}ms",
            message.MessageId, result.ProviderMessageId, result.DurationMs);
    }

    private async Task FailAsync(
        CampaignMemberEntity member,
        string key,
        ReadyToSendEvent message,
        long campaignQueueId,
        string reason,
        bool transient,
        CancellationToken ct,
        WebexSendResult? result = null,
        int attemptNumber = 1)
    {
        var now = DateTime.UtcNow;

        var exhausted = attemptNumber >= options.MaxAttempts;
        var terminal = !transient || exhausted;

        // ExecuteUpdateAsync compiles its arguments into an EXPRESSION TREE, and
        // a null-propagating operator (result?.ResponseCode) is not legal inside
        // one — CS8072. Resolved to plain locals first.
        var responseCode = result?.ResponseCode;
        var durationMs = result?.DurationMs ?? 0;
        var truncatedReason = Truncate(reason, 1000);

        // A TRANSIENT failure with attempts remaining is deliberately NOT written
        // to the submission table. That table is the idempotency guard, and
        // writing our own failure into it would permanently block the retry.
        if (terminal)
        {
            try
            {
                db.Submissions.Add(new DeliverySubmissionEntity
                {
                    IdempotencyKey = key,
                    MessageId = message.MessageId,
                    CampaignQueueId = campaignQueueId,
                    CampaignId = message.CampaignId,
                    Phone = member.Phone,
                    ResponseCode = responseCode,
                    ResponseMessage = truncatedReason,
                    Succeeded = false,
                    InstanceId = _instanceId,
                    DurationMs = durationMs,
                    SubmittedAtUtc = now
                });
                await db.SaveChangesAsync(ct);
            }
            catch (DbUpdateException ex) when (IsUniqueViolation(ex))
            {
                return;
            }
        }

        await db.CampaignMembers
            .Where(m => m.ID == member.ID)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.Status, terminal
                    ? CampaignMemberStatus.Skipped      // no further attempts
                    : CampaignMemberStatus.Pending)     // retry worker will pick it up
                .SetProperty(m => m.LifecycleState, terminal
                    ? MessageLifecycleState.Failed
                    : MessageLifecycleState.ReadyForDelivery)   // stays retryable
                .SetProperty(m => m.ResponseCode, responseCode)
                .SetProperty(m => m.ResponseMessage, truncatedReason)
                .SetProperty(m => m.ClaimedAt, (DateTime?)null)  // release the claim
                .SetProperty(m => m.RowUpdatedDt, now), ct);

        if (terminal)
            logger.LogWarning(
                "Message {MessageId} failed terminally after {Attempts} attempt(s): {Reason}",
                message.MessageId, attemptNumber, reason);
        else
            logger.LogWarning(
                "Transient failure for message {MessageId} (attempt {Attempt} of {Max}): {Reason}. "
                + "Will retry.",
                message.MessageId, attemptNumber, options.MaxAttempts, reason);
    }

    /// <summary>
    /// Records that a message was deliberately not sent — a stopped campaign, a
    /// missing row, the process ceiling.
    ///
    /// Written to the submission table so a replay does not re-evaluate it, and
    /// so the reason survives.
    /// </summary>
    private async Task RecordSkippedAsync(
        ReadyToSendEvent message, long campaignQueueId, string key, string reason,
        CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var skippedReason = Truncate(reason, 1000);

        try
        {
            db.Submissions.Add(new DeliverySubmissionEntity
            {
                IdempotencyKey = key,
                MessageId = message.MessageId,
                CampaignQueueId = campaignQueueId,
                CampaignId = message.CampaignId,
                Phone = message.Phone,
                ResponseMessage = skippedReason,
                Succeeded = false,
                InstanceId = _instanceId,
                SubmittedAtUtc = now
            });
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex) when (IsUniqueViolation(ex))
        {
            // Another instance already recorded it.
        }

        await db.CampaignMembers
            .Where(m => m.ID == message.MessageId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.ResponseMessage, skippedReason)
                .SetProperty(m => m.ClaimedAt, (DateTime?)null)
                .SetProperty(m => m.RowUpdatedDt, now), ct);
    }

    /// <summary>SQL Server unique index and primary key violations.</summary>
    private static bool IsUniqueViolation(DbUpdateException ex) =>
        ex.InnerException is Microsoft.Data.SqlClient.SqlException sql
        && (sql.Number == 2601 || sql.Number == 2627);

    private static string Truncate(string? s, int max)
        => string.IsNullOrEmpty(s) ? "" : (s.Length > max ? s[..max] : s);
}
