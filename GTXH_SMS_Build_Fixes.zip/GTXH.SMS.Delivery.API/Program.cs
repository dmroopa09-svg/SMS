using GTXH.SMS.Delivery.API.Consumers;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Delivery.API.Services;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddSmsMessaging(builder.Configuration);
builder.Services.AddKafkaHandler<ReadyToSendHandler>();

var conn = builder.Configuration.GetConnectionString("DeliveryDb");

builder.Services.AddDbContext<DeliveryDbContext>(options =>
    options.UseSqlServer(
        conn,
        sql => sql.UseCompatibilityLevel(110)));

var deliveryOptions = new DeliveryOptions();
builder.Configuration.GetSection(DeliveryOptions.SectionName).Bind(deliveryOptions);
builder.Services.AddSingleton(deliveryOptions);

// Singleton so the same pacing applies across every consumed message.
builder.Services.AddSingleton<DeliveryRateLimiter>();

// ---------------------------------------------------------------------------
// DRY RUN IS THE DEFAULT.
//
// Delivery is the only service that talks to a live API which sends the instant
// it is called. A deployment that forgets to configure it should fail to send,
// not send to real people.
// ---------------------------------------------------------------------------
if (deliveryOptions.DryRun)
{
    builder.Services.AddSingleton<IWebexSmsClient, DryRunSmsClient>();
}
else
{
    if (string.IsNullOrWhiteSpace(deliveryOptions.BaseUrl)
        || string.IsNullOrWhiteSpace(deliveryOptions.FlowTriggerPath))
    {
        // Refuse to start rather than start in a state where every send fails in
        // a way that looks like a provider problem.
        throw new InvalidOperationException(
            "Delivery:DryRun is false but BaseUrl or FlowTriggerPath is not configured. "
            + "Set both, or leave DryRun true.");
    }

    // ---------------------------------------------------------------------
    // HttpClient is constructed directly rather than through AddHttpClient.
    //
    // AddHttpClient lives in the Microsoft.Extensions.Http package, which this
    // project does not reference — that was the CS1061 error. Adding the
    // package would work, but for a single long-lived client against one base
    // address the factory buys nothing.
    //
    // PooledConnectionLifetime is the one thing a raw HttpClient would
    // otherwise get wrong: without it a long-running process caches DNS
    // forever and keeps talking to an address that has since moved. Five
    // minutes recycles connections often enough to pick up a change, and
    // rarely enough that it costs nothing.
    // ---------------------------------------------------------------------
    builder.Services.AddSingleton<IWebexSmsClient>(sp =>
    {
        var handler = new SocketsHttpHandler
        {
            PooledConnectionLifetime = TimeSpan.FromMinutes(5)
        };

        var http = new HttpClient(handler)
        {
            BaseAddress = new Uri(deliveryOptions.BaseUrl),
            Timeout = TimeSpan.FromSeconds(deliveryOptions.TimeoutSeconds)
        };

        return new WebexSmsClient(
            http,
            deliveryOptions,
            sp.GetRequiredService<ILogger<WebexSmsClient>>());
    });
}

builder.Services.AddScoped<DeliveryService>();
builder.Services.AddHostedService<DeliveryRetryWorker>();

var host = builder.Build();

// Startup banner. The difference between dry run and live is the difference
// between a test and messaging patients, and it should never be something
// someone has to go and check.
var log = host.Services.GetRequiredService<ILogger<Program>>();

if (deliveryOptions.DryRun)
{
    log.LogWarning("DELIVERY IS IN DRY RUN. No messages will be sent.");
}
else
{
    log.LogWarning(
        "DELIVERY IS LIVE. Endpoint {Url}{Path}, max {Max} sends this process, {Rate}/second.",
        deliveryOptions.BaseUrl, deliveryOptions.FlowTriggerPath,
        deliveryOptions.MaxSendsPerProcess, deliveryOptions.MaxPerSecond);

    if (!string.IsNullOrWhiteSpace(deliveryOptions.RedirectAllToNumber))
        log.LogWarning(
            "TEST REDIRECT ACTIVE — every message goes to {Number} regardless of recipient.",
            deliveryOptions.RedirectAllToNumber);
    else
        log.LogWarning("NO TEST REDIRECT — messages will go to REAL RECIPIENTS.");
}

host.Run();
