# Fast upload: bulk insert

No new stored procedure or table type is needed. The process tables have dynamic columns, so a fixed TVP doesn't fit them. Instead, SqlBulkCopy loads each chunk into a `#temp` table shaped like the target, and one `MERGE` moves it into `Process_X`. The same rules your old literal INSERT used still apply.

## Install (3 steps)

1. **Add** `BulkUploadWriter.cs` to `GTXH.OMC.Application/Services/`.
2. **Replace** `ProcessCsvAsync` in `CsvProcessingService.cs` with the one in `ProcessCsvAsync.cs`, and paste the helpers below it (`LoadAssignableUsersAsync`, `LoadDuplicateTargetsAsync`, `RequiredFieldError`, `DupTarget`).
3. **Delete this line** in `ValidateCsvAsync` (line ~77). It loads every task of the process and nothing uses the result:
   ```csharp
   var existingTasks = await _taskRepository.FindAsync(t => t.ProcessId == processId);
   ```

There are no changes to `UploadProcessingJob`. `usp_master_proc` and `usp_SetPriorityOnTarget_Indicator` still run after the import, as before.

## What it does now

| | Before (per row) | Now (per 5,000 rows) |
|---|---|---|
| Process lookup | 1 query | once per upload |
| ProcessFields | 1 query | once per upload |
| Process table insert | dynamic SQL + `sp_InsertProcessDataAndGetId` | 1 bulk copy + 1 MERGE |
| Assignee lookup | 1 query | one dictionary per upload |
| Task insert | AddAsync + SaveChanges (change tracker grows → slower each row) | 1 bulk copy |
| Existing tasks | whole table loaded twice, always | only if duplicate detection is on, TaskId + TaskData only |

- **Bad rows:** if a chunk fails (for example, a value too long for its column), only that chunk is retried row by row. Good rows still go in, and bad rows get an error message per row, as before.
- **Task columns** come from the EF model. Every other Task column (such as WorkedSeconds) gets the value EF would have written, so you won't hit another NOT NULL error.
- **Triggers on Tasks** still fire (`FireTriggers`).

## Small behaviour changes (intentional)

- **Assignee:** the row's assignee wins, and the file name fills the gap. Before, process 25 overwrote the row value inside the column loop, and other processes only used the file name when a special mapping column was present.
- **Required field missing:** the error now names the field. It used to say "ProcessDataId not available".
- **Mapped field with no column in the process table:** the value is kept in TaskData and a warning is logged. Before, every row failed.
- **Missing process table:** the upload now fails once, instead of writing an error for every row.

## Please confirm before prod

1. `sp_InsertProcessDataAndGetId`: does it only run the INSERT and return `SCOPE_IDENTITY()`? If it also writes somewhere else (an audit, a log), send it to me so the MERGE can do the same.
2. Test on a copy first with a file of ~10k rows that uses duplicate detection on Update. Compare the Tasks and Process_X rows against an old-code run.

**Not covered yet:** process 13 Excel still runs `dbo.ProcessDynamicUploadRow` once per row. Send me that procedure and I'll convert it the same way.
