// =====================================================================================
// CsvProcessingService.cs - replace the whole ProcessCsvAsync method with this one,
// and add the two private helpers + DupTarget class below it.
//
// Same signature, same ProcessCsvResult, same duplicate actions. CreateTaskAsync,
// InsertIntoProcessTableAsync, UpdateProcessTableAsync and BuildDuplicateKeys are no
// longer called - delete them or leave them, either compiles.
// =====================================================================================

    public async Task<ProcessCsvResult> ProcessCsvAsync(
        Stream csvStream,
        int processId,
        int uploadId,
        int createdByUserId,
        Dictionary<string, int> columnMappings,
        DuplicateHandlingRequest? duplicateHandling,
        IRepository<TaskEntity> taskRepository,
        IRepository<TaskAssignment> taskAssignmentRepository,
        IRepository<TaskHistory> taskHistoryRepository,
        IRepository<UploadError> uploadErrorRepository,
        IUnitOfWork unitOfWork,
        IProgress<int>? progress = null,
        Dictionary<string, string>? specialFieldMappings = null,
        Dictionary<string, string>? dateFormats = null,
        string? fileNameAssignee = null)
    {
        var result = new ProcessCsvResult { Errors = new List<ValidationErrorDto>() };

        // ---- Everything that used to be looked up per row, looked up once ------------------
        var processFields = (await _processFieldRepository.FindAsync(pf =>
            pf.ProcessId == processId && !pf.IsDeleted)).ToList();
        var fieldMap = processFields.ToDictionary(pf => pf.FieldId, pf => pf);

        var process = await _processRepository.FirstOrDefaultAsync(p => p.ProcessId == processId);
        if (process == null || string.IsNullOrEmpty(process.TableName))
            throw new InvalidOperationException(
                $"Process {processId} does not have a published table. Cannot import without ProcessDataId.");

        DuplicateDetectionConfigDto? duplicateConfig = null;
        if (!string.IsNullOrEmpty(process.DuplicateDetectionConfig))
            duplicateConfig = JsonSerializer.Deserialize<DuplicateDetectionConfigDto>(process.DuplicateDetectionConfig);

        var duplicateFields = duplicateConfig?.Fields ?? new List<string>();
        var duplicateAction = (duplicateHandling?.Action ?? duplicateConfig?.DefaultAction ?? "Ignore").ToLowerInvariant();

        // Replaces the per-row Users + UserProcessPermissions query.
        var assignableUsers = await LoadAssignableUsersAsync(processId);

        // Only when duplicate detection is configured, and only TaskId + TaskData - not whole tracked
        // entities. This used to load every task of the process unconditionally.
        var dupTargets = duplicateFields.Any()
            ? await LoadDuplicateTargetsAsync(processId, duplicateFields)
            : new Dictionary<string, DupTarget>(StringComparer.OrdinalIgnoreCase);

        // ---- Parse once --------------------------------------------------------------------
        if (csvStream.CanSeek) csvStream.Position = 0;
        var headers = (await _csvParser.ReadCsvPreviewAsync(csvStream, 1)).Columns;
        if (csvStream.CanSeek) csvStream.Position = 0;
        var allRows = await _csvParser.ReadAllRowsAsync(csvStream);

        var now = DateTime.Now;
        var staged = new List<StagedUploadRow>(allRows.Count);
        var existingUpdates = new Dictionary<int, string>();   // TaskId -> TaskData JSON
        var existingArchives = new HashSet<int>();
        var rowNumber = 1;

        StagedUploadRow NewRow(int rowNo, Dictionary<string, object> data, string? assignee, bool createTask)
        {
            int? userId = null;
            if (!string.IsNullOrWhiteSpace(assignee) && assignableUsers.TryGetValue(assignee.Trim(), out var uid))
                userId = uid;

            return new StagedUploadRow
            {
                RowNumber = rowNo,
                AssignedUsername = assignee,
                TaskData = data,
                Task = !createTask ? null : new TaskEntity
                {
                    ProcessId = processId,
                    AssignedUserId = userId,
                    Priority = TaskPriority.Medium,
                    TaskData = JsonSerializer.Serialize(data),
                    Status = Core.Enums.TaskStatus.Pending,
                    CreatedByUserId = createdByUserId,
                    CreatedDate = now,
                    ModifiedDate = now,
                    AssignedDate = now,
                },
            };
        }

        foreach (var rowData in allRows)
        {
            rowNumber++;
            try
            {
                // ---- Map columns ----
                var taskData = new Dictionary<string, object>();
                string? rowAssignee = null;

                for (int i = 0; i < headers.Count && i < rowData.Count; i++)
                {
                    var column = headers[i];
                    var value = rowData[i] ?? string.Empty;

                    if (specialFieldMappings != null && specialFieldMappings.TryGetValue(column, out var target))
                    {
                        if (target.Equals("AssignedUsername", StringComparison.OrdinalIgnoreCase))
                            rowAssignee = value;
                        continue;
                    }

                    if (columnMappings.TryGetValue(column, out var fieldId) && fieldMap.TryGetValue(fieldId, out var field))
                    {
                        string? dateFormat = null;
                        if (field.FieldType == FieldType.Date && dateFormats != null)
                            dateFormats.TryGetValue(column, out dateFormat);
                        taskData[field.FieldName] = ConvertFieldValue(field, value, dateFormat);
                    }
                }

                // Row wins if it has an assignee; the file name (Legacy Health, process 25) fills the gap.
                // This used to only run when a special-mapping column was hit.
                var assignee = string.IsNullOrWhiteSpace(rowAssignee) ? fileNameAssignee : rowAssignee;

                // ---- No duplicate detection: the common case ----
                if (!duplicateFields.Any())
                {
                    if (RequiredFieldError(processFields, taskData, rowNumber, result)) continue;
                    staged.Add(NewRow(rowNumber, taskData, assignee, createTask: true));
                    continue;
                }

                var key = BuildDuplicateKey(taskData, duplicateFields);

                if (!dupTargets.TryGetValue(key, out var existing))
                {
                    if (RequiredFieldError(processFields, taskData, rowNumber, result)) continue;
                    var row = NewRow(rowNumber, taskData, assignee, createTask: true);
                    staged.Add(row);
                    dupTargets[key] = DupTarget.Pending(row);   // catches duplicates within the same file
                    continue;
                }

                switch (duplicateAction)
                {
                    case "update":
                    {
                        var merged = JsonSerializer.Deserialize<Dictionary<string, object>>(existing.TaskDataJson ?? "{}")
                                     ?? new Dictionary<string, object>();
                        var fieldsToUpdate = duplicateConfig?.FieldsToUpdate;
                        foreach (var kvp in taskData)
                        {
                            var take = fieldsToUpdate != null && fieldsToUpdate.Any()
                                ? fieldsToUpdate.Contains(kvp.Key)
                                : !duplicateFields.Contains(kvp.Key, StringComparer.OrdinalIgnoreCase);
                            if (take) merged[kvp.Key] = kvp.Value;
                        }

                        if (RequiredFieldError(processFields, merged, rowNumber, result)) break;

                        var json = JsonSerializer.Serialize(merged);
                        existing.TaskDataJson = json;
                        if (existing.PendingRow?.Task != null)
                        {
                            existing.PendingRow.Task.TaskData = json;              // not written yet - just change it
                        }
                        else if (existing.TaskId.HasValue)
                        {
                            existingUpdates[existing.TaskId.Value] = json;
                        }

                        // The old code also inserted a process-table row for an update (without a new
                        // Task). Kept so usp_master_proc sees the same data it always has.
                        staged.Add(NewRow(rowNumber, merged, assignee, createTask: false));
                        break;
                    }

                    case "archive":
                        if (RequiredFieldError(processFields, taskData, rowNumber, result)) break;
                        if (existing.PendingRow?.Task != null)
                            existing.PendingRow.Task.Status = Core.Enums.TaskStatus.Cancelled;
                        else if (existing.TaskId.HasValue)
                            existingArchives.Add(existing.TaskId.Value);
                        staged.Add(NewRow(rowNumber, taskData, assignee, createTask: true));
                        break;

                    case "createnew":
                        if (RequiredFieldError(processFields, taskData, rowNumber, result)) break;
                        staged.Add(NewRow(rowNumber, taskData, assignee, createTask: true));
                        break;

                    default: // ignore / skip
                        result.Errors.Add(new ValidationErrorDto
                        {
                            RowNumber = rowNumber,
                            ErrorMessage = $"Duplicate detected based on fields: {string.Join(", ", duplicateFields)}",
                            ColumnName = string.Join(", ", duplicateFields),
                        });
                        break;
                }
            }
            catch (Exception ex)
            {
                result.Errors.Add(new ValidationErrorDto { RowNumber = rowNumber, ErrorMessage = ex.Message });
                _logger.LogError(ex, "Error parsing row {RowNumber} in upload {UploadId}", rowNumber, uploadId);
            }
        }

        // ---- Write: a few bulk round trips per 5,000 rows instead of 5 per row --------------
        var writer = new BulkUploadWriter(_dbContext, _logger);

        var handled = allRows.Count - staged.Count;     // errors/skips already counted as "processed"
        progress?.Report(handled);

        var writeErrors = await writer.InsertAsync(
            process.TableName, processId, uploadId, processFields, staged,
            written => { handled += written; progress?.Report(handled); });

        await writer.ApplyExistingTaskChangesAsync(existingUpdates, existingArchives, now);

        result.Errors.AddRange(writeErrors);
        result.SuccessCount = staged.Count - writeErrors.Count;
        result.ErrorCount = result.Errors.Count;

        _logger.LogInformation(
            "Upload {UploadId}: {Rows} rows -> {Success} imported, {Errors} errors, {Updated} tasks updated, {Archived} archived.",
            uploadId, allRows.Count, result.SuccessCount, result.ErrorCount, existingUpdates.Count, existingArchives.Count);

        return result;
    }

    /// <summary>Active users with permission on the process, username -> UserId. One query per upload.</summary>
    private async Task<Dictionary<string, int>> LoadAssignableUsersAsync(int processId)
    {
        var users = await _dbContext.Users.AsNoTracking()
            .Where(u => u.Status == UserStatus.Active
                     && _dbContext.UserProcessPermissions.Any(p => p.UserId == u.UserId && p.ProcessId == processId))
            .Select(u => new { u.Username, u.UserId })
            .ToListAsync();

        var map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var u in users)
            if (!string.IsNullOrEmpty(u.Username))
                map.TryAdd(u.Username.Trim(), u.UserId);
        return map;
    }

    private async Task<Dictionary<string, DupTarget>> LoadDuplicateTargetsAsync(int processId, List<string> duplicateFields)
    {
        var rows = await _dbContext.Set<TaskEntity>().AsNoTracking()
            .Where(t => t.ProcessId == processId)
            .Select(t => new { t.TaskId, t.TaskData })
            .ToListAsync();

        var keys = new Dictionary<string, DupTarget>(StringComparer.OrdinalIgnoreCase);
        foreach (var t in rows)
        {
            Dictionary<string, object> data;
            try { data = JsonSerializer.Deserialize<Dictionary<string, object>>(t.TaskData ?? "{}") ?? new(); }
            catch { data = new(); }

            var key = string.Join("|", duplicateFields.Select(f =>
                data.TryGetValue(f, out var v) ? v?.ToString() ?? string.Empty : string.Empty));

            if (!string.IsNullOrEmpty(key))
                keys[key] = new DupTarget { TaskId = t.TaskId, TaskDataJson = t.TaskData };
        }
        return keys;
    }

    /// <summary>
    /// The check InsertIntoProcessTableAsync used to do silently (returning null, which then
    /// surfaced as "ProcessDataId not available"). Now the error says which field.
    /// </summary>
    private static bool RequiredFieldError(
        List<ProcessField> processFields, Dictionary<string, object> data, int rowNumber, ProcessCsvResult result)
    {
        foreach (var f in processFields)
        {
            if (!f.IsRequired) continue;

            var missing = !data.TryGetValue(f.FieldName, out var v);
            var empty = !missing && f.IsReadOnly == true && string.IsNullOrWhiteSpace(v?.ToString());
            if (!missing && !empty) continue;

            result.Errors.Add(new ValidationErrorDto
            {
                RowNumber = rowNumber,
                ColumnName = f.FieldName,
                ErrorMessage = missing
                    ? $"Required field '{f.FieldName}' is not mapped."
                    : $"Required field '{f.FieldName}' is empty.",
            });
            return true;
        }
        return false;
    }

    private sealed class DupTarget
    {
        public int? TaskId { get; init; }
        public string? TaskDataJson { get; set; }
        public StagedUploadRow? PendingRow { get; init; }

        public static DupTarget Pending(StagedUploadRow row) =>
            new() { PendingRow = row, TaskDataJson = row.Task?.TaskData };
    }
