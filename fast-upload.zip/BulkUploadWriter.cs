using System.Data;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Core.Enums;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Microsoft.Extensions.Logging;
using ProcessField = GTXH.OMC.Core.Entities.ProcessField;
using TaskEntity = GTXH.OMC.Core.Entities.Task;

namespace GTXH.OMC.Application.Services;

/// <summary>
/// One parsed CSV row headed for the process table. <see cref="Task"/> is the Task to create
/// for it; null means "process-table row only" (the duplicate "update" path, which has always
/// inserted a process row without creating a new Task).
/// </summary>
internal sealed class StagedUploadRow
{
    public int RowNumber { get; init; }
    public string? AssignedUsername { get; init; }
    public Dictionary<string, object> TaskData { get; init; } = new();
    public TaskEntity? Task { get; init; }
}

/// <summary>
/// Writes an upload with SqlBulkCopy instead of one INSERT + one SaveChanges per row.
///
/// Per chunk of 5,000 rows:   1 bulk copy into #UpStage
///                            1 MERGE into dbo.Process_X  (OUTPUT maps ProcessDataId back to the row)
///                            1 bulk copy into dbo.Tasks
/// so 50,000 rows is ~30 round trips instead of ~250,000.
///
/// If a chunk fails (a value too long for its column, a constraint), that chunk alone is retried
/// row by row so the good rows still go in and the bad ones get a per-row error - the same
/// "one bad row doesn't kill the file" behaviour as before.
/// </summary>
internal sealed class BulkUploadWriter
{
    private const int ChunkSize = 5000;
    private const int TimeoutSeconds = 600;

    // Task properties the import sets explicitly. Everything else on Task is written exactly the
    // way EF would write it on AddAsync (CLR default, through its value converter), so a NOT NULL
    // column with no DB default - WorkedSeconds, say - still gets its 0.
    private static readonly string[] TaskPropertiesWeSet =
    {
        nameof(TaskEntity.ProcessId), nameof(TaskEntity.AssignedUserId), nameof(TaskEntity.Priority),
        nameof(TaskEntity.ProcessDataId), nameof(TaskEntity.TaskData), nameof(TaskEntity.Status),
        nameof(TaskEntity.CreatedByUserId), nameof(TaskEntity.CreatedDate), nameof(TaskEntity.ModifiedDate),
        nameof(TaskEntity.AssignedDate),
    };

    private readonly ApplicationDbContext _db;
    private readonly ILogger _logger;
    private readonly EfTableShape _tasks;

    public BulkUploadWriter(ApplicationDbContext db, ILogger logger)
    {
        _db = db;
        _logger = logger;
        _tasks = EfTableShape.For<TaskEntity>(db, TaskPropertiesWeSet);
    }

    // ---------------------------------------------------------------------------------------
    // Process table + Tasks
    // ---------------------------------------------------------------------------------------

    public async Task<List<ValidationErrorDto>> InsertAsync(
        string tableName,
        int processId,
        int uploadId,
        IReadOnlyCollection<ProcessField> processFields,
        List<StagedUploadRow> rows,
        Action<int>? onRowsWritten,
        CancellationToken ct = default)
    {
        var errors = new List<ValidationErrorDto>();
        if (rows.Count == 0) return errors;

        await _db.Database.OpenConnectionAsync(ct);
        try
        {
            var conn = (SqlConnection)_db.Database.GetDbConnection();
            var layout = await StageLayout.BuildAsync(conn, tableName, processFields, rows, _logger, ct);

            for (var start = 0; start < rows.Count; start += ChunkSize)
            {
                var chunk = rows.GetRange(start, Math.Min(ChunkSize, rows.Count - start));
                try
                {
                    await WriteChunkAsync(conn, layout, processId, uploadId, chunk, ct);
                }
                catch (Exception ex) when (chunk.Count > 1)
                {
                    _logger.LogWarning(ex,
                        "Upload {UploadId}: bulk chunk of {Count} rows into {Table} failed; retrying those rows one by one to isolate the bad ones.",
                        uploadId, chunk.Count, tableName);

                    foreach (var row in chunk)
                    {
                        try
                        {
                            await WriteChunkAsync(conn, layout, processId, uploadId, new List<StagedUploadRow> { row }, ct);
                        }
                        catch (Exception rowEx)
                        {
                            errors.Add(new ValidationErrorDto { RowNumber = row.RowNumber, ErrorMessage = Describe(rowEx) });
                        }
                    }
                }
                catch (Exception ex)
                {
                    errors.Add(new ValidationErrorDto { RowNumber = chunk[0].RowNumber, ErrorMessage = Describe(ex) });
                }

                onRowsWritten?.Invoke(chunk.Count);
            }
        }
        finally
        {
            await _db.Database.CloseConnectionAsync();
        }

        return errors;
    }

    private async System.Threading.Tasks.Task WriteChunkAsync(
        SqlConnection conn, StageLayout layout, int processId, int uploadId,
        List<StagedUploadRow> chunk, CancellationToken ct)
    {
        await using var tx = (SqlTransaction)await conn.BeginTransactionAsync(ct);
        try
        {
            // 1. Temp tables. Parameterless on purpose: a parameterised command runs inside
            //    sp_executesql and a #table created there disappears when it returns.
            await ExecAsync(conn, tx, layout.CreateStageSql, ct);

            // 2. Rows -> #UpStage
            var stage = layout.NewStageTable();
            for (var i = 0; i < chunk.Count; i++)
                layout.AddStageRow(stage, i, processId, uploadId, chunk[i]);

            using (var bulk = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, tx)
                   {
                       DestinationTableName = "#UpStage",
                       BulkCopyTimeout = TimeoutSeconds,
                   })
            {
                foreach (DataColumn c in stage.Columns) bulk.ColumnMappings.Add(c.ColumnName, c.ColumnName);
                await bulk.WriteToServerAsync(stage, ct);
            }

            // 3. #UpStage -> process table. MERGE rather than INSERT because only MERGE's OUTPUT
            //    can return a source column, which is what ties each new ProcessDataId to its row.
            var ids = new long[chunk.Count];
            await using (var cmd = new SqlCommand(layout.MergeSql, conn, tx) { CommandTimeout = TimeoutSeconds })
            await using (var reader = await cmd.ExecuteReaderAsync(ct))
            {
                while (await reader.ReadAsync(ct))
                    ids[reader.GetInt32(0)] = Convert.ToInt64(reader.GetValue(1));
            }

            // 4. Tasks, one bulk copy. FireTriggers/CheckConstraints so this behaves like EF's INSERT.
            var tasks = _tasks.NewDataTable();
            for (var i = 0; i < chunk.Count; i++)
            {
                var task = chunk[i].Task;
                if (task == null) continue;

                if (ids[i] <= 0)
                    throw new InvalidOperationException(
                        $"No ProcessDataId came back for row {chunk[i].RowNumber}. Task creation aborted.");

                task.ProcessDataId = Convert.ToInt32(ids[i]);
                _tasks.AddRow(tasks, task);
            }

            if (tasks.Rows.Count > 0)
            {
                using var bulk = new SqlBulkCopy(conn,
                    SqlBulkCopyOptions.FireTriggers | SqlBulkCopyOptions.CheckConstraints, tx)
                {
                    DestinationTableName = _tasks.QuotedTable,
                    BulkCopyTimeout = TimeoutSeconds,
                };
                foreach (DataColumn c in tasks.Columns) bulk.ColumnMappings.Add(c.ColumnName, c.ColumnName);
                await bulk.WriteToServerAsync(tasks, ct);
            }

            await ExecAsync(conn, tx, "DROP TABLE #UpStage; DROP TABLE #UpMap;", ct);
            await tx.CommitAsync(ct);
        }
        catch
        {
            // Rolls back the #tables too - DDL is transactional in SQL Server.
            try { await tx.RollbackAsync(CancellationToken.None); } catch { /* already gone */ }
            throw;
        }
    }

    // ---------------------------------------------------------------------------------------
    // Duplicate handling against tasks that already existed before this file
    // ---------------------------------------------------------------------------------------

    /// <param name="updates">TaskId -> new TaskData JSON ("update" action).</param>
    /// <param name="archives">TaskIds to cancel ("archive" action).</param>
    public async System.Threading.Tasks.Task ApplyExistingTaskChangesAsync(
        IReadOnlyDictionary<int, string> updates, IReadOnlyCollection<int> archives, DateTime now,
        CancellationToken ct = default)
    {
        if (updates.Count == 0 && archives.Count == 0) return;

        await _db.Database.OpenConnectionAsync(ct);
        try
        {
            var conn = (SqlConnection)_db.Database.GetDbConnection();
            await using var tx = (SqlTransaction)await conn.BeginTransactionAsync(ct);
            try
            {
                await ExecAsync(conn, tx,
                    "IF OBJECT_ID('tempdb..#UpTask') IS NOT NULL DROP TABLE #UpTask; " +
                    "CREATE TABLE #UpTask (TaskId int NOT NULL, Action tinyint NOT NULL, TaskData nvarchar(max) NULL, PRIMARY KEY (TaskId, Action));",
                    ct);

                var dt = new DataTable();
                dt.Columns.Add("TaskId", typeof(int));
                dt.Columns.Add("Action", typeof(byte));
                dt.Columns.Add("TaskData", typeof(string));
                foreach (var (id, json) in updates) dt.Rows.Add(id, (byte)1, json);
                foreach (var id in archives) dt.Rows.Add(id, (byte)2, DBNull.Value);

                using (var bulk = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, tx)
                       { DestinationTableName = "#UpTask", BulkCopyTimeout = TimeoutSeconds })
                {
                    bulk.ColumnMappings.Add("TaskId", "TaskId");
                    bulk.ColumnMappings.Add("Action", "Action");
                    bulk.ColumnMappings.Add("TaskData", "TaskData");
                    await bulk.WriteToServerAsync(dt, ct);
                }

                var t = _tasks;
                var sql = $@"
UPDATE t SET t.{t.Col(nameof(TaskEntity.TaskData))} = u.TaskData,
             t.{t.Col(nameof(TaskEntity.Priority))} = @Priority,
             t.{t.Col(nameof(TaskEntity.ModifiedDate))} = @Now
FROM {t.QuotedTable} t JOIN #UpTask u ON u.TaskId = t.{t.KeyCol} AND u.Action = 1;

UPDATE t SET t.{t.Col(nameof(TaskEntity.Status))} = @Cancelled,
             t.{t.Col(nameof(TaskEntity.ModifiedDate))} = @Now
FROM {t.QuotedTable} t JOIN #UpTask u ON u.TaskId = t.{t.KeyCol} AND u.Action = 2;

DROP TABLE #UpTask;";

                await using (var cmd = new SqlCommand(sql, conn, tx) { CommandTimeout = TimeoutSeconds })
                {
                    cmd.Parameters.AddWithValue("@Priority", t.ToProvider(nameof(TaskEntity.Priority), TaskPriority.Medium));
                    cmd.Parameters.AddWithValue("@Cancelled", t.ToProvider(nameof(TaskEntity.Status), Core.Enums.TaskStatus.Cancelled));
                    cmd.Parameters.AddWithValue("@Now", now);
                    await cmd.ExecuteNonQueryAsync(ct);
                }

                await tx.CommitAsync(ct);
            }
            catch
            {
                try { await tx.RollbackAsync(CancellationToken.None); } catch { }
                throw;
            }
        }
        finally
        {
            await _db.Database.CloseConnectionAsync();
        }
    }

    // ---------------------------------------------------------------------------------------

    private static async System.Threading.Tasks.Task ExecAsync(SqlConnection conn, SqlTransaction tx, string sql, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, conn, tx) { CommandTimeout = TimeoutSeconds };
        await cmd.ExecuteNonQueryAsync(ct);
    }

    private static string Describe(Exception ex)
    {
        var msg = ex.GetBaseException().Message;
        // SqlBulkCopy's "Received an invalid column length from the bcp client for colid 7" is
        // useless to a manager; say what it means.
        if (msg.Contains("invalid column length", StringComparison.OrdinalIgnoreCase))
            return "A value is longer than its column allows. " + msg;
        return msg;
    }

    internal static string Q(string name) => "[" + name.Replace("]", "]]") + "]";

    // =======================================================================================
    // Shape of #UpStage for one process table
    // =======================================================================================

    private sealed class StageLayout
    {
        // AsText: the target column is char/varchar/nvarchar. The old code wrote literals, so a Number
        // landed as '12.5' and a Date as '2026-10-28' in a text column - stage the same text so the
        // stored value doesn't change to '12.5000000000'.
        private readonly List<(string Column, ProcessField Field, bool AsText)> _fields = new();
        private bool _hasAssignee;

        public string CreateStageSql { get; private set; } = "";
        public string MergeSql { get; private set; } = "";

        public static async Task<StageLayout> BuildAsync(
            SqlConnection conn, string tableName, IReadOnlyCollection<ProcessField> processFields,
            List<StagedUploadRow> rows, ILogger logger, CancellationToken ct)
        {
            // Real columns of the process table, read once.
            var columns = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase); // name -> type
            await using (var cmd = new SqlCommand(
                             "SELECT c.name, TYPE_NAME(c.system_type_id) FROM sys.columns c WHERE c.object_id = OBJECT_ID(@t)", conn))
            {
                cmd.Parameters.AddWithValue("@t", "dbo." + Q(tableName));
                await using var r = await cmd.ExecuteReaderAsync(ct);
                while (await r.ReadAsync(ct)) columns[r.GetString(0)] = r.IsDBNull(1) ? "" : r.GetString(1);
            }

            if (columns.Count == 0)
                throw new InvalidOperationException($"Process table dbo.{tableName} was not found.");

            var layout = new StageLayout { _hasAssignee = columns.ContainsKey("AssignedUsername") };

            // Only fields the file actually mapped - same columns the old per-row INSERT used.
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var row in rows)
                foreach (var key in row.TaskData.Keys)
                    used.Add(key);

            foreach (var field in processFields)
            {
                if (!used.Contains(field.FieldName)) continue;
                if (field.FieldName.Equals("AssignedUsername", StringComparison.OrdinalIgnoreCase)) continue;

                if (!columns.TryGetValue(field.FieldName, out var sqlType))
                {
                    // The old code failed every row here ("Invalid column name"). Now the value still
                    // lands in Task.TaskData; republishing the process table fixes the column.
                    logger.LogWarning("Field {Field} is not a column of {Table}; it is kept in TaskData only.",
                        field.FieldName, tableName);
                    continue;
                }
                var asText = sqlType is "char" or "varchar" or "nchar" or "nvarchar" or "text" or "ntext";
                layout._fields.Add((field.FieldName, field, asText));
            }

            layout.BuildSql(tableName);
            return layout;
        }

        private static string SqlType(ProcessField f, bool asText) => asText ? "nvarchar(max)" : f.FieldType switch
        {
            FieldType.Date => "date",
            FieldType.Number => "decimal(38,10)",
            FieldType.Boolean => "bit",
            _ => "nvarchar(max)",
        };

        private static Type ClrType(ProcessField f, bool asText) => asText ? typeof(string) : f.FieldType switch
        {
            FieldType.Date => typeof(DateTime),
            FieldType.Number => typeof(decimal),
            FieldType.Boolean => typeof(bool),
            _ => typeof(string),
        };

        private void BuildSql(string tableName)
        {
            var stageCols = new List<string>
            {
                "[__RowNo] int NOT NULL PRIMARY KEY",
                "[ProcessId] int NOT NULL",
                "[FileRefId] int NOT NULL",
            };
            var targetCols = new List<string> { "[ProcessId]", "[FileRefId]" };

            if (_hasAssignee)
            {
                stageCols.Add("[AssignedUsername] nvarchar(max) NULL");
                targetCols.Add("[AssignedUsername]");
            }

            foreach (var (col, field, asText) in _fields)
            {
                stageCols.Add($"{Q(col)} {SqlType(field, asText)} NULL");
                targetCols.Add(Q(col));
            }

            CreateStageSql =
                "IF OBJECT_ID('tempdb..#UpStage') IS NOT NULL DROP TABLE #UpStage;\n" +
                "IF OBJECT_ID('tempdb..#UpMap') IS NOT NULL DROP TABLE #UpMap;\n" +
                $"CREATE TABLE #UpStage ({string.Join(", ", stageCols)});\n" +
                "CREATE TABLE #UpMap ([__RowNo] int NOT NULL, [ProcessDataId] bigint NOT NULL);";

            var list = string.Join(", ", targetCols);
            var values = string.Join(", ", targetCols.Select(c => "src." + c));

            MergeSql = $@"
MERGE INTO [dbo].{Q(tableName)} AS tgt
USING #UpStage AS src ON 1 = 0
WHEN NOT MATCHED THEN
    INSERT ({list}) VALUES ({values})
OUTPUT src.[__RowNo], inserted.[ProcessDataId] INTO #UpMap ([__RowNo], [ProcessDataId]);

SELECT [__RowNo], [ProcessDataId] FROM #UpMap;";
        }

        public DataTable NewStageTable()
        {
            var dt = new DataTable();
            dt.Columns.Add("__RowNo", typeof(int));
            dt.Columns.Add("ProcessId", typeof(int));
            dt.Columns.Add("FileRefId", typeof(int));
            if (_hasAssignee) dt.Columns.Add("AssignedUsername", typeof(string));
            foreach (var (col, field, asText) in _fields) dt.Columns.Add(col, ClrType(field, asText));
            return dt;
        }

        public void AddStageRow(DataTable dt, int rowNo, int processId, int uploadId, StagedUploadRow row)
        {
            var r = dt.NewRow();
            r["__RowNo"] = rowNo;
            r["ProcessId"] = processId;
            r["FileRefId"] = uploadId;
            if (_hasAssignee)
                r["AssignedUsername"] = string.IsNullOrEmpty(row.AssignedUsername) ? DBNull.Value : row.AssignedUsername;

            foreach (var (col, field, asText) in _fields)
            {
                var v = row.TaskData.TryGetValue(field.FieldName, out var raw) ? ToDbValue(field, raw) : DBNull.Value;
                r[col] = asText ? AsLiteralText(v) : v;
            }

            dt.Rows.Add(r);
        }

        /// <summary>
        /// Same rules the old InsertIntoProcessTableAsync applied when it built literals:
        /// blank / n/a / na / null dates -> NULL, unparseable number -> NULL, yes/no booleans, blank text -> NULL.
        /// </summary>
        private static object ToDbValue(ProcessField field, object? value)
        {
            if (value == null) return DBNull.Value;
            var s = value.ToString()?.Trim();

            switch (field.FieldType)
            {
                case FieldType.Date:
                    if (string.IsNullOrWhiteSpace(s) || s.Equals("n/a", StringComparison.OrdinalIgnoreCase) ||
                        s.Equals("na", StringComparison.OrdinalIgnoreCase) || s.Equals("null", StringComparison.OrdinalIgnoreCase))
                        return DBNull.Value;
                    if (value is DateTime dt) return dt.Date;
                    return DateTime.TryParse(s, out var d) ? d.Date : DBNull.Value;

                case FieldType.Number:
                    if (string.IsNullOrWhiteSpace(s) || s.Equals("n/a", StringComparison.OrdinalIgnoreCase))
                        return DBNull.Value;
                    // Rounded to the staging column's scale so SqlBulkCopy never rejects a long fraction.
                    if (value is decimal m) return Math.Round(m, 10);
                    return decimal.TryParse(s, out var n) ? Math.Round(n, 10) : DBNull.Value;

                case FieldType.Boolean:
                    if (string.IsNullOrWhiteSpace(s)) return DBNull.Value;
                    if (value is bool b) return b;
                    if (bool.TryParse(s, out var pb)) return pb;
                    var lower = s.ToLowerInvariant();
                    if (lower is "yes" or "true" or "1") return true;
                    if (lower is "no" or "false" or "0") return false;
                    return DBNull.Value;

                default:
                    return string.IsNullOrWhiteSpace(s) ? DBNull.Value : s;
            }
        }

        /// <summary>What the old SQL literal put in a text column.</summary>
        private static object AsLiteralText(object v) => v switch
        {
            DateTime d => d.ToString("yyyy-MM-dd"),
            decimal m => m.ToString(System.Globalization.CultureInfo.InvariantCulture),
            bool b => b ? "1" : "0",
            _ => v,
        };
    }
}

/// <summary>
/// Column layout of an EF entity's table, read from the EF model - so the bulk copy into Tasks
/// writes the same columns, names and converted values (string enums etc.) that EF's own INSERT does.
/// </summary>
internal sealed class EfTableShape
{
    private sealed record Col(IProperty Property, string Column, Type ProviderType, ValueConverter? Converter);

    private readonly IEntityType _entity;
    private readonly List<Col> _cols;

    public string QuotedTable { get; }
    public string KeyCol { get; }

    private EfTableShape(IEntityType entity, List<Col> cols)
    {
        _entity = entity;
        _cols = cols;
        QuotedTable = BulkUploadWriter.Q(entity.GetSchema() ?? "dbo") + "." + BulkUploadWriter.Q(entity.GetTableName()!);
        KeyCol = BulkUploadWriter.Q(entity.FindPrimaryKey()!.Properties[0].GetColumnName());
    }

    public static EfTableShape For<T>(DbContext db, IEnumerable<string> alwaysInclude)
    {
        var entity = db.Model.FindEntityType(typeof(T))
                     ?? throw new InvalidOperationException($"{typeof(T).Name} is not in the EF model.");
        var include = new HashSet<string>(alwaysInclude);
        var cols = new List<Col>();

        foreach (var p in entity.GetProperties())
        {
            if (p.PropertyInfo == null) continue;                 // shadow property
            if (p.GetComputedColumnSql() != null) continue;       // computed column
            // Identity key, rowversion, HasDefaultValue... - EF leaves these to the database when
            // the value is the CLR default, and we never set them, so we leave them too.
            if (p.ValueGenerated != ValueGenerated.Never && !include.Contains(p.Name)) continue;

            var conv = p.GetValueConverter() ?? p.FindTypeMapping()?.Converter;
            var type = conv?.ProviderClrType ?? p.ClrType;
            type = Nullable.GetUnderlyingType(type) ?? type;
            if (type.IsEnum) type = Enum.GetUnderlyingType(type);

            cols.Add(new Col(p, p.GetColumnName(), type, conv));
        }

        return new EfTableShape(entity, cols);
    }

    public string Col(string propertyName) =>
        BulkUploadWriter.Q(_entity.FindProperty(propertyName)!.GetColumnName());

    public object ToProvider(string propertyName, object value)
    {
        var p = _entity.FindProperty(propertyName)!;
        var conv = p.GetValueConverter() ?? p.FindTypeMapping()?.Converter;
        return Convert(value, conv) ?? DBNull.Value;
    }

    public DataTable NewDataTable()
    {
        var dt = new DataTable();
        foreach (var c in _cols) dt.Columns.Add(c.Column, c.ProviderType);
        return dt;
    }

    public void AddRow(DataTable dt, object entity)
    {
        var r = dt.NewRow();
        foreach (var c in _cols)
            r[c.Column] = Convert(c.Property.PropertyInfo!.GetValue(entity), c.Converter) ?? DBNull.Value;
        dt.Rows.Add(r);
    }

    private static object? Convert(object? value, ValueConverter? conv)
    {
        if (value == null) return null;
        if (conv != null) return conv.ConvertToProvider(value);
        if (value is Enum) return System.Convert.ChangeType(value, Enum.GetUnderlyingType(value.GetType()));
        return value;
    }
}
