# Background task removal and admin Task Details fixes

## 1. SQL
Run `sql/01_TaskDeleteJobs.sql`. The commented index at the bottom is recommended if `Tasks` has no `(ProcessId, Status)` index.

## 2. Backend (GTXH.OMC)

| File | Goes to |
|---|---|
| `Application/DTOs/TaskDeleteJobDtos.cs` | GTXH.OMC.Application/DTOs |
| `Application/Interfaces/ITaskDeleteJobService.cs` | GTXH.OMC.Application/Interfaces |
| `Application/Services/TaskDeleteJobService.cs` | GTXH.OMC.Application/Services |
| `Application/Services/TaskDeleteJobRunner.cs` | GTXH.OMC.Application/Services |
| `API/BackgroundServices/TaskDeleteWorker.cs` | GTXH.OMC.API/BackgroundServices |
| `API/Controllers/TaskDeleteJobsController.cs` | GTXH.OMC.API/Controllers |

Add these registrations to **Program.cs**:

```csharp
builder.Services.AddSingleton<TaskDeleteQueue>();
builder.Services.AddScoped<ITaskDeleteJobService, TaskDeleteJobService>();
builder.Services.AddScoped<TaskDeleteJobRunner>();
builder.Services.AddScoped<ITaskDeleteJobNotifier, NoOpTaskDeleteJobNotifier>();
builder.Services.AddHostedService<GTXH.OMC.API.BackgroundServices.TaskDeleteWorker>();
```

**IIS:** set the app pool's *Idle Time-out* to 0, or enable *AlwaysRunning*. That way a job doesn't pause when nobody is using the site. A job that's interrupted resumes on the next start anyway.

### What gets deleted (one place to change: `TaskDeleteRules`)
- **Remove Pending Tasks:** **Pending and InProgress**. This is the same as the old code, and the confirm text now says so. To remove only Pending, change `AllPendingStatuses` to `{ "Pending" }`.
- **Delete Selected:** Pending, InProgress, OnHold and Cancelled, again the same as before. Completed tasks are skipped and counted.

### Optional: push through your SignalR hub
The admin page already polls, so this is optional. Replace the no-op notifier:

```csharp
public class SignalRTaskDeleteJobNotifier : ITaskDeleteJobNotifier
{
    private readonly IHubContext<NotificationHub> _hub;   // your hub
    public SignalRTaskDeleteJobNotifier(IHubContext<NotificationHub> hub) => _hub = hub;

    public Task JobFinishedAsync(TaskDeleteJobDto job, CancellationToken ct = default) =>
        _hub.Clients.User(job.RequestedByUserId.ToString())
            .SendAsync("TaskDeleteJobFinished", job, ct);
}
// Program.cs: AddScoped<ITaskDeleteJobNotifier, SignalRTaskDeleteJobNotifier>()
```

The old `DeletePendingRecordsAsync` and `DeleteSelectedPendingTasksAsync` methods and their endpoints are no longer called by the admin page. Remove them once this is live.

## 3. Admin frontend
- `src/api/taskDeleteJobs.ts` is new.
- `src/pages/TaskDetailTable.tsx` replaces the existing file. Keep your original path if it lives somewhere else.

**Changes in the page:**
- **Remove Pending / Delete Selected run as background jobs.** Rows disappear right away, a progress bar shows "X of Y", and a toast appears when the job finishes. The grid then reloads from the server.
- **Leaving the page doesn't lose the job.** Coming back, or reloading, resumes the progress bar. A job that finished while you were away shows its result once.
- **Overlapping loads can't put deleted rows back.** Only the latest `loadTasks` call writes to the grid.
- **Filter dropdowns cascade.** Status, Priority, Assignee and Pivot list only values left by the other filters, the search and the pivots. Ticked values stay listed so they can be unticked.
- **Completed column added.** It shows the completed date and time (blank when the task isn't completed). It's sortable, and you can filter or pivot on it.
