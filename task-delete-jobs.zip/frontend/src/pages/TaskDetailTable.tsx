import React, {
  useState,
  useEffect,
  useMemo,
  useRef,
  useCallback,
} from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useToast } from "../components/Toast";
import {
  Search,
  Filter as FilterIcon,
  ChevronLeft,
  ChevronRight,
  Loader2,
  ArrowLeft,
  CheckSquare,
  Square,
  X,
  ChevronDown,
  ChevronUp,
  Columns,
  Eye,
  EyeOff,
  GripVertical,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Bookmark,
  Trash2,
  CheckCircle2,
  XCircle,
  UserPlus,
  Table2,
  FolderUp,
  FileX,
} from "lucide-react";
import { apiClient } from "../api/client";
import type {
  TaskDto,
  TaskListResponse,
  ProcessDto,
  ProcessFieldDto,
  AssignUser,
} from "../types"; //, UserDto, UserActivityDto
import { TaskStatus, TaskPriority } from "../types";
import { cn } from "../types";
import { useExportNotifications } from "../contexts/ExportNotificationContext";
import {
  taskDeleteJobs,
  isJobFinished,
  type TaskDeleteJob,
} from "../api/taskDeleteJobs";

/** Must match TaskDeleteRules on the server. */
const ALL_PENDING_DELETABLE = ["Pending", "InProgress"];
const SELECTED_DELETABLE = ["Pending", "InProgress", "OnHold", "Cancelled"];
//import { px } from 'motion';
// import { json } from 'stream/consumers';
// import { serialize } from 'v8';
// import { ca } from 'date-fns/locale';
// import { clear } from 'console';

interface TaskDetailTableProps {
  processId: number;
  onBack: () => void;
  addToast: (message: string, type: "success" | "error" | "info") => void;
}

type ColumnKey =
  | "taskId"
  | "externalRef"
  | "processName"
  | "status"
  | "priority"
  | "assignedUserName"
  | "createdDate"
  | "modifiedDate"
  | "completedDate"
  | string;

interface ColumnConfig {
  key: ColumnKey;
  label: string;
  visible: boolean;
  sortable: boolean;
  isDynamic?: boolean; // Indicates if this is a dynamic column from process fields
  fieldType?: string | any; // Field type for dynamic columns (can be FieldType enum or string)
}
const DEFAULT_COLUMNS: ColumnConfig[] = [
  { key: "taskId", label: "Task ID", visible: true, sortable: true },
  // { key: 'externalRef', label: 'External Ref', visible: true, sortable: true },
  { key: "processName", label: "Process", visible: true, sortable: true },
  { key: "status", label: "Status", visible: true, sortable: true },
  { key: "priority", label: "Priority", visible: true, sortable: true },
  { key: "assignedUserName", label: "Assigned", visible: true, sortable: true },
  { key: "createdDate", label: "Created", visible: true, sortable: true },
  { key: "modifiedDate", label: "Updated", visible: true, sortable: true },
  { key: "completedDate", label: "Completed", visible: true, sortable: true },
];

const STATUS_CONFIG: Record<string, { color: string; icon: React.ReactNode }> =
  {
    Pending: {
      color: "text-yellow-600 bg-yellow-50 border-yellow-200",
      icon: <Loader2 className="w-3 h-3" />,
    },
    InProgress: {
      color: "text-blue-600 bg-blue-50 border-blue-200",
      icon: <Loader2 className="w-3 h-3 animate-spin" />,
    },
    Completed: {
      color: "text-green-600 bg-green-50 border-green-200",
      icon: <CheckCircle2 className="w-3 h-3" />,
    },
    Cancelled: {
      color: "text-red-600 bg-red-50 border-red-200",
      icon: <XCircle className="w-3 h-3" />,
    },
    OnHold: {
      color: "text-gray-600 bg-gray-50 border-gray-200",
      icon: <XCircle className="w-3 h-3" />,
    },
    NeedsReview: {
      color: "text-purple-600 bg-purple-50 border-purple-200",
      icon: <Eye className="w-3 h-3" />,
    },
    AuditRework: {
      color: "text-orange-600 bg-orange-50 border-orange-200",
      icon: <RefreshCw className="w-3 h-3" />,
    },
  };

export default function TaskDetailTable({
  processId,
  onBack,
}: TaskDetailTableProps) {
  const { showToast } = useToast();
  const [tasks, setTasks] = useState<TaskDto[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [process, setProcess] = useState<ProcessDto | null>(null);
  const [processFields, setProcessFields] = useState<ProcessFieldDto[]>([]);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  // const [statusFilter] = useState<string>('');
  const [priorityFilter] = useState<string>("");
  const [assignedUserFilter] = useState<string>("");
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  // Frontend pagination: we fetch ALL rows in one shot (backend pageSize is
  // large) and paginate/filter entirely on the client. This fixes filters that
  // previously only searched the current 50-row server page. PAGE_SIZE controls
  // how many rows show per client page.
  // const PAGE_SIZE = 10000;
  const [pageSize, setPageSize] = useState<number>(50);
  // const startIndex = (page - 1) * pageSize;
  // const endIndex = startIndex + pageSize;
  // const visibleRows = tasks.slice(startIndex, endIndex);
  // const totalPage = Math.ceil(tasks.length / pageSize);
  const [selectedTasks, setSelectedTasks] = useState<Set<number>>(new Set());
  const [selectAllMode, setSelectAllMode] = useState<"visible" | "all">(
    "visible",
  );
  const [_allTaskIds, setAllTaskIds] = useState<number[]>([]);
  const [showAssignModal, setShowAssignModal] = useState(false);
  // const [users, setUsers] = useState<UserActivityDto[]>([]);
  const [assignedUsers, setassignedUsers] = useState<AssignUser[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [columns, setColumns] = useState<ColumnConfig[]>(DEFAULT_COLUMNS);
  const [showColumnMenu, setShowColumnMenu] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [sortColumn, setSortColumn] = useState<ColumnKey | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [columnFilters, setColumnFilters] = useState<
    Array<{ id: string; value: any }>
  >([]);
  const [customSavedFilters, setCustomSavedFilters] = useState<
    Array<{ id: string; name: string; filters: any[] }>
  >([]);
  const [selectedFilterId, setSelectedFilterId] = useState("all");
  const [openFilterDropdown, setOpenFilterDropdown] = useState<string | null>(
    null,
  );
  const [isSavingFilter, setIsSavingFilter] = useState(false);
  const [newFilterName, setNewFilterName] = useState("");
  const [_showPivot, setShowPivot] = useState(false);
  const [pivotColumns, setPivotColumns] = useState<string[]>([]);
  const [pivotFilters, setPivotFilters] = useState<Map<string, string[]>>(
    new Map(),
  ); // Track selected values for each pivot column
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [toDate, setToDate] = useState<Date | null>(null);
  // Read-only fx bar: shows the full value of the cell the admin last clicked.
  // This console is view-only, so the bar is always disabled (never edits).
  const [fxValue, setFxValue] = useState("");
  const [fxLabel, setFxLabel] = useState("");
  const searchInputRef = useRef<HTMLInputElement>(null);
  const { addExport } = useExportNotifications();
  const [filterSearch, setFilterSearch] = useState<Record<string, string>>({});
  const [filterSort, _setFilterSort] = useState<Record<string, "asc" | "desc">>(
    {},
  );

  // Background delete job (Remove Pending Tasks / Delete Selected) shown in the progress banner.
  const [deleteJob, setDeleteJob] = useState<TaskDeleteJob | null>(null);
  const deleteJobRunning = !!deleteJob && !isJobFinished(deleteJob);
  const finishedJobHandledRef = useRef<number | null>(null);

  // Every loadTasks call gets a number; only the latest one may write state. Stops an older,
  // slower load from putting deleted rows back after a newer load already finished.
  const loadSeqRef = useRef(0);

  // Per-process localStorage keys so each process keeps its own saved filters
  // and column layout across reloads / logins.
  const SAVED_FILTERS_KEY = `taskDetail.savedFilters_${processId}`;
  const COLUMN_PREFS_KEY = `taskDetail.columnPrefs_${processId}`;
  // Only persist saved filters after the user actually changes them, so we
  // never overwrite stored filters with the empty initial state on first load.
  const filtersUserTouchedRef = useRef(false);
  const savedFiltersLoadedKeyRef = useRef<string | null>(null);
  const colPrefsLoadedKeyRef = useRef<string | null>(null);

  type Option = {
    label: string;
    value: string;
  };

  const options: Option[] = [
    {
      label: "Pending",
      value: "Pending",
    },
    {
      label: "InProgress",
      value: "InProgress",
    },
    {
      label: "Completed",
      value: "Completed",
    },
  ];

  const [selectedValues, setSelectedValues] = useState<string[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const toggleOption = (value: string) => {
    setSelectedValues((prev) => {
      if (prev.includes(value)) {
        console.log("Removing value:", value);
        return prev.filter((v) => v !== value);
      } else {
        console.log("Adding value:", value);
        return [...prev, value];
      }
    });
  };

  const getSelectedLabels = () => {
    return options
      .filter((opt) => selectedValues.includes(opt.value))
      .map((opt) => opt.label);
  };

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  // Load process details and fields when processId changes
  useEffect(() => {
    if (processId) {
      loadProcessDetails();
    }
  }, [processId]);

  // Update columns when process fields change
  useEffect(() => {
    if (processFields.length > 0) {
      updateColumnsFromProcessFields();
    }
  }, [processFields]);

  const loadProcessDetails = async () => {
    if (!processId) return;

    try {
      const processData = await apiClient.getProcess(processId);
      setProcess(processData);
      // Filter out deleted fields and sort by displayOrder
      const activeFields = (processData.fields || [])
        .filter((f) => !f.isDeleted)
        .sort((a, b) => a.displayOrder - b.displayOrder);
      setProcessFields(activeFields);
    } catch (error) {
      console.error("Failed to load process details:", error);
    }
  };

  const updateColumnsFromProcessFields = () => {
    // Start with default columns
    const baseColumns: ColumnConfig[] = [
      { key: "taskId", label: "Task ID", visible: true, sortable: true },
      // { key: 'externalRef', label: 'External Ref', visible: true, sortable: true },
      { key: "status", label: "Status", visible: true, sortable: true },
      { key: "priority", label: "Priority", visible: true, sortable: true },
      {
        key: "assignedUserName",
        label: "Assigned",
        visible: true,
        sortable: true,
      },
      { key: "createdDate", label: "Created", visible: true, sortable: true },
      { key: "modifiedDate", label: "Updated", visible: true, sortable: true },
      {
        key: "completedDate",
        label: "Completed",
        visible: true,
        sortable: true,
      },
    ];

    // Add dynamic columns from process fields
    const dynamicColumns: ColumnConfig[] = processFields.map((field) => ({
      key: `taskData.${field.fieldName}`,
      label: field.fieldName,
      visible: true,
      sortable: true,
      isDynamic: true,
      fieldType: field.fieldType,
    }));

    // Merge columns, preserving visibility state from existing columns if they exist
    const existingColumnsMap = new Map(columns.map((col) => [col.key, col]));
    const mergedColumns = [
      ...baseColumns.map((col) => {
        const existing = existingColumnsMap.get(col.key);
        return existing ? { ...col, visible: existing.visible } : col;
      }),
      ...dynamicColumns.map((col) => {
        const existing = existingColumnsMap.get(col.key);
        return existing ? { ...col, visible: existing.visible } : col;
      }),
    ];

    // Apply saved column preferences for this process (order + visibility), if any.
    let finalColumns = mergedColumns;
    try {
      const raw = localStorage.getItem(COLUMN_PREFS_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as {
          order?: string[];
          hidden?: string[];
        };
        const validKeys = new Set(mergedColumns.map((c) => c.key));
        const hiddenSet = new Set(saved.hidden || []);

        // Apply visibility from saved hidden list.
        let withVisibility = mergedColumns.map((c) => ({
          ...c,
          visible: !hiddenSet.has(c.key),
        }));

        // Apply saved order: saved keys first (in order), then any new columns.
        if (Array.isArray(saved.order)) {
          const savedOrder = saved.order.filter((k) => validKeys.has(k));
          const byKey = new Map(withVisibility.map((c) => [c.key, c]));
          const ordered = savedOrder.map((k) => byKey.get(k)!).filter(Boolean);
          const missing = withVisibility.filter(
            (c) => !savedOrder.includes(c.key),
          );
          withVisibility = [...ordered, ...missing];
        }
        finalColumns = withVisibility;
      }
    } catch {
      /* corrupt prefs — use defaults */
    }

    setColumns(finalColumns);
    colPrefsLoadedKeyRef.current = COLUMN_PREFS_KEY;
  };

  // Persist column order + visibility whenever they change (after first load).
  useEffect(() => {
    if (colPrefsLoadedKeyRef.current !== COLUMN_PREFS_KEY) return;
    if (columns.length === 0) return;
    try {
      const order = columns.map((c) => c.key);
      const hidden = columns.filter((c) => !c.visible).map((c) => c.key);
      localStorage.setItem(COLUMN_PREFS_KEY, JSON.stringify({ order, hidden }));
    } catch {
      /* non-fatal */
    }
  }, [columns, COLUMN_PREFS_KEY]);

  // const loadAllTaskIds = async (): Promise<number[]> => {
  //   if (!processId || total === 0) return [];

  //   // Only load if we don't already have all IDs
  //   if (allTaskIds.length === total && total > 0) {
  //     return allTaskIds; // Already loaded
  //   }

  //   try {
  //     const allIds: number[] = [];
  //     const batchSize = 1000;
  //     const totalPages = Math.ceil(total / batchSize);

  //     // Load in batches to avoid memory issues
  //     for (let p = 1; p <= totalPages; p++) {
  //       const batchResult = await apiClient.getTasks({
  //         processId,
  //         status: statusFilter || undefined,
  //         page: p,
  //         pageSize: batchSize,
  //       });
  //       batchResult.items?.forEach(task => allIds.push(task.taskId));
  //     }
  //     setAllTaskIds(allIds);
  //     return allIds;
  //   } catch (error) {
  //     console.error('Failed to load all task IDs:', error);
  //     return [];
  //   }
  // };

  const loadTasks = useCallback(async () => {
    if (!processId) {
      console.warn("Cannot load tasks: processId is missing");
      setError("Process ID is missing");
      return;
    }

    const seq = ++loadSeqRef.current;
    setIsLoading(true);
    setError(null);
    try {
      const FETCH_BATCH_SIZE = 1000;
      let allItems: TaskDto[] = [];
      let currentPage = 1;
      let totalCount = 0;

      while (true) {
        const result: TaskListResponse = await apiClient.getTasks({
          processId,
          // No status/page here on purpose — we pull the full set (pageSize is
          // large) and do all filtering + pagination on the client.
          page: currentPage,
          pageSize: FETCH_BATCH_SIZE,
        });

        if (seq !== loadSeqRef.current) return; // a newer load started
        const items = result.items || [];
        allItems = allItems.concat(items);
        totalCount = result.totalCount || 0;

        if (allItems.length >= totalCount || items.length < FETCH_BATCH_SIZE)
          break;
        currentPage++;
      }
      if (seq !== loadSeqRef.current) return;
      setTasks(allItems);
      setTotal(totalCount);
    } catch (error: any) {
      if (seq !== loadSeqRef.current) return;
      console.error("Failed to load tasks:", error);
      console.error("Error details:", {
        message: error?.message,
        status: error?.status,
        code: error?.code,
        processId,
        stack: error?.stack,
      });
      // Show user-friendly error message
      const errorMessage =
        error?.message || "Failed to load tasks. Please try again.";
      setError(errorMessage);
      setTasks([]);
      setTotal(0);
      setAllTaskIds([]);
    } finally {
      if (seq === loadSeqRef.current) setIsLoading(false);
    }
  }, [processId]);

  // Load tasks once per process (full set). Client handles filter + pagination.
  useEffect(() => {
    if (processId) {
      loadTasks();
    }
  }, [processId, loadTasks]);

  const getStatusLabel = (status: TaskStatus): string => {
    return TaskStatus[status] || "Unknown";
  };

  const getStatusConfig = (status: TaskStatus) => {
    const statusKey = TaskStatus[status];
    return STATUS_CONFIG[statusKey] || STATUS_CONFIG["Pending"];
  };

  const getPriorityColor = (priority?: TaskPriority) => {
    switch (priority) {
      case TaskPriority.High:
        return "text-red-600 bg-red-50 border-red-200";
      case TaskPriority.Medium:
        return "text-amber-600 bg-amber-50 border-amber-200";
      case TaskPriority.Low:
        return "text-gray-600 bg-gray-50 border-gray-200";
      case TaskPriority.Urgent:
        return "text-red-600 bg-red-50 border-red-200";
      default:
        return "text-gray-400 bg-gray-50 border-gray-200";
    }
  };

  const [showExportOptions, setShowExportOptions] = useState(false);

  const toggleExport = () => {
    setShowExportOptions((prev) => !prev);
  };

  /** Hide rows the job is about to delete, so the grid reflects the action straight away. */
  const hideRowsLocally = (
    match: (t: TaskDto) => boolean,
  ) => {
    setTasks((prev) => {
      const next = prev.filter((t) => !match(t));
      const removed = prev.length - next.length;
      if (removed > 0) setTotal((tot) => Math.max(0, tot - removed));
      return next;
    });
  };

  const removePendingTasks = async () => {
    if (!processId || deleteJobRunning) return;
    if (
      !window.confirm(
        "Remove ALL Pending and In Progress tasks for this process? This cannot be undone.",
      )
    ) {
      return;
    }

    try {
      const res = await taskDeleteJobs.startAllPending(processId);
      if (!res.jobId || res.totalCount === 0) {
        showToast("No pending tasks to remove.", "info");
        return;
      }
      showToast(
        res.alreadyRunning
          ? "A removal is already running for this process."
          : `Removing ${res.totalCount.toLocaleString()} task(s) in the background. You can keep working.`,
        "info",
      );
      hideRowsLocally((t) =>
        ALL_PENDING_DELETABLE.includes(TaskStatus[t.status]),
      );
      setDeleteJob(await taskDeleteJobs.get(res.jobId));
    } catch (error) {
      console.error("Failed to start removing pending tasks:", error);
      showToast("Failed to start removing pending tasks.", "error");
    }
  };

  const formatDate = (dateString: string): string => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      });
    } catch {
      return dateString;
    }
  };

  const formatDateTime = (dateString: string): string => {
    try {
      const date = new Date(dateString);
      return date.toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return dateString;
    }
  };

  // Get pivot value for a task (needed before filteredTasks)
  const getPivotValue = (task: TaskDto, colKey: string): string => {
    if (colKey === "status") {
      return TaskStatus[task.status] || "Unknown";
    } else if (colKey === "priority") {
      return task.priority ? TaskPriority[task.priority] : "Not Set";
    } else if (colKey === "assignedUserName") {
      return task.assignedUserName || "Unassigned";
    } else if (colKey === "externalRef") {
      return task.externalRef;
    } else if (colKey === "createdDate") {
      return formatDate(task.createdDate);
    } else if (colKey === "modifiedDate") {
      return formatDate(task.modifiedDate);
    } else if (colKey === "completedDate") {
      return task.completedDate ? formatDate(task.completedDate) : "Not Completed";
    } else if (colKey.startsWith("taskData.")) {
      const fieldName = colKey.replace("taskData.", "");
      return String(task.taskData?.[fieldName] ?? "—");
    } else {
      return String((task as any)[colKey] ?? "—");
    }
  };

  const handleDeleteSelectedTasks = async () => {
    if (selectedTasks.size === 0) {
      showToast("No tasks selected", "error");
      return;
    }
    if (deleteJobRunning) {
      showToast("Please wait for the current removal to finish.", "info");
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to delete ${selectedTasks.size} selected task(s)? Completed tasks are skipped.`,
    );
    if (!confirmed) return;

    const ids = Array.from(selectedTasks);
    try {
      const res = await taskDeleteJobs.startSelected(processId, ids);
      showToast(
        `Deleting ${res.totalCount.toLocaleString()} task(s) in the background...`,
        "info",
      );
      const idSet = new Set(ids);
      hideRowsLocally(
        (t) =>
          idSet.has(t.taskId) &&
          SELECTED_DELETABLE.includes(TaskStatus[t.status]),
      );
      setSelectedTasks(new Set());
      setDeleteJob(await taskDeleteJobs.get(res.jobId));
    } catch (error) {
      console.error("Failed to delete tasks:", error);
      showToast("Failed to start deleting the selected tasks.", "error");
    }
  };

  // Resume the banner for a job started earlier (page reload / navigated away and back).
  useEffect(() => {
    setDeleteJob(null);
    if (!processId) return;
    let cancelled = false;
    taskDeleteJobs
      .active(processId)
      .then((list) => {
        if (cancelled || !list?.length) return;
        setDeleteJob(list.find((j) => !isJobFinished(j)) ?? list[0]);
      })
      .catch(() => {
        /* banner is a convenience */
      });
    return () => {
      cancelled = true;
    };
  }, [processId]);

  // Poll progress while the job runs.
  const deleteJobId = deleteJob?.jobId;
  useEffect(() => {
    if (!deleteJobId || !deleteJobRunning) return;
    const timer = window.setInterval(() => {
      taskDeleteJobs
        .get(deleteJobId)
        .then((job) => setDeleteJob(job))
        .catch(() => {
          /* try again next tick */
        });
    }, 2000);
    return () => window.clearInterval(timer);
  }, [deleteJobId, deleteJobRunning]);

  // When it finishes: one toast, reload from the server (the truth), and mark it seen.
  useEffect(() => {
    if (!deleteJob || !isJobFinished(deleteJob)) return;
    if (finishedJobHandledRef.current === deleteJob.jobId) return;
    finishedJobHandledRef.current = deleteJob.jobId;

    if (deleteJob.status === "Completed") {
      const skipped =
        deleteJob.skippedCount > 0
          ? ` ${deleteJob.skippedCount.toLocaleString()} skipped (no longer deletable).`
          : "";
      showToast(
        `Removed ${deleteJob.deletedCount.toLocaleString()} task(s).${skipped}`,
        "success",
      );
    } else {
      showToast(
        `Removal stopped after ${deleteJob.deletedCount.toLocaleString()} of ${deleteJob.totalCount.toLocaleString()} task(s). Run it again to finish.`,
        "error",
      );
    }

    loadTasks();
    taskDeleteJobs.markSeen(deleteJob.jobId).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deleteJob, loadTasks]);

  // ── Filter matching (shared by the grid and the cascading dropdown counts) ──
  const matchesSearch = (task: TaskDto): boolean => {
    if (!debouncedSearch) return true;
    const searchLower = debouncedSearch.toLowerCase();
    return (
      task.processName.toLowerCase().includes(searchLower) ||
      !!task.assignedUserName?.toLowerCase().includes(searchLower) ||
      task.taskId.toString().includes(searchLower) ||
      Object.values(task.taskData || {}).some((val) =>
        String(val || "")
          .toLowerCase()
          .includes(searchLower),
      )
    );
  };

  /** True when the task passes this one column filter (inactive filters pass everything). */
  const matchesColumnFilter = (
    task: TaskDto,
    filter: { id: string; value: any },
  ): boolean => {
    const v = filter.value;
    const isList = Array.isArray(v) && v.length > 0;

    if (filter.id === "status") {
      return !isList || v.includes(TaskStatus[task.status]);
    }
    if (filter.id === "priority") {
      return (
        !isList || (!!task.priority && v.includes(TaskPriority[task.priority]))
      );
    }
    if (filter.id === "assignedUserName") {
      return !isList || v.includes(task.assignedUserName || "Unassigned");
    }
    if (filter.id === "taskId") {
      return !v || task.taskId.toString().includes(String(v).toLowerCase());
    }
    if (filter.id === "createdDate") {
      return (
        !v ||
        formatDate(task.createdDate)
          .toLowerCase()
          .includes(String(v).toLowerCase())
      );
    }
    if (filter.id === "modifiedDate") {
      return (
        !v ||
        formatDateTime(task.modifiedDate)
          .toLowerCase()
          .includes(String(v).toLowerCase())
      );
    }
    if (filter.id === "completedDate") {
      if (!v) return true;
      return task.completedDate
        ? formatDateTime(task.completedDate)
            .toLowerCase()
            .includes(String(v).toLowerCase())
        : false;
    }
    if (filter.id.startsWith("taskData.")) {
      if (v === null || v === undefined || v === "") return true;
      const taskValue = task.taskData?.[filter.id.replace("taskData.", "")];
      if (Array.isArray(v)) {
        return (
          v.length === 0 ||
          v.some(
            (val: any) =>
              String(taskValue || "").toLowerCase() ===
              String(val).toLowerCase(),
          )
        );
      }
      if (typeof v === "string") {
        return String(taskValue || "")
          .toLowerCase()
          .includes(v.toLowerCase());
      }
    }
    return true;
  };

  const matchesPivot = (task: TaskDto, key: string, values: string[]) =>
    values.length === 0 || values.includes(getPivotValue(task, key));

  // Filter tasks based on search and filters (excluding pivot filters for counts calculation)
  const tasksBeforePivotFilters = useMemo(() => {
    return tasks.filter(
      (task) =>
        matchesSearch(task) &&
        (!priorityFilter || task.priority?.toString() === priorityFilter) &&
        columnFilters.every((f) => matchesColumnFilter(task, f)),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    tasks,
    debouncedSearch,
    priorityFilter,
    assignedUserFilter,
    columnFilters,
  ]);

  // Apply pivot filters to get final filtered tasks
  const filteredTasks = useMemo(() => {
    let filtered = [...tasksBeforePivotFilters];

    // Pivot filters (work like regular filters)
    pivotFilters.forEach((selectedValues: string[], pivotColKey: string) => {
      if (selectedValues.length > 0) {
        filtered = filtered.filter((task) =>
          matchesPivot(task, pivotColKey, selectedValues),
        );
      }
    });

    // Sorting
    if (sortColumn) {
      filtered.sort((a, b) => {
        let aVal: any;
        let bVal: any;

        // Handle dynamic columns (taskData fields)
        if (sortColumn.startsWith("taskData.")) {
          const fieldName = sortColumn.replace("taskData.", "");
          aVal = a.taskData[fieldName];
          bVal = b.taskData[fieldName];

          // Handle different data types
          if (aVal === null || aVal === undefined) aVal = "";
          if (bVal === null || bVal === undefined) bVal = "";

          // Try to parse as number or date
          const aNum = typeof aVal === "string" ? parseFloat(aVal) : aVal;
          const bNum = typeof bVal === "string" ? parseFloat(bVal) : bVal;

          if (!isNaN(aNum) && !isNaN(bNum) && aNum !== aVal && bNum !== bVal) {
            // Both are numbers
            aVal = aNum;
            bVal = bNum;
          } else {
            // Treat as string
            aVal = String(aVal).toLowerCase();
            bVal = String(bVal).toLowerCase();
          }
        } else {
          // Handle standard columns
          switch (sortColumn) {
            case "taskId":
              aVal = a.taskId;
              bVal = b.taskId;
              break;
            case "processName":
              aVal = a.processName.toLowerCase();
              bVal = b.processName.toLowerCase();
              break;
            case "status":
              aVal = a.status;
              bVal = b.status;
              break;
            case "priority":
              aVal = a.priority ?? 0;
              bVal = b.priority ?? 0;
              break;
            case "assignedUserName":
              aVal = a.assignedUserName?.toLowerCase() || "";
              bVal = b.assignedUserName?.toLowerCase() || "";
              break;
            case "createdDate":
              aVal = new Date(a.createdDate).getTime();
              bVal = new Date(b.createdDate).getTime();
              break;
            case "modifiedDate":
              aVal = new Date(a.modifiedDate).getTime();
              bVal = new Date(b.modifiedDate).getTime();
              break;
            case "completedDate":
              // Not-completed tasks sort as oldest.
              aVal = a.completedDate ? new Date(a.completedDate).getTime() : 0;
              bVal = b.completedDate ? new Date(b.completedDate).getTime() : 0;
              break;
            default:
              return 0;
          }
        }

        if (aVal < bVal) return sortDirection === "asc" ? -1 : 1;
        if (aVal > bVal) return sortDirection === "asc" ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [tasksBeforePivotFilters, pivotFilters, sortColumn, sortDirection]);

  // ── Frontend pagination ───────────────────────────────────────────────────
  // Total pages derived from the FILTERED set (not the server total), and the
  // current page sliced out for rendering.
  // const listForPaging = filteredTasks
  const totalPages = Math.max(1, Math.ceil(filteredTasks.length / pageSize));
  const startIndex = (page - 1) * pageSize;
  // const pagedTasks = listForPaging.slice(startIndex, startIndex + pageSize);

  // Keep the current page within range whenever the filtered set shrinks
  // (e.g. user applies a filter while on page 5 of an unfiltered list).
  useEffect(() => {
    if (page > totalPages) setPage(totalPages);
  }, [totalPages, page]);

  // Reset to the first page whenever the filters/search change so the user
  // isn't stranded on an out-of-range page.
  useEffect(() => {
    setPage(1);
  }, [
    debouncedSearch,
    columnFilters,
    pivotFilters,
    priorityFilter,
    assignedUserFilter,
    sortColumn,
    sortDirection,
  ]);

  const paginatedTasks = useMemo(() => {
    // const start = (page - 1) * PAGE_SIZE;
    return filteredTasks.slice(startIndex, startIndex + pageSize);
  }, [filteredTasks, startIndex, pageSize]);

  const handleSort = (column: ColumnKey) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("desc");
    }
  };

  const toggleColumn = (key: ColumnKey) => {
    setColumns(
      columns.map((col) =>
        col.key === key ? { ...col, visible: !col.visible } : col,
      ),
    );
  };

  const toggleSelectAll = async (mode: "visible" | "all" = selectAllMode) => {
    if (mode === "all") {
      // Select EVERY row in the current filtered set (all pages).
      const ids = filteredTasks.map((t) => t.taskId);
      if (ids.length > 0 && selectedTasks.size === ids.length) {
        setSelectedTasks(new Set());
      } else {
        setSelectedTasks(new Set(ids));
      }
    } else {
      // Select only the rows visible on the CURRENT page.
      const visibleIds = paginatedTasks.map((t) => t.taskId);
      const allVisibleSelected =
        visibleIds.length > 0 &&
        visibleIds.every((id) => selectedTasks.has(id));
      if (allVisibleSelected) {
        // Deselect the current page's rows.
        setSelectedTasks((prev) => {
          const next = new Set(prev);
          visibleIds.forEach((id) => next.delete(id));
          return next;
        });
      } else {
        // Add the current page's rows to the selection.
        setSelectedTasks((prev) => {
          const next = new Set(prev);
          visibleIds.forEach((id) => next.add(id));
          return next;
        });
      }
    }
  };

  const isAllSelected = () => {
    if (selectAllMode === "all") {
      return (
        selectedTasks.size === filteredTasks.length && filteredTasks.length > 0
      );
    } else {
      // Visible mode: all rows on the current page are selected.
      const visibleIds = paginatedTasks.map((t) => t.taskId);
      return (
        visibleIds.length > 0 && visibleIds.every((id) => selectedTasks.has(id))
      );
    }
  };

  const isPartiallySelected = () => {
    if (selectAllMode === "all") {
      return (
        selectedTasks.size > 0 && selectedTasks.size < filteredTasks.length
      );
    } else {
      const visibleIds = paginatedTasks.map((t) => t.taskId);
      const selectedVisible = visibleIds.filter((id) =>
        selectedTasks.has(id),
      ).length;
      return selectedVisible > 0 && selectedVisible < visibleIds.length;
    }
  };

  const toggleSelectTask = (taskId: number) => {
    const newSelected = new Set(selectedTasks);
    if (newSelected.has(taskId)) {
      newSelected.delete(taskId);
    } else {
      newSelected.add(taskId);
    }
    setSelectedTasks(newSelected);
  };

  const handleBulkUpdate = async (updates: {
    status?: TaskStatus;
    priority?: TaskPriority;
  }) => {
    if (selectedTasks.size === 0) return;

    try {
      setIsLoading(true);

      // Filter out tasks that already have the target status/priority
      const tasksToUpdate = Array.from(selectedTasks).filter((taskId) => {
        const task = tasks.find((t) => t.taskId === taskId);
        if (!task) return false;

        // Check if status needs updating
        if (updates.status !== undefined && task.status === updates.status) {
          return false;
        }

        // Check if priority needs updating
        if (
          updates.priority !== undefined &&
          task.priority === updates.priority
        ) {
          return false;
        }

        return true;
      });

      if (tasksToUpdate.length === 0) {
        // All selected tasks already have the target status/priority
        setSelectedTasks(new Set());
        setIsLoading(false);
        return;
      }

      const updatePromises = tasksToUpdate.map((taskId) =>
        apiClient.updateTask(taskId, updates),
      );
      await Promise.all(updatePromises);
      await loadTasks();
      setSelectedTasks(new Set());
    } catch (error) {
      console.error("Failed to update tasks:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadUsersProcess = async () => {
    if (!processId) return;

    setLoadingUsers(true);
    try {
      const usersData = await apiClient.getUsersForProcess(processId);

      const mappedUsers: AssignUser[] = usersData.map((user) => ({
        userId: user.userId,
        username: user.username,
        status: user.status, // may be undefined since backend commented it
        activeTasks: 0,
        tasksCompletedToday: 0,
      }));

      const sortedUsers = mappedUsers.sort((a, b) =>
        a.username.localeCompare(b.username),
      );

      setassignedUsers(sortedUsers);
    } catch (error) {
      console.error("Failed to load users:", error);
      setassignedUsers([]);
    } finally {
      setLoadingUsers(false);
    }
  };

  // const loadUsers = async () => {
  //   if (!processId) return;

  //   setLoadingUsers(true);
  //   try {
  //     // Get user activity which includes active task counts
  //     const activityData = await apiClient.getUserActivity();

  //     // Filter users who have active tasks for this process
  //     // We'll show all users but highlight those with active tasks
  //     const processUsers = activityData.users || [];

  //     // Sort by active tasks (descending) and then by username
  //     const sortedUsers = [...processUsers].sort((a, b) => {
  //       if (b.activeTasks !== a.activeTasks) {
  //         return b.activeTasks - a.activeTasks;
  //       }
  //       return a.username.localeCompare(b.username);
  //     });

  //     setUsers(sortedUsers);
  //   } catch (error) {
  //     console.error('Failed to load users:', error);
  //     setUsers([]);
  //   } finally {
  //     setLoadingUsers(false);
  //   }
  // };

  const handleBulkAssign = async (userId: number) => {
    if (selectedTasks.size === 0 || !userId) return;

    try {
      setIsLoading(true);
      const taskIds = Array.from(selectedTasks);

      await apiClient.assignTasks({
        taskIds,
        assignedToUserId: userId,
      });

      await loadTasks();
      setSelectedTasks(new Set());
      setShowAssignModal(false);
      setSelectedUserId(null);
    } catch (error) {
      console.error("Failed to assign tasks:", error);
      alert("Failed to assign tasks. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const openAssignModal = () => {
    setShowAssignModal(true);
    setSelectedUserId(null);
    loadUsersProcess();
  };

  const handleTaskUpdate = async (
    taskId: number,
    updates: { status?: TaskStatus; priority?: TaskPriority },
  ) => {
    try {
      await apiClient.updateTask(taskId, updates);
      await loadTasks();
    } catch (error) {
      console.error("Failed to update task:", error);
    }
  };

  const handleSaveFilter = () => {
    if (newFilterName.trim()) {
      const newFilter = {
        id: Math.random().toString(36).substring(2, 9),
        name: newFilterName.trim(),
        filters: [...columnFilters],
      };
      setCustomSavedFilters((prev) => [...prev, newFilter]);
      setSelectedFilterId(newFilter.id);
      setNewFilterName("");
      setIsSavingFilter(false);
      filtersUserTouchedRef.current = true;
    }
  };

  // Values offered in the Status / Priority / Assignee filter dropdowns, Excel-style: each list only
  // contains values from rows that pass the search, the OTHER column filters and the pivots.
  // The column's own filter is ignored so more values can still be ticked.
  const categoricalCounts = useMemo(() => {
    const counts: Record<string, Record<string, number>> = {
      status: {},
      priority: {},
      assignedUserName: {},
    };

    const keyOf = (t: TaskDto, id: string): string | null => {
      if (id === "status") return TaskStatus[t.status];
      if (id === "priority") return t.priority ? TaskPriority[t.priority] : null;
      return t.assignedUserName || "Unassigned";
    };

    const passesPivots = (t: TaskDto) => {
      for (const [key, values] of pivotFilters) {
        if (!matchesPivot(t, key, values)) return false;
      }
      return true;
    };

    for (const id of Object.keys(counts)) {
      const others = columnFilters.filter((f) => f.id !== id);
      const bucket = counts[id];

      for (const t of tasks) {
        if (!matchesSearch(t)) continue;
        if (priorityFilter && t.priority?.toString() !== priorityFilter) continue;
        if (!others.every((f) => matchesColumnFilter(t, f))) continue;
        if (!passesPivots(t)) continue;
        const k = keyOf(t, id);
        if (k == null) continue;
        bucket[k] = (bucket[k] || 0) + 1;
      }

      // Keep ticked values listed (count 0) so they can still be unticked.
      const own = columnFilters.find((f) => f.id === id);
      if (own && Array.isArray(own.value)) {
        for (const v of own.value) {
          if (!(String(v) in bucket)) bucket[String(v)] = 0;
        }
      }
    }

    return counts;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tasks, debouncedSearch, priorityFilter, columnFilters, pivotFilters]);

  // ── Load saved filters for this process from localStorage ─────────────────
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVED_FILTERS_KEY);
      setCustomSavedFilters(raw ? JSON.parse(raw) || [] : []);
    } catch {
      setCustomSavedFilters([]);
    }
    setSelectedFilterId("all");
    savedFiltersLoadedKeyRef.current = SAVED_FILTERS_KEY;
    filtersUserTouchedRef.current = false;
  }, [SAVED_FILTERS_KEY]);

  // Persist saved filters when the user adds/removes one.
  useEffect(() => {
    if (savedFiltersLoadedKeyRef.current !== SAVED_FILTERS_KEY) return;
    if (!filtersUserTouchedRef.current) return;
    try {
      localStorage.setItem(
        SAVED_FILTERS_KEY,
        JSON.stringify(customSavedFilters),
      );
    } catch {
      /* non-fatal */
    }
  }, [customSavedFilters, SAVED_FILTERS_KEY]);

  const visibleColumns = columns.filter((col) => col.visible);

  // ── Column resizing ──────────────────────────────────────────────────────────
  const DEFAULT_COL_WIDTHS: Record<string, number> = {
    taskId: 100,
    externalRef: 140,
    processName: 160,
    status: 140,
    priority: 110,
    assignedUserName: 150,
    createdDate: 130,
    modifiedDate: 150,
    completedDate: 160,
  };
  const CHECKBOX_COL_WIDTH = 60;
  const ACTIONS_COL_WIDTH = 48;
  const MIN_COL_WIDTH = 60;

  const [columnWidths, setColumnWidths] =
    useState<Record<string, number>>(DEFAULT_COL_WIDTHS);

  const getColWidth = useCallback(
    (key: string): number =>
      columnWidths[key] ?? DEFAULT_COL_WIDTHS[key] ?? 150,
    [columnWidths],
  );

  const resizingRef = useRef<{
    key: string;
    startX: number;
    startWidth: number;
  } | null>(null);

  const startResize = useCallback(
    (key: string, e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      resizingRef.current = {
        key,
        startX: e.clientX,
        startWidth: getColWidth(key),
      };

      const onMouseMove = (ev: MouseEvent) => {
        const current = resizingRef.current;
        if (!current) return;
        const delta = ev.clientX - current.startX;
        const newWidth = Math.max(MIN_COL_WIDTH, current.startWidth + delta);
        setColumnWidths((prev) => ({ ...prev, [current.key]: newWidth }));
      };

      const onMouseUp = () => {
        resizingRef.current = null;
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
        document.body.style.cursor = "";
        document.body.style.userSelect = "";
      };

      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    },
    [getColWidth],
  );
  // ────────────────────────────────────────────────────────────────────────────

  // const uniqueAssignedUsers = useMemo(() => {
  //   const users = new Set<string>();
  //   tasks.forEach((task) => {
  //     if (task.assignedUserName) {
  //       users.add(task.assignedUserName);
  //     }
  //   });
  //   return Array.from(users).sort();
  // }, [tasks]);

  // Compute pivot value counts for all pivot columns (using tasks before pivot filters)
  const pivotValueCountsMap = useMemo(() => {
    const map = new Map<string, Array<{ value: string; count: number }>>();

    pivotColumns.forEach((pivotColKey) => {
      const valueCounts = new Map<string, number>();
      // Cascading: rows that pass the filters and every OTHER pivot.
      const otherPivots = Array.from(pivotFilters.entries()).filter(
        ([key]) => key !== pivotColKey,
      );
      tasksBeforePivotFilters.forEach((task) => {
        if (!otherPivots.every(([key, vals]) => matchesPivot(task, key, vals)))
          return;
        const value = getPivotValue(task, pivotColKey);
        valueCounts.set(value, (valueCounts.get(value) || 0) + 1);
      });
      // Keep ticked values listed (count 0) so they can still be unticked.
      for (const v of pivotFilters.get(pivotColKey) || []) {
        if (!valueCounts.has(v)) valueCounts.set(v, 0);
      }
      const counts = Array.from(valueCounts.entries())
        .map(([value, count]) => ({ value, count }))
        .sort((a, b) => b.count - a.count);
      map.set(pivotColKey, counts);
    });

    return map;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tasksBeforePivotFilters, pivotColumns, pivotFilters]);

  // Get pivot group key for a task

  // Pivot is now just filtering - no grouping needed
  // Removed groupedTasks since pivot works like filters now

  const getColumnLabel = (colKey: string): string => {
    const col = columns.find((c) => c.key === colKey);
    if (col) return col.label;

    if (colKey === "status") return "Status";
    if (colKey === "priority") return "Priority";
    if (colKey === "assignedUserName") return "Assigned";
    // if (colKey === 'externalRef') return 'External Ref';
    if (colKey === "taskId") return "Task ID";
    if (colKey === "createdDate") return "Created Date";
    if (colKey === "modifiedDate") return "Modified Date";
    if (colKey === "completedDate") return "Completed Date";
    if (colKey.startsWith("taskData.")) {
      const fieldName = colKey.replace("taskData.", "");
      const col = columns.find((c) => c.key === colKey);
      return col?.label || fieldName;
    }
    return colKey;
  };

  // const selectedRows = filteredTasks.filter(t => selectedTasks.has(t.taskId));
  const hasSelection = selectedTasks.size > 0;
  const selectedCount = selectedTasks.size;

  return (
    <div className="h-[calc(100vh-4rem)] bg-white px-6 pt-2 pb-6 overflow-x-hidden overflow-y-hidden flex flex-col">
      <div className="w-full flex-1 overflow-hidden flex flex-col gap-2 min-w-0">
        {/* Header */}
        <div className="shrink-0 pt-1 px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 hover:bg-zinc-100 rounded-xl transition-colors text-zinc-400 hover:text-zinc-900"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center">
              <Table2 className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-zinc-900 sm:text-xl">
                Task Details
              </h1>
              <p className="text-sm text-zinc-500 mt-0 font-medium sm:text-xs">
                {process
                  ? `Tasks for ${process.processName}`
                  : "View and manage tasks"}
              </p>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-2xl shadow-sm border border-zinc-100 p-2 shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                ref={searchInputRef}
                type="text"
                placeholder="Search tasks, refs, comments... (Ctrl+F)"
                className="w-full pl-9 pr-10 py-2 text-sm bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-zinc-200 transition-all"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              {search && (
                <button
                  onClick={() => {
                    setSearch("");
                    setDebouncedSearch("");
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  setShowFilters(!showFilters);
                  setShowColumnMenu(false);
                }}
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 text-sm font-medium border rounded-md transition-all",
                  showFilters || columnFilters.length > 0
                    ? "bg-blue-500/10 border-blue-500 text-blue-600"
                    : "bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-50",
                )}
              >
                <FilterIcon className="w-4 h-4" />
                Filters
                {columnFilters.length > 0 && (
                  <span className="flex items-center justify-center w-5 h-5 text-[10px] bg-blue-500 text-white rounded-full ml-1">
                    {columnFilters.length}
                  </span>
                )}
              </button>
              <div className="flex items-center gap-1">
                <select
                  className="px-3 py-1.5 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors outline-none"
                  value={selectedFilterId}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSelectedFilterId(val);
                    if (val === "pending") {
                      setColumnFilters([{ id: "status", value: ["Pending"] }]);
                    } else if (val === "urgent") {
                      setColumnFilters([{ id: "priority", value: ["High"] }]);
                    } else if (val === "cancelled") {
                      setColumnFilters([
                        { id: "status", value: ["Cancelled"] },
                      ]);
                    } else if (val === "all") {
                      setColumnFilters([]);
                    } else {
                      const custom = customSavedFilters.find(
                        (f) => f.id === val,
                      );
                      if (custom) {
                        setColumnFilters(custom.filters);
                      }
                    }
                  }}
                >
                  <option value="all">Saved Filters</option>
                  <optgroup label="System Filters">
                    <option value="pending">My Pending Tasks</option>
                    <option value="urgent">Urgent Priority</option>
                    <option value="completed">Completed Tasks</option>
                    <option value="cancelled">Cancelled Tasks</option>
                  </optgroup>
                  {customSavedFilters.length > 0 && (
                    <optgroup label="My Filters">
                      {customSavedFilters.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name}
                        </option>
                      ))}
                    </optgroup>
                  )}
                </select>
                {customSavedFilters.some((f) => f.id === selectedFilterId) && (
                  <button
                    onClick={() => {
                      setCustomSavedFilters((prev) =>
                        prev.filter((f) => f.id !== selectedFilterId),
                      );
                      filtersUserTouchedRef.current = true;
                      setSelectedFilterId("all");
                      setColumnFilters([]);
                    }}
                    className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-all"
                    title="Delete saved filter"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
            <div className="relative">
              <button
                onClick={() => {
                  setShowColumnMenu(!showColumnMenu);
                  setShowFilters(false);
                }}
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 text-sm font-medium border rounded-md transition-all",
                  showColumnMenu
                    ? "bg-blue-500/10 border-blue-500 text-blue-600"
                    : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50",
                )}
              >
                <Columns className="w-4 h-4" />
                Columns
              </button>

              {/* Column Settings Panel */}
              {showColumnMenu && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowColumnMenu(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 z-50 w-64 bg-white border border-gray-200 rounded-lg shadow-xl p-4">
                    <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-100">
                      <h3 className="text-sm font-semibold text-gray-900">
                        Configure Columns
                      </h3>
                      <button
                        onClick={() => setShowColumnMenu(false)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="space-y-1 max-h-[400px] overflow-y-auto pr-1">
                      {columns.map((col, index) => {
                        const isVisible = col.visible;

                        const moveColumn = (direction: "up" | "down") => {
                          const currentOrder = [...columns];
                          const currentIndex = currentOrder.indexOf(col);
                          const targetIndex =
                            direction === "up"
                              ? currentIndex - 1
                              : currentIndex + 1;

                          if (
                            targetIndex >= 0 &&
                            targetIndex < currentOrder.length
                          ) {
                            [
                              currentOrder[currentIndex],
                              currentOrder[targetIndex],
                            ] = [
                              currentOrder[targetIndex],
                              currentOrder[currentIndex],
                            ];
                            setColumns(currentOrder);
                          }
                        };

                        return (
                          <div
                            key={col.key}
                            className="flex items-center gap-2 p-2 hover:bg-gray-50 rounded-md group"
                          >
                            <div className="flex flex-col gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button
                                disabled={index === 0}
                                onClick={() => moveColumn("up")}
                                className="p-0.5 hover:bg-gray-200 rounded disabled:opacity-30"
                              >
                                <ArrowUp className="w-3 h-3" />
                              </button>
                              <button
                                disabled={index === columns.length - 1}
                                onClick={() => moveColumn("down")}
                                className="p-0.5 hover:bg-gray-200 rounded disabled:opacity-30"
                              >
                                <ArrowDown className="w-3 h-3" />
                              </button>
                            </div>

                            <button
                              onClick={() => toggleColumn(col.key)}
                              className={cn(
                                "flex-1 flex items-center gap-2 text-xs font-medium transition-colors text-left",
                                isVisible ? "text-gray-900" : "text-gray-400",
                              )}
                            >
                              {isVisible ? (
                                <Eye className="w-3.5 h-3.5" />
                              ) : (
                                <EyeOff className="w-3.5 h-3.5" />
                              )}
                              {col.label}
                            </button>

                            <GripVertical className="w-3.5 h-3.5 text-gray-300 cursor-grab active:cursor-grabbing" />
                          </div>
                        );
                      })}
                    </div>

                    <div className="mt-4 pt-3 border-t border-gray-100 flex justify-between">
                      <button
                        onClick={() => {
                          try {
                            localStorage.removeItem(COLUMN_PREFS_KEY);
                          } catch {
                            /* ignore */
                          }
                          // Rebuild columns from process fields at their defaults.
                          colPrefsLoadedKeyRef.current = null;
                          updateColumnsFromProcessFields();
                        }}
                        className="text-[10px] font-bold uppercase text-gray-400 hover:text-blue-600 transition-colors"
                      >
                        Reset Defaults
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={loadTasks}
                disabled={isLoading}
                className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                <RefreshCw
                  className={cn("w-4 h-4", isLoading && "animate-spin")}
                />
                Refresh
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={toggleExport}
                className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
              >
                <FolderUp className="w-4 h-4" />
                Export
              </button>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={removePendingTasks}
                disabled={deleteJobRunning}
                className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-700 bg-orange-50 border border-orange-100 rounded-md hover:bg-orange-100 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {deleteJobRunning ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <FileX className="w-4 h-4" />
                )}
                {deleteJobRunning
                  ? `Removing... ${deleteJob?.percent ?? 0}%`
                  : "Remove Pending Tasks"}
              </button>
            </div>
          </div>
        </div>

        {/* Background delete progress */}
        {deleteJob && (
          <div
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-md border text-sm shrink-0",
              deleteJob.status === "Failed"
                ? "bg-red-50 border-red-200 text-red-700"
                : deleteJob.status === "Completed"
                  ? "bg-green-50 border-green-200 text-green-700"
                  : "bg-orange-50 border-orange-200 text-orange-800",
            )}
          >
            {deleteJobRunning ? (
              <Loader2 className="w-4 h-4 animate-spin shrink-0" />
            ) : deleteJob.status === "Completed" ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <XCircle className="w-4 h-4 shrink-0" />
            )}
            <div className="flex-1 min-w-0">
              <div className="font-medium truncate">
                {deleteJobRunning
                  ? `${deleteJob.mode === "Selected" ? "Deleting selected tasks" : "Removing pending tasks"}: ${deleteJob.deletedCount.toLocaleString()} of ${deleteJob.totalCount.toLocaleString()}`
                  : deleteJob.status === "Completed"
                    ? `Removed ${deleteJob.deletedCount.toLocaleString()} task(s)${deleteJob.skippedCount > 0 ? `, ${deleteJob.skippedCount.toLocaleString()} skipped` : ""}`
                    : `Stopped after ${deleteJob.deletedCount.toLocaleString()} of ${deleteJob.totalCount.toLocaleString()}: ${deleteJob.errorMessage ?? "unknown error"}`}
              </div>
              {deleteJobRunning && (
                <div className="mt-1 h-1.5 bg-orange-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-orange-500 transition-all duration-500"
                    style={{ width: `${deleteJob.percent}%` }}
                  />
                </div>
              )}
            </div>
            {!deleteJobRunning && (
              <button
                onClick={() => setDeleteJob(null)}
                className="p-1 rounded hover:bg-black/5"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {showExportOptions && (
          <div className="mt-0 flex items-center gap-3 p-3 border border-slate-100 rounded-md bg-white transition-all">
            <select
              id="exportType"
              className="pl-4 pr-4 py-2 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors outline-none"
            >
              <option value="csv">Export as CSV</option>
              <option value="excel">Export as Excel</option>
            </select>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">From:</span>
              <DatePicker
                selected={fromDate}
                onChange={setFromDate}
                dateFormat="MM/dd/yyyy"
                className="w-full pl-4 pr-4 py-2 bg-zinc-50 border border-zinc-100 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10"
                placeholderText="Select from date"
              />
              <span className="text-sm text-gray-600">To:</span>
              <DatePicker
                selected={toDate}
                onChange={setToDate}
                dateFormat="MM/dd/yyyy"
                className="w-full pl-4 pr-4 py-2 bg-zinc-50 border border-zinc-100 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10"
                placeholderText="Select to date"
              />
              <span className="text-sm text-gray-600">Status</span>
              <div className=" relative w-40" ref={dropdownRef}>
                {/* Trigger */}
                <div
                  onClick={() => setIsOpen(!isOpen)}
                  className=" flex items-center gap-1.5 px-2 py-2 bg-purple-500/5 border border-purple-500/20 rounded-md text-sm font-medium text-purple-600 cursor-pointer select-none"
                >
                  <span className="truncate">
                    {selectedValues.length > 0
                      ? getSelectedLabels().join(", ")
                      : "Select Status"}
                  </span>
                  <span className="ml-2">▾</span>
                </div>

                {/* Dropdown */}
                {isOpen && (
                  <div className="absolute z-20 mt-1 w-full bg-white border border-gray-100 rounded-md shadow-lg">
                    <div className="max-h-48 overflow-y-auto">
                      {options.map((opt) => (
                        <label
                          key={opt.value}
                          className="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                        >
                          <input
                            type="checkbox"
                            checked={selectedValues.includes(opt.value)}
                            onChange={(e) => {
                              e.stopPropagation();
                              toggleOption(opt.value);
                            }}
                          />
                          {opt.label}
                        </label>
                      ))}
                    </div>

                    {/* Optional footer */}
                    <div className="flex justify-between p-2 border-t border-gray-100 text-sm">
                      <button
                        onClick={() => setSelectedValues([])}
                        className="text-gray-500 hover:underline"
                      >
                        Clear
                      </button>
                      <button
                        onClick={() => setIsOpen(false)}
                        className="text-blue-600 hover:underline"
                      >
                        Done
                      </button>
                    </div>
                  </div>
                )}
              </div>
              <button
                onClick={async () => {
                  // if (selectedTasks.size === 0) {
                  //   alert('Please select at least one task to export.');
                  //   return;
                  // }

                  if (!fromDate || !toDate) {
                    alert("Please select both From and To dates for export.");
                    return;
                  }
                  if (selectedValues.length === 0) {
                    alert("Please select at least one status for export.");
                    return;
                  }

                  const fileType = (
                    document.getElementById("exportType") as HTMLSelectElement
                  ).value;

                  console.log("Exporting with file type:", fileType);
                  const filters = {
                    taskIds: Array.from(selectedTasks),
                    FromDate: fromDate ? fromDate.toISOString() : undefined,
                    ToDate: toDate ? toDate.toISOString() : undefined,
                    status:
                      selectedValues.length > 0 ? selectedValues : undefined,
                  };
                  try {
                    const response = await apiClient.startExport(
                      processId,
                      fileType,
                      filters,
                    );

                    if (response.exportId) {
                      addExport(response.exportId);

                      showToast("Export started successfully!", "success"); // ✅ here
                    } else {
                      showToast("Export failed to start", "error");
                    }

                    console.log("Export started:", response);
                  } catch (error) {
                    console.error("Export error:", error);

                    showToast("Failed to start export", "error"); // ✅ error case
                  }

                  // apiClient.getExportNotification().then(notifications => {
                  //   // console.log('Export notifications:', notifications);
                  // }).catch(error => {
                  //   console.error('Error fetching export notifications:', error);
                  // });
                }}
                className="flex items-center cursor-pointer bg-blue-500 hover:bg-blue-600 gap-2 px-3 py-1.5 text-sm font-medium text-white border border-blue-500 rounded-md hover:bg-blue-50 transition-colors"
              >
                <FolderUp className="w-4 h-4" />
                Export
              </button>
            </div>
          </div>
        )}

        {/* Dynamic Filters Panel */}
        {showFilters && (
          <div className="px-3 pb-3 flex flex-wrap gap-2 border-b border-gray-200 bg-gray-50/50">
            <div className="flex flex-wrap gap-2 items-center">
              {/* Pivot Columns - displayed like filters */}
              {pivotColumns.map((pivotColKey) => {
                const col = columns.find((c) => c.key === pivotColKey);
                const label = col?.label || getColumnLabel(pivotColKey);
                const pivotValueCounts =
                  pivotValueCountsMap.get(pivotColKey) || [];
                const selectedValues = pivotFilters.get(pivotColKey) || [];
                const totalCount = pivotValueCounts.reduce(
                  (sum, item) => sum + item.count,
                  0,
                );
                const allSelected =
                  selectedValues.length === 0 ||
                  (selectedValues.length === pivotValueCounts.length &&
                    pivotValueCounts.length > 0);
                const someSelected =
                  selectedValues.length > 0 &&
                  selectedValues.length < pivotValueCounts.length;

                return (
                  <div
                    key={pivotColKey}
                    className="flex items-center gap-1.5 px-2 py-1 bg-purple-500/5 border border-purple-500/20 rounded-md text-xs font-medium text-purple-600"
                  >
                    <span className="opacity-60">{label}:</span>

                    <div className="relative">
                      <button
                        onClick={() =>
                          setOpenFilterDropdown(
                            openFilterDropdown === `pivot-${pivotColKey}`
                              ? null
                              : `pivot-${pivotColKey}`,
                          )
                        }
                        className="flex items-center gap-1 px-1 py-0.5 text-xs font-bold text-purple-600 hover:bg-purple-500/5 rounded transition-colors outline-none"
                      >
                        <span className="truncate max-w-[150px]">
                          {allSelected
                            ? `All (${totalCount})`
                            : someSelected
                              ? `${selectedValues.length} selected`
                              : `All (${totalCount})`}
                        </span>
                        <ChevronDown
                          className={cn(
                            "w-3 h-3 transition-transform",
                            openFilterDropdown === `pivot-${pivotColKey}` &&
                              "rotate-180",
                          )}
                        />
                      </button>

                      {openFilterDropdown === `pivot-${pivotColKey}` && (
                        <>
                          <div
                            className="fixed inset-0 z-50"
                            onClick={() => setOpenFilterDropdown(null)}
                          />
                          <div className="absolute left-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-md shadow-xl p-1 z-50">
                            <div className="max-h-60 overflow-y-auto">
                              {pivotValueCounts.map((item) => {
                                const { value, count } = item;
                                const isSelected =
                                  selectedValues.includes(value);
                                return (
                                  <button
                                    key={value}
                                    onClick={() => {
                                      const newSelected = isSelected
                                        ? selectedValues.filter(
                                            (v: string) => v !== value,
                                          )
                                        : [...selectedValues, value];
                                      setPivotFilters(
                                        (prev: Map<string, string[]>) => {
                                          const newMap = new Map(prev);
                                          if (newSelected.length === 0) {
                                            newMap.delete(pivotColKey);
                                          } else {
                                            newMap.set(
                                              pivotColKey,
                                              newSelected,
                                            );
                                          }
                                          return newMap;
                                        },
                                      );
                                    }}
                                    className="w-full flex items-center justify-between px-2 py-1.5 text-[11px] hover:bg-gray-50 rounded transition-colors text-left group"
                                  >
                                    <div className="flex items-center gap-2 flex-1 truncate">
                                      <div
                                        className={cn(
                                          "w-3.5 h-3.5 border rounded flex items-center justify-center transition-colors",
                                          isSelected
                                            ? "bg-purple-500 border-purple-500"
                                            : "border-gray-300 group-hover:border-gray-400",
                                        )}
                                      >
                                        {isSelected && (
                                          <X className="w-2.5 h-2.5 text-white" />
                                        )}
                                      </div>
                                      <span
                                        className={cn(
                                          isSelected
                                            ? "text-purple-600 font-bold"
                                            : "text-gray-700",
                                        )}
                                      >
                                        {value}
                                      </span>
                                    </div>
                                    <span className="text-[9px] font-bold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded-full">
                                      {count}
                                    </span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        setPivotColumns((prev: string[]) =>
                          prev.filter((k) => k !== pivotColKey),
                        );
                        setPivotFilters((prev: Map<string, string[]>) => {
                          const newMap = new Map(prev);
                          newMap.delete(pivotColKey);
                          return newMap;
                        });
                        if (pivotColumns.length === 1) {
                          setShowPivot(false);
                        }
                      }}
                      className="hover:bg-purple-500/10 p-0.5 rounded transition-colors ml-1"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}

              {columnFilters.map((filter) => {
                // Get the display label for the filter
                let header = filter.id;
                if (filter.id === "status") header = "Status";
                else if (filter.id === "priority") header = "Priority";
                else if (filter.id === "assignedUserName") header = "Assigned";
                // else if (filter.id === 'externalRef') header = 'External Ref';
                else if (filter.id === "taskId") header = "Task ID";
                else if (filter.id === "createdDate") header = "Created Date";
                else if (filter.id === "modifiedDate") header = "Modified Date";
                else if (filter.id === "completedDate") header = "Completed Date";
                else if (filter.id.startsWith("taskData.")) {
                  // For dynamic columns, get the label from the column config
                  const fieldName = filter.id.replace("taskData.", "");
                  const col = columns.find((c) => c.key === filter.id);
                  header = col?.label || fieldName;
                }

                return (
                  <div
                    key={filter.id}
                    className="flex items-center gap-1.5 px-2 py-1 bg-blue-500/5 border border-blue-500/20 rounded-md text-xs font-medium text-blue-600"
                  >
                    <span className="opacity-60">{header}:</span>

                    {filter.id === "status" ||
                    filter.id === "priority" ||
                    filter.id === "assignedUserName" ? (
                      <div className="relative">
                        <button
                          onClick={() =>
                            setOpenFilterDropdown(
                              openFilterDropdown === filter.id
                                ? null
                                : filter.id,
                            )
                          }
                          className="flex items-center gap-1 px-1 py-0.5 text-xs font-bold text-blue-600 hover:bg-blue-500/5 rounded transition-colors outline-none"
                        >
                          <span className="truncate max-w-[150px]">
                            {Array.isArray(filter.value) &&
                            filter.value.length > 0
                              ? filter.value.join(", ")
                              : filter.value || "Select..."}
                          </span>
                          <ChevronDown
                            className={cn(
                              "w-3 h-3 transition-transform",
                              openFilterDropdown === filter.id && "rotate-180",
                            )}
                          />
                        </button>

                        {openFilterDropdown === filter.id && (
                          <>
                            <div
                              className="fixed inset-0 z-50"
                              onClick={() => setOpenFilterDropdown(null)}
                            />
                            <div className="absolute left-0 top-full mt-1 z-50 min-w-48 w-auto bg-white border border-gray-200 rounded-md shadow-xl p-1">
                              <div className="max-h-60 overflow-y-auto">
                                <input
                                  placeholder="Search..."
                                  value={filterSearch[filter.id] || ""}
                                  onChange={(e) =>
                                    setFilterSearch((prev) => ({
                                      ...prev,
                                      [filter.id]: e.target.value,
                                    }))
                                  }
                                  className="mb-2 h-8 border border-gray-300 rounded-md w-full text-sm px-3 py-2"
                                />
                                {/* <button
                                variant="ghost"
                                size="sm"
                                className=""
                                >
                                  {filterSort[filter.id] === 'desc' ? "Z - A" : "A - Z"}
                                </button> */}
                                {(() => {
                                  const counts =
                                    categoricalCounts[filter.id] || {};
                                  const search = (
                                    filterSearch[filter.id] || ""
                                  ).toLowerCase();

                                  return Object.entries(counts)
                                    .filter(([val]) =>
                                      val.toLowerCase().includes(search),
                                    )
                                    .sort(([a], [b]) => {
                                      const order =
                                        filterSort[filter.id] || "asc";
                                      return order === "asc"
                                        ? a.localeCompare(b)
                                        : b.localeCompare(a);
                                    })
                                    .map(([val, count]) => {
                                      const isSelected = Array.isArray(
                                        filter.value,
                                      )
                                        ? filter.value.includes(val)
                                        : filter.value === val;
                                      return (
                                        <button
                                          key={val}
                                          onClick={() => {
                                            const currentValues = Array.isArray(
                                              filter.value,
                                            )
                                              ? filter.value
                                              : [];
                                            const nextValues = isSelected
                                              ? currentValues.filter(
                                                  (v) => v !== val,
                                                )
                                              : [...currentValues, val];
                                            setColumnFilters((prev) => {
                                              const others = prev.filter(
                                                (f) => f.id !== filter.id,
                                              );
                                              if (nextValues.length === 0) {
                                                return others;
                                              }
                                              return [
                                                ...others,
                                                {
                                                  id: filter.id,
                                                  value: nextValues,
                                                },
                                              ];
                                            });
                                          }}
                                          // onClick={() => {
                                          //   if (filter.id === 'status' || filter.id === 'priority') {
                                          //     const currentValues = Array.isArray(filter.value) ? filter.value : [];
                                          //     const nextValues = isSelected
                                          //       ? currentValues.filter(v => v !== val)
                                          //       : [...currentValues, val];
                                          //       setColumnFilters(prev => {
                                          //         const others = prev.filter(f => f.id !== filter.id);
                                          //         if(nextValues.length === 0){
                                          //           return others;
                                          //         }
                                          //         return [
                                          //           ...others,
                                          //           {
                                          //             id:filter.id,
                                          //             value:nextValues,
                                          //           }
                                          //         ]
                                          //       })
                                          //     setColumnFilters(prev => prev.map(f =>
                                          //       f.id === filter.id
                                          //         ? { ...f, value: nextValues.length ? nextValues : undefined }
                                          //         : f
                                          //     ).filter(f => f.value !== undefined));
                                          //   } else {
                                          //     setColumnFilters(prev => prev.map(f =>
                                          //       f.id === filter.id
                                          //         ? { ...f, value: isSelected ? undefined : val }
                                          //         : f
                                          //     ).filter(f => f.value !== undefined));
                                          //   }
                                          // }}
                                          className="w-full flex items-center justify-between px-2 py-1.5 text-[11px] hover:bg-gray-50 rounded transition-colors text-left group"
                                        >
                                          <div className="flex items-center gap-2 flex-1 truncate">
                                            <div
                                              className={cn(
                                                "w-3.5 h-3.5 border rounded flex flex-none items-center justify-center transition-colors",
                                                isSelected
                                                  ? "bg-blue-500 border-blue-500"
                                                  : "border-gray-300 group-hover:border-gray-400",
                                              )}
                                            >
                                              {isSelected && (
                                                <X className="w-2.5 h-2.5 text-white" />
                                              )}
                                            </div>
                                            <span
                                              className={cn(
                                                isSelected
                                                  ? "text-blue-600 font-bold"
                                                  : "text-gray-700",
                                              )}
                                            >
                                              {val}
                                            </span>
                                          </div>
                                          <span className="text-[9px] font-bold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded-full">
                                            {count}
                                          </span>
                                        </button>
                                      );
                                    });
                                })()}
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    ) : (
                      <input
                        type="text"
                        className="bg-transparent border-none p-0 text-xs font-bold outline-none min-w-[100px]"
                        placeholder="Enter value..."
                        value={(filter.value as string) ?? ""}
                        onChange={(e) =>
                          setColumnFilters((prev) =>
                            prev.map((f) =>
                              f.id === filter.id
                                ? { ...f, value: e.target.value }
                                : f,
                            ),
                          )
                        }
                        onBlur={() => {
                          // Remove filter if value is empty
                          if (
                            !filter.value ||
                            (typeof filter.value === "string" &&
                              filter.value.trim() === "")
                          ) {
                            setColumnFilters((prev) =>
                              prev.filter((f) => f.id !== filter.id),
                            );
                          }
                        }}
                        autoFocus
                      />
                    )}

                    <button
                      onClick={() =>
                        setColumnFilters((prev) =>
                          prev.filter((f) => f.id !== filter.id),
                        )
                      }
                      className="hover:bg-blue-500/10 p-0.5 rounded transition-colors ml-1"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}

              <div className="flex items-center gap-2">
                <select
                  className="px-2 py-1 text-xs border border-gray-300 rounded bg-white outline-none focus:ring-1 focus:ring-blue-500"
                  onChange={(e) => {
                    const columnId = e.target.value;
                    if (columnId) {
                      if (
                        columnFilters.some((f) => f.id === columnId) ||
                        pivotColumns.includes(columnId)
                      ) {
                        e.target.value = "";
                        return;
                      }

                      let defaultValue: any = "";
                      if (columnId === "status") defaultValue = ["Pending"];
                      if (columnId === "priority") defaultValue = ["Medium"];

                      setColumnFilters((prev) => [
                        ...prev,
                        { id: columnId, value: defaultValue },
                      ]);
                      e.target.value = "";
                    }
                  }}
                >
                  <option value="">+ Add Filter</option>
                  <optgroup label="Standard Fields">
                    <option value="status">Status</option>
                    <option value="priority">Priority</option>
                    <option value="assignedUserName">Assignee</option>
                    {/* <option value="externalRef">External Ref</option> */}
                    <option value="taskId">Task ID</option>
                    <option value="createdDate">Created Date</option>
                    <option value="modifiedDate">Modified Date</option>
                    <option value="completedDate">Completed Date</option>
                  </optgroup>
                  {visibleColumns.filter((col) => col.isDynamic).length > 0 && (
                    <optgroup label="Process Fields">
                      {visibleColumns
                        .filter((col) => col.isDynamic)
                        .map((col) => (
                          <option key={col.key} value={col.key}>
                            {col.label}
                          </option>
                        ))}
                    </optgroup>
                  )}
                </select>
                <select
                  className="px-2 py-1 text-xs border border-purple-300 rounded bg-white outline-none focus:ring-1 focus:ring-purple-500"
                  onChange={(e) => {
                    const columnId = e.target.value;
                    if (columnId) {
                      if (
                        pivotColumns.includes(columnId) ||
                        columnFilters.some((f) => f.id === columnId)
                      ) {
                        e.target.value = "";
                        return;
                      }

                      setPivotColumns((prev: string[]) => [...prev, columnId]);
                      setShowPivot(true);
                      // Initialize with all values selected (empty array means show all)
                      setPivotFilters((prev: Map<string, string[]>) => {
                        const newMap = new Map(prev);
                        newMap.set(columnId, []);
                        return newMap;
                      });
                      e.target.value = "";
                    }
                  }}
                >
                  <option value="">+ Add Pivot</option>
                  <optgroup label="Standard Fields">
                    <option value="status">Status</option>
                    <option value="priority">Priority</option>
                    <option value="assignedUserName">Assignee</option>
                    {/* <option value="externalRef">External Ref</option> */}
                    <option value="createdDate">Created Date</option>
                    <option value="modifiedDate">Modified Date</option>
                    <option value="completedDate">Completed Date</option>
                  </optgroup>
                  {visibleColumns.filter((col) => col.isDynamic).length > 0 && (
                    <optgroup label="Process Fields">
                      {visibleColumns
                        .filter((col) => col.isDynamic)
                        .map((col) => (
                          <option key={col.key} value={col.key}>
                            {col.label}
                          </option>
                        ))}
                    </optgroup>
                  )}
                </select>

                {(columnFilters.length > 0 || pivotColumns.length > 0) && (
                  <button
                    onClick={() => {
                      setColumnFilters([]);
                      setPivotColumns([]);
                      setPivotFilters(new Map<string, string[]>());
                      setShowPivot(false);
                    }}
                    className="text-xs text-gray-500 hover:text-red-600 font-medium transition-colors"
                  >
                    Clear All
                  </button>
                )}
              </div>
            </div>

            {columnFilters.length > 0 && (
              <div className="flex items-center gap-2">
                {isSavingFilter ? (
                  <div className="flex items-center gap-2">
                    <input
                      autoFocus
                      type="text"
                      placeholder="Filter name..."
                      className="px-2 py-1 text-xs border border-gray-300 rounded outline-none focus:border-blue-500"
                      value={newFilterName}
                      onChange={(e) => setNewFilterName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          handleSaveFilter();
                        } else if (e.key === "Escape") {
                          setIsSavingFilter(false);
                        }
                      }}
                    />
                    <button
                      onClick={handleSaveFilter}
                      className="p-1 text-blue-600 hover:bg-blue-500/10 rounded"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setIsSavingFilter(false)}
                      className="p-1 text-gray-400 hover:bg-gray-100 rounded"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsSavingFilter(true)}
                    className="flex items-center gap-1.5 px-2 py-1 text-xs font-bold text-blue-600 hover:bg-blue-500/10 rounded transition-all"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    Save Current Filter
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* Bulk Actions Bar */}
        {hasSelection && (
          <div className="flex items-center justify-between px-4 py-2 bg-blue-500/10 border-y border-blue-500/20 flex-shrink-0">
            <div className="flex items-center gap-4">
              <span className="text-sm font-semibold text-blue-600">
                {selectedCount} task{selectedCount !== 1 ? "s" : ""} selected
                {selectAllMode === "all" && selectedCount < total && (
                  <span className="text-gray-500 ml-1 font-normal">
                    (of {total} total)
                  </span>
                )}
              </span>
              <div className="h-4 w-px bg-blue-500/20" />
              <div className="flex items-center gap-2">
                {/* Status Update Dropdown */}
                <div className="relative">
                  <button
                    onClick={() =>
                      setOpenFilterDropdown(
                        openFilterDropdown === "bulkStatus"
                          ? null
                          : "bulkStatus",
                      )
                    }
                    className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded transition-colors hover:bg-gray-50"
                  >
                    <span>Update Status</span>
                    <ChevronDown
                      className={cn(
                        "w-3 h-3 transition-transform",
                        openFilterDropdown === "bulkStatus" && "rotate-180",
                      )}
                    />
                  </button>

                  {openFilterDropdown === "bulkStatus" && (
                    <>
                      <div
                        className="fixed inset-0 z-[60]"
                        onClick={() => setOpenFilterDropdown(null)}
                      />
                      <div className="absolute left-0 top-full mt-1 z-[70] w-48 bg-white border border-gray-200 rounded-md shadow-xl overflow-hidden">
                        {Object.values(TaskStatus)
                          .filter((val) => typeof val === "number")
                          .map((status) => {
                            const statusEnum = status as TaskStatus;
                            const statusConfig = getStatusConfig(statusEnum);
                            const statusLabel = getStatusLabel(statusEnum);
                            return (
                              <button
                                key={statusEnum}
                                onClick={() => {
                                  handleBulkUpdate({ status: statusEnum });
                                  setOpenFilterDropdown(null);
                                }}
                                className="w-full flex items-center gap-2 px-3 py-2 text-xs text-left hover:bg-gray-50 transition-colors"
                              >
                                {statusConfig.icon}
                                <span
                                  className={statusConfig.color.split(" ")[0]}
                                >
                                  {statusLabel}
                                </span>
                              </button>
                            );
                          })}
                      </div>
                    </>
                  )}
                </div>

                <button
                  onClick={openAssignModal}
                  className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-blue-600 hover:bg-blue-500/20 rounded transition-colors"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  Assign
                </button>
                <button
                  onClick={() => setSelectedTasks(new Set())}
                  className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-red-600 hover:bg-red-500/20 rounded transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                  Cancel
                </button>

                {/* <button
  onClick={handleDeleteSelectedTasks}
  className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-red-600 hover:bg-red-500/20 rounded transition-colors"
>
  <Trash2 className="w-3.5 h-3.5" />
  Delete
</button> */}
              </div>
            </div>

            <div className="mt-0 flex items-center gap-3 p-3 border border-slate-100 rounded-md transition-all">
              <button
                onClick={() => setSelectedTasks(new Set())}
                className="text-xs font-medium text-blue-600 hover:text-blue-600/80"
              >
                Clear selection
              </button>

              {/* Delete Table Row Button on selected tasks */}
              <button
                onClick={handleDeleteSelectedTasks}
                disabled={deleteJobRunning}
                className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-red-600 hover:bg-red-500/20 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete Selected Task
              </button>
            </div>
          </div>
        )}

        {/* Read-only fx bar — shows the full value of the last-clicked cell.
            This admin console is view-only, so it's always disabled. */}

        <div className="flex items-stretch border border-gray-200 rounded-md bg-gray-50/70 overflow-hidden flex-shrink-0">
          <div className="flex items-center px-3 text-[11px] font-semibold uppercase tracking-wide text-gray-400 border-r border-gray-200 select-none min-w-[64px] max-w-[160px] justify-center text-center">
            <span className="truncate">{fxLabel || "fx"}</span>
          </div>
          <textarea
            readOnly
            value={fxValue}
            placeholder="Click a cell to view its full value"
            rows={1}
            ref={(el) => {
              if (el) {
                el.style.height = "auto";
                el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
              }
            }}
            className="flex-1 resize-y px-3 py-1.5 text-sm bg-gray-50 text-gray-600 outline-none cursor-default leading-snug overflow-y-auto"
            style={{ minHeight: "34px", maxHeight: "200px" }}
          />
        </div>

        {/* Table Body */}
        <div className="flex-1 overflow-x-auto overflow-y-auto relative outline-none">
          <div className="inline-block align-middle w-full">
            {/* Header */}
            <div className="sticky top-0 z-10 bg-white border-b border-gray-200 shadow-sm flex min-w-max">
              <div
                className="px-4 py-2.5 text-[11px] font-semibold text-gray-500 uppercase tracking-wider select-none flex items-center border-r border-gray-100 shrink-0 sticky left-0 bg-white z-20"
                style={{ width: CHECKBOX_COL_WIDTH }}
              >
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      toggleSelectAll(selectAllMode).catch((err) => {
                        console.error("Error toggling select all:", err);
                      });
                    }}
                    className="p-1"
                    title={
                      selectAllMode === "all"
                        ? "Select all tasks in table"
                        : "Select visible tasks"
                    }
                  >
                    {isAllSelected() ? (
                      <CheckSquare className="w-4 h-4 text-blue-600" />
                    ) : isPartiallySelected() ? (
                      <div className="w-4 h-4 border-2 border-blue-600 bg-blue-50 rounded flex items-center justify-center">
                        <div className="w-2 h-2 bg-blue-600 rounded" />
                      </div>
                    ) : (
                      <Square className="w-4 h-4 text-gray-300" />
                    )}
                  </button>
                  <div className="relative group">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setOpenFilterDropdown(
                          openFilterDropdown === "selectAllMode"
                            ? null
                            : "selectAllMode",
                        );
                      }}
                      className="p-0.5 hover:bg-gray-100 rounded transition-colors"
                      title="Select mode options"
                    >
                      <ChevronDown
                        className={cn(
                          "w-3 h-3 text-gray-400 transition-transform",
                          openFilterDropdown === "selectAllMode" &&
                            "rotate-180",
                        )}
                      />
                    </button>
                    {openFilterDropdown === "selectAllMode" && (
                      <>
                        <div
                          className="fixed inset-0 z-50"
                          onClick={() => setOpenFilterDropdown(null)}
                        />
                        <div className="absolute left-0 top-full mt-1 z-50 min-w-48 w-auto bg-white border border-gray-200 rounded-md shadow-xl p-1">
                          <button
                            onClick={() => {
                              setSelectAllMode("visible");
                              const visibleIds = paginatedTasks.map(
                                (t) => t.taskId,
                              );
                              setSelectedTasks((prev) => {
                                const next = new Set(prev);
                                visibleIds.forEach((id) => next.add(id));
                                return next;
                              });
                              setOpenFilterDropdown(null);
                            }}
                            className={cn(
                              "w-full text-left px-2 py-1.5 text-xs rounded transition-colors",
                              selectAllMode === "visible"
                                ? "bg-blue-50 text-blue-600 font-medium"
                                : "text-gray-700 hover:bg-gray-50",
                            )}
                          >
                            <div className="flex items-center gap-2">
                              {selectAllMode === "visible" && (
                                <CheckSquare className="w-3 h-3" />
                              )}
                              <span>
                                Select Visible ({paginatedTasks.length})
                              </span>
                            </div>
                          </button>
                          <button
                            onClick={() => {
                              setSelectAllMode("all");
                              setOpenFilterDropdown(null);
                              setSelectedTasks(
                                new Set(filteredTasks.map((t) => t.taskId)),
                              );
                            }}
                            className={cn(
                              "w-full text-left px-2 py-1.5 text-xs rounded transition-colors",
                              selectAllMode === "all"
                                ? "bg-blue-50 text-blue-600 font-medium"
                                : "text-gray-700 hover:bg-gray-50",
                            )}
                          >
                            <div className="flex items-center gap-2">
                              {selectAllMode === "all" && (
                                <CheckSquare className="w-3 h-3" />
                              )}
                              <span>Select All ({total})</span>
                            </div>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
              {visibleColumns.map((col) => (
                <div
                  key={col.key}
                  className="px-4 py-2.5 text-[11px] font-semibold text-gray-500 uppercase tracking-wider select-none flex items-center relative group/header border-r border-gray-100 last:border-r-0 flex-shrink-0"
                  style={{ width: getColWidth(col.key) }}
                >
                  <div
                    className={cn(
                      "flex items-center gap-1 flex-1 min-w-0",
                      col.sortable && "cursor-pointer hover:text-gray-700",
                    )}
                    onClick={() => col.sortable && handleSort(col.key)}
                  >
                    <span className="truncate">{col.label}</span>
                    {col.sortable &&
                      sortColumn === col.key &&
                      (sortDirection === "asc" ? (
                        <ChevronUp className="w-3 h-3 flex-shrink-0" />
                      ) : (
                        <ChevronDown className="w-3 h-3 flex-shrink-0" />
                      ))}
                  </div>
                  {/* Resize handle — drag to resize, double-click to reset to default */}
                  <div
                    onMouseDown={(e) => startResize(col.key, e)}
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      setColumnWidths((prev) => {
                        const next = { ...prev };
                        delete next[col.key]; // removes override → falls back to DEFAULT_COL_WIDTHS
                        return next;
                      });
                    }}
                    className="absolute right-0 top-0 h-full w-1.5 cursor-col-resize z-20 opacity-0 group-hover/header:opacity-100 bg-gray-300 hover:bg-blue-500 transition-colors"
                    title="Drag to resize · Double-click to reset"
                  />
                </div>
              ))}
              <div
                className="px-4 py-2.5 border-r border-gray-100 last:border-r-0 flex-shrink-0"
                style={{ width: ACTIONS_COL_WIDTH }}
              ></div>
            </div>

            {/* Body */}
            <div className="min-w-max ">
              {isLoading ? (
                <div className="flex items-center justify-center py-20">
                  <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                </div>
              ) : error ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <p className="text-sm font-medium text-red-600 mb-2">
                    Error loading tasks
                  </p>
                  <p className="text-xs text-gray-500 mb-4">{error}</p>
                  <button
                    onClick={loadTasks}
                    className="px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100 transition-colors"
                  >
                    Retry
                  </button>
                </div>
              ) : filteredTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                  <Search className="w-12 h-12 mb-4 opacity-20" />
                  <p className="text-sm">
                    No tasks found matching your criteria
                  </p>
                </div>
              ) : (
                paginatedTasks.map((task) => {
                  const isSelected = selectedTasks.has(task.taskId);
                  const statusConfig = getStatusConfig(task.status);

                  return (
                    <div
                      key={task.taskId}
                      className={cn(
                        "group transition-colors flex items-center border-b border-gray-100 min-w-max ",
                        isSelected ? "bg-blue-500/5" : "hover:bg-gray-50/80",
                      )}
                    >
                      <div
                        className="px-4 py-2.5 h-full flex items-center border-r border-gray-50 flex-shrink-0 sticky left-0 bg-white z-10 sm:py-2 sm:px-2"
                        style={{ width: CHECKBOX_COL_WIDTH }}
                      >
                        <button
                          onClick={() => toggleSelectTask(task.taskId)}
                          className="p-1"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-blue-600" />
                          ) : (
                            <Square className="w-4 h-4 text-gray-300" />
                          )}
                        </button>
                      </div>
                      {visibleColumns.map((col) => {
                        switch (col.key) {
                          case "taskId":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:taxt-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                <span className="font-mono text-xs text-gray-500 truncate pl-4">
                                  {task.taskId}
                                </span>
                              </div>
                            );
                          case "externalRef":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:taxt-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                <span className="font-medium truncate">
                                  {task.externalRef}
                                </span>
                              </div>
                            );
                          case "processName":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:taxt-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                <span className="truncate">
                                  {task.processName}
                                </span>
                              </div>
                            );
                          case "status":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:taxt-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                <select
                                  value={task.status}
                                  onChange={(e) =>
                                    handleTaskUpdate(task.taskId, {
                                      status: parseInt(
                                        e.target.value,
                                      ) as TaskStatus,
                                    })
                                  }
                                  className={cn(
                                    "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium border hover:opacity-80 transition-opacity cursor-pointer outline-none",
                                    statusConfig.color,
                                  )}
                                >
                                  {Object.keys(TaskStatus)
                                    .filter((key) => isNaN(Number(key)))
                                    .map((status) => (
                                      <option
                                        key={status}
                                        value={
                                          TaskStatus[
                                            status as keyof typeof TaskStatus
                                          ]
                                        }
                                      >
                                        {status}
                                      </option>
                                    ))}
                                </select>
                              </div>
                            );
                          case "priority":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:text-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 flex-shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                {task.priority ? (
                                  <select
                                    value={task.priority}
                                    onChange={(e) =>
                                      handleTaskUpdate(task.taskId, {
                                        priority: parseInt(
                                          e.target.value,
                                        ) as TaskPriority,
                                      })
                                    }
                                    className={cn(
                                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase border cursor-pointer outline-none",
                                      getPriorityColor(task.priority),
                                    )}
                                  >
                                    {Object.keys(TaskPriority)
                                      .filter((key) => isNaN(Number(key)))
                                      .map((priority) => (
                                        <option
                                          key={priority}
                                          value={
                                            TaskPriority[
                                              priority as keyof typeof TaskPriority
                                            ]
                                          }
                                        >
                                          {priority}
                                        </option>
                                      ))}
                                  </select>
                                ) : (
                                  <span className="text-gray-300 italic">
                                    Not Set
                                  </span>
                                )}
                              </div>
                            );
                          case "assignedUserName":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:text-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 flex-shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                <span className="truncate text-gray-600">
                                  {task.assignedUserName || (
                                    <span className="text-gray-300 italic">
                                      Unassigned
                                    </span>
                                  )}
                                </span>
                              </div>
                            );
                          case "createdDate":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:text-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 flex-shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                <span className="text-gray-400 text-[11px]">
                                  {formatDate(task.createdDate)}
                                </span>
                              </div>
                            );
                          case "modifiedDate":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:text-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 flex-shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                <span className="text-gray-400 text-[11px]">
                                  {formatDateTime(task.modifiedDate)}
                                </span>
                              </div>
                            );
                          case "completedDate":
                            return (
                              <div
                                key={col.key}
                                className="px-4 py-2.5 text-sm sm:text-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 flex-shrink-0"
                                style={{ width: getColWidth(col.key) }}
                              >
                                {task.completedDate ? (
                                  <span className="text-gray-400 text-[11px]">
                                    {formatDateTime(task.completedDate)}
                                  </span>
                                ) : (
                                  <span className="text-gray-300 italic text-[11px]">
                                    —
                                  </span>
                                )}
                              </div>
                            );
                          default:
                            // Handle dynamic columns (taskData fields)
                            if (
                              col.isDynamic &&
                              col.key.startsWith("taskData.")
                            ) {
                              const fieldName = col.key.replace(
                                "taskData.",
                                "",
                              );
                              const value = task.taskData?.[fieldName];

                              // Format based on field type
                              let displayValue: React.ReactNode = value ?? (
                                <span className="text-gray-300 italic">—</span>
                              );

                              if (value !== null && value !== undefined) {
                                if (
                                  col.fieldType === "Date" ||
                                  col.fieldType === "DateTime"
                                ) {
                                  try {
                                    const dateValue =
                                      typeof value === "string"
                                        ? new Date(value)
                                        : value;
                                    if (
                                      dateValue instanceof Date &&
                                      !isNaN(dateValue.getTime())
                                    ) {
                                      displayValue =
                                        col.fieldType === "DateTime"
                                          ? formatDateTime(
                                              dateValue.toISOString(),
                                            )
                                          : formatDate(dateValue.toISOString());
                                    }
                                  } catch {
                                    displayValue = String(value);
                                  }
                                } else if (
                                  col.fieldType === "Number" ||
                                  col.fieldType === "Decimal"
                                ) {
                                  const numValue =
                                    typeof value === "number"
                                      ? value
                                      : parseFloat(String(value));
                                  displayValue = !isNaN(numValue)
                                    ? numValue.toLocaleString()
                                    : String(value);
                                } else if (col.fieldType === "Boolean") {
                                  displayValue = value ? (
                                    <span className="text-green-600 font-medium">
                                      Yes
                                    </span>
                                  ) : (
                                    <span className="text-gray-400">No</span>
                                  );
                                } else {
                                  displayValue = String(value);
                                }
                              }

                              return (
                                <div
                                  key={col.key}
                                  onClick={() => {
                                    setFxLabel(col.label);
                                    setFxValue(
                                      value == null ? "" : String(value),
                                    );
                                  }}
                                  className="px-4 py-2.5 text-sm sm:text-xs text-gray-700 truncate h-full flex items-center transition-all border-r border-gray-50 shrink-0 cursor-pointer sm:py-2 sm:px-2"
                                  style={{ width: getColWidth(col.key) }}
                                >
                                  <span className="truncate">
                                    {displayValue}
                                  </span>
                                </div>
                              );
                            }
                            return null;
                        }
                      })}
                      <div
                        className="px-4 py-2.5 border-r border-gray-50 last:border-r-0 flex-shrink-0"
                        style={{ width: ACTIONS_COL_WIDTH }}
                      ></div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Status Footer */}
        <div className="flex items-center justify-between px-4 py-2 bg-white border-t border-gray-200 text-[11px] text-gray-500">
          <div className="flex items-center gap-4">
            <span>
              Showing{" "}
              <span className="font-semibold text-gray-900">
                {filteredTasks.length === 0 ? 0 : startIndex + 1}
              </span>
              –
              <span className="font-semibold text-gray-900">
                {Math.min(startIndex + pageSize, filteredTasks.length)}
              </span>{" "}
              of{" "}
              <span className="font-semibold text-gray-900">
                {filteredTasks.length}
              </span>
              {filteredTasks.length !== total && (
                <>
                  {" "}
                  (filtered from{" "}
                  <span className="font-semibold text-gray-900">{total}</span>)
                </>
              )}
            </span>
            <select
              className="px-3 py-1.5 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors outline-none"
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            {columnFilters.length > 0 && (
              <span className="flex items-center gap-1 text-blue-600 font-medium">
                <FilterIcon className="w-3 h-3" />
                {columnFilters.length} filters active
              </span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <button
              disabled={page === 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-30"
            >
              <ChevronLeft className="w-4 h-4" />
              Prev
            </button>
            <div className="flex items-center gap-2">
              {(() => {
                // Windowed page numbers: show up to 5 around the current page.
                const windowSize = 5;
                let start = Math.max(1, page - Math.floor(windowSize / 2));
                let end = Math.min(totalPages, start + windowSize - 1);
                start = Math.max(1, Math.min(start, end - windowSize + 1));
                const pageNums: number[] = [];
                for (let i = start; i <= end; i++) pageNums.push(i);
                return pageNums.map((pn) => (
                  <button
                    key={pn}
                    onClick={() => setPage(pn)}
                    className={cn(
                      "w-8 h-8 rounded-md font-medium text-xs transition-all",
                      page === pn
                        ? "bg-blue-500 text-white"
                        : "text-gray-700 hover:bg-gray-100 border border-gray-300",
                    )}
                  >
                    {pn}
                  </button>
                ));
              })()}
            </div>
            <button
              disabled={page >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-30"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Assign User Modal */}
        {showAssignModal && (
          <>
            <div
              className="fixed inset-0 bg-black/50 z-[100]"
              onClick={() => setShowAssignModal(false)}
            />
            <div className="fixed inset-0 z-[101] flex items-center justify-center p-4">
              <div
                className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[80vh] flex flex-col"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Modal Header */}
                <div className="flex items-center justify-between p-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">
                    Assign Tasks to User
                  </h3>
                  <button
                    onClick={() => setShowAssignModal(false)}
                    className="p-1 hover:bg-gray-100 rounded-md transition-colors text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Modal Body */}
                <div className="flex-1 overflow-y-auto p-4">
                  <p className="text-sm text-gray-600 mb-4">
                    Select a user to assign{" "}
                    <span className="font-semibold">{selectedCount}</span>{" "}
                    selected task{selectedCount !== 1 ? "s" : ""} to:
                  </p>

                  {loadingUsers ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
                    </div>
                  ) : assignedUsers.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>No users found</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {assignedUsers.map((user) => (
                        <button
                          key={user.userId}
                          onClick={() => setSelectedUserId(user.userId)}
                          className={cn(
                            "w-full text-left p-3 rounded-lg border-2 transition-all",
                            selectedUserId === user.userId
                              ? "border-blue-500 bg-blue-50"
                              : "border-gray-200 hover:border-gray-300 hover:bg-gray-50",
                          )}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-gray-900">
                                  {user.username}
                                </span>
                                {/* {user.status === 'Online' && (
                                  <span className="w-2 h-2 bg-green-500 rounded-full" title="Online" />
                                )}
                                {user.status === 'Idle' && (
                                  <span className="w-2 h-2 bg-yellow-500 rounded-full" title="Idle" />
                                )}
                                {user.status === 'Offline' && (
                                  <span className="w-2 h-2 bg-gray-400 rounded-full" title="Offline" />
                                )} */}
                              </div>
                              {/* <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                                <span>
                                  <span className="font-medium">{user.activeTasks}</span> active task{user.activeTasks !== 1 ? 's' : ''}
                                </span>
                                {user.tasksCompletedToday > 0 && (
                                  <span>
                                    <span className="font-medium">{user.tasksCompletedToday}</span> completed today
                                  </span>
                                )}
                              </div> */}
                            </div>
                            {selectedUserId === user.userId && (
                              <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Modal Footer */}
                <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200">
                  <button
                    onClick={() => setShowAssignModal(false)}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (selectedUserId) {
                        handleBulkAssign(selectedUserId);
                      }
                    }}
                    disabled={!selectedUserId || isLoading}
                    className={cn(
                      "px-4 py-2 text-sm font-medium text-white rounded-md transition-colors",
                      selectedUserId && !isLoading
                        ? "bg-blue-600 hover:bg-blue-700"
                        : "bg-gray-300 cursor-not-allowed",
                    )}
                  >
                    {isLoading ? (
                      <span className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Assigning...
                      </span>
                    ) : (
                      "Assign Tasks"
                    )}
                  </button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
