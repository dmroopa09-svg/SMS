import { apiClient } from "./client";

// ---------------------------------------------------------------------------
// Same adapter as clarifications.ts - change here only if apiClient's method names differ.
// ---------------------------------------------------------------------------
const http = {
  get: <T>(url: string) => apiClient.get<T>(url) as Promise<T>,
  post: <T>(url: string, body?: unknown) => apiClient.post<T>(url, body) as Promise<T>,
};

/** apiClient's base URL already ends in /api. */
const BASE = "/task-delete-jobs";

export type TaskDeleteJobStatus = "Queued" | "Running" | "Completed" | "Failed";

export interface TaskDeleteJob {
  jobId: number;
  processId: number;
  mode: "AllPending" | "Selected";
  status: TaskDeleteJobStatus;
  requestedByUserId: number;
  totalCount: number;
  processedCount: number;
  deletedCount: number;
  /** Selected mode: tasks no longer deletable (already completed / already gone). */
  skippedCount: number;
  errorMessage: string | null;
  createdDate: string;
  startedDate: string | null;
  completedDate: string | null;
  isSeen: boolean;
  isFinished: boolean;
  percent: number;
}

export interface StartTaskDeleteJobResponse {
  /** 0 = nothing to delete. */
  jobId: number;
  totalCount: number;
  alreadyRunning: boolean;
}

export const isJobFinished = (job: TaskDeleteJob | null | undefined) =>
  !!job && (job.status === "Completed" || job.status === "Failed");

export const taskDeleteJobs = {
  startAllPending: (processId: number) =>
    http.post<StartTaskDeleteJobResponse>(`${BASE}/pending/${processId}`),

  startSelected: (processId: number, taskIds: number[]) =>
    http.post<StartTaskDeleteJobResponse>(`${BASE}/selected`, { processId, taskIds }),

  get: (jobId: number) => http.get<TaskDeleteJob>(`${BASE}/${jobId}`),

  active: (processId: number) =>
    http.get<TaskDeleteJob[]>(`${BASE}/active?processId=${processId}`),

  markSeen: (jobId: number) => http.post<void>(`${BASE}/${jobId}/seen`),
};
