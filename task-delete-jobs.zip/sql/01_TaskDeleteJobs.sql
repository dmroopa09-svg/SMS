/*
  TaskDeleteJobs - background removal of tasks (Remove Pending Tasks / Delete Selected).

  The API only inserts a row here and returns the JobId. A background worker deletes in chunks of
  1,000 tasks, each chunk in its own short transaction, and records progress after every chunk.
  If anything fails or the app pool recycles, finished chunks stay done and the job resumes/reruns
  from where it stopped.
*/
IF OBJECT_ID('dbo.TaskDeleteJobs', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.TaskDeleteJobs
    (
        JobId             BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_TaskDeleteJobs PRIMARY KEY,
        ProcessId         INT            NOT NULL,
        Mode              VARCHAR(20)    NOT NULL,              -- 'AllPending' | 'Selected'
        TaskIdsJson       NVARCHAR(MAX)  NULL,                  -- Selected mode only: [123,456,...]
        RequestedByUserId INT            NOT NULL,
        Status            VARCHAR(20)    NOT NULL CONSTRAINT DF_TaskDeleteJobs_Status DEFAULT ('Queued'),
                                                                -- Queued | Running | Completed | Failed
        TotalCount        INT            NOT NULL CONSTRAINT DF_TaskDeleteJobs_Total DEFAULT (0),
        ProcessedCount    INT            NOT NULL CONSTRAINT DF_TaskDeleteJobs_Processed DEFAULT (0),
        DeletedCount      INT            NOT NULL CONSTRAINT DF_TaskDeleteJobs_Deleted DEFAULT (0),
        SkippedCount      INT            NOT NULL CONSTRAINT DF_TaskDeleteJobs_Skipped DEFAULT (0),
        ErrorMessage      NVARCHAR(2000) NULL,
        CreatedDate       DATETIME2      NOT NULL CONSTRAINT DF_TaskDeleteJobs_Created DEFAULT (GETDATE()),
        StartedDate       DATETIME2      NULL,
        CompletedDate     DATETIME2      NULL,
        IsSeen            BIT            NOT NULL CONSTRAINT DF_TaskDeleteJobs_Seen DEFAULT (0),

        CONSTRAINT CK_TaskDeleteJobs_Mode   CHECK (Mode IN ('AllPending', 'Selected')),
        CONSTRAINT CK_TaskDeleteJobs_Status CHECK (Status IN ('Queued', 'Running', 'Completed', 'Failed'))
    );

    CREATE INDEX IX_TaskDeleteJobs_Status  ON dbo.TaskDeleteJobs (Status) INCLUDE (ProcessId, Mode);
    CREATE INDEX IX_TaskDeleteJobs_User    ON dbo.TaskDeleteJobs (RequestedByUserId, JobId DESC);
END
GO

/*
  Recommended if it doesn't exist yet - every chunk deletes by ProcessId + Status:

  IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Tasks_ProcessId_Status' AND object_id = OBJECT_ID('dbo.Tasks'))
      CREATE INDEX IX_Tasks_ProcessId_Status ON dbo.Tasks (ProcessId, Status) INCLUDE (ProcessDataId);
*/
