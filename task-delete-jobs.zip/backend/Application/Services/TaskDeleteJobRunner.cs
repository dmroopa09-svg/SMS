using System.Data;
using System.Text.Json;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace GTXH.OMC.Application.Services;

/// <summary>
/// Executes one delete job. Each chunk of 1,000 tasks is its own short transaction:
/// delete the Tasks rows (capturing their ProcessDataIds), delete the matching process-table rows,
/// and record progress - all or nothing per chunk. A failure or app recycle leaves every finished
/// chunk done and the job resumable.
/// </summary>
public class TaskDeleteJobRunner
{
    private readonly ApplicationDbContext _db;
    private readonly ITaskDeleteJobNotifier _notifier;
    private readonly ILogger<TaskDeleteJobRunner> _logger;

    public TaskDeleteJobRunner(ApplicationDbContext db, ITaskDeleteJobNotifier notifier, ILogger<TaskDeleteJobRunner> logger)
    {
        _db = db;
        _notifier = notifier;
        _logger = logger;
    }

    public async System.Threading.Tasks.Task RunAsync(long jobId, CancellationToken ct)
    {
        await using var conn = new SqlConnection(_db.Database.GetConnectionString());
        await conn.OpenAsync(ct);

        var job = await TaskDeleteJobSql.GetAsync(conn, jobId, ct);
        if (job == null || job.IsFinished) return;

        await ExecAsync(conn, null, @"
            UPDATE dbo.TaskDeleteJobs
            SET Status = 'Running', StartedDate = COALESCE(StartedDate, GETDATE()), ErrorMessage = NULL
            WHERE JobId = @JobId", ct, ("@JobId", SqlDbType.BigInt, jobId));

        try
        {
            var tableName = await GetTableNameAsync(conn, job.ProcessId, ct);

            if (job.Mode == TaskDeleteJobModes.Selected)
                await RunSelectedAsync(conn, job, tableName, ct);
            else
                await RunAllPendingAsync(conn, job, tableName, ct);

            await ExecAsync(conn, null, @"
                UPDATE dbo.TaskDeleteJobs
                SET Status = 'Completed',
                    CompletedDate = GETDATE(),
                    TotalCount = CASE WHEN Mode = 'AllPending' AND DeletedCount > TotalCount THEN DeletedCount ELSE TotalCount END,
                    SkippedCount = CASE WHEN Mode = 'Selected' THEN TotalCount - DeletedCount ELSE 0 END
                WHERE JobId = @JobId", CancellationToken.None, ("@JobId", SqlDbType.BigInt, jobId));
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // App shutting down: leave it 'Running' - it is picked up again on next start.
            _logger.LogWarning("Task delete job {JobId} interrupted by shutdown; it will resume on restart.", jobId);
            return;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Task delete job {JobId} failed", jobId);
            var message = ex.GetBaseException().Message;
            if (message.Length > 1900) message = message[..1900];

            await ExecAsync(conn, null, @"
                UPDATE dbo.TaskDeleteJobs
                SET Status = 'Failed', CompletedDate = GETDATE(), ErrorMessage = @Error
                WHERE JobId = @JobId", CancellationToken.None,
                ("@JobId", SqlDbType.BigInt, jobId),
                ("@Error", SqlDbType.NVarChar, message));
        }

        try
        {
            var finished = await TaskDeleteJobSql.GetAsync(conn, jobId, CancellationToken.None);
            if (finished != null) await _notifier.JobFinishedAsync(finished, CancellationToken.None);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Task delete job {JobId}: notification failed (job itself finished).", jobId);
        }
    }

    // ------------------------------------------------------------------------------------

    private async System.Threading.Tasks.Task RunAllPendingAsync(SqlConnection conn, TaskDeleteJobDto job, string tableName, CancellationToken ct)
    {
        var sql = $@"
SET XACT_ABORT ON;
BEGIN TRAN;

DECLARE @Deleted TABLE (ProcessDataId INT NULL);

DELETE TOP (@Chunk) t
OUTPUT deleted.ProcessDataId INTO @Deleted
FROM dbo.Tasks t
WHERE t.ProcessId = @ProcessId
  AND t.Status IN ({TaskDeleteRules.SqlList(TaskDeleteRules.AllPendingStatuses)});

DELETE p
FROM [dbo].[{tableName}] p
WHERE p.ProcessDataId IN (SELECT d.ProcessDataId FROM @Deleted d WHERE d.ProcessDataId IS NOT NULL);

DECLARE @n INT = (SELECT COUNT(*) FROM @Deleted);

UPDATE dbo.TaskDeleteJobs
SET DeletedCount = DeletedCount + @n, ProcessedCount = ProcessedCount + @n
WHERE JobId = @JobId;

COMMIT;
SELECT @n;";

        while (true)
        {
            ct.ThrowIfCancellationRequested();
            var n = await ScalarIntAsync(conn, sql, ct,
                ("@Chunk", SqlDbType.Int, TaskDeleteRules.ChunkSize),
                ("@ProcessId", SqlDbType.Int, job.ProcessId),
                ("@JobId", SqlDbType.BigInt, job.JobId));
            if (n == 0) break;
        }
    }

    private async System.Threading.Tasks.Task RunSelectedAsync(SqlConnection conn, TaskDeleteJobDto job, string tableName, CancellationToken ct)
    {
        var json = await GetTaskIdsJsonAsync(conn, job.JobId, ct);
        var ids = string.IsNullOrWhiteSpace(json)
            ? new List<long>()
            : JsonSerializer.Deserialize<List<long>>(json) ?? new List<long>();

        var sql = $@"
SET XACT_ABORT ON;
BEGIN TRAN;

DECLARE @Deleted TABLE (ProcessDataId INT NULL);

DELETE t
OUTPUT deleted.ProcessDataId INTO @Deleted
FROM dbo.Tasks t
WHERE t.ProcessId = @ProcessId
  AND t.Status IN ({TaskDeleteRules.SqlList(TaskDeleteRules.SelectedStatuses)})
  AND t.TaskId IN (SELECT CAST(j.[value] AS BIGINT) FROM OPENJSON(@Ids) j);

DELETE p
FROM [dbo].[{tableName}] p
WHERE p.ProcessDataId IN (SELECT d.ProcessDataId FROM @Deleted d WHERE d.ProcessDataId IS NOT NULL);

DECLARE @n INT = (SELECT COUNT(*) FROM @Deleted);

UPDATE dbo.TaskDeleteJobs
SET DeletedCount = DeletedCount + @n, ProcessedCount = ProcessedCount + @ChunkLength
WHERE JobId = @JobId;

COMMIT;
SELECT @n;";

        // Resume after a restart: chunks already committed are skipped.
        foreach (var chunk in ids.Skip(job.ProcessedCount).Chunk(TaskDeleteRules.ChunkSize))
        {
            ct.ThrowIfCancellationRequested();
            await ScalarIntAsync(conn, sql, ct,
                ("@ProcessId", SqlDbType.Int, job.ProcessId),
                ("@Ids", SqlDbType.NVarChar, JsonSerializer.Serialize(chunk)),
                ("@ChunkLength", SqlDbType.Int, chunk.Length),
                ("@JobId", SqlDbType.BigInt, job.JobId));
        }
    }

    // ------------------------------------------------------------------------------------

    private static async Task<string> GetTableNameAsync(SqlConnection conn, int processId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand("SELECT TableName FROM dbo.Processes WHERE ProcessId = @ProcessId", conn);
        cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = processId;
        var name = await cmd.ExecuteScalarAsync(ct) as string;
        if (!TaskDeleteRules.IsSafeTableName(name))
            throw new InvalidOperationException($"Process {processId} does not have a valid table name");
        return name!;
    }

    private static async Task<string?> GetTaskIdsJsonAsync(SqlConnection conn, long jobId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand("SELECT TaskIdsJson FROM dbo.TaskDeleteJobs WHERE JobId = @JobId", conn);
        cmd.Parameters.Add("@JobId", SqlDbType.BigInt).Value = jobId;
        return await cmd.ExecuteScalarAsync(ct) as string;
    }

    private static async Task<int> ScalarIntAsync(SqlConnection conn, string sql, CancellationToken ct,
        params (string Name, SqlDbType Type, object Value)[] parameters)
    {
        await using var cmd = new SqlCommand(sql, conn) { CommandTimeout = TaskDeleteRules.CommandTimeoutSeconds };
        foreach (var (name, type, value) in parameters)
        {
            var p = cmd.Parameters.Add(name, type);
            if (type == SqlDbType.NVarChar) p.Size = -1;
            p.Value = value;
        }
        var result = await cmd.ExecuteScalarAsync(ct);
        return result == null || result is DBNull ? 0 : Convert.ToInt32(result);
    }

    private static async System.Threading.Tasks.Task ExecAsync(SqlConnection conn, SqlTransaction? tx, string sql, CancellationToken ct,
        params (string Name, SqlDbType Type, object Value)[] parameters)
    {
        await using var cmd = new SqlCommand(sql, conn, tx) { CommandTimeout = TaskDeleteRules.CommandTimeoutSeconds };
        foreach (var (name, type, value) in parameters)
        {
            var p = cmd.Parameters.Add(name, type);
            if (type == SqlDbType.NVarChar) p.Size = -1;
            p.Value = value;
        }
        await cmd.ExecuteNonQueryAsync(ct);
    }
}
