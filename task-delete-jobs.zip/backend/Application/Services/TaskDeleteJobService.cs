using System.Data;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Channels;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace GTXH.OMC.Application.Services;

/// <summary>Which task statuses each mode may delete. One place to change it.</summary>
internal static class TaskDeleteRules
{
    /// <summary>"Remove Pending Tasks" - same statuses the old DeletePendingRecordsAsync used.</summary>
    public static readonly string[] AllPendingStatuses = { "Pending", "InProgress" };

    /// <summary>"Delete Selected" - same statuses the old DeleteSelectedPendingTasksAsync used.</summary>
    public static readonly string[] SelectedStatuses = { "Pending", "InProgress", "OnHold", "Cancelled" };

    public const int ChunkSize = 1000;
    public const int CommandTimeoutSeconds = 300;

    /// <summary>Constants only - safe to inline into SQL.</summary>
    public static string SqlList(IEnumerable<string> statuses) =>
        string.Join(", ", statuses.Select(s => "'" + s.Replace("'", "''") + "'"));

    public static bool IsSafeTableName(string? name) =>
        !string.IsNullOrWhiteSpace(name) && Regex.IsMatch(name, @"^[A-Za-z0-9_]+$");
}

/// <summary>In-memory queue of job ids; the DB row is the source of truth, so losing this on restart is fine.</summary>
public sealed class TaskDeleteQueue
{
    private readonly Channel<long> _channel = Channel.CreateUnbounded<long>();

    public void Enqueue(long jobId) => _channel.Writer.TryWrite(jobId);

    public IAsyncEnumerable<long> ReadAllAsync(CancellationToken ct) => _channel.Reader.ReadAllAsync(ct);
}

public sealed class NoOpTaskDeleteJobNotifier : ITaskDeleteJobNotifier
{
    public System.Threading.Tasks.Task JobFinishedAsync(TaskDeleteJobDto job, CancellationToken ct = default) =>
        System.Threading.Tasks.Task.CompletedTask;
}

/// <summary>Shared SQL for reading job rows.</summary>
internal static class TaskDeleteJobSql
{
    public const string SelectColumns = @"
        JobId, ProcessId, Mode, Status, RequestedByUserId, TotalCount, ProcessedCount, DeletedCount,
        SkippedCount, ErrorMessage, CreatedDate, StartedDate, CompletedDate, IsSeen";

    public static TaskDeleteJobDto Read(SqlDataReader r) => new()
    {
        JobId = r.GetInt64(0),
        ProcessId = r.GetInt32(1),
        Mode = r.GetString(2),
        Status = r.GetString(3),
        RequestedByUserId = r.GetInt32(4),
        TotalCount = r.GetInt32(5),
        ProcessedCount = r.GetInt32(6),
        DeletedCount = r.GetInt32(7),
        SkippedCount = r.GetInt32(8),
        ErrorMessage = r.IsDBNull(9) ? null : r.GetString(9),
        CreatedDate = r.GetDateTime(10),
        StartedDate = r.IsDBNull(11) ? null : r.GetDateTime(11),
        CompletedDate = r.IsDBNull(12) ? null : r.GetDateTime(12),
        IsSeen = r.GetBoolean(13),
    };

    public static async Task<TaskDeleteJobDto?> GetAsync(SqlConnection conn, long jobId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(
            $"SELECT {SelectColumns} FROM dbo.TaskDeleteJobs WHERE JobId = @JobId", conn);
        cmd.Parameters.Add("@JobId", SqlDbType.BigInt).Value = jobId;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        return await r.ReadAsync(ct) ? Read(r) : null;
    }
}

public class TaskDeleteJobService : ITaskDeleteJobService
{
    private readonly ApplicationDbContext _db;
    private readonly TaskDeleteQueue _queue;
    private readonly ILogger<TaskDeleteJobService> _logger;

    public TaskDeleteJobService(ApplicationDbContext db, TaskDeleteQueue queue, ILogger<TaskDeleteJobService> logger)
    {
        _db = db;
        _queue = queue;
        _logger = logger;
    }

    private async Task<SqlConnection> OpenAsync(CancellationToken ct)
    {
        var conn = new SqlConnection(_db.Database.GetConnectionString());
        await conn.OpenAsync(ct);
        return conn;
    }

    public async Task<StartTaskDeleteJobResponse> StartAllPendingAsync(int processId, int userId, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        await EnsureProcessAsync(conn, processId, ct);

        // One removal per process at a time - a double click returns the running job instead of starting another.
        await using (var cmd = new SqlCommand(@"
            SELECT TOP 1 JobId, TotalCount FROM dbo.TaskDeleteJobs
            WHERE ProcessId = @ProcessId AND Mode = 'AllPending' AND Status IN ('Queued', 'Running')
            ORDER BY JobId DESC", conn))
        {
            cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = processId;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (await r.ReadAsync(ct))
                return new StartTaskDeleteJobResponse { JobId = r.GetInt64(0), TotalCount = r.GetInt32(1), AlreadyRunning = true };
        }

        int total;
        await using (var cmd = new SqlCommand($@"
            SELECT COUNT(*) FROM dbo.Tasks
            WHERE ProcessId = @ProcessId AND Status IN ({TaskDeleteRules.SqlList(TaskDeleteRules.AllPendingStatuses)})", conn)
            { CommandTimeout = TaskDeleteRules.CommandTimeoutSeconds })
        {
            cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = processId;
            total = Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
        }

        if (total == 0) return new StartTaskDeleteJobResponse { JobId = 0, TotalCount = 0 };

        var jobId = await InsertJobAsync(conn, processId, TaskDeleteJobModes.AllPending, null, userId, total, ct);
        _queue.Enqueue(jobId);
        _logger.LogInformation("Task delete job {JobId} queued: all pending of process {ProcessId} ({Total} tasks) by user {UserId}",
            jobId, processId, total, userId);

        return new StartTaskDeleteJobResponse { JobId = jobId, TotalCount = total };
    }

    public async Task<StartTaskDeleteJobResponse> StartSelectedAsync(int processId, IReadOnlyCollection<long> taskIds, int userId, CancellationToken ct = default)
    {
        var ids = (taskIds ?? Array.Empty<long>()).Where(id => id > 0).Distinct().ToList();
        if (ids.Count == 0) throw new ArgumentException("Task IDs list cannot be empty");

        await using var conn = await OpenAsync(ct);
        await EnsureProcessAsync(conn, processId, ct);

        var jobId = await InsertJobAsync(conn, processId, TaskDeleteJobModes.Selected,
            JsonSerializer.Serialize(ids), userId, ids.Count, ct);
        _queue.Enqueue(jobId);
        _logger.LogInformation("Task delete job {JobId} queued: {Count} selected tasks of process {ProcessId} by user {UserId}",
            jobId, ids.Count, processId, userId);

        return new StartTaskDeleteJobResponse { JobId = jobId, TotalCount = ids.Count };
    }

    public async Task<TaskDeleteJobDto?> GetAsync(long jobId, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        return await TaskDeleteJobSql.GetAsync(conn, jobId, ct);
    }

    public async Task<List<TaskDeleteJobDto>> GetActiveForUserAsync(int userId, int? processId, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand($@"
            SELECT TOP 20 {TaskDeleteJobSql.SelectColumns}
            FROM dbo.TaskDeleteJobs
            WHERE RequestedByUserId = @UserId
              AND (@ProcessId IS NULL OR ProcessId = @ProcessId)
              AND (Status IN ('Queued', 'Running')
                   OR (IsSeen = 0 AND CreatedDate >= DATEADD(DAY, -2, GETDATE())))
            ORDER BY JobId DESC", conn);
        cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
        cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = (object?)processId ?? DBNull.Value;

        var list = new List<TaskDeleteJobDto>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(TaskDeleteJobSql.Read(r));
        return list;
    }

    public async System.Threading.Tasks.Task MarkSeenAsync(long jobId, int userId, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(
            "UPDATE dbo.TaskDeleteJobs SET IsSeen = 1 WHERE JobId = @JobId AND RequestedByUserId = @UserId", conn);
        cmd.Parameters.Add("@JobId", SqlDbType.BigInt).Value = jobId;
        cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<List<long>> GetUnfinishedJobIdsAsync(CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(
            "SELECT JobId FROM dbo.TaskDeleteJobs WHERE Status IN ('Queued', 'Running') ORDER BY JobId", conn);
        var ids = new List<long>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) ids.Add(r.GetInt64(0));
        return ids;
    }

    // ------------------------------------------------------------------------------------

    private static async System.Threading.Tasks.Task EnsureProcessAsync(SqlConnection conn, int processId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand("SELECT TableName FROM dbo.Processes WHERE ProcessId = @ProcessId", conn);
        cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = processId;
        var result = await cmd.ExecuteScalarAsync(ct);

        if (result == null) throw new KeyNotFoundException($"Process with ID {processId} not found");
        if (result is DBNull || !TaskDeleteRules.IsSafeTableName(result as string))
            throw new InvalidOperationException("Process does not have a valid table name");
    }

    private static async Task<long> InsertJobAsync(SqlConnection conn, int processId, string mode, string? idsJson,
        int userId, int total, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(@"
            INSERT INTO dbo.TaskDeleteJobs (ProcessId, Mode, TaskIdsJson, RequestedByUserId, Status, TotalCount)
            OUTPUT inserted.JobId
            VALUES (@ProcessId, @Mode, @TaskIdsJson, @UserId, 'Queued', @Total)", conn);
        cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = processId;
        cmd.Parameters.Add("@Mode", SqlDbType.VarChar, 20).Value = mode;
        cmd.Parameters.Add("@TaskIdsJson", SqlDbType.NVarChar, -1).Value = (object?)idsJson ?? DBNull.Value;
        cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
        cmd.Parameters.Add("@Total", SqlDbType.Int).Value = total;
        return Convert.ToInt64(await cmd.ExecuteScalarAsync(ct));
    }
}
