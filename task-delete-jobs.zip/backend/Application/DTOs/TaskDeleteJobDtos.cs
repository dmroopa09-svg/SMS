namespace GTXH.OMC.Application.DTOs;

public static class TaskDeleteJobModes
{
    public const string AllPending = "AllPending";
    public const string Selected = "Selected";
}

public static class TaskDeleteJobStatuses
{
    public const string Queued = "Queued";
    public const string Running = "Running";
    public const string Completed = "Completed";
    public const string Failed = "Failed";
}

public class TaskDeleteJobDto
{
    public long JobId { get; set; }
    public int ProcessId { get; set; }
    public string Mode { get; set; } = TaskDeleteJobModes.AllPending;
    public string Status { get; set; } = TaskDeleteJobStatuses.Queued;
    public int RequestedByUserId { get; set; }
    public int TotalCount { get; set; }
    public int ProcessedCount { get; set; }
    public int DeletedCount { get; set; }
    public int SkippedCount { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime? StartedDate { get; set; }
    public DateTime? CompletedDate { get; set; }
    public bool IsSeen { get; set; }

    public bool IsFinished => Status == TaskDeleteJobStatuses.Completed || Status == TaskDeleteJobStatuses.Failed;

    /// <summary>0-100 for the progress bar.</summary>
    public int Percent
    {
        get
        {
            if (Status == TaskDeleteJobStatuses.Completed) return 100;
            if (TotalCount <= 0) return 0;
            var done = Mode == TaskDeleteJobModes.Selected ? ProcessedCount : DeletedCount;
            return (int)Math.Min(99, Math.Floor(done * 100.0 / TotalCount));
        }
    }
}

public class StartSelectedDeleteRequest
{
    public int ProcessId { get; set; }
    public List<long> TaskIds { get; set; } = new();
}

public class StartTaskDeleteJobResponse
{
    /// <summary>0 when there was nothing to delete.</summary>
    public long JobId { get; set; }
    public int TotalCount { get; set; }
    /// <summary>True when a removal for this process was already queued/running and that job is returned.</summary>
    public bool AlreadyRunning { get; set; }
}
