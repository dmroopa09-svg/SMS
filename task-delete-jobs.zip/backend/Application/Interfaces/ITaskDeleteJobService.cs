using GTXH.OMC.Application.DTOs;

namespace GTXH.OMC.Application.Interfaces;

public interface ITaskDeleteJobService
{
    /// <summary>Queues removal of every Pending / In Progress task of the process.</summary>
    Task<StartTaskDeleteJobResponse> StartAllPendingAsync(int processId, int userId, CancellationToken ct = default);

    /// <summary>Queues removal of the selected tasks (only those still Pending / In Progress / On Hold / Cancelled).</summary>
    Task<StartTaskDeleteJobResponse> StartSelectedAsync(int processId, IReadOnlyCollection<long> taskIds, int userId, CancellationToken ct = default);

    Task<TaskDeleteJobDto?> GetAsync(long jobId, CancellationToken ct = default);

    /// <summary>The user's running jobs plus finished ones not yet seen (last 2 days). Used to resume the progress bar after navigation.</summary>
    Task<List<TaskDeleteJobDto>> GetActiveForUserAsync(int userId, int? processId, CancellationToken ct = default);

    Task MarkSeenAsync(long jobId, int userId, CancellationToken ct = default);

    /// <summary>Queued/Running jobs - re-queued when the app starts (app pool recycle mid-job).</summary>
    Task<List<long>> GetUnfinishedJobIdsAsync(CancellationToken ct = default);
}

/// <summary>
/// Called once when a job finishes (Completed or Failed). The default does nothing - the admin page
/// polls. Register your own implementation to push through your SignalR notification hub.
/// </summary>
public interface ITaskDeleteJobNotifier
{
    Task JobFinishedAsync(TaskDeleteJobDto job, CancellationToken ct = default);
}
