using System.Security.Claims;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GTXH.OMC.API.Controllers;

/// <summary>
/// Background task removal for the admin Task Details page.
///
///   POST api/task-delete-jobs/pending/{processId}   start "Remove Pending Tasks"      -> { jobId, totalCount, alreadyRunning }
///   POST api/task-delete-jobs/selected              start "Delete Selected" { processId, taskIds }
///   GET  api/task-delete-jobs/{jobId}               progress
///   GET  api/task-delete-jobs/active?processId=20   my running + unseen finished jobs (resume after navigation)
///   POST api/task-delete-jobs/{jobId}/seen          hide a finished job from "active"
/// </summary>
[ApiController]
[Route("api/task-delete-jobs")]
[Authorize(AuthenticationSchemes = "Bearer")]
public class TaskDeleteJobsController : ControllerBase
{
    private readonly ITaskDeleteJobService _service;
    private readonly ILogger<TaskDeleteJobsController> _logger;

    public TaskDeleteJobsController(ITaskDeleteJobService service, ILogger<TaskDeleteJobsController> logger)
    {
        _service = service;
        _logger = logger;
    }

    [HttpPost("pending/{processId:int}")]
    public Task<IActionResult> StartAllPending(int processId, CancellationToken ct) =>
        Run(async userId => Ok(await _service.StartAllPendingAsync(processId, userId, ct)));

    [HttpPost("selected")]
    public Task<IActionResult> StartSelected([FromBody] StartSelectedDeleteRequest request, CancellationToken ct) =>
        Run(async userId => Ok(await _service.StartSelectedAsync(request.ProcessId, request.TaskIds, userId, ct)));

    [HttpGet("{jobId:long}")]
    public Task<IActionResult> Get(long jobId, CancellationToken ct) =>
        Run(async _ =>
        {
            var job = await _service.GetAsync(jobId, ct);
            return job == null
                ? NotFound(Error("JOB_NOT_FOUND", "Delete job not found"))
                : Ok(job);
        });

    [HttpGet("active")]
    public Task<IActionResult> Active([FromQuery] int? processId, CancellationToken ct) =>
        Run(async userId => Ok(await _service.GetActiveForUserAsync(userId, processId, ct)));

    [HttpPost("{jobId:long}/seen")]
    public Task<IActionResult> Seen(long jobId, CancellationToken ct) =>
        Run(async userId =>
        {
            await _service.MarkSeenAsync(jobId, userId, ct);
            return NoContent();
        });

    // ------------------------------------------------------------------------------------

    private async Task<IActionResult> Run(Func<int, Task<IActionResult>> action)
    {
        int userId;
        try
        {
            userId = GetCurrentUserId();
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }

        try
        {
            return await action(userId);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(Error("PROCESS_NOT_FOUND", ex.Message));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(Error("INVALID_INPUT", ex.Message));
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(Error("INVALID_OPERATION", ex.Message));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Task delete job request failed");
            return StatusCode(500, Error("SERVER_ERROR", "An error occurred while processing the delete request"));
        }
    }

    private static object Error(string code, string message) => new { error = new { code, message } };

    private int GetCurrentUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out var userId))
            throw new UnauthorizedAccessException("User ID not found in token");
        return userId;
    }
}
