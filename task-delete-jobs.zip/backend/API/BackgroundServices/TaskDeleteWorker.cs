using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Application.Services;

namespace GTXH.OMC.API.BackgroundServices;

/// <summary>
/// Runs task delete jobs one at a time (sequential on purpose - parallel deletes on Tasks would just
/// block each other). On startup it re-queues jobs left Queued/Running by an app pool recycle.
/// </summary>
public class TaskDeleteWorker : BackgroundService
{
    private readonly TaskDeleteQueue _queue;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<TaskDeleteWorker> _logger;

    public TaskDeleteWorker(TaskDeleteQueue queue, IServiceScopeFactory scopeFactory, ILogger<TaskDeleteWorker> logger)
    {
        _queue = queue;
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var service = scope.ServiceProvider.GetRequiredService<ITaskDeleteJobService>();
            foreach (var id in await service.GetUnfinishedJobIdsAsync(stoppingToken))
                _queue.Enqueue(id);
        }
        catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
        {
            _logger.LogError(ex, "Could not re-queue unfinished task delete jobs on startup.");
        }

        try
        {
            await foreach (var jobId in _queue.ReadAllAsync(stoppingToken))
            {
                try
                {
                    using var scope = _scopeFactory.CreateScope();
                    var runner = scope.ServiceProvider.GetRequiredService<TaskDeleteJobRunner>();
                    await runner.RunAsync(jobId, stoppingToken);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    // RunAsync records its own failures; this only catches setup errors.
                    _logger.LogError(ex, "Task delete job {JobId} could not be run.", jobId);
                }
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // shutting down
        }
    }
}
