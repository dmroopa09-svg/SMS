# Clarification oversight - Supervisors, Managers, SuperAdmins

**GTXH.OMC solution.** Controller + service + interface + scope resolver, so
supervisors, managers and superadmins can see their team's clarifications on the
same screen agents already use.

```
GTXH.OMC.Application/DTOs/ClarificationOversightDtos.cs
GTXH.OMC.Application/Interfaces/IClarificationOversightService.cs
GTXH.OMC.Application/Services/ClarificationOversightScope.cs      <- role -> scope
GTXH.OMC.Application/Services/ClarificationOversightService.cs
GTXH.OMC.API/Controllers/ClarificationOversightController.cs
```

**No new entities, no migration.** `ClarificationTicket`, `ClarificationComment`
and `ClarificationTicketTask` already exist from the agent-side work, trigger
mapping included.

**Nothing touches the existing agent flow.** This is a parallel service mounted at
`api/clarifications/team`; `api/clarifications` is untouched, so the thing agents
use every day cannot regress.

---

## 1. Confirm the role names first

Everything hinges on `Roles.RoleName`:

```sql
SELECT r.RoleId, r.RoleName, COUNT(u.UserId) AS Users_
FROM   dbo.Roles r
LEFT JOIN dbo.Users u ON u.RoleId = r.RoleId
GROUP BY r.RoleId, r.RoleName
ORDER BY COUNT(u.UserId) DESC;
```

Then check the three sets at the top of `ClarificationOversightScope.cs`:

| Role | Sees | Comment | Resume |
|---|---|---|---|
| SuperAdmin / Super Admin / Admin / Administrator | everyone | yes | yes |
| Manager | direct reports + their supervisors' reports | yes | yes |
| Supervisor / Team Lead | direct reports | yes | yes |
| anything else | own tickets only | no | no |

**An unmapped role falls through to the agent default.** Safe direction - it sees
less, never more. But a real role missing from the list will quietly behave like
an agent, which is why the query above matters.

### And confirm the hierarchy is actually populated

The whole supervisor view depends on it:

```sql
SELECT
    SUM(CASE WHEN SupervisorId IS NOT NULL THEN 1 ELSE 0 END) AS HasSupervisor,
    SUM(CASE WHEN ManagerId    IS NOT NULL THEN 1 ELSE 0 END) AS HasManager,
    COUNT(*)                                                  AS TotalUsers
FROM dbo.Users
WHERE Status = 'Active';
```

If `HasSupervisor` is near zero, every supervisor will see only their own
clarifications and conclude the feature is broken. **Check this before
demoing it.** If the hierarchy is not maintained, say so and we scope by
`UserProcessPermissions` instead - that is a change to one method
(`ResolveTeamAsync`), not a redesign.

---

## 2. Role comes from the database, not the JWT

Deliberate, and the same rule the QA app already follows for its rework queue.

A clarification thread carries account numbers and patient names. Someone moved
off a team this morning must stop seeing that team's threads immediately, not
when their token expires. The token says who you are; the database says what you
may see.

That is why there is **no `[Authorize(Roles = ...)]` anywhere in this
controller** - that attribute reads the token and would undo it.

---

## 3. What "my team's clarifications" means

A ticket is visible when **at least one of its tasks is assigned to someone the
caller may see.**

Ticket ownership is not stored anywhere, so it is derived from the tasks. That is
also the only definition that stays correct when one ticket covers tasks for more
than one agent, which your grouping-by-process raise flow allows.

Process permissions narrow an oversight role *further*, on top of the user
filter - never instead of it. An empty permission list is treated as **no
restriction recorded**, not as no access; otherwise every supervisor whose
permissions were never set up would get a blank screen.

---

## 4. Program.cs

```csharp
builder.Services.AddScoped<ClarificationOversightScopeResolver>();
builder.Services.AddScoped<IClarificationOversightService, ClarificationOversightService>();
```

Scoped, not singleton - both take `ApplicationDbContext`.

---

## 5. Endpoints

All under `api/clarifications/team`, all JWT-authenticated, all scoped.

| Method | Route | Purpose |
|---|---|---|
| POST | `/search` | paged list (body filters) |
| GET | `/` | same, query-string form |
| GET | `/{ticketId}` | thread + comments + tasks |
| POST | `/{ticketId}/comments` | comment on a team member's ticket |
| POST | `/{ticketId}/resume` | resume their blocked tasks |
| GET | `/summary` | counts + per-agent + per-process breakdown |
| GET | `/scope` | what this user may see and do |
| GET | `/agents` | agents in scope, for the filter dropdown |

### Wire `/scope` first

Returns `roleName`, `allUsers`, `isOversight`, `visibleAgentCount`, `canComment`,
`canResume`.

Call it once on load. **`isOversight: false` means the user should stay on the
existing agent endpoints** - so the same Clarifications page serves everyone by
switching base path and hiding controls, instead of the frontend branching on a
role string it would have to be told about separately.

### Out of scope returns 404, not 403

A ticket belonging to another team is indistinguishable from one that does not
exist. A 403 would confirm that ticket 4812 exists on some other team; a 404
confirms nothing.

### `/summary` returns zeros on error

The badge poller calls it every minute. If it threw, one transient blip would put
an error toast in front of every supervisor at once.

---

## 6. States match the agent screen exactly

Derived at read time, never stored - `CLR_Ticket.Status` has one writer and a
second would drift.

| State | Meaning |
|---|---|
| `Closed` | no tasks blocked any more |
| `Received` | QA replied, or resolved - something to read |
| `AwaitingQa` | waiting on QA |

Same values, same rule as `ClarificationService`, so the oversight screen and the
agent screen can never disagree about a ticket.

`DeriveState` and `ApplyStateFilter` encode that rule twice - once in memory for
display, once in SQL so a superadmin asking for one state does not materialise
every closed ticket first. They sit next to each other with a note. **Change one,
change the other.**

---

## 7. Two clocks, deliberately

```csharp
RowInsertDate = DateTime.UtcNow;   // CLR_ tables - shared with QA
task.ModifiedDate = DateTime.Now;  // Tasks - agent app, server-local
```

`CLR_Ticket_Comm` is written by both apps and the QA app writes `UtcNow`. Writing
server-local there would put the two halves of one thread five hours apart, and
the trigger that maintains `LastUpdateDate` from `MAX(RowInsertDate)` would order
tickets wrongly - an agent's reply could push their own ticket *down* the list.

`Tasks` belongs to this app and follows your manager's central-for-now decision.
Mixing the two is what produced the wrong working dates, so the split is
intentional until the UTC migration lands.

---

## 8. Indexes

The projection runs `TOP 1` and `COUNT` subqueries per ticket:

```sql
CREATE NONCLUSTERED INDEX IX_CLR_Ticket_Comm_Ticket_Date
    ON dbo.CLR_Ticket_Comm (TicketId, RowInsertDate)
    INCLUDE (UserType, UserId, Comment);

CREATE NONCLUSTERED INDEX IX_CLR_Ticket_Tasks_Ticket
    ON dbo.CLR_Ticket_Tasks (TicketId) INCLUDE (TaskId);
```

The first is the one that matters, and it grows most on exactly the tickets
supervisors care about.

---

## 9. Verify before deploying

These three property names are my assumption from the entities built earlier -
check them against the real classes:

```
Users:        UserId, Username, FirstName, LastName, RoleId, ManagerId, SupervisorId
Roles:        RoleId, RoleName
TaskHistory:  TaskId, Action, OldValue, NewValue, ChangedByUserId, ChangedDate
```

`TaskHistory` is the likeliest mismatch - if yours differs, the Resume path is
the only place it is used.

---

## 10. Test

1. **Agent** hits `/team/scope` -> `isOversight: false`, stays on agent endpoints
2. **Supervisor** -> sees their direct reports' tickets, not another team's
3. **Supervisor with nobody reporting to them** -> sees only their own; empty is
   correct, not a bug
4. **Manager** -> sees direct reports *and* agents under their supervisors
5. **SuperAdmin** -> every agent, `byAgent` breakdown populated
6. Supervisor requests a ticket id from another team -> **404**
7. Agent calls a `/team` write endpoint -> **403** with a clear message
8. Supervisor resumes a team member's ticket -> tasks leave Clarification,
   `TaskHistory` rows written, agent sees them unblocked
9. Comment as a supervisor, check the thread in the **QA app** -> timestamps sit
   in order with QA's, not five hours out
10. Change a user's `SupervisorId` and call `/team/scope` again **without
    re-logging-in** -> new scope applies immediately

Steps 9 and 10 are the ones that prove the clock decision and the DB-role
decision respectively.

---

## 11. One DTO change, optional

`ClarificationOversightTicketDto` duplicates `ClarificationTicketDto` plus three
fields. If you would rather have one type, add these to the existing DTO and
return it instead - they are nullable and the agent screen ignores fields it does
not render:

```csharp
public int?    RaisedByUserId { get; set; }
public string? RaisedByName   { get; set; }
public double? HoursWaiting   { get; set; }
```

`HoursWaiting` is what lets a supervisor spot a stalled ticket from the list
without opening it, and it drives the `Ageing` count in the summary.
