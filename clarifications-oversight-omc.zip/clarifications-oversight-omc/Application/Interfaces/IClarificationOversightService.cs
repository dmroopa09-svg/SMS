using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Services;

namespace GTXH.OMC.Application.Interfaces;

/// <summary>
/// Clarification oversight for supervisors, managers and superadmins.
///
/// Separate from IClarificationService on purpose. That one is the agent's own
/// view and is in production; nothing here touches it, so adding oversight
/// cannot regress the flow agents use every day.
///
/// EVERY method takes a ClarificationOversightScope. That makes it impossible to
/// call one without having first decided whose clarifications the caller may
/// read - the failure mode that matters when one screen serves an agent, a
/// supervisor and a superadmin.
/// </summary>
public interface IClarificationOversightService
{
    /// <summary>Paged ticket list across the caller's visible agents.</summary>
    Task<PagedClarificationOversightResponse> SearchAsync(
        ClarificationOversightScope scope,
        ClarificationOversightQueryRequest request,
        CancellationToken cancellationToken);

    /// <summary>
    /// One ticket with its thread and tasks.
    ///
    /// Returns null when the ticket does not exist OR sits outside the caller's
    /// scope - indistinguishable on purpose, so a guessed ticket id cannot
    /// confirm that another team has one.
    /// </summary>
    Task<ClarificationThreadDto?> GetThreadAsync(
        ClarificationOversightScope scope,
        long ticketId,
        CancellationToken cancellationToken);

    /// <summary>Post a comment on a team member's ticket. Requires scope.CanComment.</summary>
    Task<ClarificationThreadDto?> AddCommentAsync(
        ClarificationOversightScope scope,
        long ticketId,
        AddClarificationCommentRequest request,
        CancellationToken cancellationToken);

    /// <summary>
    /// Resume the blocked tasks on a team member's ticket, unblocking the agent
    /// without waiting for them. Requires scope.CanResume.
    /// </summary>
    Task<ClarificationThreadDto?> ResumeAsync(
        ClarificationOversightScope scope,
        long ticketId,
        CancellationToken cancellationToken);

    /// <summary>Counts for the oversight header, including the per-agent breakdown.</summary>
    Task<ClarificationOversightSummaryDto> GetSummaryAsync(
        ClarificationOversightScope scope,
        CancellationToken cancellationToken);
}
