using GTXH.OMC.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace GTXH.OMC.Application.Services;

/// <summary>
/// What one signed-in user may see in the clarification oversight screens.
///
/// Resolved ONCE per request and passed into every service call, so no method
/// can forget to scope. A method that takes a ClarificationOversightScope cannot
/// be called without having decided whose clarifications the caller may read.
/// </summary>
public sealed class ClarificationOversightScope
{
    public required int UserId { get; init; }
    public required string RoleName { get; init; }

    /// <summary>True for SuperAdmin / Admin - no restriction at all.</summary>
    public required bool AllUsers { get; init; }

    /// <summary>
    /// Agent UserIds whose clarifications this caller may read, always including
    /// themselves. Ignored when AllUsers is true.
    ///
    /// EMPTY alongside AllUsers = false means they see only their own, which is
    /// the correct outcome for a supervisor with nobody reporting to them - a
    /// configuration gap, not a reason to widen the query.
    /// </summary>
    public required IReadOnlyCollection<int> VisibleUserIds { get; init; }

    /// <summary>
    /// Agent ProcessIds from UserProcessPermissions. Applied ON TOP of the user
    /// set, never instead of it. Null means no process restriction.
    /// </summary>
    public IReadOnlyCollection<int>? VisibleProcessIds { get; init; }

    /// <summary>May post a reply onto someone else's ticket.</summary>
    public required bool CanComment { get; init; }

    /// <summary>May resume tasks on someone else's ticket.</summary>
    public required bool CanResume { get; init; }

    /// <summary>True when this caller sees more than just their own work.</summary>
    public bool IsOversight => AllUsers || VisibleUserIds.Count > 1;
}

/// <summary>
/// Resolves a ClarificationOversightScope from the signed-in user.
///
/// ROLE AND HIERARCHY COME FROM THE DATABASE, NOT THE JWT. A clarification
/// thread carries account numbers and patient names, so someone moved off a team
/// this morning must not keep reading that team's threads until their token
/// expires. The token says who you are; the database says what you may see.
/// </summary>
public sealed class ClarificationOversightScopeResolver
{
    private readonly ApplicationDbContext _db;

    public ClarificationOversightScopeResolver(ApplicationDbContext db) => _db = db;

    // ---------------------------------------------------------------------
    // THE ROLE MAP. One place, so widening or narrowing a role is one edit.
    //
    // Confirm these against your data before deploying:
    //     SELECT r.RoleId, r.RoleName, COUNT(u.UserId)
    //     FROM dbo.Roles r LEFT JOIN dbo.Users u ON u.RoleId = r.RoleId
    //     GROUP BY r.RoleId, r.RoleName;
    //
    // Anything not listed falls through to the agent default - own tickets only.
    // That is the safe direction: an unmapped role sees less, never more.
    // ---------------------------------------------------------------------
    private static readonly HashSet<string> UnrestrictedRoles = new(StringComparer.OrdinalIgnoreCase)
    {
        "SuperAdmin",
        "Super Admin",
        "Admin",
        "Administrator",
    };

    private static readonly HashSet<string> ManagerRoles = new(StringComparer.OrdinalIgnoreCase)
    {
        // Sees everyone reporting to them, directly or through a supervisor.
        "Manager",
    };

    private static readonly HashSet<string> SupervisorRoles = new(StringComparer.OrdinalIgnoreCase)
    {
        // Sees their direct reports only.
        "Supervisor",
        "Team Lead",
        "TeamLead",
    };

    public async Task<ClarificationOversightScope?> ResolveAsync(
        int userId,
        CancellationToken cancellationToken)
    {
        if (userId <= 0)
            return null;

        var me = await _db.Users.AsNoTracking()
            .Where(u => u.UserId == userId)
            .Select(u => new { u.UserId, u.RoleId })
            .FirstOrDefaultAsync(cancellationToken);

        if (me is null)
            return null;

        var roleName = await _db.Roles.AsNoTracking()
            .Where(r => r.RoleId == me.RoleId)
            .Select(r => r.RoleName)
            .FirstOrDefaultAsync(cancellationToken) ?? string.Empty;

        roleName = roleName.Trim();

        var unrestricted = UnrestrictedRoles.Contains(roleName);
        var isManager = ManagerRoles.Contains(roleName);
        var isSupervisor = SupervisorRoles.Contains(roleName);

        var visibleUsers = unrestricted
            ? Array.Empty<int>()
            : await ResolveTeamAsync(userId, isManager, isSupervisor, cancellationToken);

        // Process permissions narrow an oversight role further. An agent is
        // already limited to their own tickets, so applying it there as well
        // would only risk hiding their own work from them.
        IReadOnlyCollection<int>? processIds = null;
        if (!unrestricted && (isManager || isSupervisor))
        {
            processIds = await _db.UserProcessPermissions.AsNoTracking()
                .Where(p => p.UserId == userId)
                .Select(p => p.ProcessId)
                .Distinct()
                .ToListAsync(cancellationToken);

            // No rows means no restriction recorded, not "no access". Treating an
            // empty permission list as a filter would blank the screen for every
            // supervisor whose permissions were never set up.
            if (processIds.Count == 0)
                processIds = null;
        }

        return new ClarificationOversightScope
        {
            UserId = userId,
            RoleName = roleName,
            AllUsers = unrestricted,
            VisibleUserIds = visibleUsers,
            VisibleProcessIds = processIds,

            // Oversight roles answer on behalf of their team; an agent replying
            // to their own ticket already goes through the existing agent API.
            CanComment = unrestricted || isManager || isSupervisor,
            CanResume = unrestricted || isManager || isSupervisor,
        };
    }

    /// <summary>
    /// The agents this user may see.
    ///
    /// Supervisor -> direct reports.
    /// Manager    -> direct reports, plus anyone reporting to a supervisor who
    ///               reports to them. Two levels, resolved in two queries rather
    ///               than a recursive CTE - the hierarchy here is shallow and a
    ///               CTE would be harder to read for no benefit.
    ///
    /// Always includes the caller, so an oversight user still sees their own
    /// clarifications on the same screen.
    /// </summary>
    private async Task<List<int>> ResolveTeamAsync(
        int userId,
        bool isManager,
        bool isSupervisor,
        CancellationToken cancellationToken)
    {
        var team = new HashSet<int> { userId };

        if (!isManager && !isSupervisor)
            return team.ToList();   // agent - own tickets only

        var direct = await _db.Users.AsNoTracking()
            .Where(u => (isSupervisor && u.SupervisorId == userId)
                        || (isManager && u.ManagerId == userId))
            .Select(u => u.UserId)
            .ToListAsync(cancellationToken);

        foreach (var id in direct)
            team.Add(id);

        if (isManager && direct.Count > 0)
        {
            // Second level: agents under supervisors who report to this manager.
            var indirect = await _db.Users.AsNoTracking()
                .Where(u => u.SupervisorId != null && direct.Contains(u.SupervisorId.Value))
                .Select(u => u.UserId)
                .ToListAsync(cancellationToken);

            foreach (var id in indirect)
                team.Add(id);
        }

        return team.ToList();
    }
}
