using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

// Entity types are aliased rather than imported with a namespace-wide using.
// GTXH.OMC.Core.Entities contains a Task entity, which makes every bare
// non-generic `Task` in this file ambiguous with System.Threading.Tasks.Task.
// Generic Task<T> is unaffected, so the breakage shows up only on void-async
// methods and reads as a confusing "not all code paths return a value".
using TaskHistoryEntity = GTXH.OMC.Core.Entities.TaskHistory;
using TaskStatusEnum = GTXH.OMC.Core.Enums.TaskStatus;
using ClarificationComment = GTXH.OMC.Core.Entities.ClarificationComment;
using ClarificationUserType = GTXH.OMC.Core.Entities.ClarificationUserType;
using ClarificationTicketStatus = GTXH.OMC.Core.Entities.ClarificationTicketStatus;

namespace GTXH.OMC.Application.Services;

public sealed class ClarificationOversightService : IClarificationOversightService
{
    private const int MaxPageSize = 200;
    private const int MaxCommentLength = 4000;
    private const int AgeingHours = 24;

    /// <summary>
    /// Safety cap on rows pulled into memory. A superadmin sees every agent, so
    /// without this an unfiltered query grows unbounded as history accumulates.
    /// Hitting it means the caller should be filtering; the log line says so.
    /// </summary>
    private const int MaxMaterialisedRows = 5000;

    private readonly ApplicationDbContext _db;
    private readonly ILogger<ClarificationOversightService> _logger;

    public ClarificationOversightService(
        ApplicationDbContext db,
        ILogger<ClarificationOversightService> logger)
    {
        _db = db;
        _logger = logger;
    }

    // =====================================================================
    // SEARCH
    // =====================================================================

    public async Task<PagedClarificationOversightResponse> SearchAsync(
        ClarificationOversightScope scope,
        ClarificationOversightQueryRequest request,
        CancellationToken cancellationToken)
    {
        request ??= new ClarificationOversightQueryRequest();

        var page = request.Page < 1 ? 1 : request.Page;
        var pageSize = request.PageSize < 1 ? 25 : Math.Min(request.PageSize, MaxPageSize);

        var rows = await ApplyStateFilter(BuildProjection(scope, request), request.State)
            .Take(MaxMaterialisedRows)
            .ToListAsync(cancellationToken);

        if (rows.Count == MaxMaterialisedRows)
        {
            _logger.LogWarning(
                "Clarification oversight search for user {UserId} ({Role}) hit the {Cap}-row cap; "
                + "totals will be understated. Narrow by date, agent or process.",
                scope.UserId, scope.RoleName, MaxMaterialisedRows);
        }

        var withState = rows
            .Select(r => new { Row = r, State = DeriveState(r) })
            .Where(x => MatchesState(x.State, request.State))
            .ToList();

        if (request.MinHoursWaiting is int minHours and > 0)
        {
            var cutoff = DateTime.UtcNow.AddHours(-minHours);
            withState = withState
                .Where(x => x.Row.LastAgentCommentAt.HasValue
                            && x.Row.LastAgentCommentAt.Value <= cutoff
                            && x.State == DTOs.ClarificationState.AwaitingQa)
                .ToList();
        }

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            withState = withState.Where(x =>
                    x.Row.TicketId.ToString().Contains(term, StringComparison.OrdinalIgnoreCase)
                    || (x.Row.FirstQuestion ?? string.Empty).Contains(term, StringComparison.OrdinalIgnoreCase)
                    || (x.Row.LastCommentText ?? string.Empty).Contains(term, StringComparison.OrdinalIgnoreCase)
                    || (x.Row.ProcessName ?? string.Empty).Contains(term, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        var total = withState.Count;

        var ordered = OrderRows(
            withState.Select(x => (x.Row, x.State)),
            request.SortKey,
            request.SortDirection);

        var pageRows = ordered.Skip((page - 1) * pageSize).Take(pageSize).ToList();

        var names = await ResolveNamesAsync(pageRows.Select(p => p.Row), cancellationToken);

        return new PagedClarificationOversightResponse
        {
            Items = pageRows.Select(p => MapTicket(p.Row, p.State, names)).ToList(),
            Page = page,
            PageSize = pageSize,
            TotalCount = total,
            TotalPages = (int)Math.Ceiling(total / (double)pageSize),
        };
    }

    // =====================================================================
    // THREAD
    // =====================================================================

    public async Task<ClarificationThreadDto?> GetThreadAsync(
        ClarificationOversightScope scope,
        long ticketId,
        CancellationToken cancellationToken)
    {
        // Scope is part of the predicate, not checked afterwards. A ticket
        // belonging to another team is indistinguishable from one that does not
        // exist, so a guessed id leaks nothing.
        var exists = await BuildScopedTicketQuery(scope)
            .AnyAsync(t => t.TicketId == ticketId, cancellationToken);

        if (!exists)
            return null;

        return await BuildThreadAsync(scope, ticketId, cancellationToken);
    }

    // =====================================================================
    // COMMENT
    // =====================================================================

    public async Task<ClarificationThreadDto?> AddCommentAsync(
        ClarificationOversightScope scope,
        long ticketId,
        AddClarificationCommentRequest request,
        CancellationToken cancellationToken)
    {
        if (!scope.CanComment)
            throw new UnauthorizedAccessException("You do not have permission to comment on this clarification.");

        var text = (request?.Comment ?? string.Empty).Trim();
        if (text.Length == 0)
            throw new ArgumentException("A comment cannot be empty.");
        if (text.Length > MaxCommentLength)
            throw new ArgumentException($"A comment cannot be longer than {MaxCommentLength} characters.");

        var ticket = await LoadTicketInScopeAsync(scope, ticketId, cancellationToken);
        if (ticket is null)
            return null;

        // UTC, not DateTime.Now. CLR_Ticket_Comm is shared with the QA app, which
        // writes DateTime.UtcNow. Writing server-local here would put the two
        // halves of one thread five hours apart, and the trigger that maintains
        // LastUpdateDate from MAX(RowInsertDate) would order tickets wrongly.
        _db.ClarificationComments.Add(new ClarificationComment
        {
            TicketId = ticketId,
            UserId = scope.UserId.ToString(),
            UserType = ClarificationUserType.Agent,
            Comment = text,
            RowInsertDate = DateTime.UtcNow,
        });

        // LastUpdateDate and LastAuditorId are maintained by the database trigger
        // TR_CLR_Ticket_Comm_AfterInsert. Setting them here would race it.
        await _db.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Clarification {TicketId} commented on by {UserId} ({Role}) via oversight.",
            ticketId, scope.UserId, scope.RoleName);

        return await BuildThreadAsync(scope, ticketId, cancellationToken);
    }

    // =====================================================================
    // RESUME
    // =====================================================================

    public async Task<ClarificationThreadDto?> ResumeAsync(
        ClarificationOversightScope scope,
        long ticketId,
        CancellationToken cancellationToken)
    {
        if (!scope.CanResume)
            throw new UnauthorizedAccessException("You do not have permission to resume these tasks.");

        var ticket = await LoadTicketInScopeAsync(scope, ticketId, cancellationToken);
        if (ticket is null)
            return null;

        var taskIds = await _db.ClarificationTicketTasks.AsNoTracking()
            .Where(l => l.TicketId == ticketId)
            .Select(l => l.TaskId)
            .ToListAsync(cancellationToken);

        var blocked = await _db.Tasks
            .Where(t => taskIds.Contains(t.TaskId) && t.Status == TaskStatusEnum.Clarification)
            .ToListAsync(cancellationToken);

        if (blocked.Count == 0)
        {
            // Already resumed, by the agent or by someone else. Not an error -
            // return the current thread so the UI simply refreshes.
            return await BuildThreadAsync(scope, ticketId, cancellationToken);
        }

        // Tasks live on the agent app's own clock, which is server-local. Only
        // the shared CLR_ tables are UTC. Mixing them was the bug behind the
        // wrong working dates, so the distinction is deliberate here.
        var now = DateTime.Now;

        foreach (var task in blocked)
        {
            task.Status = TaskStatusEnum.Pending;
            task.ModifiedDate = now;

            _db.TaskHistories.Add(new TaskHistoryEntity
            {
                TaskId = task.TaskId,
                Action = "StatusChanged",
                OldValue = TaskStatusEnum.Clarification.ToString(),
                NewValue = TaskStatusEnum.Pending.ToString(),
                ChangedByUserId = scope.UserId,
                ChangedDate = now,
            });
        }

        ticket.Status = ClarificationTicketStatus.Resolved;

        await _db.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Clarification {TicketId}: {Count} task(s) resumed by {UserId} ({Role}) via oversight.",
            ticketId, blocked.Count, scope.UserId, scope.RoleName);

        return await BuildThreadAsync(scope, ticketId, cancellationToken);
    }

    // =====================================================================
    // SUMMARY
    // =====================================================================

    public async Task<ClarificationOversightSummaryDto> GetSummaryAsync(
        ClarificationOversightScope scope,
        CancellationToken cancellationToken)
    {
        var rows = await BuildProjection(scope, new ClarificationOversightQueryRequest())
            .Take(MaxMaterialisedRows)
            .ToListAsync(cancellationToken);

        var withState = rows.Select(r => new { Row = r, State = DeriveState(r) }).ToList();
        var names = await ResolveNamesAsync(withState.Select(x => x.Row), cancellationToken);
        var cutoff = DateTime.UtcNow.AddHours(-AgeingHours);
        var now = DateTime.UtcNow;

        var byAgent = withState
            .Where(x => x.Row.RaisedByUserId.HasValue)
            .GroupBy(x => x.Row.RaisedByUserId!.Value)
            .Select(g => new ClarificationAgentSummaryDto
            {
                UserId = g.Key,
                UserName = names.Agents.TryGetValue(g.Key, out var n) ? n : null,
                Received = g.Count(x => x.State == DTOs.ClarificationState.Received),
                AwaitingQa = g.Count(x => x.State == DTOs.ClarificationState.AwaitingQa),
                Closed = g.Count(x => x.State == DTOs.ClarificationState.Closed),
                Total = g.Count(),
                LongestWaitHours = g
                    .Where(x => x.State == DTOs.ClarificationState.AwaitingQa && x.Row.LastAgentCommentAt.HasValue)
                    .Select(x => (double?)Math.Round((now - x.Row.LastAgentCommentAt!.Value).TotalHours, 1))
                    .DefaultIfEmpty(null)
                    .Max(),
            })
            .OrderByDescending(a => a.AwaitingQa)
            .ThenByDescending(a => a.LongestWaitHours ?? 0)
            .ToList();

        var byProcess = withState
            .GroupBy(x => new { x.Row.ProcessId, x.Row.ProcessName })
            .Select(g => new ClarificationProcessSummaryDto
            {
                ProcessId = g.Key.ProcessId,
                ProcessName = g.Key.ProcessName,
                Received = g.Count(x => x.State == DTOs.ClarificationState.Received),
                AwaitingQa = g.Count(x => x.State == DTOs.ClarificationState.AwaitingQa),
                Closed = g.Count(x => x.State == DTOs.ClarificationState.Closed),
                Total = g.Count(),
            })
            .OrderByDescending(p => p.AwaitingQa)
            .ThenBy(p => p.ProcessName)
            .ToList();

        return new ClarificationOversightSummaryDto
        {
            Received = withState.Count(x => x.State == DTOs.ClarificationState.Received),
            AwaitingQa = withState.Count(x => x.State == DTOs.ClarificationState.AwaitingQa),
            Closed = withState.Count(x => x.State == DTOs.ClarificationState.Closed),
            Total = withState.Count,
            Ageing = withState.Count(x =>
                x.State == DTOs.ClarificationState.AwaitingQa
                && x.Row.LastAgentCommentAt.HasValue
                && x.Row.LastAgentCommentAt.Value < cutoff),
            AgentsBlocked = withState
                .Where(x => x.State != DTOs.ClarificationState.Closed && x.Row.RaisedByUserId.HasValue)
                .Select(x => x.Row.RaisedByUserId!.Value)
                .Distinct()
                .Count(),
            ByAgent = byAgent,
            ByProcess = byProcess,
        };
    }

    // =====================================================================
    // QUERY CONSTRUCTION
    // =====================================================================

    /// <summary>
    /// The ONE place scope is applied. Every read and every write goes through
    /// here or through LoadTicketInScopeAsync, so no path can query unscoped.
    ///
    /// A ticket is visible when at least one of its tasks is assigned to someone
    /// the caller may see. Ticket ownership is not stored, so it is derived from
    /// the tasks - which is also the only definition that stays correct when a
    /// ticket covers tasks for more than one agent.
    /// </summary>
    private IQueryable<Core.Entities.ClarificationTicket> BuildScopedTicketQuery(
        ClarificationOversightScope scope)
    {
        var query = _db.ClarificationTickets.AsNoTracking();

        if (!scope.AllUsers)
        {
            var users = scope.VisibleUserIds.ToList();

            query = query.Where(t =>
                (from l in _db.ClarificationTicketTasks
                 join tk in _db.Tasks on l.TaskId equals tk.TaskId
                 where l.TicketId == t.TicketId
                       && tk.AssignedUserId.HasValue
                       && users.Contains(tk.AssignedUserId.Value)
                 select l.TaskId).Any());
        }

        if (scope.VisibleProcessIds is { Count: > 0 })
        {
            var processes = scope.VisibleProcessIds.ToList();

            // Applied ON TOP of the user filter, never instead of it.
            query = query.Where(t =>
                (from l in _db.ClarificationTicketTasks
                 join tk in _db.Tasks on l.TaskId equals tk.TaskId
                 where l.TicketId == t.TicketId
                       && processes.Contains(tk.ProcessId)
                 select l.TaskId).Any());
        }

        return query;
    }

    private IQueryable<TicketRow> BuildProjection(
        ClarificationOversightScope scope,
        ClarificationOversightQueryRequest request)
    {
        var query = BuildScopedTicketQuery(scope);

        // ---- caller filters, all on top of scope -------------------------
        if (request.AgentUserId is int agentId && agentId > 0)
        {
            // A caller narrowing to an agent outside their scope still gets
            // nothing, because the scope predicate already ran above.
            query = query.Where(t =>
                (from l in _db.ClarificationTicketTasks
                 join tk in _db.Tasks on l.TaskId equals tk.TaskId
                 where l.TicketId == t.TicketId && tk.AssignedUserId == agentId
                 select l.TaskId).Any());
        }

        if (request.ProcessId is int pid && pid > 0)
        {
            query = query.Where(t =>
                (from l in _db.ClarificationTicketTasks
                 join tk in _db.Tasks on l.TaskId equals tk.TaskId
                 where l.TicketId == t.TicketId && tk.ProcessId == pid
                 select l.TaskId).Any());
        }

        if (TryParseDate(request.FromDate, out var from))
            query = query.Where(t => t.TicketCreateDate >= from);

        if (TryParseDate(request.ToDate, out var to))
        {
            var toExclusive = to.AddDays(1);
            query = query.Where(t => t.TicketCreateDate < toExclusive);
        }

        // ---- projection --------------------------------------------------
        return query.Select(t => new TicketRow
        {
            TicketId = t.TicketId,
            Status = t.Status,
            CreatedDate = t.TicketCreateDate,
            LastUpdateDate = t.LastUpdateDate,
            LastAuditorId = t.LastAuditorId,

            // Process comes from the tasks, not from CLR_Ticket.QA_ProcessId -
            // that column holds the QA process id and may be null where the
            // mapping row was missing when the ticket was raised.
            ProcessId = (from l in _db.ClarificationTicketTasks
                         join tk in _db.Tasks on l.TaskId equals tk.TaskId
                         where l.TicketId == t.TicketId
                         select (int?)tk.ProcessId).FirstOrDefault(),

            ProcessName = (from l in _db.ClarificationTicketTasks
                           join tk in _db.Tasks on l.TaskId equals tk.TaskId
                           join p in _db.Processes on tk.ProcessId equals p.ProcessId
                           where l.TicketId == t.TicketId
                           select p.ProcessName).FirstOrDefault(),

            RaisedByUserId = (from l in _db.ClarificationTicketTasks
                              join tk in _db.Tasks on l.TaskId equals tk.TaskId
                              where l.TicketId == t.TicketId && tk.AssignedUserId.HasValue
                              select tk.AssignedUserId).FirstOrDefault(),

            TaskCount = _db.ClarificationTicketTasks.Count(l => l.TicketId == t.TicketId),

            BlockedTaskCount = (from l in _db.ClarificationTicketTasks
                                join tk in _db.Tasks on l.TaskId equals tk.TaskId
                                where l.TicketId == t.TicketId
                                      && tk.Status == TaskStatusEnum.Clarification
                                select l.TaskId).Count(),

            CommentCount = _db.ClarificationComments.Count(c => c.TicketId == t.TicketId),

            FirstQuestion = _db.ClarificationComments
                .Where(c => c.TicketId == t.TicketId && c.UserType == ClarificationUserType.Agent)
                .OrderBy(c => c.RowInsertDate).ThenBy(c => c.CommId)
                .Select(c => c.Comment)
                .FirstOrDefault(),

            LastCommentType = _db.ClarificationComments
                .Where(c => c.TicketId == t.TicketId)
                .OrderByDescending(c => c.RowInsertDate).ThenByDescending(c => c.CommId)
                .Select(c => c.UserType)
                .FirstOrDefault(),

            LastCommentText = _db.ClarificationComments
                .Where(c => c.TicketId == t.TicketId)
                .OrderByDescending(c => c.RowInsertDate).ThenByDescending(c => c.CommId)
                .Select(c => c.Comment)
                .FirstOrDefault(),

            LastAgentCommentAt = _db.ClarificationComments
                .Where(c => c.TicketId == t.TicketId && c.UserType == ClarificationUserType.Agent)
                .Max(c => (DateTime?)c.RowInsertDate),
        });
    }

    private async Task<Core.Entities.ClarificationTicket?> LoadTicketInScopeAsync(
        ClarificationOversightScope scope,
        long ticketId,
        CancellationToken cancellationToken)
    {
        // Tracked, because callers mutate it. Scope still comes from the shared
        // predicate so writes cannot reach a ticket reads could not.
        var visible = await BuildScopedTicketQuery(scope)
            .AnyAsync(t => t.TicketId == ticketId, cancellationToken);

        if (!visible)
            return null;

        return await _db.ClarificationTickets
            .FirstOrDefaultAsync(t => t.TicketId == ticketId, cancellationToken);
    }

    // =====================================================================
    // THREAD ASSEMBLY
    //
    // Returns the SAME ClarificationThreadDto the agent screen already renders,
    // so the oversight page reuses that component unchanged.
    // =====================================================================

    private async Task<ClarificationThreadDto?> BuildThreadAsync(
        ClarificationOversightScope scope,
        long ticketId,
        CancellationToken cancellationToken)
    {
        var row = await BuildProjection(scope, new ClarificationOversightQueryRequest())
            .Where(r => r.TicketId == ticketId)
            .FirstOrDefaultAsync(cancellationToken);

        if (row is null)
            return null;

        var comments = await LoadCommentsAsync(ticketId, cancellationToken);
        var tasks = await LoadTasksAsync(ticketId, cancellationToken);
        var names = await ResolveNamesAsync(new[] { row }, cancellationToken);
        var state = DeriveState(row);

        return new ClarificationThreadDto
        {
            TicketId = row.TicketId,
            State = state,
            ProcessName = row.ProcessName,
            CreatedDate = row.CreatedDate,
            LastUpdateDate = row.LastUpdateDate,
            Comments = comments,
            Tasks = tasks,
        };
    }

    private async Task<List<ClarificationCommentDto>> LoadCommentsAsync(
        long ticketId,
        CancellationToken cancellationToken)
    {
        var raw = await _db.ClarificationComments.AsNoTracking()
            .Where(c => c.TicketId == ticketId)
            .OrderBy(c => c.RowInsertDate).ThenBy(c => c.CommId)
            .Select(c => new { c.CommId, c.UserId, c.UserType, c.Comment, c.RowInsertDate })
            .ToListAsync(cancellationToken);

        var agentIds = raw
            .Where(c => string.Equals(c.UserType, ClarificationUserType.Agent, StringComparison.OrdinalIgnoreCase))
            .Select(c => int.TryParse(c.UserId, out var v) ? v : (int?)null)
            .Where(v => v.HasValue).Select(v => v!.Value).Distinct().ToList();

        var auditorIds = raw
            .Where(c => string.Equals(c.UserType, ClarificationUserType.Auditor, StringComparison.OrdinalIgnoreCase))
            .Select(c => c.UserId).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().ToList();

        var agentNames = await LoadAgentNamesAsync(agentIds, cancellationToken);
        var auditorNames = await LoadAuditorNamesAsync(auditorIds!, cancellationToken);

        return raw.Select(c =>
        {
            var isAgent = string.Equals(c.UserType, ClarificationUserType.Agent, StringComparison.OrdinalIgnoreCase);
            string? name = null;

            if (isAgent && int.TryParse(c.UserId, out var uid))
                agentNames.TryGetValue(uid, out name);
            else if (!isAgent && c.UserId is not null)
                auditorNames.TryGetValue(c.UserId, out name);

            return new ClarificationCommentDto
            {
                CommentId = c.CommId,
                UserType = c.UserType ?? string.Empty,
                UserName = name ?? (isAgent ? "Agent" : "Auditor"),
                Comment = c.Comment ?? string.Empty,
                CreatedDate = c.RowInsertDate,
            };
        }).ToList();
    }

    private async Task<List<ClarificationTaskDto>> LoadTasksAsync(
        long ticketId,
        CancellationToken cancellationToken)
    {
        var rows = await (from l in _db.ClarificationTicketTasks.AsNoTracking()
                          join tk in _db.Tasks.AsNoTracking() on l.TaskId equals tk.TaskId
                          where l.TicketId == ticketId
                          select new
                          {
                              tk.TaskId,
                              tk.ExternalRef,
                              tk.Status,
                              tk.TaskData,
                              tk.ProcessId,
                          })
            .ToListAsync(cancellationToken);

        return rows.Select(r => new ClarificationTaskDto
        {
            TaskId = r.TaskId,
            ExternalRef = r.ExternalRef,
            Status = r.Status.ToString(),
            IsBlocked = r.Status == TaskStatusEnum.Clarification,
            TaskData = r.TaskData,
            ProcessId = r.ProcessId,
        }).ToList();
    }

    // =====================================================================
    // NAME RESOLUTION
    //
    // Matched in memory, case-insensitively for auditors. A SQL join on
    // CAST(Id AS nvarchar) was tried on this codebase before and silently
    // matched nothing when the stored formatting differed - every name came
    // back as the literal "Auditor".
    // =====================================================================

    private async Task<Dictionary<int, string?>> LoadAgentNamesAsync(
        List<int> ids,
        CancellationToken cancellationToken)
    {
        if (ids.Count == 0)
            return new Dictionary<int, string?>();

        var rows = await _db.Users.AsNoTracking()
            .Where(u => ids.Contains(u.UserId))
            .Select(u => new { u.UserId, u.FirstName, u.LastName, u.Username })
            .ToListAsync(cancellationToken);

        return rows.ToDictionary(
            r => r.UserId,
            r => string.IsNullOrWhiteSpace(r.FirstName) && string.IsNullOrWhiteSpace(r.LastName)
                ? r.Username
                : $"{r.FirstName} {r.LastName}".Trim());
    }

    private async Task<Dictionary<string, string?>> LoadAuditorNamesAsync(
        List<string> ids,
        CancellationToken cancellationToken)
    {
        if (ids.Count == 0)
            return new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);

        var all = await _db.QaUsers.AsNoTracking()
            .Select(u => new { u.Id, u.Name })
            .ToListAsync(cancellationToken);

        var wanted = new HashSet<string>(ids, StringComparer.OrdinalIgnoreCase);

        return all
            .Where(r => r.Id != null && wanted.Contains(r.Id))
            .GroupBy(r => r.Id!, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First().Name, StringComparer.OrdinalIgnoreCase);
    }

    private async Task<NameLookup> ResolveNamesAsync(
        IEnumerable<TicketRow> rows,
        CancellationToken cancellationToken)
    {
        var list = rows.ToList();

        var agentIds = list.Where(r => r.RaisedByUserId.HasValue)
            .Select(r => r.RaisedByUserId!.Value).Distinct().ToList();

        var auditorIds = list.Select(r => r.LastAuditorId)
            .Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().ToList();

        return new NameLookup
        {
            Agents = await LoadAgentNamesAsync(agentIds, cancellationToken),
            Auditors = await LoadAuditorNamesAsync(auditorIds!, cancellationToken),
        };
    }

    // =====================================================================
    // DERIVATION
    //
    // THE TWO METHODS BELOW ENCODE THE SAME RULE AND MUST STAY IN STEP.
    // DeriveState decides what a row IS, in memory, for display.
    // ApplyStateFilter decides which rows COME BACK, in SQL, so a superadmin
    // asking for one state does not materialise every closed ticket first.
    // Change one, change the other.
    //
    // These values match the agent-side ClarificationService exactly, so the
    // oversight screen and the agent screen can never disagree about a ticket.
    // =====================================================================

    private static string DeriveState(TicketRow r)
    {
        // Nothing blocked any more - the work moved on, whoever resumed it.
        if (r.BlockedTaskCount == 0)
            return DTOs.ClarificationState.Closed;

        if (string.Equals(r.Status, ClarificationTicketStatus.Resolved, StringComparison.OrdinalIgnoreCase))
            return DTOs.ClarificationState.Received;

        // QA wrote last, so there is an answer waiting to be read.
        if (string.Equals(r.LastCommentType, ClarificationUserType.Auditor, StringComparison.OrdinalIgnoreCase))
            return DTOs.ClarificationState.Received;

        return DTOs.ClarificationState.AwaitingQa;
    }

    /// <summary>SQL-side twin of DeriveState. Keep the two in step.</summary>
    private static IQueryable<TicketRow> ApplyStateFilter(IQueryable<TicketRow> q, string? state)
    {
        var s = (state ?? string.Empty).Trim();

        if (s.Length == 0 || string.Equals(s, DTOs.ClarificationState.All, StringComparison.OrdinalIgnoreCase))
            return q;

        if (string.Equals(s, DTOs.ClarificationState.Closed, StringComparison.OrdinalIgnoreCase))
            return q.Where(r => r.BlockedTaskCount == 0);

        var open = q.Where(r => r.BlockedTaskCount > 0);

        if (string.Equals(s, DTOs.ClarificationState.Received, StringComparison.OrdinalIgnoreCase))
        {
            return open.Where(r =>
                r.Status == ClarificationTicketStatus.Resolved
                || r.LastCommentType == ClarificationUserType.Auditor);
        }

        if (string.Equals(s, DTOs.ClarificationState.AwaitingQa, StringComparison.OrdinalIgnoreCase))
        {
            return open.Where(r =>
                r.Status != ClarificationTicketStatus.Resolved
                && (r.LastCommentType == null || r.LastCommentType != ClarificationUserType.Auditor));
        }

        // Unrecognised state - return everything and let MatchesState decide,
        // rather than silently returning nothing.
        return q;
    }

    private static bool MatchesState(string state, string? requested)
    {
        if (string.IsNullOrWhiteSpace(requested)
            || string.Equals(requested, DTOs.ClarificationState.All, StringComparison.OrdinalIgnoreCase))
            return true;

        return string.Equals(state, requested.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    private static IEnumerable<(TicketRow Row, string State)> OrderRows(
        IEnumerable<(TicketRow Row, string State)> rows,
        string? sortKey,
        string? sortDirection)
    {
        var desc = string.Equals(sortDirection, "desc", StringComparison.OrdinalIgnoreCase);
        var key = (sortKey ?? string.Empty).Trim().ToLowerInvariant();

        return key switch
        {
            "ticketid" => desc
                ? rows.OrderByDescending(r => r.Row.TicketId)
                : rows.OrderBy(r => r.Row.TicketId),

            "agent" or "raisedby" => desc
                ? rows.OrderByDescending(r => r.Row.RaisedByUserId)
                : rows.OrderBy(r => r.Row.RaisedByUserId),

            "process" or "processname" => desc
                ? rows.OrderByDescending(r => r.Row.ProcessName)
                : rows.OrderBy(r => r.Row.ProcessName),

            "created" or "createddate" => desc
                ? rows.OrderByDescending(r => r.Row.CreatedDate)
                : rows.OrderBy(r => r.Row.CreatedDate),

            "tasks" or "taskcount" => desc
                ? rows.OrderByDescending(r => r.Row.TaskCount)
                : rows.OrderBy(r => r.Row.TaskCount),

            // Default: longest-waiting unanswered first. A supervisor opens this
            // screen to find who is stuck, not to read the newest ticket.
            _ => desc
                ? rows.OrderByDescending(r => r.Row.LastUpdateDate ?? r.Row.CreatedDate)
                : rows.OrderBy(r => r.State == DTOs.ClarificationState.AwaitingQa ? 0 : 1)
                      .ThenBy(r => r.Row.LastAgentCommentAt ?? r.Row.CreatedDate),
        };
    }

    private static ClarificationOversightTicketDto MapTicket(TicketRow r, string state, NameLookup names)
    {
        double? hoursWaiting = null;
        if (state == DTOs.ClarificationState.AwaitingQa && r.LastAgentCommentAt.HasValue)
            hoursWaiting = Math.Round((DateTime.UtcNow - r.LastAgentCommentAt.Value).TotalHours, 1);

        return new ClarificationOversightTicketDto
        {
            TicketId = r.TicketId,
            ProcessId = r.ProcessId,
            ProcessName = r.ProcessName,
            State = state,
            CreatedDate = r.CreatedDate,
            LastUpdateDate = r.LastUpdateDate,
            RaisedByUserId = r.RaisedByUserId,
            RaisedByName = r.RaisedByUserId.HasValue
                           && names.Agents.TryGetValue(r.RaisedByUserId.Value, out var an) ? an : null,
            LastAuditorId = r.LastAuditorId,
            LastAuditorName = r.LastAuditorId is not null
                              && names.Auditors.TryGetValue(r.LastAuditorId, out var qn) ? qn : null,
            TaskCount = r.TaskCount,
            BlockedTaskCount = r.BlockedTaskCount,
            CommentCount = r.CommentCount,
            FirstQuestion = r.FirstQuestion,
            LastComment = r.LastCommentText,
            LastCommentBy = r.LastCommentType,
            HoursWaiting = hoursWaiting,
        };
    }

    private static bool TryParseDate(string? value, out DateTime date)
    {
        date = default;
        if (string.IsNullOrWhiteSpace(value))
            return false;
        return DateTime.TryParse(value.Trim(), out date);
    }

    // =====================================================================
    // INTERNAL SHAPES
    // =====================================================================

    private sealed class TicketRow
    {
        public long TicketId { get; init; }
        public string? Status { get; init; }
        public int? ProcessId { get; init; }
        public string? ProcessName { get; init; }
        public DateTime CreatedDate { get; init; }
        public DateTime? LastUpdateDate { get; init; }
        public string? LastAuditorId { get; init; }
        public int? RaisedByUserId { get; init; }
        public int TaskCount { get; init; }
        public int BlockedTaskCount { get; init; }
        public int CommentCount { get; init; }
        public string? FirstQuestion { get; init; }
        public string? LastCommentType { get; init; }
        public string? LastCommentText { get; init; }
        public DateTime? LastAgentCommentAt { get; init; }
    }

    private sealed class NameLookup
    {
        public Dictionary<int, string?> Agents { get; init; } = new();
        public Dictionary<string, string?> Auditors { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    }
}
