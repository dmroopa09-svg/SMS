namespace GTXH.OMC.Application.DTOs;

// =========================================================================
// These REUSE the existing clarification DTOs wherever possible, so the
// Clarifications page the agents already use renders an oversight response
// without changing a line of its table code.
//
// Only the pieces management needs that agents do not are new.
// =========================================================================

/// <summary>
/// Query for the oversight list. Mirrors ClarificationQueryRequest and adds the
/// two filters that only make sense when you can see more than your own work.
/// </summary>
public class ClarificationOversightQueryRequest
{
    /// <summary>One of ClarificationState. Null or "All" returns everything in scope.</summary>
    public string? State { get; set; }

    /// <summary>Narrow to one agent. Ignored when outside the caller's visible set.</summary>
    public int? AgentUserId { get; set; }

    /// <summary>Narrow to one agent process.</summary>
    public int? ProcessId { get; set; }

    public string? Search { get; set; }

    /// <summary>Ticket creation date, inclusive, yyyy-MM-dd.</summary>
    public string? FromDate { get; set; }
    public string? ToDate { get; set; }

    /// <summary>Only tickets with no QA reply for more than this many hours.</summary>
    public int? MinHoursWaiting { get; set; }

    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 25;

    public string? SortKey { get; set; }
    public string? SortDirection { get; set; }
}

/// <summary>
/// ADD THESE THREE PROPERTIES to the existing ClarificationTicketDto rather than
/// creating a parallel type. They are nullable and the agent screen ignores
/// fields it does not render, so adding them breaks nothing:
///
///     public string? RaisedByName  { get; set; }
///     public int?    RaisedByUserId { get; set; }
///     public double? HoursWaiting  { get; set; }
///
/// If you would rather not touch that file, this type carries the same shape
/// plus the extras and the oversight endpoints can return it instead.
/// </summary>
public class ClarificationOversightTicketDto
{
    public long TicketId { get; set; }

    public int? ProcessId { get; set; }
    public string? ProcessName { get; set; }

    /// <summary>Received / AwaitingQa / Closed - same values as the agent screen.</summary>
    public string State { get; set; } = string.Empty;

    public DateTime CreatedDate { get; set; }
    public DateTime? LastUpdateDate { get; set; }

    /// <summary>The agent who raised it. This is the column oversight adds.</summary>
    public int? RaisedByUserId { get; set; }
    public string? RaisedByName { get; set; }

    public string? LastAuditorId { get; set; }
    public string? LastAuditorName { get; set; }

    public int TaskCount { get; set; }

    /// <summary>Of those, how many are still blocked in Clarification.</summary>
    public int BlockedTaskCount { get; set; }

    public int CommentCount { get; set; }

    public string? FirstQuestion { get; set; }
    public string? LastComment { get; set; }
    public string? LastCommentBy { get; set; }

    /// <summary>
    /// Hours since the agent's last unanswered message. Null once QA has
    /// replied. Lets a supervisor spot a stalled ticket without opening it.
    /// </summary>
    public double? HoursWaiting { get; set; }
}

public class PagedClarificationOversightResponse
{
    public List<ClarificationOversightTicketDto> Items { get; set; } = new();
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages { get; set; }
}

/// <summary>
/// Counts for the oversight header. Extends the agent summary with the
/// per-agent breakdown, which is the question a supervisor actually opens this
/// screen to answer: who is blocked, and for how long.
/// </summary>
public class ClarificationOversightSummaryDto
{
    public int Received { get; set; }
    public int AwaitingQa { get; set; }
    public int Closed { get; set; }
    public int Total { get; set; }

    /// <summary>AwaitingQa tickets with no reply for more than 24 hours.</summary>
    public int Ageing { get; set; }

    /// <summary>Agents in scope who currently have at least one open clarification.</summary>
    public int AgentsBlocked { get; set; }

    public List<ClarificationAgentSummaryDto> ByAgent { get; set; } = new();
    public List<ClarificationProcessSummaryDto> ByProcess { get; set; } = new();
}

public class ClarificationAgentSummaryDto
{
    public int UserId { get; set; }
    public string? UserName { get; set; }
    public int Received { get; set; }
    public int AwaitingQa { get; set; }
    public int Closed { get; set; }
    public int Total { get; set; }

    /// <summary>Longest current wait for this agent, in hours.</summary>
    public double? LongestWaitHours { get; set; }
}

public class ClarificationProcessSummaryDto
{
    public int? ProcessId { get; set; }
    public string? ProcessName { get; set; }
    public int Received { get; set; }
    public int AwaitingQa { get; set; }
    public int Closed { get; set; }
    public int Total { get; set; }
}

/// <summary>What the signed-in user may see and do, for the UI to render once.</summary>
public class ClarificationScopeDto
{
    public string RoleName { get; set; } = string.Empty;
    public bool AllUsers { get; set; }
    public bool IsOversight { get; set; }
    public int VisibleAgentCount { get; set; }
    public bool CanComment { get; set; }
    public bool CanResume { get; set; }
}
