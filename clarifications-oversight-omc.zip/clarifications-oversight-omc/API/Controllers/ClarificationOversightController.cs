using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Application.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace GTXH.OMC.API.Controllers;

/// <summary>
/// Clarification oversight for supervisors, managers and superadmins.
///
/// Mounted under api/clarifications/team so the existing agent endpoints at
/// api/clarifications are untouched. Those are in production; nothing here can
/// regress the flow agents use every day.
///
/// There is no [Authorize(Roles = ...)] on any action on purpose. Role and team
/// come from the database through ClarificationOversightScopeResolver, so
/// someone moved off a team this morning stops seeing it immediately rather than
/// when their token expires. A role attribute would read the token and undo that.
///
/// Responses reuse the same DTOs the agent Clarifications page already renders,
/// so the UI is the same component pointed at a different base path.
/// </summary>
[ApiController]
[Route("api/clarifications/team")]
[Authorize]
public class ClarificationOversightController : ControllerBase
{
    private readonly IClarificationOversightService _service;
    private readonly ClarificationOversightScopeResolver _scopeResolver;
    private readonly ILogger<ClarificationOversightController> _logger;

    public ClarificationOversightController(
        IClarificationOversightService service,
        ClarificationOversightScopeResolver scopeResolver,
        ILogger<ClarificationOversightController> logger)
    {
        _service = service;
        _scopeResolver = scopeResolver;
        _logger = logger;
    }

    // =====================================================================

    /// <summary>Paged ticket list across every agent the caller may see.</summary>
    [HttpPost("search")]
    public async Task<ActionResult<PagedClarificationOversightResponse>> Search(
        [FromBody] ClarificationOversightQueryRequest request,
        CancellationToken cancellationToken)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        try
        {
            return Ok(await _service.SearchAsync(
                scope, request ?? new ClarificationOversightQueryRequest(), cancellationToken));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error searching team clarifications");
            return StatusCode(500, new { error = new { message = "An error occurred while loading clarifications" } });
        }
    }

    /// <summary>Query-string form of search, so links stay shareable between supervisors.</summary>
    [HttpGet]
    public async Task<ActionResult<PagedClarificationOversightResponse>> List(
        [FromQuery] string? state,
        [FromQuery] int? agentUserId,
        [FromQuery] int? processId,
        [FromQuery] string? search,
        [FromQuery] string? fromDate,
        [FromQuery] string? toDate,
        [FromQuery] int? minHoursWaiting,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 25,
        [FromQuery] string? sortKey = null,
        [FromQuery] string? sortDirection = null,
        CancellationToken cancellationToken = default)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        var request = new ClarificationOversightQueryRequest
        {
            State = state,
            AgentUserId = agentUserId,
            ProcessId = processId,
            Search = search,
            FromDate = fromDate,
            ToDate = toDate,
            MinHoursWaiting = minHoursWaiting,
            Page = page,
            PageSize = pageSize,
            SortKey = sortKey,
            SortDirection = sortDirection,
        };

        try
        {
            return Ok(await _service.SearchAsync(scope, request, cancellationToken));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing team clarifications");
            return StatusCode(500, new { error = new { message = "An error occurred while loading clarifications" } });
        }
    }

    /// <summary>One ticket with its thread and tasks.</summary>
    [HttpGet("{ticketId:long}")]
    public async Task<ActionResult<ClarificationThreadDto>> GetThread(
        long ticketId,
        CancellationToken cancellationToken)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        try
        {
            var thread = await _service.GetThreadAsync(scope, ticketId, cancellationToken);

            // Out of scope and non-existent both return 404 on purpose - a
            // guessed ticket id must not confirm that another team has one.
            if (thread is null)
                return NotFound(new { error = new { code = "TICKET_NOT_FOUND", message = "Clarification not found." } });

            return Ok(thread);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading team clarification {TicketId}", ticketId);
            return StatusCode(500, new { error = new { message = "An error occurred while loading the clarification" } });
        }
    }

    /// <summary>Comment on a team member's ticket.</summary>
    [HttpPost("{ticketId:long}/comments")]
    public async Task<ActionResult<ClarificationThreadDto>> AddComment(
        long ticketId,
        [FromBody] AddClarificationCommentRequest request,
        CancellationToken cancellationToken)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        try
        {
            var thread = await _service.AddCommentAsync(scope, ticketId, request, cancellationToken);
            if (thread is null)
                return NotFound(new { error = new { code = "TICKET_NOT_FOUND", message = "Clarification not found." } });

            return Ok(thread);
        }
        catch (UnauthorizedAccessException ex)
        {
            return StatusCode(403, new { error = new { code = "FORBIDDEN", message = ex.Message } });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = new { code = "INVALID_COMMENT", message = ex.Message } });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error commenting on team clarification {TicketId}", ticketId);
            return StatusCode(500, new { error = new { message = "An error occurred while saving the comment" } });
        }
    }

    /// <summary>Resume the blocked tasks on a team member's ticket.</summary>
    [HttpPost("{ticketId:long}/resume")]
    public async Task<ActionResult<ClarificationThreadDto>> Resume(
        long ticketId,
        CancellationToken cancellationToken)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        try
        {
            var thread = await _service.ResumeAsync(scope, ticketId, cancellationToken);
            if (thread is null)
                return NotFound(new { error = new { code = "TICKET_NOT_FOUND", message = "Clarification not found." } });

            return Ok(thread);
        }
        catch (UnauthorizedAccessException ex)
        {
            return StatusCode(403, new { error = new { code = "FORBIDDEN", message = ex.Message } });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error resuming team clarification {TicketId}", ticketId);
            return StatusCode(500, new { error = new { message = "An error occurred while resuming the tasks" } });
        }
    }

    /// <summary>Counts for the oversight header, including the per-agent breakdown.</summary>
    [HttpGet("summary")]
    public async Task<ActionResult<ClarificationOversightSummaryDto>> GetSummary(
        CancellationToken cancellationToken)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        try
        {
            return Ok(await _service.GetSummaryAsync(scope, cancellationToken));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading team clarification summary");

            // The badge poller calls this every minute. Returning zeros rather
            // than a 500 keeps one transient blip from putting an error toast in
            // front of every supervisor at once.
            return Ok(new ClarificationOversightSummaryDto());
        }
    }

    /// <summary>
    /// What the signed-in user may see and do.
    ///
    /// Call this once on load: the same Clarifications page then serves an agent,
    /// a supervisor and a superadmin by hiding controls rather than branching on
    /// a role string the frontend would have to be told about separately.
    /// IsOversight false means this user should stay on the agent endpoints.
    /// </summary>
    [HttpGet("scope")]
    public async Task<ActionResult<ClarificationScopeDto>> GetScope(
        CancellationToken cancellationToken)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        return Ok(new ClarificationScopeDto
        {
            RoleName = scope.RoleName,
            AllUsers = scope.AllUsers,
            IsOversight = scope.IsOversight,
            VisibleAgentCount = scope.AllUsers ? -1 : scope.VisibleUserIds.Count,
            CanComment = scope.CanComment,
            CanResume = scope.CanResume,
        });
    }

    /// <summary>
    /// Agents in scope, for the filter dropdown. Saves the UI inventing its own
    /// user list and accidentally offering someone the caller cannot see.
    /// </summary>
    [HttpGet("agents")]
    public async Task<IActionResult> GetAgents(CancellationToken cancellationToken)
    {
        var scope = await ResolveScopeAsync(cancellationToken);
        if (scope is null)
            return Forbid();

        var agents = await _service.GetSummaryAsync(scope, cancellationToken);

        return Ok(agents.ByAgent
            .Select(a => new { userId = a.UserId, userName = a.UserName })
            .OrderBy(a => a.userName)
            .ToList());
    }

    // =====================================================================

    private async Task<ClarificationOversightScope?> ResolveScopeAsync(CancellationToken cancellationToken)
    {
        var claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                    ?? User.FindFirst("UserId")?.Value;

        if (!int.TryParse(claim, out var userId))
            return null;

        return await _scopeResolver.ResolveAsync(userId, cancellationToken);
    }
}
