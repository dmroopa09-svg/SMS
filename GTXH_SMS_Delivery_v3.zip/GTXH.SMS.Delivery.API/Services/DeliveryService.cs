using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Consumes ReadyToSend and submits to the provider.
///
/// THE GUARD IS A CONDITIONAL UPDATE, NOT A SEPARATE TABLE.
///
/// MessageId IS SMS_Queue_Detail.ID — the primary key — so uniqueness is
/// already guaranteed by the row. The claim is:
///
///     UPDATE ... SET LifecycleState = Submitting
///     WHERE ID = @id AND LifecycleState = ReadyForDelivery
///
/// One statement, atomic. Rows affected = 1 means we won and may send; 0 means
/// another instance already has it, or a replay arrived for something already
/// handled. Either way we stop.
///
/// This is what makes a Kafka replay safe. Compliance publishes BEFORE it
/// persists the hold as Released, so a crash republishes; a consumer rebalance
/// replays too. Both land here, and only the first one can move the row out of
/// ReadyForDelivery.
/// </summary>
public sealed class DeliveryService(
    DeliveryDbContext db,
    IWebexSmsClient client,
    DeliveryOptions options,
    DeliveryRateLimiter rateLimiter,
    ILogger<DeliveryService> logger)
{
    private static int _sentThisProcess;

    private readonly string _instanceId =
        $"{Environment.MachineName}:{Environment.ProcessId}";

    public async Task HandleReadyAsync(ReadyToSendEvent message, CancellationToken ct)
    {
        var campaignQueueId = message.CampaignQueueId ?? 0;
        var now = DateTime.UtcNow;

        // -----------------------------------------------------------------
        // 1. CAMPAIGN STATE — the stop switch.
        //
        // Read fresh per message, never cached. A campaign stopped thirty
        // seconds ago must not keep sending because a cache has not expired.
        // -----------------------------------------------------------------
        var campaign = await db.CampaignQueue.AsNoTracking()
            .FirstOrDefaultAsync(c => c.ID == (int)campaignQueueId, ct);

        if (campaign is null)
        {
            logger.LogWarning("Campaign queue {Id} not found for message {MessageId}.",
                campaignQueueId, message.MessageId);
            return;
        }

        if (campaign.State is not (CampaignState.Ready or CampaignState.Running))
        {
            logger.LogInformation(
                "Campaign {Id} is {State}; not sending message {MessageId}.",
                campaignQueueId, campaign.State, message.MessageId);
            return;
        }

        // -----------------------------------------------------------------
        // 2. CLAIM — the duplicate guard.
        //
        // Only a row still in ReadyForDelivery can be taken, and taking it
        // moves it out in the same statement. A second arrival of the same
        // message affects zero rows and stops here.
        // -----------------------------------------------------------------
        var claimed = await db.CampaignMembers
            .Where(m => m.ID == message.MessageId
                     && m.LifecycleState == MessageLifecycleState.ReadyForDelivery
                     && m.Sent_Timestamp_UTC == null)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LifecycleState, MessageLifecycleState.Submitting)
                .SetProperty(m => m.Status, CampaignMemberStatus.Processing)
                .SetProperty(m => m.ClaimedAt, now)
                .SetProperty(m => m.RowUpdatedDt, now), ct);

        if (claimed == 0)
        {
            logger.LogInformation(
                "Message {MessageId} was not claimable — already handled or in flight elsewhere.",
                message.MessageId);
            return;
        }

        // -----------------------------------------------------------------
        // 3. LOAD THE ROW
        //
        // Message text comes from the ROW, not the event. The row is current;
        // the event is a snapshot from whenever it was published.
        // -----------------------------------------------------------------
        var member = await db.CampaignMembers.AsNoTracking()
            .FirstOrDefaultAsync(m => m.ID == message.MessageId, ct);

        if (member is null)
        {
            logger.LogError("Message {MessageId} vanished after claim.", message.MessageId);
            return;
        }

        if (string.IsNullOrWhiteSpace(member.MessageText))
        {
            await FailAsync(member, "MESSAGE_TEXT_EMPTY", transient: false, ct);
            return;
        }

        var phone = member.Phone ?? message.Phone;
        if (string.IsNullOrWhiteSpace(phone))
        {
            await FailAsync(member, "PHONE_MISSING", transient: false, ct);
            return;
        }

        // -----------------------------------------------------------------
        // 4. PROCESS CEILING — a testing circuit breaker.
        //
        // ⚠ PER PROCESS, NOT GLOBAL. Two people running the service at once get
        // two ceilings. Coordinate before testing.
        // -----------------------------------------------------------------
        if (options.MaxSendsPerProcess > 0
            && Interlocked.Increment(ref _sentThisProcess) > options.MaxSendsPerProcess)
        {
            logger.LogError(
                "Process send ceiling of {Max} reached; message {MessageId} not sent.",
                options.MaxSendsPerProcess, message.MessageId);

            await ReleaseAsync(member.ID, "PROCESS_SEND_CEILING", ct);
            return;
        }

        // -----------------------------------------------------------------
        // 5. SUBMIT
        // -----------------------------------------------------------------
        var destination = phone;

        if (!string.IsNullOrWhiteSpace(options.RedirectAllToNumber))
        {
            logger.LogWarning(
                "TEST REDIRECT: message {MessageId} intended for ***{Intended} sent to {Redirect}.",
                message.MessageId,
                phone.Length >= 4 ? phone[^4..] : "****",
                options.RedirectAllToNumber);

            destination = options.RedirectAllToNumber!;
        }

        await rateLimiter.WaitAsync(ct);

        var result = await client.SendAsync(new WebexSendRequest
        {
            SmsId = member.ID.ToString(),
            Phone = destination,
            MessageText = member.MessageText!,
            ZipCode = member.ZipCode,
            AccountInfoId = member.Account_Info_ID?.ToString(),
            LeadAccountId = member.AccountID.ToString(),
            CampaignPhoneNumber = campaign.OutboundPhoneNumber
        }, ct);

        if (result.Accepted)
            await AcceptAsync(member, result, ct);
        else
            await FailAsync(member, result.ResponseMessage ?? "SEND_FAILED", result.IsTransient, ct, result);
    }

    // =====================================================================

    private async Task AcceptAsync(
        CampaignMemberEntity member, WebexSendResult result, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var code = result.ResponseCode;
        var providerId = result.ProviderMessageId;

        await db.CampaignMembers
            .Where(m => m.ID == member.ID)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LifecycleState, MessageLifecycleState.Submitted)
                .SetProperty(m => m.Status, CampaignMemberStatus.Emitted)
                .SetProperty(m => m.ProviderMessageId, providerId)
                .SetProperty(m => m.ResponseCode, code)
                .SetProperty(m => m.ResponseMessage, "Queued")
                .SetProperty(m => m.Sent_Timestamp_UTC, now)
                .SetProperty(m => m.AttemptCount, m => m.AttemptCount + 1)
                .SetProperty(m => m.ClaimedAt, (DateTime?)null)
                .SetProperty(m => m.RowUpdatedDt, now), ct);

        logger.LogInformation(
            "Submitted message {MessageId} transid={TransId} in {Ms}ms",
            member.ID, providerId, result.DurationMs);
    }

    private async Task FailAsync(
        CampaignMemberEntity member,
        string reason,
        bool transient,
        CancellationToken ct,
        WebexSendResult? result = null)
    {
        var now = DateTime.UtcNow;
        var attempt = member.AttemptCount + 1;
        var exhausted = attempt >= options.MaxAttempts;
        var terminal = !transient || exhausted;

        // Hoisted — ExecuteUpdateAsync builds an expression tree and ?. is not
        // legal inside one.
        var code = result?.ResponseCode;
        var text = Truncate(reason, 1000);

        // Terminal -> Failed. Retryable -> back to ReadyForDelivery so the
        // retry worker can pick it up again.
        var newState = terminal
            ? MessageLifecycleState.Failed
            : MessageLifecycleState.ReadyForDelivery;

        var newStatus = terminal
            ? CampaignMemberStatus.Skipped
            : CampaignMemberStatus.Pending;

        await db.CampaignMembers
            .Where(m => m.ID == member.ID)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LifecycleState, newState)
                .SetProperty(m => m.Status, newStatus)
                .SetProperty(m => m.ResponseCode, code)
                .SetProperty(m => m.ResponseMessage, text)
                .SetProperty(m => m.AttemptCount, attempt)
                .SetProperty(m => m.ClaimedAt, (DateTime?)null)
                .SetProperty(m => m.RowUpdatedDt, now), ct);

        if (terminal)
            logger.LogWarning(
                "Message {MessageId} failed terminally after {Attempt} attempt(s): {Reason}",
                member.ID, attempt, reason);
        else
            logger.LogWarning(
                "Transient failure for message {MessageId} (attempt {Attempt} of {Max}): {Reason}",
                member.ID, attempt, options.MaxAttempts, reason);
    }

    /// <summary>
    /// Puts a claimed row back without counting an attempt — used when we
    /// declined to send rather than tried and failed.
    /// </summary>
    private async Task ReleaseAsync(long messageId, string reason, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var text = Truncate(reason, 1000);

        await db.CampaignMembers
            .Where(m => m.ID == messageId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LifecycleState, MessageLifecycleState.ReadyForDelivery)
                .SetProperty(m => m.Status, CampaignMemberStatus.Pending)
                .SetProperty(m => m.ResponseMessage, text)
                .SetProperty(m => m.ClaimedAt, (DateTime?)null)
                .SetProperty(m => m.RowUpdatedDt, now), ct);
    }

    private static string Truncate(string? s, int max)
        => string.IsNullOrEmpty(s) ? "" : (s.Length > max ? s[..max] : s);
}
