DELIVERY V3 — consolidated tables, receipts, corrected payload
==============================================================

Replaces the earlier delivery zips. Do not apply both.


⚠ TWO THINGS YOU MUST ADD BEFORE THIS BUILDS
============================================

1. NEW ENUM VALUE — GTXH.SMS.Common/Enums.cs

       public enum MessageLifecycleState
       {
           ...
           ReadyForDelivery = 10,
           Submitting       = 11    <-- ADD THIS
       }

   Needed for the claim. A row moves ReadyForDelivery -> Submitting in one
   atomic statement; that transition IS the duplicate guard, replacing the
   separate table.

2. NEW PROPERTY — GTXH.SMS.Common CampaignQueueEntity

       public string? OutboundPhoneNumber { get; set; }

   The CampaignPHNumber the payload now requires. If SMS_Queue_Mst already has
   a column for the outbound number under a different name, map to that instead
   and change the one reference in DeliveryService.


RUN ORDER
---------
    Scripts/D_03_Consolidate.sql     adds AttemptCount + ProviderMessageId,
                                     indexes receipts both ways

Then overwrite:
    GTXH.SMS.Delivery.API/Services/DeliveryService.cs
    GTXH.SMS.Delivery.API/Services/WebexSmsClient.cs
    GTXH.SMS.Delivery.API/Services/DeliveryReceiptWorker.cs   (new)


=============================================================================
WHAT CHANGED
=============================================================================

TABLES CONSOLIDATED — Madan was right
-------------------------------------
SMS_Delivery_Submission and SMS_Delivery_Attempt are gone.

MessageId IS SMS_Queue_Detail.ID, the primary key, so uniqueness was already
guaranteed by the row. A separate table with a unique index on "{ID}:Ready" was
guarding something the table already guaranteed.

The guard is now a conditional update:

    UPDATE SMS_Queue_Detail SET LifecycleState = Submitting
    WHERE ID = @id AND LifecycleState = ReadyForDelivery

Rows affected 1 -> we won, send. 0 -> someone else has it, stop.

Two columns added instead of two tables: AttemptCount and ProviderMessageId.
ResponseCode, ResponseMessage and Sent_Timestamp_UTC were already there.

The DROP statements at the end of D_03 are COMMENTED OUT. Run them only once
this is working — until then those tables are the audit trail of everything
sent so far.


PAYLOAD CORRECTED
-----------------
The contract changed after the first build. Field names now match:

    was ZIPCODE                  now ZipCode
    was DBID_LeadAccountNumber   now Account_Info_ID + LeadAccountId
    (absent)                     now CampaignPHNumber

CampaignPHNumber is the outbound number mapped in the campaign — the per-client
sender number finally being passed rather than hardcoded in the flow. Real
sends will not be correct without it.


RECEIPTS — the loop is now closed
---------------------------------
Nothing joined SMS_Delivery_Receipts back to the queue, so messages stopped at
Submitted forever even though the receipt saying "Delivered" was sitting in the
table. Every report would have shown submission counts while reading as
delivery counts.

DeliveryReceiptWorker sweeps every 30s:

    code 7500  -> Delivered
    code 7282  -> Failed (invalid route)
    anything else -> Failed, and logged so the catalogue can be filled in

An unknown code is never treated as delivered. Calling it delivered on a guess
would overstate every number anyone reports on.

NO "PROCESSED" FLAG IS ADDED TO THE RECEIPTS TABLE. The sweep only looks at
queue rows still in Submitted, so once one moves it stops matching. Re-running
is harmless, and that table belongs to the Status API — we only read it.


>>> THE ONE THING TO CONFIRM WITH MADAN <<<
===========================================
Which receipt column carries OUR transid.

    SubTid   = bb11627f-...   the JSON's "tid" / "main_tid"
    TransId  = 6635c9d1-...   the JSON's "source_tid"

I matched BOTH, so it works either way and needs no change if I guessed wrong:

    ON  r.TransId = q.ProviderMessageId
     OR r.SubTid  = q.ProviderMessageId

MY READING: TransId. In the receipt JSON, sfeSessionInfo contains
"transid:6635c9d1-..." — the field literally named transid carries the value
stored in the TransId column. SubTid holds tid/main_tid, which is the
downstream carrier-leg id Webex generates, not the one returned to us.

TO CONFIRM: send one live message, note the transid we store, then

    SELECT Id, SubTid, TransId, Code, Description
    FROM   dbo.SMS_Delivery_Receipts
    WHERE  SubTid = '<our transid>' OR TransId = '<our transid>';

WHERE TO CHANGE IT once confirmed:

    File   GTXH.SMS.Delivery.API/Services/DeliveryReceiptWorker.cs
    Method RunOnceAsync
    Look for  ON  r.TransId = q.ProviderMessageId
              OR r.SubTid  = q.ProviderMessageId

    Delete the losing line. Nothing else changes.

Leaving both is functionally fine — it just costs one extra index probe per
row.


KAFKA — NOTHING TO ADD
----------------------
Already wired. Program.cs has AddKafkaHandler<ReadyToSendHandler>() and the
handler declares Topic => Topics.ReadyToSend, the same constant compliance
publishes to. They match by construction.

Check appsettings only:

    "Kafka": {
      "BootstrapServers": "gtxh-dev23:9092",   must match compliance
      "GroupId": "delivery-ready",
      "MaxPollIntervalMs": 600000
    }

MaxPollIntervalMs matters — you hit "maximum poll interval exceeded, leaving
group" earlier. A rebalance is exactly when Kafka redelivers messages another
consumer already processed, which is what the claim guard is there for.


A NOTE ON THE DOUBLE SEND
-------------------------
Two people running the service at once was the cause. The claim worked
correctly — that is why your debugger showed 0 candidates while his instance
sent — but MaxSendsPerProcess is PER PROCESS, so two instances meant two
ceilings.

Coordinate before testing. The ceiling is a testing brake, not a system limit.


SETTINGS
--------
    "Delivery": {
      "DryRun": true,
      "RedirectAllToNumber": null,
      "MaxSendsPerProcess": 25,
      "MaxPerSecond": 25,
      "MaxAttempts": 3,
      "ReceiptProcessingEnabled": true,
      "ReceiptPollSeconds": 30,
      "ReceiptBatchSize": 200
    }

MaxPerSecond is now 25 — confirmed as the provider limit. Still PER INSTANCE.


TEST ORDER
----------
1. Run D_03_Consolidate.sql
2. Add the enum value and the OutboundPhoneNumber property
3. DryRun true — confirm rows reach Submitted
4. Replay the same ReadyToSend twice — the second must log "not claimable" and
   change nothing
5. DryRun false, RedirectAllToNumber to your handset, MaxSendsPerProcess 3
6. Confirm the transid column, then check receipts move rows to Delivered
