/* ============================================================================
   CONSOLIDATE DELIVERY INTO SMS_Queue_Detail
   ============================================================================

   Removes the two extra tables. Everything lives on the queue row.

   WHY THIS IS THE RIGHT CALL
   --------------------------
   MessageId IS SMS_Queue_Detail.ID - the primary key. Uniqueness is already
   guaranteed by the table itself, so a separate table with a unique index on
   "{ID}:Ready" was guarding something the row already guaranteed.

   The guard becomes a CONDITIONAL UPDATE instead:

       UPDATE ... SET LifecycleState = Submitting
       WHERE ID = @id AND LifecycleState = ReadyForDelivery

   @@ROWCOUNT = 1 -> we won, send it.  0 -> someone else has it, skip.
   Atomic, no extra table, and ResponseCode / ResponseMessage /
   Sent_Timestamp_UTC are already columns on the row.

   Safe to run more than once.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ---------------------------------------------------------------------------
   1. Attempt counter on the queue row.

   Replaces SMS_Delivery_Attempt. One number is enough - the retry worker only
   needs to know how many tries have happened, and ResponseMessage already
   carries why the last one failed.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'AttemptCount')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail
        ADD AttemptCount INT NOT NULL CONSTRAINT DF_SMSQD_AttemptCount DEFAULT (0);
    PRINT 'Added SMS_Queue_Detail.AttemptCount';
END
GO

/* ---------------------------------------------------------------------------
   2. Provider message id on the queue row.

   Replaces SMS_Delivery_Submission.ProviderMessageId. This is the Webex transid
   and it is what the receipt processor joins on.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'ProviderMessageId')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD ProviderMessageId NVARCHAR(128) NULL;
    PRINT 'Added SMS_Queue_Detail.ProviderMessageId';
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSQD_ProviderMessageId'
                 AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
    CREATE INDEX IX_SMSQD_ProviderMessageId
        ON dbo.SMS_Queue_Detail (ProviderMessageId)
        INCLUDE (LifecycleState)
        WHERE ProviderMessageId IS NOT NULL;
GO

/* ---------------------------------------------------------------------------
   3. Supports the delivery claim and the retry scan.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSQD_Delivery'
                 AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
    CREATE INDEX IX_SMSQD_Delivery
        ON dbo.SMS_Queue_Detail (LifecycleState, SMSQueue_Mst_ID)
        INCLUDE (Phone, ZipCode, AccountID, Account_Info_ID, MessageText,
                 ClaimedAt, AttemptCount, Sent_Timestamp_UTC);
GO

/* ---------------------------------------------------------------------------
   4. Receipt lookup indexes.

   The receipt processor matches our ProviderMessageId against EITHER column,
   because which one Webex echoes back is not yet confirmed. Both are indexed so
   the join is a seek whichever way it resolves.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSDR_TransId'
                 AND object_id = OBJECT_ID('dbo.SMS_Delivery_Receipts'))
    CREATE INDEX IX_SMSDR_TransId ON dbo.SMS_Delivery_Receipts (TransId);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSDR_SubTid'
                 AND object_id = OBJECT_ID('dbo.SMS_Delivery_Receipts'))
    CREATE INDEX IX_SMSDR_SubTid ON dbo.SMS_Delivery_Receipts (SubTid);
GO

/* ---------------------------------------------------------------------------
   5. Drop the two tables.

   COMMENTED OUT DELIBERATELY. Run only once the new code is deployed and
   working - if it is not, this is the audit trail of everything sent so far.
   --------------------------------------------------------------------------- */
-- DROP TABLE dbo.SMS_Delivery_Submission;
-- DROP TABLE dbo.SMS_Delivery_Attempt;

PRINT '--- verify ---';
SELECT name, TYPE_NAME(user_type_id) AS DataType
FROM   sys.columns
WHERE  object_id = OBJECT_ID('dbo.SMS_Queue_Detail')
  AND  name IN ('AttemptCount','ProviderMessageId','ClaimedAt','Sent_Timestamp_UTC',
                'ResponseCode','ResponseMessage','LifecycleState');
GO
