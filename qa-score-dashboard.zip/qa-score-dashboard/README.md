# QA Score on the Agent Dashboard

backend/Application/Services/QaScore_ADD_THESE.cs.txt   paste 4 blocks
wiring/WIRING.md                                        api.ts, dashboardService, App.tsx, Dashboard.tsx

No migration. No new entity. No change to the QA application.

## What the view told us

  LEFT OUTER JOIN dbo.Users AS E ON A.employee_id = E.UserId

audits.employee_id is simply Users.UserId held as a string. That was the blocker
and it needed no mapping table at all.

  ActionTxt: 0 = NA, 1 = ERROR, 2 = FYI

## Semantics, all taken from the QA app rather than guessed

  employee_id  Users.UserId as nvarchar
  process_id   QA_Processes.Id; QA_Processes.task_process_id = agent ProcessId
  created_at   the work date. NOT completed_at - the QA queue filters on
               created_at (AuditQueueService.ApplyScopeFilters), so using
               completed_at would make the two apps disagree about the same day
  Status       'completed', lowercase string
  Score        0-100
  Action       0 NA, 1 ERROR, 2 FYI

Colour bands match RiskLabel in the QA app: <50 critical, <70 high, <85 medium,
else low. Same number, same meaning, both screens.

## Reads dbo.audits, not dbo.AuditDetails

The view INNER JOINs templates and Tasks, so an audit whose task row is missing
vanishes from it. Harmless for the QA queue; wrong for an average, because a
silently dropped audit inflates the score. None of the joined columns are needed
for a count and a mean.

## Security

The endpoint takes NO userId. It always uses the signed-in agent, so nobody can
read a colleague's score by editing the URL.

## Null is not zero

score is null when nothing was audited. The UI renders an em dash. Rendering 0%
would say "failed every audit" when it means "was not sampled" - and a manager
scanning a wall of 0% escalates before checking which it was.

## Open question for your manager

This is the AVERAGE of Score. If he means PASS RATE - percentage of audits with
no error - that is computed from Action instead. The endpoint already returns
both, so it is a one-line change in the component. Worth settling before agents
start quoting the number at each other.
