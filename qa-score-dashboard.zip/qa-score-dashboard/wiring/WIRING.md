# QA Score on the Agent Dashboard — wiring

Shows the agent's audit score beside "Tasks Completed" in the Selected Day panel,
for the selected date and process.

Backend: see `backend/Application/Services/QaScore_ADD_THESE.cs.txt` — DTO,
interface method, service method, controller endpoint.

---

## 1. `config/api.ts`

Under `dashboard`:

```ts
    qaScore: '/api/dashboard/qa-score',
```

---

## 2. `services/dashboardService.ts`

```ts
export interface QaScoreDto {
  score: number | null;      // null = nothing audited. Render as an em dash, never 0.
  auditedCount: number;
  scoredCount: number;
  errorCount: number;
  fyiCount: number;
}

  async getQaScore(processId: number, date: string): Promise<QaScoreDto> {
    return apiClient.get<QaScoreDto>(
      `${API_ENDPOINTS.dashboard.qaScore}?processId=${processId}&date=${date}`
    );
  }
```

`date` is `yyyy-MM-dd`.

---

## 3. `App.tsx` — pass processId

`Dashboard` already declares `processId?: string | number` in its props but
nothing passes it, so it is always undefined. The score is per-process, so this
is required.

FIND:
```tsx
            <Dashboard
              tasks={tasks}
              onNavigateToTasks={() => setCurrentPage("tasks")}
              userName={`${user.firstName} ${user.lastName}`}
              processName={selectedProcess?.name}
            />
```

REPLACE WITH:
```tsx
            <Dashboard
              tasks={tasks}
              onNavigateToTasks={() => setCurrentPage("tasks")}
              userName={`${user.firstName} ${user.lastName}`}
              processName={selectedProcess?.name}
              processId={selectedProcess?.id}
            />
```

---

## 4. `Dashboard.tsx` — three edits

### 4a. Accept processId in the signature

FIND:
```tsx
export const Dashboard: React.FC<DashboardProps> = ({ tasks, onNavigateToTasks, userName, processName }) => {
```

REPLACE WITH:
```tsx
export const Dashboard: React.FC<DashboardProps> = ({ tasks, onNavigateToTasks, userName, processName, processId }) => {
```

### 4b. State + fetch, keyed on the selected day and process

Add after the `pendingReworkCount` state:

```tsx
  const [qaScore, setQaScore] = useState<QaScoreDto | null>(null);
  const [qaScoreLoading, setQaScoreLoading] = useState(false);
```

And add this effect AFTER `selectedDay` is defined (it depends on it):

```tsx
  // Refetches whenever the agent picks a different day or switches process.
  useEffect(() => {
    const pid = Number(processId);
    if (!selectedDay || !pid) {
      setQaScore(null);
      return;
    }

    // Nothing can have been audited for a date that has not happened.
    if (selectedDay.status === 'future') {
      setQaScore(null);
      return;
    }

    let cancelled = false;
    setQaScoreLoading(true);

    const day = format(selectedDay.fullDate, 'yyyy-MM-dd');

    dashboardService
      .getQaScore(pid, day)
      .then((data) => { if (!cancelled) setQaScore(data); })
      .catch(() => { if (!cancelled) setQaScore(null); })
      .finally(() => { if (!cancelled) setQaScoreLoading(false); });

    return () => { cancelled = true; };
  }, [selectedDay, processId]);
```

Import the type:
```tsx
import { DashboardMetricsDto, dashboardService, QaScoreDto } from '../services/dashboardService';
```

### 4c. The tile, beside Tasks Completed

FIND (inside the Selected Day panel):
```tsx
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-brand-primary shadow-sm">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase">Tasks Completed</p>
                        <p className="text-lg font-bold text-gray-900">{selectedDay.count}</p>
                      </div>
                    </div>
```

REPLACE WITH (the original block, plus the score tile after it):
```tsx
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-brand-primary shadow-sm">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase">Tasks Completed</p>
                        <p className="text-lg font-bold text-gray-900">{selectedDay.count}</p>
                      </div>
                    </div>

                    {/* QA Score. Colour bands match RiskLabel in the QA app
                        (<50 critical, <70 high, <85 medium, else low) so the two
                        applications never disagree about what a number means. */}
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm ${
                        qaScore?.score == null ? 'text-gray-300'
                          : qaScore.score < 50 ? 'text-red-600'
                          : qaScore.score < 70 ? 'text-orange-500'
                          : qaScore.score < 85 ? 'text-amber-500'
                          : 'text-emerald-600'
                      }`}>
                        <Target className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase">QA Score</p>
                        {qaScoreLoading ? (
                          <p className="text-lg font-bold text-gray-300">…</p>
                        ) : qaScore?.score == null ? (
                          <p
                            className="text-lg font-bold text-gray-300"
                            title="No audits for this date"
                          >
                            —
                          </p>
                        ) : (
                          <div className="flex items-baseline gap-1.5">
                            <p className="text-lg font-bold text-gray-900">
                              {qaScore.score.toFixed(0)}%
                            </p>
                            <span
                              className="text-[10px] font-medium text-gray-400"
                              title={`${qaScore.errorCount} error(s), ${qaScore.fyiCount} FYI`}
                            >
                              {qaScore.auditedCount} audited
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
```

`Target` is already imported in Dashboard.tsx.

---

## Why an em dash and not 0%

`score` is null when nothing was audited that day. Rendering that as 0% says
"this agent failed every audit" when it actually means "this agent was not
sampled" — and a manager scanning a wall of 0% will escalate before anyone
checks which it was.

## Verify against the QA app

Open the QA queue for the same date and process (your screenshot:
`.../date/2026-05-26`), pick an agent, and compare. The numbers should match
because both read `dbo.audits` with the same filters:

  created_at within the day   (NOT completed_at — the QA queue uses created_at,
                               so completed_at would disagree about the day)
  Status = 'completed'
  process_id joined through QA_Processes.task_process_id

If they differ, the most likely cause is the date column. Check that first.

```sql
-- Same numbers the endpoint returns, for eyeballing
DECLARE @uid nvarchar(64) = N'<Users.UserId>';
DECLARE @pid int = <agent ProcessId>;
DECLARE @d date = '2026-05-26';

SELECT COUNT(*) AS Audited,
       AVG(CAST(a.Score AS float)) AS AvgScore,
       SUM(CASE WHEN a.[Action] = 1 THEN 1 ELSE 0 END) AS Errors,
       SUM(CASE WHEN a.[Action] = 2 THEN 1 ELSE 0 END) AS Fyi
FROM   dbo.audits a
JOIN   dbo.QA_Processes p ON p.Id = a.process_id
WHERE  a.employee_id = @uid
  AND  TRY_CAST(p.task_process_id AS int) = @pid
  AND  a.[Status] = 'completed'
  AND  a.created_at >= @d AND a.created_at < DATEADD(day, 1, @d);
```

## One decision left for your manager

This is the AVERAGE of audit scores, which matches what `Score` means and what
the QA app's own RiskLabel bands assume.

If "QA score" is meant to be a PASS RATE instead — percentage of audits with no
error — that is a different number, computed from `Action` rather than `Score`:

    passRate = (AuditedCount - ErrorCount) / AuditedCount * 100

Both values are already returned by the endpoint, so switching is a one-line
change in the component. Worth confirming which one he means before agents start
quoting it at each other.
