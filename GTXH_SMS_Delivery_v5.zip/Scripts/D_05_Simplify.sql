/* ============================================================================
   DELIVERY - SIMPLIFIED
   ============================================================================

   Keeps SMS_Delivery_Submission and SMS_Delivery_Receipts.
   Drops the attempt table and the columns that only the retry logic used.

   Safe to run more than once.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ---------------------------------------------------------------------------
   1. Unique index on MessageId - THE DUPLICATE GUARD.

   Delivery inserts a row here BEFORE calling Webex. A second attempt for the
   same message fails on this index and stops, before the provider is called.

   Without it, a Kafka redelivery becomes a second text to a real patient.
   --------------------------------------------------------------------------- */
IF EXISTS (SELECT 1 FROM sys.indexes
           WHERE name = 'UQ_SMSDS_IdempotencyKey'
             AND object_id = OBJECT_ID('dbo.SMS_Delivery_Submission'))
BEGIN
    DROP INDEX UQ_SMSDS_IdempotencyKey ON dbo.SMS_Delivery_Submission;
    PRINT 'Dropped UQ_SMSDS_IdempotencyKey (no longer used)';
END
GO

/* Clear duplicates first, or the unique index cannot be created. Keeps the
   earliest row per message. */
;WITH dupes AS (
    SELECT ID, ROW_NUMBER() OVER (PARTITION BY MessageId ORDER BY ID) AS rn
    FROM   dbo.SMS_Delivery_Submission
)
DELETE FROM dupes WHERE rn > 1;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'UQ_SMSDS_MessageId'
                 AND object_id = OBJECT_ID('dbo.SMS_Delivery_Submission'))
BEGIN
    CREATE UNIQUE INDEX UQ_SMSDS_MessageId
        ON dbo.SMS_Delivery_Submission (MessageId);
    PRINT 'Created UQ_SMSDS_MessageId - the duplicate guard';
END
GO

/* IdempotencyKey is no longer written. Left in place rather than dropped, in
   case the existing rows are still wanted. Make it nullable so inserts work. */
IF EXISTS (SELECT 1 FROM sys.columns
           WHERE object_id = OBJECT_ID('dbo.SMS_Delivery_Submission')
             AND name = 'IdempotencyKey' AND is_nullable = 0)
BEGIN
    ALTER TABLE dbo.SMS_Delivery_Submission ALTER COLUMN IdempotencyKey VARCHAR(100) NULL;
    PRINT 'IdempotencyKey made nullable - no longer written';
END
GO

/* ---------------------------------------------------------------------------
   2. Drop the attempt table - only the retry logic used it, and retry is off.
   --------------------------------------------------------------------------- */
IF OBJECT_ID('dbo.SMS_Delivery_Attempt', 'U') IS NOT NULL
BEGIN
    DROP TABLE dbo.SMS_Delivery_Attempt;
    PRINT 'Dropped SMS_Delivery_Attempt';
END
GO

/* ---------------------------------------------------------------------------
   3. AttemptCount on the queue row - only the retry logic used it.
   --------------------------------------------------------------------------- */
IF EXISTS (SELECT 1 FROM sys.columns
           WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'AttemptCount')
BEGIN
    IF EXISTS (SELECT 1 FROM sys.default_constraints
               WHERE name = 'DF_SMSQD_AttemptCount')
        ALTER TABLE dbo.SMS_Queue_Detail DROP CONSTRAINT DF_SMSQD_AttemptCount;

    ALTER TABLE dbo.SMS_Queue_Detail DROP COLUMN AttemptCount;
    PRINT 'Dropped SMS_Queue_Detail.AttemptCount';
END
GO

/* ---------------------------------------------------------------------------
   4. ProviderMessageId on the queue row - KEPT.

   Holds the Webex transid so anyone reading SMS_Queue_Detail can see which
   provider transaction a message became, without joining another table.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'ProviderMessageId')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD ProviderMessageId NVARCHAR(128) NULL;
    PRINT 'Added SMS_Queue_Detail.ProviderMessageId';
END
GO

/* ---------------------------------------------------------------------------
   5. Outbound number on the campaign - required by the payload contract.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Mst') AND name = 'OutboundPhoneNumber')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Mst ADD OutboundPhoneNumber VARCHAR(20) NULL;
    PRINT 'Added SMS_Queue_Mst.OutboundPhoneNumber';
END
GO

PRINT '--- verify ---';
SELECT name, is_unique FROM sys.indexes
WHERE  object_id = OBJECT_ID('dbo.SMS_Delivery_Submission') AND name IS NOT NULL;
GO
