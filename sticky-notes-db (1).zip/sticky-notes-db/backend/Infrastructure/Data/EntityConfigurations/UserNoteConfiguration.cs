using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GTXH.OMC.Core.Entities;

namespace GTXH.OMC.Infrastructure.Data.EntityConfigurations;

public class UserNoteConfiguration : IEntityTypeConfiguration<UserNote>
{
    public void Configure(EntityTypeBuilder<UserNote> builder)
    {
        builder.ToTable("UserNotes");

        builder.HasKey(n => n.NoteId);
        builder.Property(n => n.NoteId).ValueGeneratedOnAdd();

        builder.Property(n => n.NoteText)
            .IsRequired()
            .HasColumnType("NVARCHAR(MAX)");

        builder.Property(n => n.IsPinned).HasDefaultValue(false);
        builder.Property(n => n.IsDeleted).HasDefaultValue(false);

        builder.Property(n => n.CreatedDate).HasColumnType("datetime2(0)");
        builder.Property(n => n.ModifiedDate).HasColumnType("datetime2(0)");

        builder.HasOne(n => n.User)
            .WithMany()
            .HasForeignKey(n => n.UserId)
            .OnDelete(DeleteBehavior.Restrict);

        // The only access path: my notes, excluding deleted.
        builder.HasIndex(n => new { n.UserId, n.IsDeleted });
    }
}
