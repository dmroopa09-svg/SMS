using GTXH.OMC.Application.DTOs;

namespace GTXH.OMC.Application.Interfaces;

public interface INoteService
{
    Task<List<UserNoteDto>> GetNotesAsync(int userId);
    Task<UserNoteDto> CreateNoteAsync(int userId, CreateNoteRequest request);
    Task<UserNoteDto> UpdateNoteAsync(int userId, long noteId, UpdateNoteRequest request);
    Task DeleteNoteAsync(int userId, long noteId);
    Task<int> DeleteAllNotesAsync(int userId);

    /// <summary>One-time import of notes carried over from browser localStorage.</summary>
    Task<int> MigrateNotesAsync(int userId, MigrateNotesRequest request);
}
