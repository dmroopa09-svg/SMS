namespace GTXH.OMC.Application.DTOs;

public class UserNoteDto
{
    public long NoteId { get; set; }
    public string NoteText { get; set; } = string.Empty;
    public int? ProcessId { get; set; }
    public bool IsPinned { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
}

public class CreateNoteRequest
{
    public string NoteText { get; set; } = string.Empty;
    public int? ProcessId { get; set; }
}

public class UpdateNoteRequest
{
    public string? NoteText { get; set; }
    public bool? IsPinned { get; set; }
}

/// <summary>
/// One-time move of notes an agent already has sitting in browser localStorage.
/// Without this, switching to server storage silently discards whatever they
/// had written before the change went live.
/// </summary>
public class MigrateNotesRequest
{
    public List<MigrateNoteItem> Notes { get; set; } = new();
}

public class MigrateNoteItem
{
    public string Text { get; set; } = string.Empty;
    /// <summary>Original creation time from localStorage, preserved so ordering survives.</summary>
    public DateTime? CreatedAt { get; set; }
}
