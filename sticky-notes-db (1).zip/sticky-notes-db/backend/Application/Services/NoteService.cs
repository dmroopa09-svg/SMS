using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

// Aliased rather than `using GTXH.OMC.Core.Entities;` — that namespace contains
// Core.Entities.Task, which makes every bare non-generic `Task` in this file
// ambiguous with System.Threading.Tasks.Task. Generic Task<T> is unaffected,
// so the breakage shows up only on void-async methods and reads as a confusing
// "not all code paths return a value".
using UserNote = GTXH.OMC.Core.Entities.UserNote;

namespace GTXH.OMC.Application.Services;

/// <summary>
/// Agent sticky notes.
///
/// Takes ApplicationDbContext directly, following ReworkService — this is small
/// CRUD and the repository indirection buys nothing.
///
/// Every method takes userId and filters on it. Notes are private: an agent must
/// never be able to read or modify another agent's note by guessing a NoteId.
/// </summary>
public class NoteService : INoteService
{
    private readonly ApplicationDbContext _db;
    private readonly ILogger<NoteService> _logger;

    /// <summary>
    /// Sanity bound. The column is NVARCHAR(MAX), but a sticky note is a sticky
    /// note — a cap keeps a runaway paste from becoming a support ticket.
    /// </summary>
    private const int MaxNoteLength = 5000;

    /// <summary>Cap on a single localStorage import, to bound the one-time call.</summary>
    private const int MaxMigrateBatch = 200;

    public NoteService(ApplicationDbContext db, ILogger<NoteService> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<List<UserNoteDto>> GetNotesAsync(int userId)
    {
        return await _db.Set<UserNote>()
            .Where(n => n.UserId == userId && !n.IsDeleted)
            .OrderByDescending(n => n.IsPinned)
            .ThenByDescending(n => n.CreatedDate)
            .Select(n => new UserNoteDto
            {
                NoteId = n.NoteId,
                NoteText = n.NoteText,
                ProcessId = n.ProcessId,
                IsPinned = n.IsPinned,
                CreatedDate = n.CreatedDate,
                ModifiedDate = n.ModifiedDate,
            })
            .ToListAsync();
    }

    public async Task<UserNoteDto> CreateNoteAsync(int userId, CreateNoteRequest request)
    {
        var text = Validate(request?.NoteText);
        var now = DateTime.Now;

        var note = new UserNote
        {
            UserId = userId,
            NoteText = text,
            ProcessId = request?.ProcessId,
            IsPinned = false,
            IsDeleted = false,
            CreatedDate = now,
            ModifiedDate = now,
        };

        _db.Set<UserNote>().Add(note);
        await _db.SaveChangesAsync();

        return Map(note);
    }

    public async Task<UserNoteDto> UpdateNoteAsync(int userId, long noteId, UpdateNoteRequest request)
    {
        var note = await FindOwnedAsync(userId, noteId);

        if (request?.NoteText != null)
            note.NoteText = Validate(request.NoteText);

        if (request?.IsPinned.HasValue == true)
            note.IsPinned = request.IsPinned.Value;

        note.ModifiedDate = DateTime.Now;
        await _db.SaveChangesAsync();

        return Map(note);
    }

    public async Task DeleteNoteAsync(int userId, long noteId)
    {
        var note = await FindOwnedAsync(userId, noteId);

        // Soft delete — recoverable if the agent hits it by mistake.
        note.IsDeleted = true;
        note.ModifiedDate = DateTime.Now;
        await _db.SaveChangesAsync();
    }

    public async Task<int> DeleteAllNotesAsync(int userId)
    {
        var notes = await _db.Set<UserNote>()
            .Where(n => n.UserId == userId && !n.IsDeleted)
            .ToListAsync();

        var now = DateTime.Now;
        foreach (var n in notes)
        {
            n.IsDeleted = true;
            n.ModifiedDate = now;
        }

        await _db.SaveChangesAsync();
        return notes.Count;
    }

    public async Task<int> MigrateNotesAsync(int userId, MigrateNotesRequest request)
    {
        if (request?.Notes == null || request.Notes.Count == 0) return 0;

        var incoming = request.Notes
            .Where(n => !string.IsNullOrWhiteSpace(n.Text))
            .Take(MaxMigrateBatch)
            .ToList();

        if (incoming.Count == 0) return 0;

        // Guard against a double import — a second tab running the migration, or
        // an agent whose first attempt failed after the insert but before
        // localStorage was cleared. Matching on text is crude but this runs once
        // and a duplicated sticky note is worse than a missed one.
        var existing = await _db.Set<UserNote>()
            .Where(n => n.UserId == userId && !n.IsDeleted)
            .Select(n => n.NoteText)
            .ToListAsync();

        var existingSet = new HashSet<string>(existing, StringComparer.Ordinal);
        var now = DateTime.Now;
        var added = 0;

        foreach (var item in incoming)
        {
            var text = item.Text.Trim();
            if (text.Length > MaxNoteLength) text = text[..MaxNoteLength];
            if (!existingSet.Add(text)) continue;

            var created = item.CreatedAt ?? now;
            _db.Set<UserNote>().Add(new UserNote
            {
                UserId = userId,
                NoteText = text,
                IsPinned = false,
                IsDeleted = false,
                CreatedDate = created,
                ModifiedDate = now,
            });
            added++;
        }

        if (added > 0) await _db.SaveChangesAsync();

        _logger.LogInformation(
            "Migrated {Added} of {Sent} local notes for user {UserId}.",
            added, request.Notes.Count, userId);

        return added;
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private async Task<UserNote> FindOwnedAsync(int userId, long noteId)
    {
        // UserId is part of the predicate, not checked afterwards — a note
        // belonging to someone else is indistinguishable from one that does not
        // exist, so a guessed NoteId leaks nothing.
        var note = await _db.Set<UserNote>()
            .FirstOrDefaultAsync(n => n.NoteId == noteId && n.UserId == userId && !n.IsDeleted);

        if (note == null)
            throw new KeyNotFoundException($"Note {noteId} not found.");

        return note;
    }

    private static string Validate(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
            throw new ArgumentException("Note text is required.");

        var trimmed = text.Trim();
        if (trimmed.Length > MaxNoteLength)
            throw new ArgumentException($"A note cannot be longer than {MaxNoteLength} characters.");

        return trimmed;
    }

    private static UserNoteDto Map(UserNote n) => new()
    {
        NoteId = n.NoteId,
        NoteText = n.NoteText,
        ProcessId = n.ProcessId,
        IsPinned = n.IsPinned,
        CreatedDate = n.CreatedDate,
        ModifiedDate = n.ModifiedDate,
    };
}
