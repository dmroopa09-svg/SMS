namespace GTXH.OMC.Core.Entities;

/// <summary>
/// Maps dbo.UserNotes — an agent's sticky notes, stored server side.
///
/// These were previously held in browser localStorage, which is scoped to one
/// browser profile on one machine for one origin. On shared or rotating
/// machines, or where policy clears browsing data at logout, the notes were
/// simply gone the next day.
/// </summary>
public class UserNote
{
    public long NoteId { get; set; }

    /// <summary>Owner. Notes are private — never returned to another user.</summary>
    public int UserId { get; set; }

    public string NoteText { get; set; } = string.Empty;

    /// <summary>Process the agent was working when the note was written. Recorded, not yet filtered on.</summary>
    public int? ProcessId { get; set; }

    public bool IsPinned { get; set; }

    /// <summary>Soft delete — an accidental delete should be recoverable.</summary>
    public bool IsDeleted { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.Now;
    public DateTime ModifiedDate { get; set; } = DateTime.Now;

    public virtual User User { get; set; } = null!;
}
