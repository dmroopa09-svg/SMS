using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;

namespace GTXH.OMC.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(AuthenticationSchemes = "Bearer")]
public class NotesController : ControllerBase
{
    private readonly INoteService _noteService;
    private readonly ILogger<NotesController> _logger;

    public NotesController(INoteService noteService, ILogger<NotesController> logger)
    {
        _noteService = noteService;
        _logger = logger;
    }

    /// <summary>My notes, pinned first then newest first.</summary>
    [HttpGet]
    public async Task<ActionResult<List<UserNoteDto>>> GetNotes()
    {
        try
        {
            return Ok(await _noteService.GetNotesAsync(GetCurrentUserId()));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving notes");
            return StatusCode(500, new { error = new { message = "An error occurred while retrieving notes" } });
        }
    }

    [HttpPost]
    public async Task<ActionResult<UserNoteDto>> CreateNote([FromBody] CreateNoteRequest request)
    {
        try
        {
            return Ok(await _noteService.CreateNoteAsync(GetCurrentUserId(), request));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = new { code = "INVALID_NOTE", message = ex.Message } });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating note");
            return StatusCode(500, new { error = new { message = "An error occurred while saving the note" } });
        }
    }

    [HttpPut("{noteId}")]
    public async Task<ActionResult<UserNoteDto>> UpdateNote(long noteId, [FromBody] UpdateNoteRequest request)
    {
        try
        {
            return Ok(await _noteService.UpdateNoteAsync(GetCurrentUserId(), noteId, request));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = new { code = "INVALID_NOTE", message = ex.Message } });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { error = new { code = "NOTE_NOT_FOUND", message = ex.Message } });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating note {NoteId}", noteId);
            return StatusCode(500, new { error = new { message = "An error occurred while updating the note" } });
        }
    }

    [HttpDelete("{noteId}")]
    public async Task<IActionResult> DeleteNote(long noteId)
    {
        try
        {
            await _noteService.DeleteNoteAsync(GetCurrentUserId(), noteId);
            return Ok(new { message = "Note deleted", noteId });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { error = new { code = "NOTE_NOT_FOUND", message = ex.Message } });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting note {NoteId}", noteId);
            return StatusCode(500, new { error = new { message = "An error occurred while deleting the note" } });
        }
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteAllNotes()
    {
        try
        {
            var count = await _noteService.DeleteAllNotesAsync(GetCurrentUserId());
            return Ok(new { message = "Notes cleared", deletedCount = count });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error clearing notes");
            return StatusCode(500, new { error = new { message = "An error occurred while clearing notes" } });
        }
    }

    /// <summary>One-time import of notes carried over from browser localStorage.</summary>
    [HttpPost("migrate")]
    public async Task<IActionResult> Migrate([FromBody] MigrateNotesRequest request)
    {
        try
        {
            var added = await _noteService.MigrateNotesAsync(GetCurrentUserId(), request);
            return Ok(new { message = "Notes migrated", migratedCount = added });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error migrating notes");
            return StatusCode(500, new { error = new { message = "An error occurred while migrating notes" } });
        }
    }

    private int GetCurrentUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out var userId))
        {
            throw new UnauthorizedAccessException("User ID not found in token");
        }
        return userId;
    }
}
