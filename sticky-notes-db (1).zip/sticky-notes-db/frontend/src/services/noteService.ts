import { apiClient, API_ENDPOINTS } from './api';

// ─── Server shape ─────────────────────────────────────────────────────────────

export interface UserNoteDto {
  noteId: number;
  noteText: string;
  processId?: number | null;
  isPinned: boolean;
  createdDate: string;
  modifiedDate: string;
}

/**
 * The shape App.tsx already renders: { id, text, createdAt }.
 *
 * Kept deliberately identical to the old localStorage shape so the sticky-note
 * JSX does not have to change — only the handlers that load and save.
 */
export interface StickyNote {
  id: string;
  text: string;
  createdAt: string;
  isPinned: boolean;
}

const toSticky = (dto: UserNoteDto): StickyNote => ({
  id: String(dto.noteId),
  text: dto.noteText,
  createdAt: new Date(dto.createdDate).toLocaleString(),
  isPinned: dto.isPinned,
});

// ─── Service ──────────────────────────────────────────────────────────────────

class NoteService {
  async getNotes(): Promise<StickyNote[]> {
    const res = await apiClient.get<UserNoteDto[]>(API_ENDPOINTS.notes.list);
    return (res ?? []).map(toSticky);
  }

  async createNote(text: string, processId?: number): Promise<StickyNote> {
    const res = await apiClient.post<UserNoteDto>(API_ENDPOINTS.notes.create, {
      noteText: text,
      processId: processId ?? null,
    });
    return toSticky(res);
  }

  async updateNote(
    noteId: number,
    changes: { text?: string; isPinned?: boolean }
  ): Promise<StickyNote> {
    const res = await apiClient.put<UserNoteDto>(API_ENDPOINTS.notes.update(noteId), {
      noteText: changes.text,
      isPinned: changes.isPinned,
    });
    return toSticky(res);
  }

  async deleteNote(noteId: number): Promise<void> {
    await apiClient.delete(API_ENDPOINTS.notes.delete(noteId));
  }

  async deleteAll(): Promise<{ deletedCount: number }> {
    return apiClient.delete<{ deletedCount: number }>(API_ENDPOINTS.notes.deleteAll);
  }

  /**
   * Moves anything still sitting in localStorage into the database, once.
   *
   * Runs on first load after this change ships. Without it, agents silently lose
   * whatever they had written before the switch — which is the opposite of the
   * point. localStorage is only cleared AFTER the server confirms, so a failed
   * call leaves the notes where they are and the next load retries.
   */
  async migrateLocalNotes(): Promise<number> {
    const raw = localStorage.getItem('stickyNotes');
    if (!raw) return 0;

    let local: { id?: string; text?: string; createdAt?: string }[] = [];
    try {
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed) || parsed.length === 0) {
        localStorage.removeItem('stickyNotes');
        return 0;
      }
      local = parsed;
    } catch {
      localStorage.removeItem('stickyNotes');
      return 0;
    }

    const notes = local
      .filter((n) => n?.text && String(n.text).trim().length > 0)
      .map((n) => {
        // localStorage stored createdAt via toLocaleString(), which does not
        // round-trip reliably. Send it only if it actually parses; the server
        // falls back to now when it is absent.
        const parsedDate = n.createdAt ? new Date(n.createdAt) : null;
        const valid = parsedDate && !isNaN(parsedDate.getTime());
        return {
          text: String(n.text).trim(),
          createdAt: valid ? parsedDate!.toISOString() : null,
        };
      });

    if (notes.length === 0) {
      localStorage.removeItem('stickyNotes');
      return 0;
    }

    const res = await apiClient.post<{ migratedCount: number }>(
      API_ENDPOINTS.notes.migrate,
      { notes }
    );

    localStorage.removeItem('stickyNotes');
    return res?.migratedCount ?? 0;
  }
}

export const noteService = new NoteService();
