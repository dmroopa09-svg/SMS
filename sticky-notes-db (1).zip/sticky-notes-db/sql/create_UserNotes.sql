USE [GTXH_OMC];
GO

/*
    dbo.UserNotes — sticky notes, per agent, stored server side.

    Named to match the existing UserBreakLogs / UserActivities /
    UserProcessPermissions tables rather than inventing a new prefix.

    You can create this EITHER by running this script OR by letting EF create it:

      Running this script by hand:
        dotnet ef migrations add AddUserNotes
        -> EMPTY the Up() and Down() bodies (table already exists)

      Letting EF create it:
        dotnet ef migrations add AddUserNotes
        -> leave Up()/Down() alone, dotnet ef database update

    Do one or the other, not both.
*/

IF OBJECT_ID('dbo.UserNotes', 'U') IS NOT NULL
BEGIN
    PRINT 'dbo.UserNotes already exists - nothing to do.';
    RETURN;
END
GO

CREATE TABLE dbo.UserNotes
(
    [NoteId]       bigint IDENTITY(1,1) NOT NULL,
    [UserId]       int            NOT NULL,
    [NoteText]     nvarchar(max)  NOT NULL,

    -- Which process the agent was working when the note was written. Nullable
    -- and not filtered on today; recorded now so it is available later without
    -- a schema change and without backfilling.
    [ProcessId]    int            NULL,

    [IsPinned]     bit            NOT NULL CONSTRAINT DF_UserNotes_IsPinned  DEFAULT (0),

    -- Soft delete. The whole point of this table is that notes stop vanishing,
    -- so an accidental delete should be recoverable. Costs one bit and one
    -- WHERE clause.
    [IsDeleted]    bit            NOT NULL CONSTRAINT DF_UserNotes_IsDeleted DEFAULT (0),

    [CreatedDate]  datetime2(0)   NOT NULL CONSTRAINT DF_UserNotes_Created   DEFAULT (getdate()),
    [ModifiedDate] datetime2(0)   NOT NULL CONSTRAINT DF_UserNotes_Modified  DEFAULT (getdate()),

    CONSTRAINT PK_UserNotes PRIMARY KEY CLUSTERED ([NoteId] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
GO

ALTER TABLE dbo.UserNotes WITH CHECK
    ADD CONSTRAINT FK_UserNotes_Users FOREIGN KEY ([UserId])
    REFERENCES dbo.Users ([UserId]);
GO
ALTER TABLE dbo.UserNotes CHECK CONSTRAINT FK_UserNotes_Users;
GO

-- Blank notes are meaningless and the UI already blocks them; enforce it here
-- too so a bad client cannot create rows that render as empty boxes.
ALTER TABLE dbo.UserNotes WITH CHECK
    ADD CONSTRAINT CK_UserNotes_NoteText CHECK (len(ltrim(rtrim([NoteText]))) > 0);
GO
ALTER TABLE dbo.UserNotes CHECK CONSTRAINT CK_UserNotes_NoteText;
GO

-- The only query this table serves: my notes, pinned first, newest first.
CREATE NONCLUSTERED INDEX IX_UserNotes_User_Active
    ON dbo.UserNotes ([UserId], [IsDeleted])
    INCLUDE ([IsPinned], [CreatedDate]);
GO

PRINT 'dbo.UserNotes created.';
GO


/* ── Housekeeping (optional, run later) ────────────────────────────────────

-- Soft-deleted notes older than 90 days can be cleared out for good.
-- DELETE FROM dbo.UserNotes WHERE IsDeleted = 1 AND ModifiedDate < DATEADD(day, -90, GETDATE());

-- Who is using notes, and how much
-- SELECT u.Username, COUNT(*) AS Notes, MAX(n.CreatedDate) AS LastNote
-- FROM dbo.UserNotes n JOIN dbo.Users u ON u.UserId = n.UserId
-- WHERE n.IsDeleted = 0 GROUP BY u.Username ORDER BY Notes DESC;

──────────────────────────────────────────────────────────────────────────── */
