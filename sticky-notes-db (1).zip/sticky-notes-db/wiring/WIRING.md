# Wiring — server-side sticky notes

The sticky-note PANEL JSX does not change. `noteService` returns the same
`{ id, text, createdAt }` shape localStorage used, so only the four handlers
that load, save and delete are replaced.

---

## 1. Database

Run `sql/create_UserNotes.sql`, then:

```
dotnet ef migrations add AddUserNotes
```
and **empty the `Up()` and `Down()` bodies** — the table already exists.

Or skip the script entirely, run the migration, and let EF create it. One or the
other, not both.

---

## 2. `ApplicationDbContext.cs`

```csharp
    // User Management
    public DbSet<User> Users { get; set; }
    public DbSet<QaUser> QaUsers { get; set; }
    public DbSet<Role> Roles { get; set; }
    public DbSet<UserProcessPermission> UserProcessPermissions { get; set; }
    public DbSet<UserNote> UserNotes { get; set; }        // <-- ADD
```

---

## 3. `Program.cs`

Next to the other application service registrations:

```csharp
builder.Services.AddScoped<GTXH.OMC.Application.Interfaces.INoteService,
                           GTXH.OMC.Application.Services.NoteService>();
```

---

## 4. `config/api.ts`

```ts
  notes: {
    list: '/api/notes',
    create: '/api/notes',
    update: (id: number) => `/api/notes/${id}`,
    delete: (id: number) => `/api/notes/${id}`,
    deleteAll: '/api/notes',
    migrate: '/api/notes/migrate',
  },
```

---

## 5. `App.tsx`

### 5a. Import

```tsx
import { noteService, StickyNote } from "./services/noteService";
```

### 5b. Replace the state initialiser

```tsx
  // was: useState(() => JSON.parse(localStorage.getItem("stickyNotes") ?? "[]"))
  const [stickyNotes, setStickyNotes] = useState<StickyNote[]>([]);
  const [notesLoading, setNotesLoading] = useState(false);
```

### 5c. Load on login, migrating anything left in localStorage first

```tsx
  useEffect(() => {
    if (!isAuthenticated) return;

    let cancelled = false;

    (async () => {
      setNotesLoading(true);
      try {
        // Anything written before this change went live. Runs once — the service
        // clears localStorage only after the server confirms, so a failure here
        // leaves the notes in place and the next load retries.
        const migrated = await noteService.migrateLocalNotes().catch(() => 0);

        const notes = await noteService.getNotes();
        if (cancelled) return;

        setStickyNotes(notes);
        if (migrated > 0) {
          addToast(`${migrated} saved note(s) moved to your account`, "success");
        }
      } catch (error) {
        console.error("Failed to load notes:", error);
        if (!cancelled) addToast("Failed to load notes", "error");
      } finally {
        if (!cancelled) setNotesLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [isAuthenticated, addToast]);
```

### 5d. Replace `handleSaveStickyNote`

```tsx
  const handleSaveStickyNote = async () => {
    const text = stickyNoteText.trim();
    if (!text) return;

    // Clear the box immediately — an agent on a call should not wait on a round
    // trip. Restored if the save fails.
    setStickyNoteText("");

    try {
      const saved = await noteService.createNote(text, selectedProcess?.id);
      setStickyNotes((prev) => [saved, ...prev]);
    } catch (error) {
      console.error("Failed to save note:", error);
      setStickyNoteText(text);
      addToast("Failed to save note", "error");
    }
  };
```

### 5e. Replace `handleDeleteStickyNote`

```tsx
  const handleDeleteStickyNote = async (id: string) => {
    const previous = stickyNotes;
    setStickyNotes((prev) => prev.filter((n) => n.id !== id));   // optimistic

    try {
      await noteService.deleteNote(Number(id));
    } catch (error) {
      console.error("Failed to delete note:", error);
      setStickyNotes(previous);                                   // rollback
      addToast("Failed to delete note", "error");
    }
  };
```

### 5f. Replace the "Clear all" button handler

The old one was `setStickyNotes([]); localStorage.removeItem("stickyNotes");`

```tsx
                          onClick={async () => {
                            const previous = stickyNotes;
                            setStickyNotes([]);
                            try {
                              await noteService.deleteAll();
                            } catch (error) {
                              console.error("Failed to clear notes:", error);
                              setStickyNotes(previous);
                              addToast("Failed to clear notes", "error");
                            }
                          }}
```

### 5g. Optional — loading state in the list view

In the `stickyView === "list"` block, before the `stickyNotes.length === 0` check:

```tsx
                    {notesLoading ? (
                      <div className="flex items-center justify-center py-10 text-yellow-500 gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-xs">Loading notes…</span>
                      </div>
                    ) : stickyNotes.length === 0 ? (
```

`Loader2` is already imported in App.tsx.

---

## Test

1. Add two notes, hard-refresh -> both still there
2. Log in from a DIFFERENT machine or browser -> same notes appear
   (this is the whole point; localStorage could never do it)
3. Delete one, refresh -> stays deleted
4. Before deploying, seed localStorage in DevTools:
   `localStorage.setItem('stickyNotes', JSON.stringify([{id:'1',text:'old note',createdAt:'7/1/2026, 10:00:00 AM'}]))`
   then load the app -> "1 saved note(s) moved to your account", localStorage key gone
5. Run the migration load twice -> no duplicates (the service dedupes on text)
