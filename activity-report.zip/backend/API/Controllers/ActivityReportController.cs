using System.Security.Claims;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GTXH.OMC.API.Controllers;

/// <summary>
///   POST api/activity-report   ActivityReportRequest -> ActivityReportDto
///   Same body with includeDetails = true for the Excel export (adds Breaks / Breaches rows).
/// Managers/supervisors see their processes; roles in WorkPolicy:AllProcessRoleIds see all.
/// </summary>
[ApiController]
[Route("api/activity-report")]
[Authorize(AuthenticationSchemes = "Bearer")]
public class ActivityReportController : ControllerBase
{
    private static readonly int[] ProcessScopedRoleIds = { 2, 6 };

    private readonly IActivityReportService _service;
    private readonly IConfiguration _config;
    private readonly ILogger<ActivityReportController> _logger;

    public ActivityReportController(IActivityReportService service, IConfiguration config, ILogger<ActivityReportController> logger)
    {
        _service = service;
        _config = config;
        _logger = logger;
    }

    [HttpPost]
    public async Task<IActionResult> Report([FromBody] ActivityReportRequest request, CancellationToken ct)
    {
        if (!int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var userId)) return Unauthorized();

        var roleClaim = User.FindFirst(ClaimTypes.Role)?.Value ?? User.FindFirst("roleId")?.Value;
        int.TryParse(roleClaim, out var roleId);
        var allProcessRoles = _config.GetSection("WorkPolicy:AllProcessRoleIds").Get<int[]>() ?? new[] { 1 };

        bool restricted;
        if (allProcessRoles.Contains(roleId)) restricted = false;
        else if (ProcessScopedRoleIds.Contains(roleId)) restricted = true;
        else return StatusCode(403, Error("FORBIDDEN", "Only supervisors, managers and superadmins can view activity reports"));

        try
        {
            return Ok(await _service.GetReportAsync(userId, restricted, request ?? new ActivityReportRequest(), ct));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(Error("VALIDATION_ERROR", ex.Message));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Activity report failed");
            return StatusCode(500, Error("SERVER_ERROR", "An error occurred while building the activity report"));
        }
    }

    private static object Error(string code, string message) => new { error = new { code, message } };
}
