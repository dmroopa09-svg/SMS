namespace GTXH.OMC.Application.DTOs;

public class ActivityReportRequest
{
    /// <summary>yyyy-MM-dd, work date in the process time zone (inclusive).</summary>
    public string FromDate { get; set; } = string.Empty;
    public string ToDate { get; set; } = string.Empty;

    /// <summary>Empty = every process the viewer can see.</summary>
    public List<int>? ProcessIds { get; set; }

    /// <summary>Empty = everyone.</summary>
    public List<int>? UserIds { get; set; }

    /// <summary>1 = Break, 2 = Inactivity, 3 = Delay. Empty = all.</summary>
    public List<int>? ReasonTypes { get; set; }

    /// <summary>day | week | month - buckets for the trend.</summary>
    public string GroupBy { get; set; } = "day";

    /// <summary>Export: also return every break and every breach (Breaks / Breaches sheets).</summary>
    public bool IncludeDetails { get; set; }
}

public class ReasonColumnDto
{
    public int ReasonId { get; set; }
    public string Label { get; set; } = string.Empty;
    public int ReasonType { get; set; }
}

public class ReasonStatDto
{
    public int Count { get; set; }
    public int Minutes { get; set; }
}

public class ActivityKpisDto
{
    public int UsersInScope { get; set; }
    public int UsersPresent { get; set; }
    public int PersonDays { get; set; }
    /// <summary>"HH:mm" average first login (process time).</summary>
    public string? AvgFirstLogin { get; set; }
    public int LateLogins { get; set; }
    public int EarlyLogouts { get; set; }
    public int Breaks { get; set; }
    public int BreakMinutes { get; set; }
    public int OverLimitBreaks { get; set; }
    public int InactivityEvents { get; set; }
    public int InactivityMinutes { get; set; }
    public int Breaches { get; set; }
    public int PendingBreaches { get; set; }
    public int TasksCompleted { get; set; }
}

public class UserActivitySummaryRowDto
{
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Processes { get; set; } = string.Empty;

    public int DaysPresent { get; set; }
    public string? AvgFirstLogin { get; set; }
    public string? AvgLastLogout { get; set; }
    public decimal? AvgHoursPerDay { get; set; }

    public int LateLogins { get; set; }
    public int LateMinutes { get; set; }
    public int EarlyLogouts { get; set; }

    public int Breaks { get; set; }
    public int BreakMinutes { get; set; }
    public decimal? AvgBreakMinutes { get; set; }
    public int OverLimitBreaks { get; set; }

    public int InactivityEvents { get; set; }
    public int InactivityMinutes { get; set; }

    public int Breaches { get; set; }
    public int PendingBreaches { get; set; }
    public int ApprovedBreaches { get; set; }
    public int RejectedBreaches { get; set; }

    public int TasksCompleted { get; set; }
    public decimal? TasksPerDay { get; set; }

    /// <summary>reasonId -> count / minutes (excludes sign-off).</summary>
    public Dictionary<int, ReasonStatDto> ByReason { get; set; } = new();
}

public class UserDailyRowDto
{
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    /// <summary>yyyy-MM-dd</summary>
    public string WorkDate { get; set; } = string.Empty;
    public string? FirstLogin { get; set; }
    public string? LastLogout { get; set; }
    public decimal? Hours { get; set; }
    public bool LateLogin { get; set; }
    public bool EarlyLogout { get; set; }
    public int Breaks { get; set; }
    public int BreakMinutes { get; set; }
    public int OverLimitBreaks { get; set; }
    public int InactivityMinutes { get; set; }
    public int Breaches { get; set; }
    public int TasksCompleted { get; set; }
}

public class ActivityTrendPointDto
{
    /// <summary>Bucket key: yyyy-MM-dd (day / week start) or yyyy-MM (month).</summary>
    public string Period { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public int UsersPresent { get; set; }
    public int Breaks { get; set; }
    public int BreakMinutes { get; set; }
    public int Breaches { get; set; }
    public int LateLogins { get; set; }
    public int TasksCompleted { get; set; }
}

public class BreakDetailRowDto
{
    public int BreakLogId { get; set; }
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string? ProcessName { get; set; }
    public string? Reason { get; set; }
    public string ReasonTypeName { get; set; } = string.Empty;
    /// <summary>yyyy-MM-dd HH:mm, process time zone.</summary>
    public string Start { get; set; } = string.Empty;
    public string? End { get; set; }
    public int? Minutes { get; set; }
    public int? AllowedMinutes { get; set; }
    public bool OverLimit { get; set; }
    public string? Status { get; set; }
    public string? Comment { get; set; }
}

public class BreachDetailRowDto
{
    public long BreachId { get; set; }
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string? ProcessName { get; set; }
    public string WorkDate { get; set; } = string.Empty;
    public string BreachType { get; set; } = string.Empty;
    public string? Reason { get; set; }
    public string? Details { get; set; }
    public int? ExceededMinutes { get; set; }
    public string Status { get; set; } = string.Empty;
    public string? AgentComment { get; set; }
    public string? DecidedBy { get; set; }
    public string? DecisionComment { get; set; }
}

public class ActivityReportDto
{
    public string FromDate { get; set; } = string.Empty;
    public string ToDate { get; set; } = string.Empty;
    public string GroupBy { get; set; } = "day";
    public ActivityKpisDto Kpis { get; set; } = new();
    public List<ReasonColumnDto> Reasons { get; set; } = new();
    public List<UserActivitySummaryRowDto> Users { get; set; } = new();
    public List<UserDailyRowDto> Daily { get; set; } = new();
    public List<ActivityTrendPointDto> Trend { get; set; } = new();
    public List<BreakDetailRowDto>? Breaks { get; set; }
    public List<BreachDetailRowDto>? Breaches { get; set; }
    /// <summary>Details were capped at MaxDetailRows - narrow the range or filters.</summary>
    public bool Truncated { get; set; }
}
