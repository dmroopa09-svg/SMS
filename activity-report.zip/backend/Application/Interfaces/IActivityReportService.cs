using GTXH.OMC.Application.DTOs;

namespace GTXH.OMC.Application.Interfaces;

public interface IActivityReportService
{
    /// <summary>
    /// Attendance, breaks, breaches and output per user for a date range.
    /// restrictToAssignedProcesses = manager/supervisor: only their UserProcessPermissions processes.
    /// </summary>
    Task<ActivityReportDto> GetReportAsync(int viewerUserId, bool restrictToAssignedProcesses,
        ActivityReportRequest request, CancellationToken ct = default);
}
