import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  Clock,
  Coffee,
  Download,
  FileSpreadsheet,
  Loader2,
  LogIn,
  RefreshCw,
  Search,
  ShieldAlert,
  Users,
  CheckCircle2,
} from "lucide-react";
import { apiClient } from "../api/client";
import type { ProcessDto } from "../types";
import { cn } from "../types";
import { useToast } from "../components/Toast";
import {
  activityReportApi,
  type ActivityReport as ReportData,
  type GroupBy,
  type TrendPoint,
  type UserSummaryRow,
} from "../api/activityReport";
import { presenceApi, formatMinutes, type TeamPresence, type PresenceStatus } from "../api/presence";

// ─────────────────────────────────────────────────────────────────────────────
// Dates. Work dates are US Central, so "today" is Central's today, not the PC's.
// ─────────────────────────────────────────────────────────────────────────────
const PROCESS_TZ = "America/Chicago";

const todayInProcessTz = () =>
  new Intl.DateTimeFormat("en-CA", { timeZone: PROCESS_TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(
    new Date(),
  );

const parse = (s: string) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
};
const fmt = (d: Date) => d.toISOString().slice(0, 10);
const addDays = (s: string, n: number) => {
  const d = parse(s);
  d.setUTCDate(d.getUTCDate() + n);
  return fmt(d);
};
const daysBetween = (a: string, b: string) => Math.round((parse(b).getTime() - parse(a).getTime()) / 86_400_000) + 1;

type Preset = "today" | "yesterday" | "thisWeek" | "lastWeek" | "thisMonth" | "lastMonth" | "last30" | "last90" | "thisYear" | "custom";

const PRESETS: { id: Preset; label: string }[] = [
  { id: "today", label: "Today" },
  { id: "yesterday", label: "Yesterday" },
  { id: "thisWeek", label: "This week" },
  { id: "lastWeek", label: "Last week" },
  { id: "thisMonth", label: "This month" },
  { id: "lastMonth", label: "Last month" },
  { id: "last30", label: "Last 30 days" },
  { id: "last90", label: "Last 90 days" },
  { id: "thisYear", label: "This year" },
  { id: "custom", label: "Custom" },
];

function presetRange(p: Preset): [string, string] | null {
  const t = todayInProcessTz();
  const d = parse(t);
  const dow = (d.getUTCDay() + 6) % 7; // Monday = 0
  switch (p) {
    case "today":
      return [t, t];
    case "yesterday":
      return [addDays(t, -1), addDays(t, -1)];
    case "thisWeek":
      return [addDays(t, -dow), t];
    case "lastWeek":
      return [addDays(t, -dow - 7), addDays(t, -dow - 1)];
    case "thisMonth":
      return [`${t.slice(0, 7)}-01`, t];
    case "lastMonth": {
      const first = parse(`${t.slice(0, 7)}-01`);
      first.setUTCDate(0); // last day of previous month
      const end = fmt(first);
      return [`${end.slice(0, 7)}-01`, end];
    }
    case "last30":
      return [addDays(t, -29), t];
    case "last90":
      return [addDays(t, -89), t];
    case "thisYear":
      return [`${t.slice(0, 4)}-01-01`, t];
    default:
      return null;
  }
}

const autoGroupBy = (from: string, to: string): GroupBy => {
  const n = daysBetween(from, to);
  return n <= 31 ? "day" : n <= 120 ? "week" : "month";
};

const mins = (m: number | null | undefined) => (m ? formatMinutes(m) : "-");

// ─────────────────────────────────────────────────────────────────────────────

type SortKey =
  | "username"
  | "daysPresent"
  | "avgFirstLogin"
  | "avgHoursPerDay"
  | "lateLogins"
  | "earlyLogouts"
  | "breaks"
  | "breakMinutes"
  | "overLimitBreaks"
  | "inactivityMinutes"
  | "breaches"
  | "tasksPerDay";

const TREND_METRICS: { id: keyof TrendPoint; label: string; color: string }[] = [
  { id: "breaks", label: "Breaks", color: "#3b82f6" },
  { id: "breakMinutes", label: "Break minutes", color: "#0ea5e9" },
  { id: "breaches", label: "Breaches", color: "#ef4444" },
  { id: "lateLogins", label: "Late logins", color: "#f59e0b" },
  { id: "usersPresent", label: "People present", color: "#10b981" },
  { id: "tasksCompleted", label: "Tasks completed", color: "#6366f1" },
];

const PRESENCE_STYLE: Record<PresenceStatus, string> = {
  Online: "bg-emerald-50 text-emerald-700 border-emerald-200",
  Idle: "bg-amber-50 text-amber-700 border-amber-200",
  OnBreak: "bg-sky-50 text-sky-700 border-sky-200",
  Offline: "bg-zinc-50 text-zinc-500 border-zinc-200",
};

interface ActivityReportProps {
  /** Set inside a process's detail page: report for this process only, plus who's working now. */
  processId?: number;
}

/**
 * Attendance, breaks, breaches and output per user for any date range, with Excel export.
 * Used as the "Activity" tab of a process and as the cross-process Activity Reports page.
 */
export default function ActivityReport({ processId: fixedProcessId }: ActivityReportProps = {}) {
  const { showToast } = useToast();
  const embedded = !!fixedProcessId;

  // ── Filters ──
  const [preset, setPreset] = useState<Preset>("thisMonth");
  const [[fromDate, toDate], setRange] = useState<[string, string]>(() => presetRange("thisMonth")!);
  const [groupByChoice, setGroupByChoice] = useState<GroupBy | "auto">("auto");
  const [processes, setProcesses] = useState<ProcessDto[]>([]);
  const [selectedProcessIds, setSelectedProcessIds] = useState<number[]>([]);
  const [selectedUserIds, setSelectedUserIds] = useState<number[]>([]);
  const [reasonTypes, setReasonTypes] = useState<number[]>([]); // empty = all
  const [search, setSearch] = useState("");
  const [showByReason, setShowByReason] = useState(false);
  const [openMenu, setOpenMenu] = useState<"process" | "user" | "export" | null>(null);

  // ── Data ──
  const [report, setReport] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [presence, setPresence] = useState<TeamPresence | null>(null);
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({ key: "breaches", dir: "desc" });
  const [expandedUser, setExpandedUser] = useState<number | null>(null);
  const [trendMetric, setTrendMetric] = useState<keyof TrendPoint>("breaks");

  const groupBy: GroupBy = groupByChoice === "auto" ? autoGroupBy(fromDate, toDate) : groupByChoice;
  const processIds = embedded ? [fixedProcessId!] : selectedProcessIds;

  useEffect(() => {
    if (embedded) return;
    apiClient.getProcesses().then(setProcesses).catch(() => {});
  }, [embedded]);

  const buildRequest = useCallback(
    (includeDetails: boolean) => ({
      fromDate,
      toDate,
      groupBy,
      processIds: processIds.length ? processIds : undefined,
      userIds: selectedUserIds.length ? selectedUserIds : undefined,
      reasonTypes: reasonTypes.length ? reasonTypes : undefined,
      includeDetails,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [fromDate, toDate, groupBy, processIds.join(","), selectedUserIds.join(","), reasonTypes.join(",")],
  );

  const load = useCallback(async () => {
    if (!fromDate || !toDate || toDate < fromDate) return;
    setLoading(true);
    try {
      setReport(await activityReportApi.get(buildRequest(false)));
      setExpandedUser(null);
    } catch (err: any) {
      showToast(err?.message || "Failed to load the activity report", "error");
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [buildRequest]);

  useEffect(() => {
    const t = window.setTimeout(load, 250); // let quick filter clicks settle
    return () => window.clearTimeout(t);
  }, [load]);

  // Live status - only on the process tab.
  useEffect(() => {
    if (!embedded) return;
    let cancelled = false;
    const tick = () =>
      presenceApi
        .team(fixedProcessId)
        .then((p) => !cancelled && setPresence(p))
        .catch(() => {});
    tick();
    const id = window.setInterval(() => document.visibilityState === "visible" && tick(), 30_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [embedded, fixedProcessId]);

  // Users offered in the user filter: everyone the report knows about (kept while filtering).
  const [knownUsers, setKnownUsers] = useState<{ userId: number; username: string }[]>([]);
  useEffect(() => {
    if (!report || selectedUserIds.length) return;
    setKnownUsers(report.users.map((u) => ({ userId: u.userId, username: u.username })));
  }, [report, selectedUserIds.length]);

  const rows = useMemo(() => {
    if (!report) return [];
    const q = search.trim().toLowerCase();
    const list = report.users.filter((u) => !q || u.username.toLowerCase().includes(q));
    const val = (u: UserSummaryRow): number | string => {
      const v = u[sort.key];
      return v == null ? (sort.dir === "asc" ? Number.MAX_SAFE_INTEGER : -1) : (v as number | string);
    };
    return [...list].sort((a, b) => {
      const x = val(a);
      const y = val(b);
      const c = typeof x === "string" && typeof y === "string" ? x.localeCompare(y) : (x as number) - (y as number);
      return sort.dir === "asc" ? c : -c;
    });
  }, [report, search, sort]);

  const dailyByUser = useMemo(() => {
    const map = new Map<number, ReportData["daily"]>();
    for (const d of report?.daily ?? []) {
      if (!map.has(d.userId)) map.set(d.userId, []);
      map.get(d.userId)!.push(d);
    }
    return map;
  }, [report]);

  const choosePreset = (p: Preset) => {
    setPreset(p);
    const r = presetRange(p);
    if (r) setRange(r);
  };

  const toggleSort = (key: SortKey) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: key === "username" ? "asc" : "desc" }));

  // ── Export ──
  const fileBase = () => {
    const scope = embedded
      ? "process"
      : selectedProcessIds.length === 1
        ? processes.find((p) => p.processId === selectedProcessIds[0])?.processName ?? "process"
        : "all-processes";
    return `activity_${scope.replace(/[^\w-]+/g, "_")}_${fromDate}_to_${toDate}`;
  };

  const summarySheetRows = (r: ReportData) =>
    r.users.map((u) => {
      const row: Record<string, string | number | null> = {
        User: u.username,
        Processes: u.processes,
        "Days present": u.daysPresent,
        "Avg first login": u.avgFirstLogin,
        "Avg last logout": u.avgLastLogout,
        "Avg hours/day": u.avgHoursPerDay,
        "Late logins": u.lateLogins,
        "Late minutes": u.lateMinutes,
        "Early logouts": u.earlyLogouts,
        Breaks: u.breaks,
        "Break minutes": u.breakMinutes,
        "Avg break minutes": u.avgBreakMinutes,
        "Over-limit breaks": u.overLimitBreaks,
        "Inactivity events": u.inactivityEvents,
        "Inactivity minutes": u.inactivityMinutes,
        Breaches: u.breaches,
        "Breaches pending": u.pendingBreaches,
        "Breaches approved": u.approvedBreaches,
        "Breaches rejected": u.rejectedBreaches,
        "Tasks completed": u.tasksCompleted,
        "Tasks/day": u.tasksPerDay,
      };
      for (const reason of r.reasons) {
        const s = u.byReason[String(reason.reasonId)];
        row[`${reason.label} (count)`] = s?.count ?? 0;
        row[`${reason.label} (minutes)`] = s?.minutes ?? 0;
      }
      return row;
    });

  const exportExcel = async () => {
    setOpenMenu(null);
    setExporting(true);
    try {
      const [full, XLSX] = await Promise.all([activityReportApi.get(buildRequest(true)), import("xlsx")]);
      const wb = XLSX.utils.book_new();
      const add = (name: string, data: object[]) =>
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.length ? data : [{ Note: "No data" }]), name);

      add("Summary", summarySheetRows(full));
      add(
        "Daily",
        full.daily.map((d) => ({
          Date: d.workDate,
          User: d.username,
          "First login": d.firstLogin,
          "Last logout": d.lastLogout,
          Hours: d.hours,
          "Late login": d.lateLogin ? "Yes" : "",
          "Early logout": d.earlyLogout ? "Yes" : "",
          Breaks: d.breaks,
          "Break minutes": d.breakMinutes,
          "Over-limit breaks": d.overLimitBreaks,
          "Inactivity minutes": d.inactivityMinutes,
          Breaches: d.breaches,
          "Tasks completed": d.tasksCompleted,
        })),
      );
      add(
        "Breaks",
        (full.breaks ?? []).map((b) => ({
          User: b.username,
          Process: b.processName,
          Type: b.reasonTypeName,
          Reason: b.reason,
          Start: b.start,
          End: b.end,
          Minutes: b.minutes,
          "Allowed minutes": b.allowedMinutes,
          "Over limit": b.overLimit ? "Yes" : "",
          Status: b.status,
          Comment: b.comment,
        })),
      );
      add(
        "Breaches",
        (full.breaches ?? []).map((b) => ({
          Date: b.workDate,
          User: b.username,
          Process: b.processName,
          Breach: b.breachType,
          Reason: b.reason,
          Details: b.details,
          "Over by (min)": b.exceededMinutes,
          Status: b.status,
          "Agent comment": b.agentComment,
          "Decided by": b.decidedBy,
          "Decision comment": b.decisionComment,
        })),
      );
      add(
        "Trend",
        full.trend.map((t) => ({
          Period: t.label,
          "People present": t.usersPresent,
          Breaks: t.breaks,
          "Break minutes": t.breakMinutes,
          Breaches: t.breaches,
          "Late logins": t.lateLogins,
          "Tasks completed": t.tasksCompleted,
        })),
      );

      XLSX.writeFile(wb, `${fileBase()}.xlsx`);
      if (full.truncated) showToast("Very large range: Breaks/Breaches sheets were capped at 200,000 rows", "info");
    } catch (err: any) {
      showToast(err?.message || "Export failed", "error");
    } finally {
      setExporting(false);
    }
  };

  const exportCsv = () => {
    setOpenMenu(null);
    if (!report) return;
    const data = summarySheetRows(report);
    if (!data.length) return;
    const headers = Object.keys(data[0]);
    const esc = (v: unknown) => {
      const s = v == null ? "" : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const csv = [headers.join(","), ...data.map((r) => headers.map((h) => esc(r[h])).join(","))].join("\r\n");
    const url = URL.createObjectURL(new Blob([`﻿${csv}`], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${fileBase()}_summary.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ── Render helpers ──
  const k = report?.kpis;
  const metric = TREND_METRICS.find((m) => m.id === trendMetric)!;
  const trendMax = Math.max(1, ...(report?.trend ?? []).map((t) => Number(t[trendMetric]) || 0));

  const SortTh = ({ k: key, children, right }: { k: SortKey; children: React.ReactNode; right?: boolean }) => (
    <th
      onClick={() => toggleSort(key)}
      className={cn("px-3 py-3 cursor-pointer select-none hover:text-zinc-600 whitespace-nowrap", right && "text-right")}
    >
      {children}
      {sort.key === key && <span className="ml-1">{sort.dir === "asc" ? "▲" : "▼"}</span>}
    </th>
  );

  return (
    <div className={embedded ? "space-y-6" : "h-full overflow-auto bg-white p-6"}>
      <div className={embedded ? "space-y-6" : "max-w-7xl mx-auto space-y-6"}>
        {/* Header */}
        {!embedded && (
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-zinc-900">Activity Reports</h1>
              <p className="text-sm text-zinc-500">Attendance, breaks, breaches and output by user</p>
            </div>
          </div>
        )}

        {/* Live now (process tab only) */}
        {embedded && presence && (
          <section className="border border-zinc-100 rounded-2xl p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <h3 className="text-base font-bold text-zinc-900">Right now</h3>
              <div className="flex gap-3 text-xs font-bold">
                <span className="text-emerald-600">{presence.summary.online} online</span>
                <span className="text-amber-600">{presence.summary.idle} idle</span>
                <span className="text-sky-600">{presence.summary.onBreak} on break</span>
                <span className="text-zinc-400">{presence.summary.offline} offline</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {presence.users
                .filter((u) => u.status !== "Offline")
                .map((u) => (
                  <span key={u.userId} className={cn("px-2.5 py-1 rounded-full border text-xs font-medium", PRESENCE_STYLE[u.status])}>
                    {u.username}
                    {u.status === "OnBreak" && ` · ${u.breakReason} ${formatMinutes(u.breakMinutes)}`}
                    {u.status === "Idle" && ` · idle ${formatMinutes(u.idleMinutes)}`}
                  </span>
                ))}
              {presence.users.every((u) => u.status === "Offline") && (
                <span className="text-sm text-zinc-400">Nobody is signed in to this process.</span>
              )}
            </div>
          </section>
        )}

        {/* Filters */}
        <section className="flex flex-wrap items-center gap-2 text-sm">
          <select value={preset} onChange={(e) => choosePreset(e.target.value as Preset)} className="px-3 py-2 border border-zinc-200 rounded-lg bg-white">
            {PRESETS.map((p) => (
              <option key={p.id} value={p.id}>{p.label}</option>
            ))}
          </select>
          <input type="date" value={fromDate} max={toDate} onChange={(e) => { setPreset("custom"); setRange([e.target.value, toDate]); }} className="px-2 py-1.5 border border-zinc-200 rounded-lg" />
          <span className="text-zinc-400">to</span>
          <input type="date" value={toDate} min={fromDate} onChange={(e) => { setPreset("custom"); setRange([fromDate, e.target.value]); }} className="px-2 py-1.5 border border-zinc-200 rounded-lg" />

          {!embedded && (
            <div className="relative">
              <button onClick={() => setOpenMenu(openMenu === "process" ? null : "process")} className="flex items-center gap-1.5 px-3 py-2 border border-zinc-200 rounded-lg bg-white">
                {selectedProcessIds.length ? `${selectedProcessIds.length} process(es)` : "All my processes"}
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              {openMenu === "process" && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setOpenMenu(null)} />
                  <div className="absolute z-50 mt-1 w-72 max-h-80 overflow-auto bg-white border border-zinc-200 rounded-lg shadow-xl p-1">
                    <button onClick={() => setSelectedProcessIds([])} className="w-full text-left px-2 py-1.5 text-xs text-blue-600 hover:bg-zinc-50 rounded">All my processes</button>
                    {processes.map((p) => (
                      <label key={p.processId} className="flex items-center gap-2 px-2 py-1.5 hover:bg-zinc-50 rounded cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedProcessIds.includes(p.processId)}
                          onChange={(e) =>
                            setSelectedProcessIds((prev) => (e.target.checked ? [...prev, p.processId] : prev.filter((id) => id !== p.processId)))
                          }
                        />
                        <span className="truncate">{p.processName}</span>
                      </label>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          <div className="relative">
            <button onClick={() => setOpenMenu(openMenu === "user" ? null : "user")} className="flex items-center gap-1.5 px-3 py-2 border border-zinc-200 rounded-lg bg-white">
              {selectedUserIds.length ? `${selectedUserIds.length} user(s)` : "All users"}
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
            {openMenu === "user" && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setOpenMenu(null)} />
                <div className="absolute z-50 mt-1 w-64 max-h-80 overflow-auto bg-white border border-zinc-200 rounded-lg shadow-xl p-1">
                  <button onClick={() => setSelectedUserIds([])} className="w-full text-left px-2 py-1.5 text-xs text-blue-600 hover:bg-zinc-50 rounded">All users</button>
                  {knownUsers.map((u) => (
                    <label key={u.userId} className="flex items-center gap-2 px-2 py-1.5 hover:bg-zinc-50 rounded cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedUserIds.includes(u.userId)}
                        onChange={(e) =>
                          setSelectedUserIds((prev) => (e.target.checked ? [...prev, u.userId] : prev.filter((id) => id !== u.userId)))
                        }
                      />
                      <span className="truncate">{u.username}</span>
                    </label>
                  ))}
                </div>
              </>
            )}
          </div>

          <div className="flex items-center gap-1 px-2 py-1 border border-zinc-200 rounded-lg">
            {[
              [1, "Breaks"],
              [2, "Inactivity"],
              [3, "Delay"],
            ].map(([id, label]) => {
              const on = reasonTypes.length === 0 || reasonTypes.includes(id as number);
              return (
                <button
                  key={id}
                  onClick={() =>
                    setReasonTypes((prev) => {
                      const current = prev.length ? prev : [1, 2, 3];
                      const next = current.includes(id as number) ? current.filter((x) => x !== id) : [...current, id as number];
                      return next.length === 3 || next.length === 0 ? [] : next;
                    })
                  }
                  className={cn("px-2 py-1 rounded text-xs font-medium", on ? "bg-zinc-900 text-white" : "text-zinc-400 hover:bg-zinc-50")}
                >
                  {label}
                </button>
              );
            })}
          </div>

          <select value={groupByChoice} onChange={(e) => setGroupByChoice(e.target.value as GroupBy | "auto")} className="px-3 py-2 border border-zinc-200 rounded-lg bg-white">
            <option value="auto">Trend: auto ({autoGroupBy(fromDate, toDate)})</option>
            <option value="day">Trend: by day</option>
            <option value="week">Trend: by week</option>
            <option value="month">Trend: by month</option>
          </select>

          <div className="ml-auto flex items-center gap-2">
            <button onClick={load} className="p-2 border border-zinc-200 rounded-lg text-zinc-500 hover:bg-zinc-50" title="Refresh">
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </button>
            <div className="relative">
              <button
                disabled={!report || exporting}
                onClick={() => setOpenMenu(openMenu === "export" ? null : "export")}
                className="flex items-center gap-2 px-3 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                Export
              </button>
              {openMenu === "export" && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setOpenMenu(null)} />
                  <div className="absolute right-0 z-50 mt-1 w-64 bg-white border border-zinc-200 rounded-lg shadow-xl p-1">
                    <button onClick={exportExcel} className="w-full flex items-start gap-2 px-3 py-2 text-left hover:bg-zinc-50 rounded">
                      <FileSpreadsheet className="w-4 h-4 mt-0.5 text-emerald-600" />
                      <span>
                        <span className="block font-medium">Excel - full report</span>
                        <span className="block text-xs text-zinc-400">Summary, Daily, Breaks, Breaches, Trend</span>
                      </span>
                    </button>
                    <button onClick={exportCsv} className="w-full flex items-start gap-2 px-3 py-2 text-left hover:bg-zinc-50 rounded">
                      <Download className="w-4 h-4 mt-0.5 text-zinc-500" />
                      <span>
                        <span className="block font-medium">CSV - summary</span>
                        <span className="block text-xs text-zinc-400">One row per user</span>
                      </span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </section>

        {loading && !report ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
          </div>
        ) : report && k ? (
          <>
            {/* KPIs */}
            <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {[
                { icon: Users, label: "People active", value: `${k.usersPresent} / ${k.usersInScope}`, sub: `${k.personDays} person-days`, color: "text-blue-600" },
                { icon: LogIn, label: "Avg first login", value: k.avgFirstLogin ?? "-", sub: `${k.lateLogins} late · ${k.earlyLogouts} early out`, color: "text-amber-600" },
                { icon: Coffee, label: "Breaks", value: k.breaks.toLocaleString(), sub: `${mins(k.breakMinutes)} total · ${k.overLimitBreaks} over limit`, color: "text-sky-600" },
                { icon: Clock, label: "Inactivity", value: mins(k.inactivityMinutes), sub: `${k.inactivityEvents} times`, color: "text-zinc-600" },
                { icon: ShieldAlert, label: "Breaches", value: k.breaches.toLocaleString(), sub: `${k.pendingBreaches} awaiting approval`, color: "text-red-600" },
                { icon: CheckCircle2, label: "Tasks completed", value: k.tasksCompleted.toLocaleString(), sub: k.personDays ? `${(k.tasksCompleted / k.personDays).toFixed(1)} per person-day` : "-", color: "text-emerald-600" },
              ].map((t) => (
                <div key={t.label} className="border border-zinc-100 rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{t.label}</span>
                    <t.icon className={cn("w-4 h-4", t.color)} />
                  </div>
                  <p className="text-2xl font-semibold text-zinc-900 mt-2">{t.value}</p>
                  <p className="text-xs text-zinc-400 mt-1">{t.sub}</p>
                </div>
              ))}
            </section>

            {/* Trend */}
            <section className="border border-zinc-100 rounded-2xl p-5">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <h3 className="text-base font-bold text-zinc-900">Trend</h3>
                <div className="flex flex-wrap gap-1">
                  {TREND_METRICS.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setTrendMetric(m.id)}
                      className={cn("px-2.5 py-1 rounded-full text-xs font-medium border", trendMetric === m.id ? "bg-zinc-900 text-white border-zinc-900" : "text-zinc-500 border-zinc-200 hover:bg-zinc-50")}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>
              {report.trend.length === 0 ? (
                <p className="text-sm text-zinc-400">No data.</p>
              ) : (
                <div className="flex items-end gap-1 h-40 overflow-x-auto pb-6 relative">
                  {report.trend.map((t) => {
                    const v = Number(t[trendMetric]) || 0;
                    return (
                      <div key={t.period} className="flex flex-col items-center justify-end h-full min-w-[22px] flex-1 group relative">
                        <span className="text-[10px] text-zinc-500 opacity-0 group-hover:opacity-100">{v}</span>
                        <div
                          className="w-full rounded-t"
                          style={{ height: `${(v / trendMax) * 100}%`, minHeight: v ? 2 : 0, background: metric.color }}
                          title={`${t.label}: ${v} ${metric.label.toLowerCase()}`}
                        />
                        <span className="absolute -bottom-5 text-[9px] text-zinc-400 whitespace-nowrap">
                          {report.trend.length <= 16 || report.trend.indexOf(t) % Math.ceil(report.trend.length / 12) === 0 ? t.label : ""}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>

            {/* Users */}
            <section className="border border-zinc-100 rounded-2xl overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 border-b border-zinc-100">
                <h3 className="text-base font-bold text-zinc-900">By user</h3>
                <div className="flex items-center gap-3 text-sm">
                  <label className="flex items-center gap-2 text-zinc-500">
                    <input type="checkbox" checked={showByReason} onChange={(e) => setShowByReason(e.target.checked)} />
                    Show each reason
                  </label>
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400" />
                    <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find user" className="pl-8 pr-3 py-1.5 border border-zinc-200 rounded-lg" />
                  </div>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-zinc-100 text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                      <th className="w-8" />
                      <SortTh k="username">User</SortTh>
                      <SortTh k="daysPresent" right>Days</SortTh>
                      <SortTh k="avgFirstLogin">Avg login</SortTh>
                      <SortTh k="avgHoursPerDay" right>Hrs/day</SortTh>
                      <SortTh k="lateLogins" right>Late</SortTh>
                      <SortTh k="earlyLogouts" right>Early out</SortTh>
                      <SortTh k="breaks" right>Breaks</SortTh>
                      <SortTh k="breakMinutes" right>Break time</SortTh>
                      <SortTh k="overLimitBreaks" right>Over limit</SortTh>
                      <SortTh k="inactivityMinutes" right>Inactivity</SortTh>
                      <SortTh k="breaches" right>Breaches</SortTh>
                      <SortTh k="tasksPerDay" right>Tasks/day</SortTh>
                      {showByReason &&
                        report.reasons.map((r) => (
                          <th key={r.reasonId} className="px-3 py-3 text-right whitespace-nowrap">{r.label}</th>
                        ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-50">
                    {rows.length === 0 && (
                      <tr>
                        <td colSpan={13 + (showByReason ? report.reasons.length : 0)} className="py-12 text-center text-zinc-400">
                          No activity in this range.
                        </td>
                      </tr>
                    )}
                    {rows.map((u) => {
                      const open = expandedUser === u.userId;
                      const days = dailyByUser.get(u.userId) ?? [];
                      return (
                        <Fragment key={u.userId}>
                          <tr onClick={() => setExpandedUser(open ? null : u.userId)} className={cn("cursor-pointer hover:bg-zinc-50/70", open && "bg-blue-50/40")}>
                            <td className="pl-4">{open ? <ChevronDown className="w-4 h-4 text-zinc-400" /> : <ChevronRight className="w-4 h-4 text-zinc-300" />}</td>
                            <td className="px-3 py-3">
                              <div className="font-semibold text-zinc-900">{u.username}</div>
                              {!embedded && <div className="text-[11px] text-zinc-400 truncate max-w-[220px]">{u.processes}</div>}
                            </td>
                            <td className="px-3 py-3 text-right">{u.daysPresent}</td>
                            <td className="px-3 py-3">{u.avgFirstLogin ?? "-"}</td>
                            <td className="px-3 py-3 text-right">{u.avgHoursPerDay ?? "-"}</td>
                            <td className={cn("px-3 py-3 text-right", u.lateLogins > 0 && "text-amber-600 font-semibold")}>{u.lateLogins}</td>
                            <td className={cn("px-3 py-3 text-right", u.earlyLogouts > 0 && "text-amber-600 font-semibold")}>{u.earlyLogouts}</td>
                            <td className="px-3 py-3 text-right">{u.breaks}</td>
                            <td className="px-3 py-3 text-right">{mins(u.breakMinutes)}</td>
                            <td className={cn("px-3 py-3 text-right", u.overLimitBreaks > 0 && "text-red-600 font-semibold")}>{u.overLimitBreaks}</td>
                            <td className="px-3 py-3 text-right">{mins(u.inactivityMinutes)}</td>
                            <td className="px-3 py-3 text-right">
                              <span className={cn(u.breaches > 0 && "text-red-600 font-semibold")}>{u.breaches}</span>
                              {u.pendingBreaches > 0 && (
                                <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold" title="Awaiting approval">
                                  {u.pendingBreaches}
                                </span>
                              )}
                            </td>
                            <td className="px-3 py-3 text-right font-semibold text-emerald-600">{u.tasksPerDay ?? "-"}</td>
                            {showByReason &&
                              report.reasons.map((r) => {
                                const s = u.byReason[String(r.reasonId)];
                                return (
                                  <td key={r.reasonId} className="px-3 py-3 text-right whitespace-nowrap text-zinc-600">
                                    {s ? `${s.count} · ${mins(s.minutes)}` : "-"}
                                  </td>
                                );
                              })}
                          </tr>

                          {open && (
                            <tr>
                              <td colSpan={13 + (showByReason ? report.reasons.length : 0)} className="bg-zinc-50/60 px-6 py-3">
                                {days.length === 0 ? (
                                  <p className="text-xs text-zinc-400">No daily activity.</p>
                                ) : (
                                  <table className="w-full text-xs">
                                    <thead>
                                      <tr className="text-zinc-400 uppercase tracking-wider text-[10px]">
                                        <th className="py-1.5 text-left">Date</th>
                                        <th className="text-left">Login</th>
                                        <th className="text-left">Logout</th>
                                        <th className="text-right">Hours</th>
                                        <th className="text-right">Breaks</th>
                                        <th className="text-right">Break time</th>
                                        <th className="text-right">Over limit</th>
                                        <th className="text-right">Inactivity</th>
                                        <th className="text-right">Breaches</th>
                                        <th className="text-right">Tasks</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {days.map((d) => (
                                        <tr key={d.workDate} className="border-t border-zinc-100">
                                          <td className="py-1.5">{parse(d.workDate).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", timeZone: "UTC" })}</td>
                                          <td className={cn(d.lateLogin && "text-amber-600 font-semibold")}>
                                            {d.firstLogin ?? "-"}
                                            {d.lateLogin && " late"}
                                          </td>
                                          <td className={cn(d.earlyLogout && "text-amber-600 font-semibold")}>
                                            {d.lastLogout ?? "-"}
                                            {d.earlyLogout && " early"}
                                          </td>
                                          <td className="text-right">{d.hours ?? "-"}</td>
                                          <td className="text-right">{d.breaks}</td>
                                          <td className="text-right">{mins(d.breakMinutes)}</td>
                                          <td className={cn("text-right", d.overLimitBreaks > 0 && "text-red-600 font-semibold")}>{d.overLimitBreaks}</td>
                                          <td className="text-right">{mins(d.inactivityMinutes)}</td>
                                          <td className={cn("text-right", d.breaches > 0 && "text-red-600 font-semibold")}>{d.breaches}</td>
                                          <td className="text-right">{d.tasksCompleted}</td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                )}
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>

            <p className="flex items-start gap-2 text-xs text-zinc-400">
              <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              Dates and times are US Central work days. "Sign-off for the day" is not counted as break time. Login and logout times
              start from when the presence tracking went live; earlier days show breaks and tasks only.
            </p>
          </>
        ) : null}
      </div>
    </div>
  );
}
