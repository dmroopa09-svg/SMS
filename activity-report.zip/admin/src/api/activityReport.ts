import { apiClient } from "./client";

// post is protected on BaseApiService; call it directly (TypeScript-only restriction).
const client = apiClient as unknown as {
  post<T>(url: string, body?: unknown): Promise<T>;
};

export type GroupBy = "day" | "week" | "month";

export interface ActivityReportRequest {
  fromDate: string; // yyyy-MM-dd
  toDate: string;
  processIds?: number[];
  userIds?: number[];
  reasonTypes?: number[]; // 1 Break, 2 Inactivity, 3 Delay
  groupBy: GroupBy;
  includeDetails?: boolean;
}

export interface ReasonColumn {
  reasonId: number;
  label: string;
  reasonType: number;
}

export interface ActivityKpis {
  usersInScope: number;
  usersPresent: number;
  personDays: number;
  avgFirstLogin: string | null;
  lateLogins: number;
  earlyLogouts: number;
  breaks: number;
  breakMinutes: number;
  overLimitBreaks: number;
  inactivityEvents: number;
  inactivityMinutes: number;
  breaches: number;
  pendingBreaches: number;
  tasksCompleted: number;
}

export interface UserSummaryRow {
  userId: number;
  username: string;
  processes: string;
  daysPresent: number;
  avgFirstLogin: string | null;
  avgLastLogout: string | null;
  avgHoursPerDay: number | null;
  lateLogins: number;
  lateMinutes: number;
  earlyLogouts: number;
  breaks: number;
  breakMinutes: number;
  avgBreakMinutes: number | null;
  overLimitBreaks: number;
  inactivityEvents: number;
  inactivityMinutes: number;
  breaches: number;
  pendingBreaches: number;
  approvedBreaches: number;
  rejectedBreaches: number;
  tasksCompleted: number;
  tasksPerDay: number | null;
  byReason: Record<string, { count: number; minutes: number }>;
}

export interface UserDailyRow {
  userId: number;
  username: string;
  workDate: string;
  firstLogin: string | null;
  lastLogout: string | null;
  hours: number | null;
  lateLogin: boolean;
  earlyLogout: boolean;
  breaks: number;
  breakMinutes: number;
  overLimitBreaks: number;
  inactivityMinutes: number;
  breaches: number;
  tasksCompleted: number;
}

export interface TrendPoint {
  period: string;
  label: string;
  usersPresent: number;
  breaks: number;
  breakMinutes: number;
  breaches: number;
  lateLogins: number;
  tasksCompleted: number;
}

export interface BreakDetailRow {
  breakLogId: number;
  userId: number;
  username: string;
  processName: string | null;
  reason: string | null;
  reasonTypeName: string;
  start: string;
  end: string | null;
  minutes: number | null;
  allowedMinutes: number | null;
  overLimit: boolean;
  status: string | null;
  comment: string | null;
}

export interface BreachDetailRow {
  breachId: number;
  userId: number;
  username: string;
  processName: string | null;
  workDate: string;
  breachType: string;
  reason: string | null;
  details: string | null;
  exceededMinutes: number | null;
  status: string;
  agentComment: string | null;
  decidedBy: string | null;
  decisionComment: string | null;
}

export interface ActivityReport {
  fromDate: string;
  toDate: string;
  groupBy: GroupBy;
  kpis: ActivityKpis;
  reasons: ReasonColumn[];
  users: UserSummaryRow[];
  daily: UserDailyRow[];
  trend: TrendPoint[];
  breaks: BreakDetailRow[] | null;
  breaches: BreachDetailRow[] | null;
  truncated: boolean;
}

export const activityReportApi = {
  get: (req: ActivityReportRequest) => client.post<ActivityReport>("/activity-report", req),
};
