# Activity reports

One report, shown in two places:
- **Process → Activity tab**: this process only, plus a live "Right now" strip (who's online, idle, on break).
- **Activity Reports page** (sidebar): any mix of the processes you can see.

Filters: date presets (today … this year) or a custom range up to 400 days, users, processes,
reason types (Breaks / Inactivity / Delay), trend grouping (auto day/week/month).
Shows KPIs, a trend chart, and a per-user table (click a user for their day-by-day rows;
"Show each reason" adds a count · time column per break reason).

Export:
- **Excel**: 5 sheets — Summary (one row per user, incl. every reason's count and minutes),
  Daily (user × day), Breaks (every break), Breaches (every breach + decision), Trend.
- **CSV**: the summary sheet only.

## Install

1. **Depends on work-policy.zip** (uses IWorkPolicyService, UserDailyAttendance, PolicyBreaches). No new SQL.
2. Backend files → same folders as before (API/Controllers, Application/DTOs, Interfaces, Services).
3. Program.cs:
   ```csharp
   builder.Services.AddScoped<IActivityReportService, ActivityReportService>();
   ```
4. Admin app:
   ```
   npm i xlsx
   ```
   Copy `api/activityReport.ts`, `pages/ActivityReport.tsx`, and replace `pages/ProcessDetail.tsx`
   (only changes: the import, `'activity'` in the tab type, the Activity tab button, and the Activity body branch).
5. Sidebar page (optional), in your router and nav:
   ```tsx
   import ActivityReport from "./pages/ActivityReport";
   <Route path="/activity-reports" element={<ActivityReport />} />
   // nav item: { label: "Activity Reports", icon: Activity, path: "/activity-reports" }
   ```

## Access
Same as Work Policy: roles in `WorkPolicy:AllProcessRoleIds` see every process; Manager (2) and
Supervisor (6) see only their UserProcessPermissions processes; everyone else gets 403.

## Notes
- Work days are each process's time zone (default Central). "Sign-off for the day" is not counted as a break.
- Login/logout, late and early-out figures only exist from the day presence tracking went live;
  breaks and completed tasks go back as far as your data does.
- Breaks/Breaches export sheets cap at 200,000 rows (you get a notice if a range hits it).
