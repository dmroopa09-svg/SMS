using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Data;
using GTXH.SMS.Messaging;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Retries messages that compliance released but delivery never successfully
/// submitted.
///
/// WHY THIS HAS TO EXIST
/// ---------------------
/// Without it, a transient failure is a silent loss.
///
/// When Webex times out or returns a 5xx, DeliveryService leaves the row
/// retryable and deliberately does NOT write a submission row. But nothing was
/// retrying it: compliance had already released the hold and moved on, and the
/// Kafka message was consumed. Those rows sat forever, looking queued, never
/// moving, with nothing reporting a problem.
///
/// A provider blip of a few seconds would have quietly stranded every message in
/// flight at that moment.
///
/// It also recovers a case that is not a failure at all — an event Kafka never
/// delivered, or one lost because the consumer died before committing. Those
/// rows look identical from here and the same sweep picks them up.
/// </summary>
public sealed class DeliveryRetryWorker(
    IServiceScopeFactory scopeFactory,
    DeliveryOptions options,
    ILogger<DeliveryRetryWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!options.RetryEnabled)
        {
            logger.LogWarning(
                "Delivery retry worker is DISABLED. Transient failures will not be retried "
                + "and those messages will never send.");
            return;
        }

        logger.LogInformation(
            "Delivery retry worker started. Every {Poll}s, backoff {Backoff}s, max {Max} attempts.",
            options.RetryPollSeconds, options.RetryBackoffSeconds, options.MaxAttempts);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var retried = await RunOnceAsync(stoppingToken);
                if (retried > 0)
                    logger.LogInformation("Retried {Count} message(s).", retried);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Delivery retry sweep failed.");
            }

            try
            {
                await Task.Delay(TimeSpan.FromSeconds(options.RetryPollSeconds), stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }

        logger.LogInformation("Delivery retry worker stopping.");
    }

    private async Task<int> RunOnceAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DeliveryDbContext>();
        var delivery = scope.ServiceProvider.GetRequiredService<DeliveryService>();

        var candidates = await ClaimAsync(db, ct);
        if (candidates.Count == 0)
            return 0;

        var retried = 0;
        var nowUtc = DateTimeOffset.UtcNow;

        foreach (var c in candidates)
        {
            if (ct.IsCancellationRequested)
                break;

            // -------------------------------------------------------------
            // THE SEND WINDOW MAY HAVE CLOSED WHILE THIS WAS WAITING.
            //
            // A message that failed at 20:50 and is retried at 21:05 would go
            // out after the legal window shut. Compliance computed ExpireAt as
            // end of the recipient's local day precisely so that decision does
            // not have to be recomputed here — if it has passed, the message
            // must not be sent, and tomorrow's run will re-select the account.
            //
            // Without this check the retry worker would quietly reintroduce the
            // breach the whole compliance service exists to prevent.
            // -------------------------------------------------------------
            if (c.ExpireAt is not null && c.ExpireAt <= nowUtc)
            {
                await ExpireAsync(db, c.MessageId, ct);
                logger.LogInformation(
                    "Message {MessageId} not retried — its send window closed at {ExpireAt}.",
                    c.MessageId, c.ExpireAt);
                continue;
            }

            // Rebuild the event from the row. HandleReadyAsync re-checks
            // everything — idempotency, campaign state, content — so a row that
            // became ineligible since it was claimed is handled correctly
            // without duplicating those checks here.
            var evt = new ReadyToSendEvent
            {
                MessageId = c.MessageId,

                // int widens to long? implicitly. See the note on the claim
                // query about why this is an int.
                CampaignQueueId = c.CampaignQueueId,

                CampaignId = c.CampaignId,
                Phone = c.Phone ?? "",
                Account_Info_ID = c.AccountInfoId,
                TemplateId = c.TemplateId,
                ProducerService = ProducerServices.Delivery,

                // Carried from the hold rather than set to "now", so the event
                // still states the instant compliance actually authorised.
                // Falls back to now only when the hold row has gone.
                SendAt = c.SendAt ?? DateTimeOffset.UtcNow,

                // SAME KEY AS THE ORIGINAL. A retry is the same logical message,
                // so if the first attempt did in fact reach the provider, the
                // submission guard stops this becoming a second text.
                IdempotencyKey = $"{c.MessageId}:Ready"
            };

            await delivery.HandleReadyAsync(evt, ct);
            retried++;
        }

        return retried;
    }

    /// <summary>
    /// Marks a message whose send window closed before it could be retried.
    /// Terminal — tomorrow's run re-selects the account if it is still eligible.
    /// </summary>
    private static async Task ExpireAsync(DeliveryDbContext db, long messageId, CancellationToken ct)
    {
        var now = DateTime.UtcNow;

        await db.CampaignMembers
            .Where(m => m.ID == messageId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.Status, CampaignMemberStatus.Expired)
                .SetProperty(m => m.LifecycleState, MessageLifecycleState.TerminatedCompliance)
                .SetProperty(m => m.ResponseMessage, "Send window closed before retry.")
                .SetProperty(m => m.ClaimedAt, (DateTime?)null)
                .SetProperty(m => m.RowUpdatedDt, now), ct);
    }

    /// <summary>
    /// Claims rows atomically so two instances never retry the same message.
    ///
    /// Uses ClaimedAt on SMS_Queue_Detail, which already exists. A claim older
    /// than the stale window is reclaimable, which recovers work from an
    /// instance that died mid-retry.
    ///
    /// READPAST makes a second instance skip rows the first holds rather than
    /// queue behind them, so instances stay independent.
    ///
    /// ⚠ EVERY COLUMN IS EXPLICITLY CAST.
    ///
    /// SqlQuery maps by ordinal and calls the reader method for the declared
    /// property type, with no widening. The row mixes widths — SMS_Queue_Detail
    /// has ID as BIGINT but SMSQueue_Mst_ID as INT — so a property declared long
    /// against an INT column throws:
    ///
    ///     InvalidCastException: Unable to cast object of type 'System.Int32'
    ///     to type 'System.Int64'  at SqlDataReader.GetInt64
    ///
    /// Casting in SQL makes the returned type match the DTO exactly, so this
    /// cannot drift if a column width changes later.
    /// </summary>
    private async Task<List<RetryCandidate>> ClaimAsync(DeliveryDbContext db, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var backoffCutoff = now.AddSeconds(-options.RetryBackoffSeconds);
        var staleClaimCutoff = now.AddSeconds(-options.RetryClaimTimeoutSeconds);

        var readyForDelivery = (byte)MessageLifecycleState.ReadyForDelivery;
        var stateReady = (byte)CampaignState.Ready;
        var stateRunning = (byte)CampaignState.Running;

        return await db.Database
            .SqlQuery<RetryCandidate>($"""
                UPDATE TOP ({options.RetryBatchSize}) d
                SET    d.ClaimedAt = {now}
                OUTPUT CAST(inserted.ID              AS BIGINT) AS MessageId,
                       CAST(inserted.SMSQueue_Mst_ID AS INT)    AS CampaignQueueId,
                       CAST(inserted.Phone           AS VARCHAR(15)) AS Phone,
                       CAST(inserted.Account_Info_ID AS BIGINT) AS AccountInfoId,
                       CAST(m.Campaign_Mstr_ID       AS INT)    AS CampaignId,
                       CAST(m.TemplateId             AS INT)    AS TemplateId,
                       CAST(h.SendAt   AS DATETIMEOFFSET)       AS SendAt,
                       CAST(h.ExpireAt AS DATETIMEOFFSET)       AS ExpireAt
                FROM   dbo.SMS_Queue_Detail AS d WITH (ROWLOCK, UPDLOCK, READPAST)
                INNER  JOIN dbo.SMS_Queue_Mst AS m
                       ON m.ID = d.SMSQueue_Mst_ID
                LEFT   JOIN dbo.SMS_Compliance_holds AS h
                       ON h.MessageId = d.ID
                LEFT   JOIN dbo.SMS_Delivery_Submission AS s
                       ON s.MessageId = d.ID
                OUTER  APPLY (
                       SELECT COUNT(*)              AS Attempts,
                              MAX(a.AttemptedAtUtc) AS LastAttempt
                       FROM   dbo.SMS_Delivery_Attempt AS a
                       WHERE  a.MessageId = d.ID
                ) AS att
                WHERE  d.LifecycleState     = {readyForDelivery}
                  AND  d.Sent_Timestamp_UTC IS NULL
                  AND  s.ID                 IS NULL
                  AND  m.State IN ({stateReady}, {stateRunning})
                  AND  ISNULL(att.Attempts, 0) < {options.MaxAttempts}
                  AND  (att.LastAttempt IS NULL OR att.LastAttempt <= {backoffCutoff})
                  AND  (d.ClaimedAt IS NULL OR d.ClaimedAt <= {staleClaimCutoff})
                """)
            .ToListAsync(ct);
    }

    /// <summary>
    /// Shape returned by the claim.
    ///
    /// Property names must match the OUTPUT aliases, and the TYPES must match
    /// what SQL returns — the casts in the query above guarantee that.
    /// </summary>
    public sealed class RetryCandidate
    {
        /// <summary>SMS_Queue_Detail.ID — BIGINT.</summary>
        public long MessageId { get; set; }

        /// <summary>
        /// SMS_Queue_Detail.SMSQueue_Mst_ID — INT, not BIGINT.
        ///
        /// This is what threw before: declared long against an INT column.
        /// It widens to long? implicitly when the event is built.
        /// </summary>
        public int CampaignQueueId { get; set; }

        public string? Phone { get; set; }

        /// <summary>SMS_Queue_Detail.Account_Info_ID — BIGINT, nullable.</summary>
        public long? AccountInfoId { get; set; }

        /// <summary>SMS_Queue_Mst.Campaign_Mstr_ID — INT.</summary>
        public int CampaignId { get; set; }

        /// <summary>SMS_Queue_Mst.TemplateId — INT.</summary>
        public int TemplateId { get; set; }

        /// <summary>Nullable because the hold join is a LEFT JOIN.</summary>
        public DateTimeOffset? SendAt { get; set; }

        /// <summary>End of the recipient's local day, as compliance computed it.</summary>
        public DateTimeOffset? ExpireAt { get; set; }
    }
}
