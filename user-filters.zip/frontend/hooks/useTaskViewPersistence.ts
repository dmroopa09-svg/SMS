import { useCallback, useEffect, useRef, useState } from "react";
import { SavedFilter, TaskView, userFilterService } from "../services/userFilterService";

/**
 * Keeps the task grid's view (search, filters, columns, sort, paging) across sign-outs and refreshes.
 *
 *  - On process open: restores the server's last state (falls back to a local copy).
 *  - On every change: writes a local copy immediately and the server copy 800 ms after the user stops.
 *  - If the server save fails (session expired mid-shift), the local copy survives the sign-out and is
 *    pushed to the server on the next load - so nothing the agent set up is lost.
 *
 * Usage in the task screen:
 *   const { loaded, saved, saveAs, applySaved, deleteSaved, resetView } =
 *     useTaskViewPersistence(selectedProcess?.id, user?.userId, view, setView, DEFAULT_VIEW);
 *   // Don't fetch tasks until `loaded` is true, or the first fetch uses the default view.
 */
export function useTaskViewPersistence(
  processId: number | null | undefined,
  userId: number | null | undefined,
  view: TaskView,
  applyView: (v: TaskView) => void,
  defaultView: TaskView,
  debounceMs = 800,
) {
  const [loaded, setLoaded] = useState(false);
  const [saved, setSaved] = useState<SavedFilter[]>([]);

  // Which process the current `view` belongs to. Saves are skipped until the restore for this process
  // has been applied - otherwise the default view would overwrite the agent's saved state.
  const restoredFor = useRef<number | null>(null);
  const timer = useRef<number | undefined>(undefined);
  const lastSentJson = useRef<string>("");

  const localKey = processId && userId ? `taskView:${userId}:${processId}` : null;

  // ---- Restore on process change -------------------------------------------------
  useEffect(() => {
    if (!processId || !userId) return;
    let cancelled = false;
    restoredFor.current = null;
    setLoaded(false);

    const local = readLocal(localKey);

    userFilterService
      .getAll(processId)
      .then((res) => {
        if (cancelled) return;
        setSaved(res.saved ?? []);

        const server = res.state;
        // Local copy is newer = the last server save failed (e.g. signed out). Use it and re-sync.
        const useLocal = local && (!server || Date.parse(local.at) > Date.parse(server.updatedAt));
        const v = useLocal ? local!.view : server?.filters ?? defaultView;

        applyView({ ...defaultView, ...v });
        lastSentJson.current = useLocal ? "" : JSON.stringify(v);
      })
      .catch(() => {
        if (cancelled) return;
        applyView(local ? { ...defaultView, ...local.view } : defaultView);
      })
      .finally(() => {
        if (cancelled) return;
        restoredFor.current = processId;
        setLoaded(true);
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [processId, userId]);

  // ---- Save on change -----------------------------------------------------------
  useEffect(() => {
    if (!processId || !localKey || restoredFor.current !== processId) return;

    const json = JSON.stringify(view);
    writeLocal(localKey, view);
    if (json === lastSentJson.current) return;

    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      userFilterService
        .saveState(processId, view)
        .then(() => {
          lastSentJson.current = json;
        })
        .catch(() => {
          /* local copy already written; re-synced on next load */
        });
    }, debounceMs);

    return () => window.clearTimeout(timer.current);
  }, [view, processId, localKey, debounceMs]);

  // ---- Saved filters -------------------------------------------------------------
  const saveAs = useCallback(
    async (name: string, overwrite = false) => {
      if (!processId) return;
      const created = await userFilterService.createSaved(processId, name, view, overwrite);
      setSaved((list) =>
        [...list.filter((s) => s.id !== created.id), created].sort((a, b) => a.name.localeCompare(b.name)),
      );
      return created;
    },
    [processId, view],
  );

  const applySaved = useCallback(
    (s: SavedFilter) => applyView({ ...defaultView, ...s.filters, pageNumber: 1 }),
    [applyView, defaultView],
  );

  const deleteSaved = useCallback(
    async (id: number) => {
      if (!processId) return;
      await userFilterService.deleteSaved(processId, id);
      setSaved((list) => list.filter((s) => s.id !== id));
    },
    [processId],
  );

  const resetView = useCallback(async () => {
    applyView(defaultView);
    if (localKey) removeLocal(localKey);
    if (processId) await userFilterService.clearState(processId).catch(() => {});
  }, [applyView, defaultView, localKey, processId]);

  return { loaded, saved, saveAs, applySaved, deleteSaved, resetView };
}

// ---- localStorage helpers (logout only clears auth_* keys, so these survive sign-out) ----

function readLocal(key: string | null): { view: TaskView; at: string } | null {
  if (!key) return null;
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function writeLocal(key: string, view: TaskView) {
  try {
    localStorage.setItem(key, JSON.stringify({ view, at: new Date().toISOString() }));
  } catch {
    /* storage full / blocked - server copy still works */
  }
}

function removeLocal(key: string) {
  try {
    localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}
