import { apiClient } from "./api";

// ---------------------------------------------------------------------------
// ADAPT THIS ONE BLOCK if apiClient's method names differ (or it has no put/delete:
// add them next to get/post, they are the same request() call with another method).
// ---------------------------------------------------------------------------
const http = {
  get: <T>(url: string) => apiClient.get<T>(url) as Promise<T>,
  post: <T>(url: string, body?: unknown) => apiClient.post<T>(url, body) as Promise<T>,
  put: <T>(url: string, body?: unknown) => apiClient.put<T>(url, body) as Promise<T>,
  del: <T>(url: string) => apiClient.delete<T>(url) as Promise<T>,
};

/** Agent app endpoints include /api (API_BASE_URL ends in /Backend). */
const BASE = "/api/user-filters";

/**
 * What one grid view looks like. Store column KEYS ("taskId"), not header labels ("TASK ID"):
 * labels get renamed, keys don't, and a renamed label would silently drop the column from saved views.
 */
export interface TaskView {
  search: string;
  filters: Record<string, string[]>;
  visibleColumns: string[];
  sort?: { key: string; direction: "asc" | "desc" } | null;
  pageSize: number;
  pageNumber: number;
  /** Bump when the shape changes so old saved views can be migrated or ignored. */
  v?: number;
}

export interface FilterState {
  filters: TaskView;
  updatedAt: string;
}

export interface SavedFilter {
  id: number;
  name: string;
  filters: TaskView;
  createdAt: string;
  updatedAt: string;
}

export interface ProcessFilters {
  processId: number;
  state: FilterState | null;
  saved: SavedFilter[];
}

export const userFilterService = {
  getAll: (processId: number) => http.get<ProcessFilters>(`${BASE}/${processId}`),

  saveState: (processId: number, filters: TaskView) =>
    http.put<FilterState>(`${BASE}/${processId}/state`, { filters }),

  clearState: (processId: number) => http.del<void>(`${BASE}/${processId}/state`),

  getSaved: (processId: number) => http.get<SavedFilter[]>(`${BASE}/${processId}/saved`),

  createSaved: (processId: number, name: string, filters: TaskView, overwrite = false) =>
    http.post<SavedFilter>(`${BASE}/${processId}/saved`, { name, filters, overwrite }),

  updateSaved: (processId: number, id: number, changes: { name?: string; filters?: TaskView }) =>
    http.put<SavedFilter>(`${BASE}/${processId}/saved/${id}`, changes),

  deleteSaved: (processId: number, id: number) => http.del<void>(`${BASE}/${processId}/saved/${id}`),
};
