/*
  UserProcessFilters - per user, per process task-grid view.

  Two kinds of row:
    IsDefault = 1, FilterName NULL      -> the "last state", auto-saved and auto-restored. One per user+process.
    IsDefault = 0, FilterName NOT NULL  -> a named Saved Filter. Name unique per user+process.

  Changes from the first draft:
    - CHECK constraint ties IsDefault to FilterName, so there is no 'DEFAULT'-string convention to get wrong.
    - Unique index on saved filter names (stops two "AETNA Pending" filters).
    - ISJSON check so a broken payload can never be stored.
    - The plain (UserId, ProcessId) index is dropped: the two filtered indexes below already cover
      both lookups (load last state / list saved filters).
*/

IF OBJECT_ID('dbo.UserProcessFilters', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.UserProcessFilters
    (
        Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_UserProcessFilters PRIMARY KEY,
        UserId      INT            NOT NULL,
        ProcessId   INT            NOT NULL,
        FilterName  NVARCHAR(100)  NULL,
        IsDefault   BIT            NOT NULL,
        Filters     NVARCHAR(MAX)  NOT NULL,
        CreatedAt   DATETIME2      NOT NULL CONSTRAINT DF_UserProcessFilters_CreatedAt DEFAULT SYSUTCDATETIME(),
        UpdatedAt   DATETIME2      NOT NULL CONSTRAINT DF_UserProcessFilters_UpdatedAt DEFAULT SYSUTCDATETIME(),

        CONSTRAINT FK_UserProcessFilters_Users
            FOREIGN KEY (UserId) REFERENCES dbo.Users (UserId) ON DELETE CASCADE,
        CONSTRAINT FK_UserProcessFilters_Processes
            FOREIGN KEY (ProcessId) REFERENCES dbo.Processes (ProcessId) ON DELETE CASCADE,

        CONSTRAINT CK_UserProcessFilters_Kind CHECK (
               (IsDefault = 1 AND FilterName IS NULL)
            OR (IsDefault = 0 AND FilterName IS NOT NULL AND LEN(FilterName) > 0)),

        CONSTRAINT CK_UserProcessFilters_Json CHECK (ISJSON(Filters) = 1)
    );

    -- One last-state row per user per process.
    CREATE UNIQUE INDEX UX_UserProcessFilters_State
        ON dbo.UserProcessFilters (UserId, ProcessId)
        WHERE IsDefault = 1;

    -- Saved filter names unique per user per process (case-insensitive with the default collation).
    CREATE UNIQUE INDEX UX_UserProcessFilters_SavedName
        ON dbo.UserProcessFilters (UserId, ProcessId, FilterName)
        WHERE IsDefault = 0;
END
GO

/*
  If CREATE fails with error 1785 ("may cause cycles or multiple cascade paths"), some other FK already
  cascades from Users to Processes. Change ON DELETE CASCADE to NO ACTION on FK_UserProcessFilters_Processes.
*/
