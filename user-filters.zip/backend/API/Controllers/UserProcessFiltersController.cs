using System.Security.Claims;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GTXH.OMC.API.Controllers;

/// <summary>
/// The logged-in user's task-grid views. The user always comes from the token, never from the request,
/// so nobody can read or overwrite someone else's filters.
///
///   GET    api/user-filters/{processId}                 last state + saved filters (call on grid open)
///   GET    api/user-filters/{processId}/state           last state (204 if none)
///   PUT    api/user-filters/{processId}/state           save last state (debounced from the grid)
///   DELETE api/user-filters/{processId}/state           reset view
///   GET    api/user-filters/{processId}/saved           saved filters
///   POST   api/user-filters/{processId}/saved           create (409 if the name exists, unless overwrite)
///   PUT    api/user-filters/{processId}/saved/{id}      rename and/or replace filters
///   DELETE api/user-filters/{processId}/saved/{id}      delete
/// </summary>
[ApiController]
[Authorize]
[Route("api/user-filters")]
public class UserProcessFiltersController : ControllerBase
{
    private readonly IUserProcessFilterService _service;
    private readonly ILogger<UserProcessFiltersController> _logger;

    public UserProcessFiltersController(IUserProcessFilterService service, ILogger<UserProcessFiltersController> logger)
    {
        _service = service;
        _logger = logger;
    }

    [HttpGet("{processId:int}")]
    public Task<IActionResult> GetAll(int processId, CancellationToken ct) =>
        Run(async userId => Ok(await _service.GetAllAsync(userId, processId, ct)));

    [HttpGet("{processId:int}/state")]
    public Task<IActionResult> GetState(int processId, CancellationToken ct) =>
        Run(async userId =>
        {
            var state = await _service.GetStateAsync(userId, processId, ct);
            return state == null ? NoContent() : Ok(state);
        });

    [HttpPut("{processId:int}/state")]
    public Task<IActionResult> SaveState(int processId, [FromBody] SaveFilterStateRequest request, CancellationToken ct) =>
        Run(async userId => Ok(await _service.SaveStateAsync(userId, processId, request.Filters, ct)));

    [HttpDelete("{processId:int}/state")]
    public Task<IActionResult> ClearState(int processId, CancellationToken ct) =>
        Run(async userId =>
        {
            await _service.ClearStateAsync(userId, processId, ct);
            return NoContent();
        });

    [HttpGet("{processId:int}/saved")]
    public Task<IActionResult> GetSaved(int processId, CancellationToken ct) =>
        Run(async userId => Ok(await _service.GetSavedAsync(userId, processId, ct)));

    [HttpPost("{processId:int}/saved")]
    public Task<IActionResult> CreateSaved(int processId, [FromBody] CreateSavedFilterRequest request, CancellationToken ct) =>
        Run(async userId =>
        {
            var saved = await _service.CreateSavedAsync(userId, processId, request, ct);
            return Ok(saved);
        });

    [HttpPut("{processId:int}/saved/{id:int}")]
    public Task<IActionResult> UpdateSaved(int processId, int id, [FromBody] UpdateSavedFilterRequest request, CancellationToken ct) =>
        Run(async userId => Ok(await _service.UpdateSavedAsync(userId, processId, id, request, ct)));

    [HttpDelete("{processId:int}/saved/{id:int}")]
    public Task<IActionResult> DeleteSaved(int processId, int id, CancellationToken ct) =>
        Run(async userId =>
            await _service.DeleteSavedAsync(userId, processId, id, ct)
                ? NoContent()
                : NotFound(new { message = "Saved filter not found." }));

    // ------------------------------------------------------------------------------------

    private async Task<IActionResult> Run(Func<int, Task<IActionResult>> action)
    {
        var userId = GetCurrentUserId();
        if (userId == null) return Unauthorized();

        try
        {
            return await action(userId.Value);
        }
        catch (UserFilterException ex)
        {
            return StatusCode(ex.StatusCode, new { message = ex.Message });
        }
        catch (OperationCanceledException) when (HttpContext.RequestAborted.IsCancellationRequested)
        {
            return StatusCode(499); // client went away (tab closed mid-save) - not an error
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "User filters request failed for user {UserId}", userId);
            return StatusCode(500, new { message = "Could not save or load filters." });
        }
    }

    /// <summary>
    /// ADAPT if your JWT puts the user id under a different claim. If the other controllers already
    /// have a GetCurrentUserId / base-controller helper, use that instead.
    /// </summary>
    private int? GetCurrentUserId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier)
                    ?? User.FindFirstValue("UserId")
                    ?? User.FindFirstValue("userId")
                    ?? User.FindFirstValue("sub");
        return int.TryParse(value, out var id) ? id : null;
    }
}
