using GTXH.OMC.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GTXH.OMC.Infrastructure.Data.Configurations;

public class UserProcessFilterConfiguration : IEntityTypeConfiguration<UserProcessFilter>
{
    public void Configure(EntityTypeBuilder<UserProcessFilter> b)
    {
        b.ToTable("UserProcessFilters", "dbo");
        b.HasKey(x => x.Id);

        b.Property(x => x.FilterName).HasMaxLength(100);
        b.Property(x => x.Filters).IsRequired();
        b.Property(x => x.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");
        b.Property(x => x.UpdatedAt).HasDefaultValueSql("SYSUTCDATETIME()");

        // Mirrors the SQL script (the table is created by script, not migration).
        b.HasIndex(x => new { x.UserId, x.ProcessId })
            .IsUnique()
            .HasFilter("[IsDefault] = 1")
            .HasDatabaseName("UX_UserProcessFilters_State");

        b.HasIndex(x => new { x.UserId, x.ProcessId, x.FilterName })
            .IsUnique()
            .HasFilter("[IsDefault] = 0")
            .HasDatabaseName("UX_UserProcessFilters_SavedName");
    }
}
