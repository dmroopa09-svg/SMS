using System.Text.Json;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
// Alias, not "using GTXH.OMC.Core.Entities;" - that namespace has a Task entity that clashes with
// System.Threading.Tasks.Task in every async signature below.
using UserProcessFilter = GTXH.OMC.Core.Entities.UserProcessFilter;
using ProcessEntity = GTXH.OMC.Core.Entities.Process;

namespace GTXH.OMC.Application.Services;

public class UserProcessFilterService : IUserProcessFilterService
{
    /// <summary>A grid view is a few hundred bytes; anything near this is a frontend bug, not a view.</summary>
    private const int MaxJsonChars = 64 * 1024;
    private const int MaxSavedPerProcess = 30;

    private readonly ApplicationDbContext _db;
    private readonly ILogger<UserProcessFilterService> _logger;

    public UserProcessFilterService(ApplicationDbContext db, ILogger<UserProcessFilterService> logger)
    {
        _db = db;
        _logger = logger;
    }

    private DbSet<UserProcessFilter> Rows => _db.Set<UserProcessFilter>();

    // ------------------------------------------------------------------------------------
    // Read
    // ------------------------------------------------------------------------------------

    public async Task<ProcessFiltersDto> GetAllAsync(int userId, int processId, CancellationToken ct = default)
    {
        var rows = await Rows.AsNoTracking()
            .Where(x => x.UserId == userId && x.ProcessId == processId)
            .ToListAsync(ct);

        var state = rows.FirstOrDefault(x => x.IsDefault);

        return new ProcessFiltersDto
        {
            ProcessId = processId,
            State = state == null ? null : ToStateDto(state),
            Saved = rows.Where(x => !x.IsDefault)
                        .OrderBy(x => x.FilterName)
                        .Select(ToSavedDto)
                        .ToList(),
        };
    }

    public async Task<FilterStateDto?> GetStateAsync(int userId, int processId, CancellationToken ct = default)
    {
        var row = await Rows.AsNoTracking()
            .FirstOrDefaultAsync(x => x.UserId == userId && x.ProcessId == processId && x.IsDefault, ct);
        return row == null ? null : ToStateDto(row);
    }

    public async Task<List<SavedFilterDto>> GetSavedAsync(int userId, int processId, CancellationToken ct = default)
    {
        var rows = await Rows.AsNoTracking()
            .Where(x => x.UserId == userId && x.ProcessId == processId && !x.IsDefault)
            .OrderBy(x => x.FilterName)
            .ToListAsync(ct);
        return rows.Select(ToSavedDto).ToList();
    }

    // ------------------------------------------------------------------------------------
    // Last state
    // ------------------------------------------------------------------------------------

    public async Task<FilterStateDto> SaveStateAsync(int userId, int processId, JsonElement filters, CancellationToken ct = default)
    {
        var json = ValidateJson(filters);
        await EnsureProcessExistsAsync(processId, ct);

        var now = DateTime.UtcNow;
        var row = await Rows.FirstOrDefaultAsync(x => x.UserId == userId && x.ProcessId == processId && x.IsDefault, ct);

        if (row != null)
        {
            row.Filters = json;
            row.UpdatedAt = now;
            await _db.SaveChangesAsync(ct);
            return ToStateDto(row);
        }

        row = new UserProcessFilter
        {
            UserId = userId,
            ProcessId = processId,
            IsDefault = true,
            FilterName = null,
            Filters = json,
            CreatedAt = now,
            UpdatedAt = now,
        };
        Rows.Add(row);

        try
        {
            await _db.SaveChangesAsync(ct);
            return ToStateDto(row);
        }
        catch (DbUpdateException ex) when (IsUniqueViolation(ex))
        {
            // Two tabs saved the first state at the same moment; the other one won the insert.
            // Update its row instead.
            _db.Entry(row).State = EntityState.Detached;

            var existing = await Rows.FirstAsync(x => x.UserId == userId && x.ProcessId == processId && x.IsDefault, ct);
            existing.Filters = json;
            existing.UpdatedAt = now;
            await _db.SaveChangesAsync(ct);
            return ToStateDto(existing);
        }
    }

    public async Task<bool> ClearStateAsync(int userId, int processId, CancellationToken ct = default)
    {
        var row = await Rows.FirstOrDefaultAsync(x => x.UserId == userId && x.ProcessId == processId && x.IsDefault, ct);
        if (row == null) return false;

        Rows.Remove(row);
        await _db.SaveChangesAsync(ct);
        return true;
    }

    // ------------------------------------------------------------------------------------
    // Saved filters
    // ------------------------------------------------------------------------------------

    public async Task<SavedFilterDto> CreateSavedAsync(int userId, int processId, CreateSavedFilterRequest request, CancellationToken ct = default)
    {
        var name = CleanName(request.Name);
        var json = ValidateJson(request.Filters);
        await EnsureProcessExistsAsync(processId, ct);

        var now = DateTime.UtcNow;

        // SQL Server's default collation is case-insensitive, so this matches the unique index.
        var existing = await Rows.FirstOrDefaultAsync(x =>
            x.UserId == userId && x.ProcessId == processId && !x.IsDefault && x.FilterName == name, ct);

        if (existing != null)
        {
            if (!request.Overwrite)
                throw new UserFilterException(409, $"A saved filter named '{name}' already exists.");

            existing.Filters = json;
            existing.UpdatedAt = now;
            await _db.SaveChangesAsync(ct);
            return ToSavedDto(existing);
        }

        var count = await Rows.CountAsync(x => x.UserId == userId && x.ProcessId == processId && !x.IsDefault, ct);
        if (count >= MaxSavedPerProcess)
            throw new UserFilterException(400,
                $"You can keep up to {MaxSavedPerProcess} saved filters per process. Delete one first.");

        var row = new UserProcessFilter
        {
            UserId = userId,
            ProcessId = processId,
            IsDefault = false,
            FilterName = name,
            Filters = json,
            CreatedAt = now,
            UpdatedAt = now,
        };
        Rows.Add(row);

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex) when (IsUniqueViolation(ex))
        {
            _db.Entry(row).State = EntityState.Detached;
            throw new UserFilterException(409, $"A saved filter named '{name}' already exists.");
        }

        return ToSavedDto(row);
    }

    public async Task<SavedFilterDto> UpdateSavedAsync(int userId, int processId, int id, UpdateSavedFilterRequest request, CancellationToken ct = default)
    {
        // Scoped by user + process: an id from someone else's filter is simply "not found".
        var row = await Rows.FirstOrDefaultAsync(x =>
            x.Id == id && x.UserId == userId && x.ProcessId == processId && !x.IsDefault, ct)
            ?? throw new UserFilterException(404, "Saved filter not found.");

        if (request.Name != null)
        {
            var name = CleanName(request.Name);
            if (!string.Equals(name, row.FilterName, StringComparison.OrdinalIgnoreCase))
            {
                var clash = await Rows.AnyAsync(x =>
                    x.UserId == userId && x.ProcessId == processId && !x.IsDefault && x.Id != id && x.FilterName == name, ct);
                if (clash)
                    throw new UserFilterException(409, $"A saved filter named '{name}' already exists.");
            }
            row.FilterName = name;
        }

        if (request.Filters.HasValue && request.Filters.Value.ValueKind != JsonValueKind.Undefined)
            row.Filters = ValidateJson(request.Filters.Value);

        row.UpdatedAt = DateTime.UtcNow;

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex) when (IsUniqueViolation(ex))
        {
            throw new UserFilterException(409, $"A saved filter named '{row.FilterName}' already exists.");
        }

        return ToSavedDto(row);
    }

    public async Task<bool> DeleteSavedAsync(int userId, int processId, int id, CancellationToken ct = default)
    {
        var row = await Rows.FirstOrDefaultAsync(x =>
            x.Id == id && x.UserId == userId && x.ProcessId == processId && !x.IsDefault, ct);
        if (row == null) return false;

        Rows.Remove(row);
        await _db.SaveChangesAsync(ct);
        return true;
    }

    // ------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------

    private async System.Threading.Tasks.Task EnsureProcessExistsAsync(int processId, CancellationToken ct)
    {
        // Without this a bad processId surfaces as an FK violation (500) instead of a 404.
        var exists = await _db.Set<ProcessEntity>().AsNoTracking().AnyAsync(p => p.ProcessId == processId, ct);
        if (!exists) throw new UserFilterException(404, $"Process {processId} not found.");
    }

    private static string ValidateJson(JsonElement filters)
    {
        if (filters.ValueKind != JsonValueKind.Object)
            throw new UserFilterException(400, "filters must be a JSON object.");

        var json = filters.GetRawText();
        if (json.Length > MaxJsonChars)
            throw new UserFilterException(400, "filters is too large.");

        return json;
    }

    private static string CleanName(string? name)
    {
        var n = (name ?? string.Empty).Trim();
        if (n.Length == 0) throw new UserFilterException(400, "Filter name is required.");
        if (n.Length > 100) throw new UserFilterException(400, "Filter name must be 100 characters or fewer.");
        return n;
    }

    private static bool IsUniqueViolation(DbUpdateException ex) =>
        ex.GetBaseException() is SqlException sql && (sql.Number == 2601 || sql.Number == 2627);

    private static JsonElement Parse(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(json) ? "{}" : json);
            return doc.RootElement.Clone();
        }
        catch (JsonException)
        {
            using var empty = JsonDocument.Parse("{}");
            return empty.RootElement.Clone();
        }
    }

    private static FilterStateDto ToStateDto(UserProcessFilter x) => new()
    {
        Filters = Parse(x.Filters),
        UpdatedAt = x.UpdatedAt,
    };

    private static SavedFilterDto ToSavedDto(UserProcessFilter x) => new()
    {
        Id = x.Id,
        Name = x.FilterName ?? string.Empty,
        Filters = Parse(x.Filters),
        CreatedAt = x.CreatedAt,
        UpdatedAt = x.UpdatedAt,
    };
}
