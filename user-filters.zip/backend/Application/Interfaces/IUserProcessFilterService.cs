using System.Text.Json;
using GTXH.OMC.Application.DTOs;

namespace GTXH.OMC.Application.Interfaces;

public interface IUserProcessFilterService
{
    /// <summary>Last state + saved filters for one process.</summary>
    Task<ProcessFiltersDto> GetAllAsync(int userId, int processId, CancellationToken ct = default);

    Task<FilterStateDto?> GetStateAsync(int userId, int processId, CancellationToken ct = default);

    /// <summary>Insert or update the last state. Safe to call often (debounced from the grid).</summary>
    Task<FilterStateDto> SaveStateAsync(int userId, int processId, JsonElement filters, CancellationToken ct = default);

    /// <summary>"Reset view". Returns false if there was nothing to clear.</summary>
    Task<bool> ClearStateAsync(int userId, int processId, CancellationToken ct = default);

    Task<List<SavedFilterDto>> GetSavedAsync(int userId, int processId, CancellationToken ct = default);

    Task<SavedFilterDto> CreateSavedAsync(int userId, int processId, CreateSavedFilterRequest request, CancellationToken ct = default);

    Task<SavedFilterDto> UpdateSavedAsync(int userId, int processId, int id, UpdateSavedFilterRequest request, CancellationToken ct = default);

    Task<bool> DeleteSavedAsync(int userId, int processId, int id, CancellationToken ct = default);
}
