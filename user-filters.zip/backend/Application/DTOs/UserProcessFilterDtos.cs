using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace GTXH.OMC.Application.DTOs;

/*
  Filters travels as a JSON object, not a string - the frontend sends and receives the object as-is:

  {
    "search": "AETNA",
    "filters": { "status": ["Pending"], "priority": ["URGENT"], "assigned": ["Bhanu Priya"] },
    "visibleColumns": ["taskId", "status", "priority", "assigned", "insurance"],
    "sort": { "key": "createdDate", "direction": "desc" },
    "pageSize": 50,
    "pageNumber": 1
  }

  The API does not interpret the contents, so new keys can be added on the frontend with no backend change.
*/

/// <summary>The auto-saved last state for a process.</summary>
public class FilterStateDto
{
    public JsonElement Filters { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class SavedFilterDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public JsonElement Filters { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

/// <summary>Everything the task grid needs on open, in one call.</summary>
public class ProcessFiltersDto
{
    public int ProcessId { get; set; }
    public FilterStateDto? State { get; set; }
    public List<SavedFilterDto> Saved { get; set; } = new();
}

public class SaveFilterStateRequest
{
    public JsonElement Filters { get; set; }
}

public class CreateSavedFilterRequest
{
    [Required, StringLength(100, MinimumLength = 1)]
    public string Name { get; set; } = string.Empty;

    public JsonElement Filters { get; set; }

    /// <summary>True replaces a saved filter that already has this name instead of returning 409.</summary>
    public bool Overwrite { get; set; }
}

public class UpdateSavedFilterRequest
{
    /// <summary>New name; null keeps the current one.</summary>
    [StringLength(100, MinimumLength = 1)]
    public string? Name { get; set; }

    /// <summary>New filters; omitted keeps the current ones.</summary>
    public JsonElement? Filters { get; set; }
}

/// <summary>Thrown by the filter service; the controller maps StatusCode to the HTTP response.</summary>
public class UserFilterException : Exception
{
    public int StatusCode { get; }
    public UserFilterException(int statusCode, string message) : base(message) => StatusCode = statusCode;
}
