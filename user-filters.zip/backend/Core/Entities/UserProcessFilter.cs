namespace GTXH.OMC.Core.Entities;

/// <summary>
/// A user's saved task-grid view for one process.
/// IsDefault = true  -> the auto-saved "last state" (FilterName is null, one per user+process).
/// IsDefault = false -> a named Saved Filter.
/// </summary>
public class UserProcessFilter
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int ProcessId { get; set; }
    public string? FilterName { get; set; }
    public bool IsDefault { get; set; }

    /// <summary>Raw JSON: search, filters, visibleColumns, sort, pageSize, pageNumber.</summary>
    public string Filters { get; set; } = "{}";

    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}
