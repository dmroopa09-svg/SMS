# User filters: saved views for the Agent Tasks app

Keeps each agent's grid view (search, filters, columns, sort, page size, page) per process, so a sign-out or refresh no longer resets it. Agents can also keep named **Saved Filters**.

## Backend (GTXH.OMC)

| File | Goes to |
|---|---|
| `sql/01_UserProcessFilters.sql` | Run once (instead of the first draft) |
| `Core/Entities/UserProcessFilter.cs` | GTXH.OMC.Core/Entities |
| `Infrastructure/Data/Configurations/UserProcessFilterConfiguration.cs` | GTXH.OMC.Infrastructure/Data/Configurations |
| `Application/DTOs/UserProcessFilterDtos.cs` | GTXH.OMC.Application/DTOs |
| `Application/Interfaces/IUserProcessFilterService.cs` | GTXH.OMC.Application/Interfaces |
| `Application/Services/UserProcessFilterService.cs` | GTXH.OMC.Application/Services |
| `API/Controllers/UserProcessFiltersController.cs` | GTXH.OMC.API/Controllers |

**Wire-up (2 lines):**

```csharp
// Program.cs
builder.Services.AddScoped<IUserProcessFilterService, UserProcessFilterService>();

// ApplicationDbContext.OnModelCreating - skip if you already call ApplyConfigurationsFromAssembly
modelBuilder.ApplyConfiguration(new UserProcessFilterConfiguration());
```

You can optionally add `public DbSet<UserProcessFilter> UserProcessFilters { get; set; }` to the DbContext. The service uses `Set<UserProcessFilter>()`, so it isn't required.

**Check:** `GetCurrentUserId()` in the controller reads the `NameIdentifier`, `UserId` or `sub` claim. If your other controllers use a helper, use that instead.

## Endpoints

| Method | Route | Use |
|---|---|---|
| GET | `api/user-filters/{processId}` | On grid open: last state and saved filters |
| PUT | `api/user-filters/{processId}/state` | Auto-save the view (debounced) |
| DELETE | `api/user-filters/{processId}/state` | "Reset view" |
| GET | `api/user-filters/{processId}/saved` | List saved filters |
| POST | `api/user-filters/{processId}/saved` | Save as `{ name, filters, overwrite }`. Returns 409 if the name exists |
| PUT | `api/user-filters/{processId}/saved/{id}` | Rename or update `{ name?, filters? }` |
| DELETE | `api/user-filters/{processId}/saved/{id}` | Delete |

`filters` is sent and returned as a **JSON object**, not a string. The API doesn't look inside it, so you can add new keys without a backend change.

## Frontend (agentCs_frontend)

- `services/userFilterService.ts` goes to `src/services/`. Check the `http` block, because apiClient needs `put` and `delete`.
- `hooks/useTaskViewPersistence.ts` goes to `src/hooks/`.

```tsx
const DEFAULT_VIEW: TaskView = {
  search: "", filters: {}, visibleColumns: ALL_COLUMN_KEYS, sort: null, pageSize: 50, pageNumber: 1, v: 1,
};
const [view, setView] = useState<TaskView>(DEFAULT_VIEW);

const { loaded, saved, saveAs, applySaved, deleteSaved, resetView } =
  useTaskViewPersistence(selectedProcess?.id, user?.userId, view, setView, DEFAULT_VIEW);

// Gate the first task fetch on `loaded`, otherwise it runs with the default view.
```

If the server save fails because the session expired, the view is also kept in localStorage under `taskView:{userId}:{processId}`. Logout only clears the `auth_*` keys, so this copy survives. On the next login the newer copy wins and is pushed back to the server.

Store column **keys** (`taskId`), not header labels (`TASK ID`). Labels get renamed and keys don't.
