namespace FileSyncWatcher;

public sealed class SyncOptions
{
    public const string SectionName = "Sync";

    /// <summary>
    /// The folder the application writes merged PDFs to (DestinationPath in the legacy app).
    /// This is the RIGHT-hand folder in the screenshots: ...\WebsiteData\eDocs\Live\EOBs\GTXHPrintMail
    /// </summary>
    public string SourceDirectory { get; set; } = "";

    /// <summary>
    /// The folder the application is supposed to copy into (ArchivePath in the legacy app).
    /// This is the LEFT-hand folder: ...\FreeData\Letter_Logic_Queue\Active\PM_PDFs
    /// </summary>
    public string TargetDirectory { get; set; } = "";

    /// <summary>File filter for the watcher. Defaults to PDFs only.</summary>
    public string Filter { get; set; } = "*.pdf";

    /// <summary>
    /// SAFETY SWITCH. When true, the service logs every action it *would* take but copies nothing.
    /// Leave this true for one full business day, read the log, then flip it.
    /// </summary>
    public bool DryRun { get; set; } = true;

    /// <summary>
    /// When true, a file present in the source but completely absent from the target is copied.
    ///
    /// DANGER: if TargetDirectory is a queue that a downstream process drains, "absent" means
    /// "already processed and mailed", not "copy failed". Turning this on can cause duplicate
    /// mailings. Only enable after confirming the target is a passive archive, or rely on
    /// MissingGraceMinutes to bound the blast radius.
    /// </summary>
    public bool CopyWhenMissingFromTarget { get; set; } = false;

    /// <summary>
    /// Only relevant when CopyWhenMissingFromTarget is true. A source file whose last-write time
    /// is older than this many minutes is never treated as "missing" — it is assumed to have been
    /// consumed downstream. Keep this comfortably shorter than your queue drain interval.
    /// </summary>
    public int MissingGraceMinutes { get; set; } = 20;

    /// <summary>
    /// Compare file contents with SHA-256 rather than trusting length alone.
    /// Slower, but catches same-size-different-content cases.
    /// </summary>
    public bool UseHashComparison { get; set; } = true;

    /// <summary>
    /// Files larger than this are compared on length + last-write-time only, never hashed.
    /// Default 64 MB.
    /// </summary>
    public long MaxHashBytes { get; set; } = 64L * 1024 * 1024;

    /// <summary>
    /// How long a file's length must stay unchanged before it is considered fully written.
    /// The producing app writes PDFs incrementally, so acting too early copies a truncated file.
    /// </summary>
    public int StabilityWindowSeconds { get; set; } = 5;

    /// <summary>Maximum time to wait for a file to stabilise before giving up on it.</summary>
    public int StabilityTimeoutSeconds { get; set; } = 300;

    /// <summary>
    /// Reconciliation sweep interval. FileSystemWatcher drops events on network shares
    /// (dropped SMB sessions, buffer overflow), so the sweep is the real guarantee — the
    /// watcher is only the fast path.
    /// </summary>
    public int SweepIntervalMinutes { get; set; } = 15;

    /// <summary>
    /// The sweep only examines source files modified within this many hours. With 63k+ files in
    /// the source directory, a full scan every cycle is neither necessary nor kind to the NAS.
    /// </summary>
    public int SweepLookbackHours { get; set; } = 24;

    /// <summary>Retry attempts for a copy that fails on a transient IO/sharing error.</summary>
    public int CopyRetryCount { get; set; } = 5;

    /// <summary>Base delay between copy retries; grows linearly with attempt number.</summary>
    public int CopyRetryBaseDelaySeconds { get; set; } = 3;

    public IEnumerable<string> Validate()
    {
        if (string.IsNullOrWhiteSpace(SourceDirectory))
            yield return "Sync:SourceDirectory is required.";
        if (string.IsNullOrWhiteSpace(TargetDirectory))
            yield return "Sync:TargetDirectory is required.";

        if (!string.IsNullOrWhiteSpace(SourceDirectory) &&
            !string.IsNullOrWhiteSpace(TargetDirectory) &&
            string.Equals(
                Path.TrimEndingDirectorySeparator(SourceDirectory),
                Path.TrimEndingDirectorySeparator(TargetDirectory),
                StringComparison.OrdinalIgnoreCase))
        {
            yield return "Sync:SourceDirectory and Sync:TargetDirectory must not be the same folder.";
        }

        if (StabilityWindowSeconds < 1)
            yield return "Sync:StabilityWindowSeconds must be at least 1.";
        if (SweepIntervalMinutes < 1)
            yield return "Sync:SweepIntervalMinutes must be at least 1.";
        if (MissingGraceMinutes < 0)
            yield return "Sync:MissingGraceMinutes must not be negative.";
    }
}
