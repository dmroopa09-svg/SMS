using Microsoft.Extensions.Logging;

namespace FileSyncWatcher;

/// <summary>
/// The producing application creates the PDF with FileMode.Create and streams pages into it.
/// A Created event therefore fires long before the file is complete. This waits until the
/// length has stopped changing AND the file can be opened for exclusive read.
/// </summary>
public sealed class FileStabilityChecker
{
    private readonly ILogger<FileStabilityChecker> _logger;

    public FileStabilityChecker(ILogger<FileStabilityChecker> logger) => _logger = logger;

    public async Task<bool> WaitForStableAsync(
        string path,
        TimeSpan window,
        TimeSpan timeout,
        CancellationToken ct)
    {
        var deadline = DateTime.UtcNow + timeout;
        long lastLength = -1;
        var stableSince = DateTime.UtcNow;

        while (!ct.IsCancellationRequested)
        {
            if (DateTime.UtcNow > deadline)
            {
                _logger.LogWarning(
                    "Gave up waiting for {Path} to stabilise after {Timeout}. It may be locked by another process.",
                    path, timeout);
                return false;
            }

            FileInfo info;
            try
            {
                info = new FileInfo(path);
                info.Refresh();
                if (!info.Exists)
                {
                    // Transient during a rename, or the file was removed again. Either way, nothing to do.
                    _logger.LogDebug("{Path} no longer exists while waiting for stability.", path);
                    return false;
                }
            }
            catch (IOException ex)
            {
                _logger.LogDebug(ex, "Could not stat {Path}; will retry.", path);
                await Task.Delay(TimeSpan.FromSeconds(1), ct);
                continue;
            }

            if (info.Length != lastLength)
            {
                lastLength = info.Length;
                stableSince = DateTime.UtcNow;
            }
            else if (DateTime.UtcNow - stableSince >= window && CanOpenExclusively(path))
            {
                return true;
            }

            await Task.Delay(TimeSpan.FromSeconds(1), ct);
        }

        return false;
    }

    private static bool CanOpenExclusively(string path)
    {
        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.None);
            return true;
        }
        catch (IOException)
        {
            // Still held open by the writer.
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            // Permissions issue rather than a lock; let the copy attempt surface the real error.
            return true;
        }
    }
}
