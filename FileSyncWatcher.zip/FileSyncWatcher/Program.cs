using FileSyncWatcher;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Serilog;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddWindowsService(options =>
{
    options.ServiceName = "FileSyncWatcher";
});

builder.Services.AddSerilog((services, config) => config
    .ReadFrom.Configuration(builder.Configuration)
    .ReadFrom.Services(services));

builder.Services
    .AddOptions<SyncOptions>()
    .Bind(builder.Configuration.GetSection(SyncOptions.SectionName))
    .Validate(options =>
    {
        var errors = options.Validate().ToList();
        if (errors.Count == 0) return true;
        foreach (var error in errors)
            Console.Error.WriteLine($"Configuration error: {error}");
        return false;
    }, "Invalid Sync configuration. See errors above.")
    .ValidateOnStart();

builder.Services.AddSingleton<FileStabilityChecker>();
builder.Services.AddSingleton<SyncService>();
builder.Services.AddHostedService<SyncWorker>();

var host = builder.Build();

try
{
    // Surface configuration problems as a clean message rather than a stack trace on startup.
    _ = host.Services.GetRequiredService<IOptions<SyncOptions>>().Value;
}
catch (OptionsValidationException ex)
{
    Console.Error.WriteLine(ex.Message);
    return 1;
}

await host.RunAsync();
return 0;
