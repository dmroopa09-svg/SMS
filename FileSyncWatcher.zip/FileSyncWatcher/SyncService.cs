using System.Security.Cryptography;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace FileSyncWatcher;

public enum SyncDecision
{
    /// <summary>Target already matches the source. Nothing done.</summary>
    InSync,

    /// <summary>Target exists but differs. This is the stale-archive bug.</summary>
    CopiedOverStale,

    /// <summary>Target absent and policy allowed the copy.</summary>
    CopiedMissing,

    /// <summary>Target absent but policy withheld the copy (likely already consumed downstream).</summary>
    SkippedMissing,

    /// <summary>Source vanished, was never stable, or the copy failed after all retries.</summary>
    Failed
}

public sealed class SyncService
{
    private readonly SyncOptions _options;
    private readonly FileStabilityChecker _stability;
    private readonly ILogger<SyncService> _logger;

    public SyncService(
        IOptions<SyncOptions> options,
        FileStabilityChecker stability,
        ILogger<SyncService> logger)
    {
        _options = options.Value;
        _stability = stability;
        _logger = logger;
    }

    public async Task<SyncDecision> ProcessAsync(string sourcePath, CancellationToken ct)
    {
        var fileName = Path.GetFileName(sourcePath);

        if (!File.Exists(sourcePath))
        {
            _logger.LogDebug("{File} disappeared before it could be processed.", fileName);
            return SyncDecision.Failed;
        }

        var stable = await _stability.WaitForStableAsync(
            sourcePath,
            TimeSpan.FromSeconds(_options.StabilityWindowSeconds),
            TimeSpan.FromSeconds(_options.StabilityTimeoutSeconds),
            ct);

        if (!stable)
            return SyncDecision.Failed;

        var targetPath = Path.Combine(_options.TargetDirectory, fileName);

        if (!File.Exists(targetPath))
            return await HandleMissingAsync(sourcePath, targetPath, fileName, ct);

        return await HandleExistingAsync(sourcePath, targetPath, fileName, ct);
    }

    private async Task<SyncDecision> HandleMissingAsync(
        string sourcePath, string targetPath, string fileName, CancellationToken ct)
    {
        if (!_options.CopyWhenMissingFromTarget)
        {
            _logger.LogInformation(
                "MISSING  {File} — not present in target. Not copying (CopyWhenMissingFromTarget is off; " +
                "the file was most likely already picked up downstream).",
                fileName);
            return SyncDecision.SkippedMissing;
        }

        var age = DateTime.UtcNow - File.GetLastWriteTimeUtc(sourcePath);
        if (age > TimeSpan.FromMinutes(_options.MissingGraceMinutes))
        {
            _logger.LogInformation(
                "MISSING  {File} — absent from target but {Age:0} minutes old, beyond the {Grace} minute grace " +
                "window. Assuming it was consumed downstream; not copying.",
                fileName, age.TotalMinutes, _options.MissingGraceMinutes);
            return SyncDecision.SkippedMissing;
        }

        _logger.LogWarning(
            "MISSING  {File} — absent from target and only {Age:0} minutes old. Copying.",
            fileName, age.TotalMinutes);

        return await CopyAsync(sourcePath, targetPath, fileName, ct)
            ? SyncDecision.CopiedMissing
            : SyncDecision.Failed;
    }

    private async Task<SyncDecision> HandleExistingAsync(
        string sourcePath, string targetPath, string fileName, CancellationToken ct)
    {
        bool differs;
        string reason;

        try
        {
            var srcInfo = new FileInfo(sourcePath);
            var tgtInfo = new FileInfo(targetPath);

            if (srcInfo.Length != tgtInfo.Length)
            {
                differs = true;
                reason = $"length {srcInfo.Length:N0} vs {tgtInfo.Length:N0}";
            }
            else if (_options.UseHashComparison && srcInfo.Length <= _options.MaxHashBytes)
            {
                var srcHash = await ComputeHashAsync(sourcePath, ct);
                var tgtHash = await ComputeHashAsync(targetPath, ct);
                differs = !string.Equals(srcHash, tgtHash, StringComparison.Ordinal);
                reason = differs ? "content hash mismatch at equal length" : "identical";
            }
            else
            {
                // Equal length and hashing skipped: fall back to modification time.
                differs = srcInfo.LastWriteTimeUtc > tgtInfo.LastWriteTimeUtc.AddSeconds(2);
                reason = differs
                    ? $"source newer ({srcInfo.LastWriteTimeUtc:u} vs {tgtInfo.LastWriteTimeUtc:u}) at equal length"
                    : "identical";
            }
        }
        catch (IOException ex)
        {
            _logger.LogError(ex, "FAILED   {File} — could not compare source and target.", fileName);
            return SyncDecision.Failed;
        }

        if (!differs)
        {
            _logger.LogDebug("IN SYNC  {File}", fileName);
            return SyncDecision.InSync;
        }

        _logger.LogWarning(
            "STALE    {File} — target differs from source ({Reason}). This is the archive-copy failure. Overwriting.",
            fileName, reason);

        return await CopyAsync(sourcePath, targetPath, fileName, ct)
            ? SyncDecision.CopiedOverStale
            : SyncDecision.Failed;
    }

    /// <summary>
    /// Copies via a temporary file in the target directory, then moves it into place.
    /// A straight File.Copy into a live queue folder can be picked up half-written by the
    /// downstream process; the move is close enough to atomic on a single SMB share to avoid that.
    /// </summary>
    private async Task<bool> CopyAsync(string sourcePath, string targetPath, string fileName, CancellationToken ct)
    {
        if (_options.DryRun)
        {
            _logger.LogInformation("DRY RUN  would copy {Source} -> {Target}", sourcePath, targetPath);
            return true;
        }

        var tempPath = targetPath + ".syncing.tmp";

        for (var attempt = 1; attempt <= _options.CopyRetryCount; attempt++)
        {
            try
            {
                Directory.CreateDirectory(_options.TargetDirectory);

                using (var src = new FileStream(sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, useAsync: true))
                using (var dst = new FileStream(tempPath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
                {
                    await src.CopyToAsync(dst, ct);
                    await dst.FlushAsync(ct);
                }

                File.Move(tempPath, targetPath, overwrite: true);
                File.SetLastWriteTimeUtc(targetPath, File.GetLastWriteTimeUtc(sourcePath));

                _logger.LogInformation("COPIED   {File} -> {Target}", fileName, targetPath);
                return true;
            }
            catch (OperationCanceledException)
            {
                TryDeleteTemp(tempPath);
                throw;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                TryDeleteTemp(tempPath);

                if (attempt == _options.CopyRetryCount)
                {
                    _logger.LogError(ex,
                        "FAILED   {File} — copy failed after {Attempts} attempts. Target may still hold a stale version.",
                        fileName, attempt);
                    return false;
                }

                var delay = TimeSpan.FromSeconds(_options.CopyRetryBaseDelaySeconds * attempt);
                _logger.LogWarning(
                    "RETRY    {File} — attempt {Attempt} failed ({Message}). Retrying in {Delay}.",
                    fileName, attempt, ex.Message, delay);
                await Task.Delay(delay, ct);
            }
        }

        return false;
    }

    private void TryDeleteTemp(string tempPath)
    {
        try
        {
            if (File.Exists(tempPath))
                File.Delete(tempPath);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Could not clean up temp file {Temp}.", tempPath);
        }
    }

    private static async Task<string> ComputeHashAsync(string path, CancellationToken ct)
    {
        using var sha = SHA256.Create();
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, useAsync: true);
        var hash = await sha.ComputeHashAsync(stream, ct);
        return Convert.ToHexString(hash);
    }
}
