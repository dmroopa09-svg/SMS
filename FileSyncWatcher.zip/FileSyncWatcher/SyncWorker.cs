using System.Collections.Concurrent;
using System.Threading.Channels;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace FileSyncWatcher;

public sealed class SyncWorker : BackgroundService
{
    private readonly SyncOptions _options;
    private readonly SyncService _sync;
    private readonly ILogger<SyncWorker> _logger;

    private readonly Channel<string> _queue =
        Channel.CreateUnbounded<string>(new UnboundedChannelOptions { SingleReader = true });

    // Prevents the same path being queued repeatedly by the burst of Changed events
    // that follows every Created event.
    private readonly ConcurrentDictionary<string, byte> _pending = new(StringComparer.OrdinalIgnoreCase);

    private FileSystemWatcher? _watcher;

    public SyncWorker(IOptions<SyncOptions> options, SyncService sync, ILogger<SyncWorker> logger)
    {
        _options = options.Value;
        _sync = sync;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Source (watched): {Source}", _options.SourceDirectory);
        _logger.LogInformation("Target (archive): {Target}", _options.TargetDirectory);
        _logger.LogInformation(
            "DryRun={DryRun}  CopyWhenMissingFromTarget={Missing}  Hashing={Hash}  Sweep={Sweep}m/{Lookback}h",
            _options.DryRun, _options.CopyWhenMissingFromTarget, _options.UseHashComparison,
            _options.SweepIntervalMinutes, _options.SweepLookbackHours);

        if (_options.DryRun)
            _logger.LogWarning("DRY RUN IS ON. Nothing will be copied. Set Sync:DryRun to false to act.");

        await WaitForDirectoriesAsync(stoppingToken);

        StartWatcher();

        var consumer = ConsumeAsync(stoppingToken);
        var sweeper = SweepLoopAsync(stoppingToken);

        await Task.WhenAll(consumer, sweeper);
    }

    private async Task WaitForDirectoriesAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            var sourceOk = SafeDirectoryExists(_options.SourceDirectory);
            var targetOk = SafeDirectoryExists(_options.TargetDirectory);

            if (sourceOk && targetOk)
                return;

            _logger.LogError(
                "Waiting for share access. Source reachable: {Source}. Target reachable: {Target}. Retrying in 30s.",
                sourceOk, targetOk);

            await Task.Delay(TimeSpan.FromSeconds(30), ct);
        }
    }

    private static bool SafeDirectoryExists(string path)
    {
        try { return Directory.Exists(path); }
        catch { return false; }
    }

    private void StartWatcher()
    {
        DisposeWatcher();

        var watcher = new FileSystemWatcher(_options.SourceDirectory, _options.Filter)
        {
            NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size,
            IncludeSubdirectories = false,
            // 64 KB is the maximum the OS will honour. On a busy share the default 8 KB
            // overflows and events are silently lost, which is exactly what the sweep backstops.
            InternalBufferSize = 64 * 1024
        };

        watcher.Created += (_, e) => Enqueue(e.FullPath, "created");
        watcher.Changed += (_, e) => Enqueue(e.FullPath, "changed");
        watcher.Renamed += (_, e) => Enqueue(e.FullPath, "renamed");
        watcher.Error += OnWatcherError;

        watcher.EnableRaisingEvents = true;
        _watcher = watcher;

        _logger.LogInformation("Watching {Source} for {Filter}.", _options.SourceDirectory, _options.Filter);
    }

    private void OnWatcherError(object sender, ErrorEventArgs e)
    {
        // Buffer overflow or a dropped SMB session. Rebuild the watcher and force an
        // immediate sweep so nothing missed during the gap is lost.
        _logger.LogError(e.GetException(), "Watcher error. Rebuilding watcher and forcing a sweep.");

        _ = Task.Run(async () =>
        {
            await Task.Delay(TimeSpan.FromSeconds(5));
            try
            {
                StartWatcher();
                await SweepAsync(CancellationToken.None);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to recover the watcher.");
            }
        });
    }

    private void Enqueue(string path, string trigger)
    {
        if (path.EndsWith(".syncing.tmp", StringComparison.OrdinalIgnoreCase))
            return;

        if (!_pending.TryAdd(path, 0))
            return;

        _logger.LogDebug("Queued {File} ({Trigger}).", Path.GetFileName(path), trigger);
        _queue.Writer.TryWrite(path);
    }

    private async Task ConsumeAsync(CancellationToken ct)
    {
        try
        {
            await foreach (var path in _queue.Reader.ReadAllAsync(ct))
            {
                try
                {
                    await _sync.ProcessAsync(path, ct);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Unhandled error processing {File}.", Path.GetFileName(path));
                }
                finally
                {
                    _pending.TryRemove(path, out _);
                }
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("Consumer stopping.");
        }
    }

    private async Task SweepLoopAsync(CancellationToken ct)
    {
        // Run one sweep at startup so any files that already diverged get picked up.
        try
        {
            await SweepAsync(ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Startup sweep failed.");
        }

        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(_options.SweepIntervalMinutes));

        try
        {
            while (await timer.WaitForNextTickAsync(ct))
            {
                try
                {
                    await SweepAsync(ct);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Sweep failed; will try again next cycle.");
                }
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("Sweeper stopping.");
        }
    }

    private Task SweepAsync(CancellationToken ct)
    {
        var cutoff = DateTime.UtcNow.AddHours(-_options.SweepLookbackHours);
        var queued = 0;
        var scanned = 0;

        var directory = new DirectoryInfo(_options.SourceDirectory);

        foreach (var file in directory.EnumerateFiles(_options.Filter, SearchOption.TopDirectoryOnly))
        {
            ct.ThrowIfCancellationRequested();
            scanned++;

            if (file.LastWriteTimeUtc < cutoff)
                continue;

            Enqueue(file.FullName, "sweep");
            queued++;
        }

        _logger.LogInformation(
            "Sweep complete. Scanned {Scanned} files, {Queued} within the {Lookback}h window queued for checking.",
            scanned, queued, _options.SweepLookbackHours);

        return Task.CompletedTask;
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        DisposeWatcher();
        _queue.Writer.TryComplete();
        await base.StopAsync(cancellationToken);
    }

    private void DisposeWatcher()
    {
        if (_watcher is null) return;
        try
        {
            _watcher.EnableRaisingEvents = false;
            _watcher.Dispose();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Error disposing watcher.");
        }
        _watcher = null;
    }

    public override void Dispose()
    {
        DisposeWatcher();
        base.Dispose();
    }
}
