# FileSyncWatcher

A stopgap for the archive-copy failure in `GetixHealth_Doc.Admin` → `HomeController.MergePDFs`.

## What it is for

The legacy app merges PDFs to `DestinationPath`, then does:

```csharp
try { System.IO.File.Copy(outputPath, Path.Combine(AppSettings["ArchivePath"], ...)); }
catch { }
```

The two-argument `File.Copy` throws when the destination already exists, and the empty `catch`
swallows it. A preview run writes the file to the archive first; the real submission then merges
the full document but its copy silently fails, so the archive keeps the preview version.

This service watches the source folder and repairs that divergence until the code fix ships.

**This does not replace the code fix.** The real fix is `overwrite: true`, a guard so previews
never copy, and a `catch` that actually logs.

## The safety decision worth understanding

`PM_PDFs` sits under `Letter_Logic_Queue\Active` and holds a handful of files while
`GTXHPrintMail` holds tens of thousands. That is the shape of a queue something drains, not a
mirror.

If that is right, a file **absent** from the target means *already picked up and mailed*, not
*copy failed*. Blindly copying every missing file would re-inject documents into a print/mail
pipeline — duplicate patient mailings.

So the default policy is:

| Situation | Action |
|---|---|
| Target file exists and differs from source | **Copy, overwriting.** This is the diagnosed bug. |
| Target file exists and matches | Skip. |
| Target file absent | **Log only.** Copy requires `CopyWhenMissingFromTarget: true`. |

If `PM_PDFs` turns out to be a passive archive that nothing drains, set
`CopyWhenMissingFromTarget: true`. `MissingGraceMinutes` still bounds the damage by refusing to
copy anything older than the window.

## First run

`DryRun` ships as `true`. Nothing is copied; every action it *would* take is logged.

1. Run it for a business day.
2. Read `logs/filesync-*.log`. Confirm the `STALE` lines are files you expect and the
   `MISSING` lines are files you are happy to leave alone.
3. Set `"DryRun": false`.

## Running it

```powershell
cd FileSyncWatcher
dotnet restore
dotnet run
```

Publish and install as a Windows service:

```powershell
dotnet publish -c Release -r win-x64 --self-contained false -o C:\Services\FileSyncWatcher

sc.exe create FileSyncWatcher `
  binPath= "C:\Services\FileSyncWatcher\FileSyncWatcher.exe" `
  start= auto `
  obj= "DOMAIN\svc_account" `
  password= "..."

sc.exe description FileSyncWatcher "Repairs stale PDFs in the Letter_Logic print/mail queue."
sc.exe start FileSyncWatcher
```

The account must have read on the source share and read/write/delete on the target. Run it under
a domain service account, not `LocalSystem` — `LocalSystem` authenticates to UNC paths as the
machine account and will usually be denied.

## Design notes

**The sweep is the real guarantee, not the watcher.** `FileSystemWatcher` on an SMB share drops
events when its buffer overflows or the session reconnects. The buffer is raised to the 64 KB
maximum and the `Error` event rebuilds the watcher, but a reconciliation sweep every
`SweepIntervalMinutes` is what actually catches everything. It only examines files modified in
the last `SweepLookbackHours`, so a 63k-file directory is not rescanned in full each cycle.

**Files are waited on before being read.** A `Created` event fires when the merge opens its
`FileStream`, long before the last page is written. `FileStabilityChecker` waits for the length
to stop changing and for an exclusive open to succeed.

**Copies land via a temp file.** Writing straight into a live queue folder risks the downstream
process grabbing a half-written PDF. The copy goes to `<name>.pdf.syncing.tmp` and is then moved
into place.

**Comparison is by length, then SHA-256.** Equal-length-different-content is rare here but cheap
to rule out. Files above `MaxHashBytes` (64 MB) fall back to length plus modification time.

## Log vocabulary

| Prefix | Meaning |
|---|---|
| `STALE` | Target differed. Copied over. The bug, caught. |
| `MISSING` | Target absent. Copied or skipped per policy. |
| `IN SYNC` | Match (debug level). |
| `COPIED` | A copy completed. |
| `DRY RUN` | What would have happened. |
| `RETRY` / `FAILED` | Transient or terminal copy failure. |

A steady stream of `STALE` lines confirms the diagnosis. Once the code fix ships they should stop
entirely — that is your signal to retire this service.
