// =============================================================================
// ADD THESE PROPERTIES TO THE EXISTING CLASSES IN GTXH.SMS.Common
// This file is a reference, not a drop-in — paste the members into the classes
// you already have, then delete this file.
// =============================================================================

namespace GTXH.SMS.Common;

/*
    CampaignMemberEntity  (maps to SMS_Queue_Detail)
    ------------------------------------------------
    Add these two properties.
*/

//  /// <summary>
//  /// How many times delivery has tried to submit this message.
//  ///
//  /// Bounds the retry loop. Without a counter a provider outage produces
//  /// unbounded retries — worse than the outage itself, because it hammers the
//  /// provider while it is recovering and a message that will never succeed is
//  /// retried forever instead of being reported as failed.
//  ///
//  /// Replaces the SMS_Delivery_Attempt table, which existed almost entirely to
//  /// hold this number.
//  /// </summary>
//  public int AttemptCount { get; set; }

//  /// <summary>
//  /// The provider's transaction id — Webex "transid" — returned when a message
//  /// is accepted.
//  ///
//  /// Every delivery receipt references it. Without it stored, receipts arrive
//  /// and cannot be matched to anything, so messages stay at Submitted forever
//  /// and delivery rate is unmeasurable.
//  /// </summary>
//  public string? ProviderMessageId { get; set; }


/*
    CampaignQueueEntity  (maps to SMS_Queue_Mst)
    --------------------------------------------
    Add this one property.
*/

//  /// <summary>
//  /// Outbound number (DNIS) this campaign sends from, passed to Webex as
//  /// CampaignPHNumber.
//  ///
//  /// The recipient sees this number and carriers display the business name
//  /// registered against it, so each client needs their own. Previously
//  /// hardcoded inside the Webex flow, which meant one number for everyone.
//  /// </summary>
//  public string? OutboundPhoneNumber { get; set; }


/*
    MessageLifecycleState  (Enums.cs)
    ---------------------------------
    Add value 11.

        Submitting = 11

    WHY A SEPARATE STATE RATHER THAN GOING STRAIGHT TO Submitted:

    Submitting means "claimed, provider call in progress".
    Submitted  means "the provider accepted it".

    Collapsing them would mark a message as accepted before the call was made,
    so a crash mid-call would leave a row claiming success for a message that
    never went. Keeping them apart means a stuck Submitting row is visibly
    stuck, and the retry sweep reclaims it after ClaimedAt goes stale.

    The transition ReadyForDelivery -> Submitting IS the duplicate guard:

        UPDATE SMS_Queue_Detail SET LifecycleState = Submitting
        WHERE  ID = @id AND LifecycleState = ReadyForDelivery

    One atomic statement. Rows affected 1 = we won. 0 = someone else has it.
    That is what allowed SMS_Delivery_Submission to be deleted.
*/
