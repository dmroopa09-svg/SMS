namespace GTXH.SMS.Delivery.API.Services;

/// <summary>Delivery configuration. Bound from the "Delivery" section.</summary>
public sealed class DeliveryOptions
{
    public const string SectionName = "Delivery";

    public string BaseUrl { get; set; } = "";

    /// <summary>Relative path to the flow trigger, e.g. events/OA3ZL2N9FJ</summary>
    public string FlowTriggerPath { get; set; } = "";

    /// <summary>
    /// When true, nothing is sent. DEFAULTS TO TRUE so a deployment that forgets
    /// to configure delivery cannot message real people.
    /// </summary>
    public bool DryRun { get; set; } = true;

    /// <summary>
    /// Sends every message to this number regardless of recipient. The
    /// client-side twin of the filter on the Webex side — two independent nets.
    /// The intended recipient is logged each time.
    /// </summary>
    public string? RedirectAllToNumber { get; set; }

    /// <summary>
    /// Hard ceiling on sends in this process's lifetime. 0 = no limit.
    ///
    /// ⚠ PER PROCESS. Two people running the service at once get two ceilings —
    /// which is what caused the unexpected volume during testing. Coordinate
    /// before running.
    /// </summary>
    public int MaxSendsPerProcess { get; set; } = 25;

    /// <summary>
    /// Provider limit, confirmed at 25 per second.
    /// ⚠ ALSO PER INSTANCE. Three instances at 25 each send 75.
    /// </summary>
    public int MaxPerSecond { get; set; } = 25;

    /// <summary>Attempts before a message is marked Failed.</summary>
    public int MaxAttempts { get; set; } = 3;

    public int TimeoutSeconds { get; set; } = 30;

    // ---- retry worker ----

    public bool RetryEnabled { get; set; } = true;
    public int RetryPollSeconds { get; set; } = 30;

    /// <summary>
    /// Flat delay, not exponential. These are provider blips measured in
    /// seconds; a growing delay would mostly push messages past their window.
    /// </summary>
    public int RetryBackoffSeconds { get; set; } = 120;

    public int RetryBatchSize { get; set; } = 50;

    /// <summary>
    /// A claimed row older than this is reclaimable — recovers work from an
    /// instance that died mid-send. Must be comfortably longer than the worst
    /// realistic send, or a slow send is retried while still in flight.
    /// </summary>
    public int RetryClaimTimeoutSeconds { get; set; } = 300;

    // ---- receipt worker ----

    /// <summary>
    /// Disabling this leaves every message at Submitted. Delivery rate then
    /// cannot be measured — only submission rate.
    /// </summary>
    public bool ReceiptProcessingEnabled { get; set; } = true;

    public int ReceiptPollSeconds { get; set; } = 30;

    public int ReceiptBatchSize { get; set; } = 200;
}
