using GTXH.SMS.Common;
using GTXH.SMS.Delivery.API.Data;
using Microsoft.EntityFrameworkCore;

namespace GTXH.SMS.Delivery.API.Services;

/// <summary>
/// Reads SMS_Delivery_Receipts and moves the queue row to its final state.
///
/// WITHOUT THIS, NOTHING EVER REACHES Delivered.
///
/// The Status API writes receipts, but nothing joined them back to the queue.
/// Messages stopped at Submitted forever even though the receipt saying
/// "Delivered" was sitting in the table — so every report would have shown
/// submission counts while looking like delivery counts.
///
/// NO "PROCESSED" FLAG IS NEEDED ON THE RECEIPTS TABLE.
/// The sweep only looks at queue rows still in Submitted. Once a receipt moves
/// one to Delivered or Failed it stops matching, so re-running is harmless and
/// the receipts table — which belongs to the Status API, not to us — is never
/// written to.
/// </summary>
public sealed class DeliveryReceiptWorker(
    IServiceScopeFactory scopeFactory,
    DeliveryOptions options,
    ILogger<DeliveryReceiptWorker> logger) : BackgroundService
{
    /// <summary>
    /// Provider codes seen so far. 7500 and 7282 are confirmed from real
    /// receipts; anything else is treated as a failure and logged, because
    /// reporting an unknown code as delivered would overstate every figure.
    /// </summary>
    private const int CodeDelivered = 7500;
    private const int CodeInvalidRoute = 7282;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!options.ReceiptProcessingEnabled)
        {
            logger.LogWarning(
                "Receipt processing is DISABLED. Messages will stay at Submitted and "
                + "delivery rate cannot be measured.");
            return;
        }

        logger.LogInformation(
            "Receipt worker started, polling every {Poll}s.", options.ReceiptPollSeconds);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var applied = await RunOnceAsync(stoppingToken);
                if (applied > 0)
                    logger.LogInformation("Applied {Count} delivery receipt(s).", applied);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Receipt sweep failed.");
            }

            try
            {
                await Task.Delay(TimeSpan.FromSeconds(options.ReceiptPollSeconds), stoppingToken);
            }
            catch (OperationCanceledException) { break; }
        }

        logger.LogInformation("Receipt worker stopping.");
    }

    private async Task<int> RunOnceAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DeliveryDbContext>();

        var submitted = (byte)MessageLifecycleState.Submitted;

        // ⚠ THE JOIN MATCHES EITHER RECEIPT COLUMN.
        //
        // Which one Webex echoes back is not yet confirmed. The evidence points
        // to TransId — in the receipt JSON the field literally named "transid"
        // inside sfeSessionInfo carries the value stored in TransId, while
        // SubTid holds "tid"/"main_tid", which is the downstream carrier-leg id
        // Webex generates rather than the one returned to us.
        //
        // Matching both means the code works either way. Once confirmed, drop
        // the losing side of the OR — see the README for the exact line.
        //
        // Both columns are indexed, so this is a seek whichever way it lands.
        var matches = await db.Database
            .SqlQuery<ReceiptMatch>($"""
                SELECT TOP ({options.ReceiptBatchSize})
                       CAST(q.ID AS BIGINT)                 AS MessageId,
                       CAST(r.Code AS INT)                  AS Code,
                       CAST(r.Description AS NVARCHAR(500)) AS Description,
                       CAST(r.Id AS BIGINT)                 AS ReceiptId
                FROM   dbo.SMS_Queue_Detail AS q
                INNER  JOIN dbo.SMS_Delivery_Receipts AS r
                       ON  r.TransId = q.ProviderMessageId
                        OR r.SubTid  = q.ProviderMessageId
                WHERE  q.LifecycleState     = {submitted}
                  AND  q.ProviderMessageId IS NOT NULL
                ORDER  BY r.Id
                """)
            .ToListAsync(ct);

        if (matches.Count == 0)
            return 0;

        var applied = 0;

        // A message can have more than one receipt — submitted, then delivered.
        // Take the last one per message, which is the outcome that stands.
        foreach (var group in matches.GroupBy(m => m.MessageId))
        {
            var final = group.OrderByDescending(m => m.ReceiptId).First();
            var now = DateTime.UtcNow;

            int receiptCode = final.Code;
            var delivered = receiptCode == CodeDelivered;

            if (!delivered && receiptCode != CodeInvalidRoute)
            {
                // Unknown code. Treated as a failure, because calling it
                // delivered on a guess would overstate the numbers everyone
                // reports on. Logged so the catalogue can be filled in.
                logger.LogWarning(
                    "Uncatalogued receipt code {Code} ({Description}) for message {MessageId}. "
                    + "Recorded as failed.",
                    receiptCode, final.Description, final.MessageId);
            }

            var newState = delivered
                ? MessageLifecycleState.Delivered
                : MessageLifecycleState.Failed;

            var newStatus = delivered
                ? CampaignMemberStatus.Emitted
                : CampaignMemberStatus.Skipped;

            var code = receiptCode.ToString();
            var message = Truncate(final.Description ?? (delivered ? "Delivered" : "Failed"), 1000);

            // Guarded on Submitted so two instances cannot both apply it.
            var rows = await db.CampaignMembers
                .Where(m => m.ID == final.MessageId
                         && m.LifecycleState == MessageLifecycleState.Submitted)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LifecycleState, newState)
                    .SetProperty(m => m.Status, newStatus)
                    .SetProperty(m => m.ResponseCode, code)
                    .SetProperty(m => m.ResponseMessage, message)
                    .SetProperty(m => m.RowUpdatedDt, now), ct);

            if (rows > 0)
                applied++;
        }

        return applied;
    }

    private static string Truncate(string? s, int max)
        => string.IsNullOrEmpty(s) ? "" : (s.Length > max ? s[..max] : s);

    public sealed class ReceiptMatch
    {
        public long MessageId { get; set; }
        public int Code { get; set; }
        public string? Description { get; set; }
        public long ReceiptId { get; set; }
    }
}
