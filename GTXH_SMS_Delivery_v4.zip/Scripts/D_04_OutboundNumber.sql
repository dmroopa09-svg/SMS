/* ============================================================================
   OUTBOUND PHONE NUMBER ON SMS_Queue_Mst
   ============================================================================

   The payload contract requires CampaignPHNumber - the outbound number (DNIS)
   the campaign sends from. No column in SMS_Queue_Mst currently holds it, so
   delivery would send the field empty.

   The columns today are: ID, Campaign_Mstr_ID, CampaignVersion, State,
   TemplateId, TemplateVersion, Timezone, LimitHour, LimitDay, LimitWeek,
   LimitMonth, RunTime, Status, CreatedBy, CreatedDt, UpdatedDt, Scheduler_ID,
   ExternalQueueID. None of those is a phone number.

   WHY IT MATTERS
   --------------
   The recipient sees this number, and carriers display the business name
   registered against it. With roughly a hundred clients, one shared number
   cannot work - every client needs their own so patients see the right name.

   It has been hardcoded inside the Webex flow until now, which meant one
   number for everyone. Passing it per campaign is what makes per-client
   numbers possible without a separate flow per client.

   ⚠ ONE THING TO CONFIRM
   The contract says "mapped in the campaign". If the number belongs to the
   CAMPAIGN DEFINITION it may be a better fit on Campaign_Mstr, read through
   Campaign_Mstr_ID. If it can differ per run, SMS_Queue_Mst is right.

   This script uses SMS_Queue_Mst because that is what delivery already reads
   and it needs no extra join. Moving it later is small - but only before data
   exists.

   Safe to run more than once.
   ============================================================================ */

SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Mst')
                 AND name = 'OutboundPhoneNumber')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Mst ADD OutboundPhoneNumber VARCHAR(20) NULL;
    PRINT 'Added SMS_Queue_Mst.OutboundPhoneNumber';
END
GO

/* Populate for the test campaign. Replace with the real DNIS. */
-- UPDATE dbo.SMS_Queue_Mst
-- SET    OutboundPhoneNumber = '14805421761'
-- WHERE  ID = 2;

PRINT '--- campaigns with no outbound number ---';
PRINT '--- these will send CampaignPHNumber empty ---';
SELECT ID, Campaign_Mstr_ID, State, OutboundPhoneNumber
FROM   dbo.SMS_Queue_Mst
WHERE  OutboundPhoneNumber IS NULL
  AND  State IN (1, 2);
GO
