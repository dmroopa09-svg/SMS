# Dependent dropdowns — patches

FC Name → filters Workqueue, Status Code, Action Code.

Order: SQL → backend → frontend. Roughly 30 minutes.

New file: `frontend/src/utils/fieldOptions.ts` (in this zip)

---

## 1. SQL

Run `sql/dependent_dropdowns.sql`. Step 2 gives you the ProcessId; set it in
step 3 before running the seed.

**Complete the Status_Code lists from the spreadsheet** — that column was
truncated in the screenshot, so what I seeded is partial.

---

## 2. Backend — 4 edits

### 2a. `GTXH.OMC.Core/Entities/ProcessField.cs`

```csharp
    public string? Options { get; set; }

    /// <summary>
    /// Name of the field this one depends on, e.g. Workqueue depends on FC_Name.
    /// NULL = an ordinary flat dropdown. Field NAME rather than id because
    /// TaskData is keyed by name.
    /// </summary>
    public string? ParentFieldName { get; set; }

    /// <summary>
    /// Options keyed by parent value:
    ///   { "Medicaid": ["30417 - Follow up", ...], "Commercial": [...] }
    /// Only used when ParentFieldName is set; Options stays authoritative
    /// for every non-dependent field.
    /// </summary>
    public string? OptionsJson { get; set; }
```

### 2b. `GTXH.OMC.Application/DTOs/ProcessFieldDto.cs`

```csharp
    public string? ParentFieldName { get; set; }
    public string? OptionsJson { get; set; }
```

### 2c. `MappingService.MapToProcessFieldDto`

```csharp
        Options = field.Options,
        ParentFieldName = field.ParentFieldName,   // ADD
        OptionsJson = field.OptionsJson,           // ADD
```

### 2d. `TaskService.cs` — TWO inline mappings, easy to miss

`TaskService` builds `ProcessFieldDto` by hand in two places rather than going
through `MappingService`. Miss these and the columns arrive null even though 2c
is correct — the grid then silently falls back to flat options and nothing works.

```
Ctrl+F in TaskService.cs:   new ProcessFieldDto
```

Add to **both**:

```csharp
    Options = f.Options,
    ParentFieldName = f.ParentFieldName,   // ADD
    OptionsJson = f.OptionsJson,           // ADD
```

No migration needed if you ran the SQL — but if you scaffold one, empty the
`Up()`/`Down()` bodies, the columns already exist.

---

## 3. Frontend

### 3a. `services/processService.ts`

```ts
export interface ProcessFieldDto {
  // ...existing...
  options?: string;
  parentFieldName?: string | null;   // ADD
  optionsJson?: string | null;       // ADD
}
```

### 3b. Copy in `utils/fieldOptions.ts` from this zip

### 3c. `utils/columnGenerator.tsx` — THREE edits

#### Edit 1 — import

FIND:
```tsx
import { ProcessFieldDto } from '../services/processService';
```
(or wherever the imports end)

ADD BELOW:
```tsx
import { resolveOptions, getDependentFieldNames, isValueStillValid } from './fieldOptions';
```

#### Edit 2 — remove the per-column options (line ~56)

**This is the structural fix.** Options were computed once per COLUMN. They must
be per ROW: row 1 can be Medicaid and row 2 Commercial in the same column.

FIND:
```tsx
    const options = field.options ? field.options.split(',').map(o => o.trim()) : [];
```

REPLACE WITH:
```tsx
    // Options are resolved PER ROW inside the cell renderer — see below.
    // They used to be computed here, once per column, which cannot express
    // "row 1 is Medicaid, row 2 is Commercial" in the same column.
    // Kept only for MultiSelect (case 4), which has no dependency support yet.
    const options = field.options ? field.options.split(',').map(o => o.trim()) : [];
```

(Leave the line in place so `case 4` keeps working. `case 3` stops using it.)

#### Edit 3 — the dropdown case

FIND the whole `case 3:` block, from `case 3: // Dropdown` down to the closing
`);` before `case 4:`.

REPLACE WITH:

```tsx
          case 3: { // Dropdown
            // PER ROW. This row's parent value decides this row's options.
            const resolved = resolveOptions(field, row.original.taskData, processFields);
            const valueValid = isValueStillValid(value, resolved);

            /**
             * Changing a parent invalidates everything downstream, so clear it.
             * Keeping a stale child value is worse than blanking it — the row
             * looks correct and reports wrong.
             */
            const handleDropdownUpdate = (newValue: string) => {
              const currentTaskData = row.original.taskData || {};
              const dependents = getDependentFieldNames(fieldName, processFields);

              const cleared: Record<string, null> = {};
              for (const dep of dependents) {
                if (currentTaskData[dep] !== null && currentTaskData[dep] !== undefined && currentTaskData[dep] !== '') {
                  cleared[dep] = null;
                }
              }

              if (field.isRequired && (!newValue || newValue.trim() === '')) {
                addToast?.(`Field '${fieldName}' is required.`, 'error');
              }

              onUpdateTask(taskId, {
                taskData:    { ...currentTaskData, [fieldName]: newValue, ...cleared },
                dataChanged: { [fieldName]: newValue, ...cleared },
              });

              const clearedNames = Object.keys(cleared);
              if (clearedNames.length > 0) {
                addToast?.(`${clearedNames.join(', ')} cleared — ${fieldName} changed.`, 'info');
              }
            };

            if (isEditing) {
              return (
                <select
                  data-cell-id={`${taskId}-field_${fieldName}`}
                  disabled={isReadOnly || resolved.disabled}
                  className="w-full p-1 text-xs border rounded bg-white outline-none focus:ring-1 focus:ring-brand-primary disabled:bg-gray-50 disabled:text-gray-400"
                  value={value ? String(value) : ''}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      if (!isReadOnly && !resolved.disabled) {
                        handleDropdownUpdate((e.target as HTMLSelectElement).value);
                        if (pendingValueRef) pendingValueRef.current = null;
                      }
                      setEditingCell(null);
                    }
                    if (e.key === 'Escape') {
                      if (discardingRef) discardingRef.current = true;
                      if (pendingValueRef) pendingValueRef.current = null;
                      !isReadOnly && setEditingCell(null);
                    }
                  }}
                  onChange={(e) => {
                    if (!isReadOnly && !resolved.disabled) {
                      if (pendingValueRef) {
                        pendingValueRef.current = { taskId, fieldName, value: e.target.value };
                      }
                      handleDropdownUpdate(e.target.value);
                    }
                  }}
                  onBlur={() => {
                    if (pendingValueRef) pendingValueRef.current = null;
                    !isReadOnly && setEditingCell(null);
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <option value="">
                    {resolved.disabled ? (resolved.reason ?? 'Select parent first') : 'Select...'}
                  </option>

                  {/* A stored value that is no longer valid still needs to be
                      selectable, or opening the dropdown would silently blank it. */}
                  {!valueValid && value && (
                    <option value={String(value)}>{String(value)} (not in list)</option>
                  )}

                  {resolved.options.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              );
            }

            return (
              <div
                data-cell-id={`${taskId}-field_${fieldName}`}
                className={`w-full h-full flex items-center flex-col justify-center ${!isReadOnly ? 'cursor-pointer hover:bg-gray-50/50 p-1' : 'p-1'} rounded transition-colors ${hasValidationError ? 'bg-red-50' : ''}`}
                onClick={() => !isReadOnly && setEditingCell({ id: taskId, field: `field_${fieldName}` })}
                title={resolved.disabled ? resolved.reason : (!valueValid && value ? 'This value is not valid for the selected parent' : undefined)}
              >
                {hasValidationError && !value ? (
                  <span className="text-red-600 text-[10px] font-bold">is required</span>
                ) : (
                  <span className={`truncate ${!valueValid && value ? 'text-amber-600' : ''}`}>
                    {String(value || '')}
                  </span>
                )}
              </div>
            );
          }
```

Note the block is now wrapped in `{ }` because it declares consts — matching how
`case 4` already does it.

---

## 4. Test

1. New task, leave FC Name empty → the other three show
   **"Select FC_Name first"** and are disabled
2. Pick **Medicaid** → all three populate with Medicaid values only
3. Pick a Workqueue and a Status → **Action Code list does not change**
   (they are siblings, not a chain)
4. Change to **Commercial** → all three clear, toast names what was cleared,
   lists reload as Commercial
5. Existing task with an old value → renders in amber, still selectable, **not**
   auto-cleared on load
6. A process with no dependencies → dropdowns behave exactly as before

---

## 5. Known gaps — deliberate, for today

**No admin UI yet.** Configuration is the SQL in this zip. The editor (parent
picker, per-parent option lists, paste-from-Excel) is a separate piece — worth
building properly rather than rushing, since the current single-line input is
already unusable at 25 options.

**Drag-to-fill and bulk update are not validated.** Both bypass the dropdown and
can push a Commercial value into a Medicaid row. Worth adding next; flagging it
now so nobody is surprised.

**MultiSelect (case 4) has no dependency support.** Only Dropdown (case 3). Say
if you need it.
