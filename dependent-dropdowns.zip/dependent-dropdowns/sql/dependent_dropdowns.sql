USE [GTXH_OMC];
GO

/* ═══════════════════════════════════════════════════════════════════════
   1. SCHEMA — two nullable columns. Nothing existing changes.

   Options (the CSV column) keeps working exactly as it does for every
   non-dependent field. OptionsJson is populated ONLY where a parent exists.
   ═══════════════════════════════════════════════════════════════════════ */

IF COL_LENGTH('dbo.ProcessFields', 'ParentFieldName') IS NULL
    ALTER TABLE dbo.ProcessFields ADD ParentFieldName nvarchar(200) NULL;
GO

IF COL_LENGTH('dbo.ProcessFields', 'OptionsJson') IS NULL
    ALTER TABLE dbo.ProcessFields ADD OptionsJson nvarchar(max) NULL;
GO

/*
   ParentFieldName, not ParentFieldId, because TaskData is keyed by field NAME.
   The resolver reads taskData[parentFieldName] directly with no second lookup.
*/


/* ═══════════════════════════════════════════════════════════════════════
   2. FIND YOUR FIELD IDs — run this first and note the ProcessId
   ═══════════════════════════════════════════════════════════════════════ */

SELECT  p.ProcessId, p.ProcessName,
        f.FieldId, f.FieldName, f.FieldType, f.DisplayOrder,
        f.ParentFieldName, f.Options
FROM    dbo.ProcessFields f
JOIN    dbo.Processes p ON p.ProcessId = f.ProcessId
WHERE   f.IsDeleted = 0
  AND   f.FieldName IN ('FC_Name','Workqueue','Status_Code','Action_Code')
ORDER BY p.ProcessName, f.DisplayOrder;


/* ═══════════════════════════════════════════════════════════════════════
   3. SEED — replace @ProcessId, then run.

   All three depend on FC_Name (fan-out, not a chain), matching what you
   described. If another process later needs Action_Code under Status_Code,
   change only ParentFieldName and re-key the JSON — no schema change.
   ═══════════════════════════════════════════════════════════════════════ */

DECLARE @ProcessId int = 5;   -- <<< SET THIS from step 2

BEGIN TRANSACTION;

-- ── FC_Name: the parent. Flat CSV, no dependency. ──────────────────────
UPDATE dbo.ProcessFields
SET    Options         = N'Medicaid,Commercial',
       ParentFieldName = NULL,
       OptionsJson     = NULL
WHERE  ProcessId = @ProcessId AND FieldName = 'FC_Name';

-- ── Workqueue ──────────────────────────────────────────────────────────
UPDATE dbo.ProcessFields
SET    ParentFieldName = N'FC_Name',
       OptionsJson = N'{
  "Medicaid":   ["30417 - Follow up","37020 (COB)","38503 - Denial"],
  "Commercial": ["21371 (Correspondence)","30406 - Follow up","38622 - Denial"]
}'
WHERE  ProcessId = @ProcessId AND FieldName = 'Workqueue';

-- ── Status_Code ────────────────────────────────────────────────────────
-- The Status column was truncated in the screenshot I had. COMPLETE THESE
-- FROM THE SPREADSHEET before running - the lists below are partial.
UPDATE dbo.ProcessFields
SET    ParentFieldName = N'FC_Name',
       OptionsJson = N'{
  "Medicaid": [
    "Claim Paid",
    "Claim in Process",
    "Claim Not On File",
    "Secondary Policy",
    "Denied for PRIM",
    "Primary paid",
    "Invalid NDC Billed",
    "Need newborn"
  ],
  "Commercial": [
    "Working on",
    "Appeal sent",
    "Claim paid, Not released",
    "While submitting",
    "Claim is denied",
    "Secondary insurance",
    "Emailing the"
  ]
}'
WHERE  ProcessId = @ProcessId AND FieldName = 'Status_Code';

-- ── Action_Code ────────────────────────────────────────────────────────
UPDATE dbo.ProcessFields
SET    ParentFieldName = N'FC_Name',
       OptionsJson = N'{
  "Medicaid": [
    "Portal Inquiry",
    "Faxed Correspondence",
    "Pending Fax Receipt",
    "Retro auth requested",
    "Claim Resubmitted - Elect",
    "Need to Follow-Up",
    "Moved to Ins paid",
    "Reimbursement review needed",
    "Moved to Credentialing Issue",
    "Need nurse audit review",
    "Need HIM review",
    "Submitted/Faxed Medical records",
    "Billed Patient",
    "Submitted primary EOB",
    "Adjustment",
    "Added Insurance and billed",
    "Sent letter to Patient",
    "Appeal submitted",
    "Need Post review",
    "Patient Charge Review Needed",
    "UR review needed",
    "Sent back for reprocess",
    "HCFA Claims Review Needed"
  ],
  "Commercial": [
    "Correspondence",
    "Deferred Follow up",
    "Appeal in process",
    "Appeal Sent",
    "Claim in process",
    "Claim paid, Not released",
    "Claim Recently Billed/Worked",
    "Claim Resubmitted - Elect",
    "Claim set to pay",
    "Corrected Claim sent",
    "Faxed Appeal",
    "Faxed Medical Records",
    "Medical Records Inprocess",
    "Retro auth in process",
    "Sent back for reprocess",
    "Sent Email for status",
    "Sent Itemized Bill",
    "Sent Reconsideration",
    "Submitted primary EOB",
    "Submitted retro auth request",
    "Appeal Review Needed",
    "Bill Editor Review",
    "HIM Coding Review",
    "Insurance Audit Hold",
    "Need CCCA review",
    "Need POST review"
  ]
}'
WHERE  ProcessId = @ProcessId AND FieldName = 'Action_Code';


-- ── Verify the JSON parses before committing ───────────────────────────
SELECT  FieldName,
        ParentFieldName,
        ISJSON(OptionsJson) AS JsonValid,   -- must be 1
        LEN(OptionsJson)    AS JsonLength
FROM    dbo.ProcessFields
WHERE   ProcessId = @ProcessId
  AND   FieldName IN ('FC_Name','Workqueue','Status_Code','Action_Code');

-- COMMIT TRANSACTION;
-- ROLLBACK TRANSACTION;
GO


/* ═══════════════════════════════════════════════════════════════════════
   4. AFTERWARDS — which existing tasks now hold an invalid combination?

   Informational only. The grid renders these values and does NOT clear them;
   they are only cleared when an agent changes the parent themselves.
   ═══════════════════════════════════════════════════════════════════════ */

DECLARE @Pid int = 5;   -- same ProcessId

SELECT  t.TaskId,
        JSON_VALUE(t.TaskData, '$.FC_Name')     AS FC_Name,
        JSON_VALUE(t.TaskData, '$.Workqueue')   AS Workqueue,
        JSON_VALUE(t.TaskData, '$.Status_Code') AS Status_Code,
        JSON_VALUE(t.TaskData, '$.Action_Code') AS Action_Code
FROM    dbo.Tasks t
WHERE   t.ProcessId = @Pid
  AND   ISJSON(t.TaskData) = 1
  AND   JSON_VALUE(t.TaskData, '$.FC_Name') IS NOT NULL
ORDER BY t.TaskId DESC;
