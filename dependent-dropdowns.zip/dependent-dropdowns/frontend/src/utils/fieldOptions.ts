import { ProcessFieldDto } from '../services/processService';

/**
 * THE ONLY PLACE THAT KNOWS HOW DROPDOWN OPTIONS ARE STORED.
 *
 * Today that is a JSON blob on ProcessFields.OptionsJson. If the lists ever
 * outgrow that - retiring codes without breaking old tasks, hundreds of options,
 * two admins editing the same field - swapping to a real option table is a change
 * to this file and nothing else. Keep it that way: never parse OptionsJson
 * anywhere but here.
 */

export interface ResolvedOptions {
  options: string[];
  /** True when a parent is configured but not yet chosen. Render the select disabled. */
  disabled: boolean;
  /** Shown in the placeholder, e.g. "Select FC_Name first". */
  reason?: string;
}

const parseCsv = (csv?: string | null): string[] =>
  csv ? csv.split(',').map(o => o.trim()).filter(Boolean) : [];

function parseOptionsJson(json?: string | null): Record<string, string[]> | null {
  if (!json || !json.trim()) return null;
  try {
    const parsed = JSON.parse(json);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;

    const out: Record<string, string[]> = {};
    for (const [key, value] of Object.entries(parsed)) {
      if (Array.isArray(value)) {
        out[key] = value.map(v => String(v).trim()).filter(Boolean);
      }
    }
    return Object.keys(out).length > 0 ? out : null;
  } catch {
    // Malformed JSON must not take the grid down. Falls back to the CSV below.
    return null;
  }
}

/**
 * Keys are entered by hand in the admin screen and values come from uploads, so
 * casing and stray whitespace will not always match. Compare leniently.
 */
function findKey(map: Record<string, string[]>, value: string): string | undefined {
  const needle = value.trim().toLowerCase();
  return Object.keys(map).find(k => k.trim().toLowerCase() === needle);
}

/**
 * Options for one field, for ONE ROW.
 *
 * Per row, not per column: row 1 may be Medicaid and row 2 Commercial in the same
 * column, so this must be called from inside the cell renderer with that row's
 * taskData - not hoisted out of it.
 */
export function resolveOptions(
  field: ProcessFieldDto,
  taskData: Record<string, unknown> | undefined,
  allFields: ProcessFieldDto[]
): ResolvedOptions {
  const parentName = field.parentFieldName?.trim();

  // No dependency configured - behaves exactly as before this feature existed.
  if (!parentName) {
    return { options: parseCsv(field.options), disabled: false };
  }

  const parentField = allFields.find(
    f => !f.isDeleted && f.fieldName.trim().toLowerCase() === parentName.toLowerCase()
  );

  // Parent named but missing (renamed or deleted). Fall back to the flat list
  // rather than leaving the agent with a dead dropdown.
  if (!parentField) {
    return { options: parseCsv(field.options), disabled: false };
  }

  const parentValue = taskData?.[parentField.fieldName];
  if (parentValue === null || parentValue === undefined || String(parentValue).trim() === '') {
    return { options: [], disabled: true, reason: `Select ${parentField.fieldName} first` };
  }

  const map = parseOptionsJson(field.optionsJson);
  if (!map) {
    // Dependency configured but no map saved yet - do not blank the field.
    return { options: parseCsv(field.options), disabled: false };
  }

  const key = findKey(map, String(parentValue));
  return { options: key ? map[key] : [], disabled: false };
}

/**
 * Every field that depends on `fieldName`, directly or through a chain.
 *
 * Used to clear downstream values when a parent changes: switching FC_Name from
 * Medicaid to Commercial invalidates Workqueue, Status_Code and Action_Code, and
 * silently keeping them is worse than blanking them - the row looks right and
 * reports wrong.
 */
export function getDependentFieldNames(
  fieldName: string,
  allFields: ProcessFieldDto[],
  seen: Set<string> = new Set()
): string[] {
  const key = fieldName.trim().toLowerCase();
  if (seen.has(key)) return [];        // guards a mis-configured cycle
  seen.add(key);

  const direct = allFields
    .filter(f => !f.isDeleted && f.parentFieldName?.trim().toLowerCase() === key)
    .map(f => f.fieldName);

  return direct.flatMap(name => [name, ...getDependentFieldNames(name, allFields, seen)]);
}

/**
 * True when a stored value is no longer in the row's valid list.
 *
 * Render these - do NOT auto-clear on load. Tasks hold values entered before the
 * dependency existed, and silently rewriting live task data on render is not
 * something the agent asked for. Clear only when they change the parent
 * themselves.
 */
export function isValueStillValid(
  value: unknown,
  resolved: ResolvedOptions
): boolean {
  if (value === null || value === undefined || String(value).trim() === '') return true;
  if (resolved.disabled || resolved.options.length === 0) return true;
  const v = String(value).trim().toLowerCase();
  return resolved.options.some(o => o.trim().toLowerCase() === v);
}
