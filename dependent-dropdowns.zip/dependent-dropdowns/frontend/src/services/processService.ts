// REFERENCE ONLY — do not copy this file over yours.
// Add the two marked fields to your existing ProcessFieldDto interface.
export interface ProcessFieldDto {
  fieldId: number;
  processId: number;
  fieldName: string;
  fieldType: string | number;
  isRequired: boolean;
  isReadOnly: boolean;
  displayOrder: number;
  options?: string;
  validationRules?: string;
  defaultValue?: string;
  maxLength?: number;
  minLength?: number;
  isDeleted?: boolean;

  // ── ADD THESE TWO ───────────────────────────────────────────────────
  /** Field this one depends on, by NAME. null = ordinary flat dropdown. */
  parentFieldName?: string | null;
  /** { "Medicaid": [...], "Commercial": [...] } — only when parentFieldName is set. */
  optionsJson?: string | null;
}
