# FileSyncWatcher

A stopgap for the archive-copy failure in `GetixHealth_Doc.Admin` → `HomeController.MergePDFs`.

## What it is for

The legacy app merges PDFs to `DestinationPath`, then does:

```csharp
try { System.IO.File.Copy(outputPath, Path.Combine(AppSettings["ArchivePath"], ...)); }
catch { }
```

The two-argument `File.Copy` throws when the destination already exists, and the empty `catch`
swallows it. A preview run writes the file to the archive first; the real submission then merges
the full document but its copy silently fails, so the archive keeps the preview version.

This service watches the source folder and repairs that divergence until the code fix ships.

**This does not replace the code fix.** The real fix is `overwrite: true`, a guard so previews
never copy, and a `catch` that actually logs.

## Direction of flow

| | |
|---|---|
| **Source** (watched) | `...\FreeData\Letter_Logic_Queue\Active\PM_PDFs` — the app's `DestinationPath`. The mailer drains this roughly every 30 minutes. |
| **Target** (repaired) | `...\WebsiteData\eDocs\Live\EOBs\GTXHPrintMail` — the app's `ArchivePath`. The permanent record agents browse as "sent files". |

Nothing mails out of the target, so copying into it carries no duplicate-mailing risk.

| Situation | Action |
|---|---|
| Target exists and differs from source | **Copy, overwriting.** The diagnosed bug. |
| Target exists and matches | Skip. |
| Target absent | **Copy.** The archive copy failed; agents cannot see a document that was mailed. |
| Source gone before the copy | Log at `DRAINED`, no retry. |

## The real constraint: the source is volatile

The source queue empties every ~30 minutes. Once the mailer takes a file, it exists nowhere to
copy from and **can never be reconciled**. The window to catch a failed archive copy is that
30 minutes and no longer.

Two consequences:

`SweepIntervalMinutes` must stay well under the drain interval. It ships at 5. Do not raise it
towards 30 without understanding that you are shrinking the safety margin to nothing.

**Service downtime is permanent data loss.** An hour of outage means every batch drained in that
hour is missing from the agent-facing archive forever. Configure Windows service recovery to
restart on failure, and alert on the service being down:

```powershell
sc.exe failure FileSyncWatcher reset= 86400 actions= restart/60000/restart/60000/restart/60000
```

This is the strongest argument for treating the watcher as temporary. The code fix copies
synchronously, before any drain can occur, and has no window to miss.

## First run

`DryRun` ships as `true`. Nothing is copied; every action it *would* take is logged.

1. Run it for a business day.
2. Read `logs/filesync-*.log`. Confirm the `STALE` lines are files you expect and the
   `MISSING` lines are files you are happy to leave alone.
3. Set `"DryRun": false`.

## Running it

```powershell
cd FileSyncWatcher
dotnet restore
dotnet run
```

Publish and install as a Windows service:

```powershell
dotnet publish -c Release -r win-x64 --self-contained false -o C:\Services\FileSyncWatcher

sc.exe create FileSyncWatcher `
  binPath= "C:\Services\FileSyncWatcher\FileSyncWatcher.exe" `
  start= auto `
  obj= "DOMAIN\svc_account" `
  password= "..."

sc.exe description FileSyncWatcher "Repairs stale PDFs in the Letter_Logic print/mail queue."
sc.exe start FileSyncWatcher
```

The account must have read on the source share and read/write/delete on the target. Run it under
a domain service account, not `LocalSystem` — `LocalSystem` authenticates to UNC paths as the
machine account and will usually be denied.

## Design notes

**The sweep is the real guarantee, not the watcher.** `FileSystemWatcher` on an SMB share drops
events when its buffer overflows or the session reconnects. The buffer is raised to the 64 KB
maximum and the `Error` event rebuilds the watcher, but a reconciliation sweep every
`SweepIntervalMinutes` is what actually catches everything. It only examines files modified in
the last `SweepLookbackHours`, so a 63k-file directory is not rescanned in full each cycle.

**Files are waited on before being read.** A `Created` event fires when the merge opens its
`FileStream`, long before the last page is written. `FileStabilityChecker` waits for the length
to stop changing and for an exclusive open to succeed.

**Copies land via a temp file.** Writing straight into a live queue folder risks the downstream
process grabbing a half-written PDF. The copy goes to `<name>.pdf.syncing.tmp` and is then moved
into place.

**Comparison is by length, then SHA-256.** Equal-length-different-content is rare here but cheap
to rule out. Files above `MaxHashBytes` (64 MB) fall back to length plus modification time.

## Log vocabulary

| Prefix | Meaning |
|---|---|
| `STALE` | Target differed. Copied over. The bug, caught. |
| `MISSING` | Target absent. Copied or skipped per policy. |
| `DRAINED` | Source removed by the mailer mid-processing. Not an error. |
| `IN SYNC` | Match (debug level). |
| `COPIED` | A copy completed. |
| `DRY RUN` | What would have happened. |
| `RETRY` / `FAILED` | Transient or terminal copy failure. |

A steady stream of `STALE` lines confirms the diagnosis. Once the code fix ships they should stop
entirely — that is your signal to retire this service.
