using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace Sms.Core.Services
{
    /// <summary>
    /// Reports that this instance is alive, on every cycle.
    ///
    /// EVERY SERVICE MUST CALL THIS OR STOP CONFIRMATION CANNOT WORK.
    ///
    /// Confirming a stop needs two facts: nothing is in flight, and every
    /// service has been seen since the stop was requested. The queue supplies
    /// the first. This supplies the second.
    ///
    /// Without it, a crashed service is indistinguishable from a stopped one —
    /// both have nothing in flight, the first because it stopped properly and
    /// the second because it is not doing anything at all. The UI would report a
    /// clean stop on a service that had died.
    /// </summary>
    public sealed class ServiceHeartbeat
    {
        private readonly string _connectionString;
        private readonly ILogger<ServiceHeartbeat>? _logger;

        public string InstanceId { get; }
        public string ServiceName { get; }
        public string MachineName { get; }

        /// <param name="serviceName">
        /// Must match what usp_SMS_ConfirmStop expects — Campaign, Compliance or
        /// Delivery. A service reporting under a name the confirmation does not
        /// know is invisible to it, and the stop will never confirm.
        /// </param>
        public ServiceHeartbeat(
            string connectionString,
            string serviceName,
            ILogger<ServiceHeartbeat>? logger = null)
        {
            _connectionString = connectionString;
            ServiceName = serviceName;
            _logger = logger;

            MachineName = Environment.MachineName;

            // Machine name plus process id plus start time.
            //
            // MACHINE NAME ALONE IS NOT ENOUGH. Two instances on one server
            // would share an id and overwrite each other's heartbeat, so the
            // confirmation would count one service where two are running — and
            // could confirm a stop while the second instance is still sending.
            //
            // Start time is included so a restarted process gets a fresh row
            // rather than inheriting the old one's history.
            var pid = Environment.ProcessId;
            var started = Process.GetCurrentProcess().StartTime.ToUniversalTime();
            InstanceId = $"{MachineName}:{serviceName}:{pid}:{started:yyyyMMddHHmmss}";

            if (InstanceId.Length > 100)
                InstanceId = InstanceId[..100];
        }

        /// <summary>
        /// Records this cycle. Call once per loop, whether or not work was found
        /// — a service that only heartbeats when busy looks dead during a quiet
        /// period, which is exactly when someone is most likely to be watching.
        /// </summary>
        public async Task BeatAsync(
            int claimedThisCycle = 0,
            long? currentRunId = null,
            CancellationToken ct = default)
        {
            const string sql = "dbo.usp_SMS_Heartbeat";

            try
            {
                await using var conn = new SqlConnection(_connectionString);
                await conn.OpenAsync(ct);

                await using var cmd = new SqlCommand(sql, conn)
                {
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandTimeout = 10
                };

                cmd.Parameters.AddWithValue("@InstanceId", InstanceId);
                cmd.Parameters.AddWithValue("@ServiceName", ServiceName);
                cmd.Parameters.AddWithValue("@MachineName", MachineName);
                cmd.Parameters.AddWithValue("@LastClaimed", claimedThisCycle);
                cmd.Parameters.AddWithValue("@CurrentRunId",
                    (object?)currentRunId ?? DBNull.Value);

                await cmd.ExecuteNonQueryAsync(ct);
            }
            catch (Exception ex)
            {
                // A failed heartbeat must not stop the service — it only affects
                // what the monitoring screen shows.
                //
                // But log it at warning, because a service that cannot heartbeat
                // will eventually appear dead, and someone will act on that.
                _logger?.LogWarning(ex,
                    "Heartbeat failed for {InstanceId}. The service is running but " +
                    "will appear unresponsive until this succeeds.", InstanceId);
            }
        }
    }
}
