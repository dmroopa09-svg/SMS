/* ============================================================================
   CAMPAIGN MANAGER — RATE LIMIT ENFORCEMENT
   ============================================================================

   SMS_Campaign_Settings holds MaxPerMinute, MaxPerHour and MaxPerDay. This is
   what makes them mean something.

   HOW SENDS ARE COUNTED
   ---------------------
   From Sent_Timestamp_UTC on SMS_Queue_Detail — the moment the message went to
   the provider.

   Counting by STATUS instead would be wrong: a message that was sent and later
   failed still consumed its slot at the provider, but its status is now Failed.
   Counting by status would let a campaign with a high failure rate quietly
   exceed its own ceiling by retrying.

   ⚠ ENFORCEMENT IS APPROXIMATE UNDER CONCURRENCY
   ----------------------------------------------
   Three instances can each read "400 remaining this hour" at the same instant
   and each claim 400, sending 1,200 against a limit of 1,000.

   That is accepted deliberately. Making it exact would mean serialising the
   claim across instances, which removes the horizontal scaling the whole design
   exists for. A rate cap is a volume guardrail, not a financial ledger — a few
   percent over on an hourly figure has no consequence, whereas losing the
   ability to add servers does.

   If a hard ceiling is ever genuinely required — a provider contract with
   penalties, say — the answer is a shared counter, not a tighter query.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ============================================================================
   1. usp_SMS_GetClaimAllowance

   How many messages this campaign may still send right now.

   Returns the TIGHTEST of the three windows. A campaign at 900 of 1,000 for the
   day but 50 of 100 for the hour may send 50, not 100.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_GetClaimAllowance', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_GetClaimAllowance;
GO

CREATE PROCEDURE dbo.usp_SMS_GetClaimAllowance
    @CampaignMstrId INT,
    @RequestedBatch INT = NULL      -- NULL: use the campaign's BatchSize
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Now DATETIME2 = SYSUTCDATETIME();

    DECLARE @MaxMinute INT, @MaxHour INT, @MaxDay INT, @BatchSize INT;

    SELECT @MaxMinute = MaxPerMinute,
           @MaxHour   = MaxPerHour,
           @MaxDay    = MaxPerDay,
           @BatchSize = BatchSize
    FROM   dbo.SMS_Campaign_Settings
    WHERE  Campaign_Mstr_ID = @CampaignMstrId;

    /* No settings row means no configured limits. Default batch rather than
       unlimited-everything, so an unconfigured campaign paces itself rather
       than emptying its queue at once. */
    SET @BatchSize = ISNULL(@RequestedBatch, ISNULL(@BatchSize, 100));

    /* Window boundaries. Minute and hour are rolling; day is the UTC calendar
       day, which is what an operator setting "50,000 per day" means. */
    DECLARE @MinuteStart DATETIME2 = DATEADD(MINUTE, -1, @Now);
    DECLARE @HourStart   DATETIME2 = DATEADD(HOUR,   -1, @Now);
    DECLARE @DayStart    DATETIME2 = CAST(CAST(@Now AS DATE) AS DATETIME2);

    DECLARE @SentMinute INT = 0, @SentHour INT = 0, @SentDay INT = 0;

    /* Only count what the limits actually need. A campaign with no per-minute
       limit should not pay for a per-minute count on every cycle. */
    IF @MaxMinute IS NOT NULL
        SELECT @SentMinute = COUNT(*)
        FROM   dbo.SMS_Queue_Detail d
        INNER  JOIN dbo.SMS_Queue_Mst m ON m.ID = d.SMSQueue_Mst_ID
        WHERE  m.Campaign_Mstr_ID = @CampaignMstrId
          AND  d.Sent_Timestamp_UTC >= @MinuteStart;

    IF @MaxHour IS NOT NULL
        SELECT @SentHour = COUNT(*)
        FROM   dbo.SMS_Queue_Detail d
        INNER  JOIN dbo.SMS_Queue_Mst m ON m.ID = d.SMSQueue_Mst_ID
        WHERE  m.Campaign_Mstr_ID = @CampaignMstrId
          AND  d.Sent_Timestamp_UTC >= @HourStart;

    IF @MaxDay IS NOT NULL
        SELECT @SentDay = COUNT(*)
        FROM   dbo.SMS_Queue_Detail d
        INNER  JOIN dbo.SMS_Queue_Mst m ON m.ID = d.SMSQueue_Mst_ID
        WHERE  m.Campaign_Mstr_ID = @CampaignMstrId
          AND  d.Sent_Timestamp_UTC >= @DayStart;

    DECLARE @Allowance INT = @BatchSize;
    DECLARE @LimitedBy VARCHAR(20) = 'BatchSize';

    IF @MaxMinute IS NOT NULL AND (@MaxMinute - @SentMinute) < @Allowance
    BEGIN
        SET @Allowance = @MaxMinute - @SentMinute;
        SET @LimitedBy = 'PerMinute';
    END

    IF @MaxHour IS NOT NULL AND (@MaxHour - @SentHour) < @Allowance
    BEGIN
        SET @Allowance = @MaxHour - @SentHour;
        SET @LimitedBy = 'PerHour';
    END

    IF @MaxDay IS NOT NULL AND (@MaxDay - @SentDay) < @Allowance
    BEGIN
        SET @Allowance = @MaxDay - @SentDay;
        SET @LimitedBy = 'PerDay';
    END

    IF @Allowance < 0 SET @Allowance = 0;

    SELECT @Allowance  AS Allowance,
           @LimitedBy  AS LimitedBy,
           @SentMinute AS SentLastMinute,
           @SentHour   AS SentLastHour,
           @SentDay    AS SentToday,
           @MaxMinute  AS MaxPerMinute,
           @MaxHour    AS MaxPerHour,
           @MaxDay     AS MaxPerDay;
END
GO


/* ============================================================================
   2. usp_SMS_ClaimBatchRateLimited

   Allowance and claim in one call, so a service does not need two round trips
   or the logic to combine them.

   Returns nothing when the allowance is zero — which the caller should treat as
   "wait", not "no work". A campaign throttled to its hourly limit has plenty of
   work; it simply may not do it yet.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_ClaimBatchRateLimited', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_ClaimBatchRateLimited;
GO

CREATE PROCEDURE dbo.usp_SMS_ClaimBatchRateLimited
    @CampaignMstrId INT,
    @FromStatus     TINYINT,
    @ClaimStatus    TINYINT,
    @InstanceId     VARCHAR(100),
    @MaxBatch       INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Now DATETIME2 = SYSUTCDATETIME();

    /* ---- allowance ---- */
    DECLARE @Allowance TABLE (
        Allowance INT, LimitedBy VARCHAR(20),
        SentLastMinute INT, SentLastHour INT, SentToday INT,
        MaxPerMinute INT, MaxPerHour INT, MaxPerDay INT);

    INSERT INTO @Allowance
    EXEC dbo.usp_SMS_GetClaimAllowance @CampaignMstrId, @MaxBatch;

    DECLARE @Batch INT = (SELECT TOP 1 Allowance FROM @Allowance);

    IF ISNULL(@Batch, 0) <= 0
    BEGIN
        /* Empty result set, plus the reason. The caller needs to distinguish
           "throttled, come back shortly" from "queue empty, idle longer". */
        SELECT TOP 0 CAST(NULL AS BIGINT) AS ID;
        SELECT Allowance, LimitedBy, SentLastMinute, SentLastHour, SentToday
        FROM   @Allowance;
        RETURN;
    END

    /* ---- claim ---- */
    UPDATE TOP (@Batch) d
    SET    d.SMSStatus    = @ClaimStatus,
           d.ClaimedBy    = @InstanceId,
           d.ClaimedUtc   = @Now,
           d.RowUpdatedDt = @Now
    OUTPUT inserted.ID,
           inserted.SMSQueue_Mst_ID,
           inserted.AccountID,
           inserted.Mobile,
           inserted.StateCode,
           inserted.ZipCode,
           inserted.MessageText,
           inserted.AttemptCount
    FROM   dbo.SMS_Queue_Detail AS d WITH (ROWLOCK, UPDLOCK, READPAST)
    INNER  JOIN dbo.SMS_Queue_Mst AS m ON m.ID = d.SMSQueue_Mst_ID
    WHERE  d.SMSStatus = @FromStatus
      AND  m.Campaign_Mstr_ID = @CampaignMstrId
      AND  m.RunStatus = 1                       -- Running only
      AND  (d.NextAttemptUtc IS NULL OR d.NextAttemptUtc <= @Now);

    SELECT Allowance, LimitedBy, SentLastMinute, SentLastHour, SentToday
    FROM   @Allowance;
END
GO


/* ============================================================================
   3. usp_SMS_GetCampaignThrottleStatus

   For the UI. Shows why a campaign is not sending as fast as expected, which is
   otherwise a question that needs a developer.

   The three answers an operator wants to distinguish:
       throttled       working as configured
       queue empty     nothing left to send
       window closed   waiting, not broken
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_GetCampaignThrottleStatus', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_GetCampaignThrottleStatus;
GO

CREATE PROCEDURE dbo.usp_SMS_GetCampaignThrottleStatus
    @CampaignMstrId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Allowance TABLE (
        Allowance INT, LimitedBy VARCHAR(20),
        SentLastMinute INT, SentLastHour INT, SentToday INT,
        MaxPerMinute INT, MaxPerHour INT, MaxPerDay INT);

    INSERT INTO @Allowance
    EXEC dbo.usp_SMS_GetClaimAllowance @CampaignMstrId;

    DECLARE @Waiting INT, @Deferred INT;

    SELECT @Waiting  = SUM(CASE WHEN d.SMSStatus IN (0,2) THEN 1 ELSE 0 END),
           @Deferred = SUM(CASE WHEN d.SMSStatus = 7      THEN 1 ELSE 0 END)
    FROM   dbo.SMS_Queue_Detail d
    INNER  JOIN dbo.SMS_Queue_Mst m ON m.ID = d.SMSQueue_Mst_ID
    WHERE  m.Campaign_Mstr_ID = @CampaignMstrId
      AND  m.RunStatus IN (1, 2, 6);

    SELECT
        a.*,
        ISNULL(@Waiting, 0)  AS WaitingToSend,
        ISNULL(@Deferred, 0) AS DeferredToLater,
        CASE
            WHEN ISNULL(@Waiting, 0) = 0 AND ISNULL(@Deferred, 0) = 0
                THEN 'Nothing left to send'
            WHEN ISNULL(@Waiting, 0) = 0 AND ISNULL(@Deferred, 0) > 0
                THEN 'All remaining messages are outside their recipients'' send window'
            WHEN a.Allowance = 0
                THEN 'Throttled by ' + a.LimitedBy + ' limit'
            ELSE 'Sending'
        END AS Explanation
    FROM @Allowance a;
END
GO
