/* ============================================================================
   SMS COMPLIANCE — STATE-LEVEL TIME ZONE SEED
   ============================================================================

   WHAT THIS IS
   ------------
   A verifiable fallback covering the 37 states (plus DC and Puerto Rico) that
   lie entirely within ONE time zone. For these, StateCode alone determines the
   zone correctly — no zip lookup needed.

   WHAT THIS IS NOT
   ----------------
   A replacement for ZipCode_TimeZones. Fourteen states span two zones. For
   those, only the zip can decide, and this script deliberately refuses to guess.

   WHY IT IS SPLIT THIS WAY
   ------------------------
   State-to-zone for a single-zone state is a small, checkable fact — you can
   verify every row below at a glance. Zip-to-zone for a straddling state is
   41,000 rows of geography that has to come from an authoritative source.
   Mixing the two would hide which is which.

   HOW TO USE
   ----------
   1. Run this. It creates dbo.State_TimeZone_Default.
   2. Load the real zip data into ZipCode_TimeZones (see IMPORT_ZIPCODE_DATA.txt).
   3. Resolution order in code: zip first, then this table, then block.
   4. For the fourteen straddling states there is no state-level row, so a
      recipient there without a zip match will BLOCK rather than send at a
      guessed hour. That is the intended behaviour.
   ============================================================================ */

IF OBJECT_ID('dbo.State_TimeZone_Default', 'U') IS NOT NULL
    DROP TABLE dbo.State_TimeZone_Default;
GO

CREATE TABLE dbo.State_TimeZone_Default (
    StateCode        CHAR(2)       NOT NULL
        CONSTRAINT PK_State_TimeZone_Default PRIMARY KEY,
    TimeZone         VARCHAR(64)   NOT NULL,   -- IANA id, matches ZipCode_TimeZones.TimeZone
    ObservesDST      BIT           NOT NULL,
    IsSingleZone     BIT           NOT NULL,   -- always 1 here; straddling states are absent
    Notes            NVARCHAR(200) NULL,
    CreatedAt        DATETIME2     NOT NULL
        CONSTRAINT DF_STZD_CreatedAt DEFAULT SYSUTCDATETIME()
);
GO

/* ---------------------------------------------------------------------------
   EASTERN — entirely within America/New_York
   --------------------------------------------------------------------------- */
INSERT INTO dbo.State_TimeZone_Default (StateCode, TimeZone, ObservesDST, IsSingleZone, Notes) VALUES
 ('CT','America/New_York',1,1,NULL),
 ('DE','America/New_York',1,1,NULL),
 ('DC','America/New_York',1,1,NULL),
 ('GA','America/New_York',1,1,NULL),
 ('ME','America/New_York',1,1,NULL),
 ('MD','America/New_York',1,1,NULL),
 ('MA','America/New_York',1,1,NULL),
 ('NH','America/New_York',1,1,NULL),
 ('NJ','America/New_York',1,1,NULL),
 ('NY','America/New_York',1,1,NULL),
 ('NC','America/New_York',1,1,NULL),
 ('OH','America/New_York',1,1,NULL),
 ('PA','America/New_York',1,1,NULL),
 ('RI','America/New_York',1,1,NULL),
 ('SC','America/New_York',1,1,NULL),
 ('VT','America/New_York',1,1,NULL),
 ('VA','America/New_York',1,1,NULL),
 ('WV','America/New_York',1,1,NULL);
GO

/* ---------------------------------------------------------------------------
   CENTRAL — entirely within America/Chicago
   --------------------------------------------------------------------------- */
INSERT INTO dbo.State_TimeZone_Default (StateCode, TimeZone, ObservesDST, IsSingleZone, Notes) VALUES
 ('AL','America/Chicago',1,1,NULL),
 ('AR','America/Chicago',1,1,NULL),
 ('IL','America/Chicago',1,1,NULL),
 ('IA','America/Chicago',1,1,NULL),
 ('LA','America/Chicago',1,1,NULL),
 ('MN','America/Chicago',1,1,NULL),
 ('MS','America/Chicago',1,1,NULL),
 ('MO','America/Chicago',1,1,NULL),
 ('OK','America/Chicago',1,1,NULL),
 ('WI','America/Chicago',1,1,NULL);
GO

/* ---------------------------------------------------------------------------
   MOUNTAIN — entirely within America/Denver, except Arizona
   --------------------------------------------------------------------------- */
INSERT INTO dbo.State_TimeZone_Default (StateCode, TimeZone, ObservesDST, IsSingleZone, Notes) VALUES
 ('CO','America/Denver',1,1,NULL),
 ('MT','America/Denver',1,1,NULL),
 ('NM','America/Denver',1,1,NULL),
 ('UT','America/Denver',1,1,NULL),
 ('WY','America/Denver',1,1,NULL);
GO

/* Arizona keeps Mountain Standard Time all year and does NOT observe DST.
   In summer its local clock matches Pacific, in winter it matches Mountain.
   Using America/Denver for Arizona sends an hour early every summer. */
INSERT INTO dbo.State_TimeZone_Default (StateCode, TimeZone, ObservesDST, IsSingleZone, Notes) VALUES
 ('AZ','America/Phoenix',0,1,
  'No DST. The Navajo Nation in northeastern AZ does observe DST - if you have volume there, zip-level data is required.');
GO

/* ---------------------------------------------------------------------------
   PACIFIC
   --------------------------------------------------------------------------- */
INSERT INTO dbo.State_TimeZone_Default (StateCode, TimeZone, ObservesDST, IsSingleZone, Notes) VALUES
 ('CA','America/Los_Angeles',1,1,NULL),
 ('WA','America/Los_Angeles',1,1,NULL);
GO

/* ---------------------------------------------------------------------------
   NON-CONTIGUOUS AND TERRITORIES
   --------------------------------------------------------------------------- */
INSERT INTO dbo.State_TimeZone_Default (StateCode, TimeZone, ObservesDST, IsSingleZone, Notes) VALUES
 ('HI','Pacific/Honolulu',0,1,'No DST.'),
 ('PR','America/Puerto_Rico',0,1,'No DST. Atlantic Standard Time year round.'),
 ('VI','America/St_Thomas',0,1,'No DST.'),
 ('GU','Pacific/Guam',0,1,'No DST.'),
 ('AS','Pacific/Pago_Pago',0,1,'No DST.'),
 ('MP','Pacific/Saipan',0,1,'No DST.');
GO

/* ============================================================================
   DELIBERATELY ABSENT — THE FOURTEEN STRADDLING STATES
   ============================================================================

   These states span two time zones. There is NO correct state-level answer, so
   no row is inserted. A recipient in one of these states with no zip match will
   fall through and BLOCK, which is the safe outcome.

     AK   Alaska / Hawaii-Aleutian     Aleutian Islands west of 169.5W
     FL   Eastern / Central            panhandle west of the Apalachicola River
     ID   Mountain / Pacific           northern panhandle is Pacific
     IN   Eastern / Central            northwest and southwest corners
     KS   Central / Mountain           four westernmost counties
     KY   Eastern / Central            western half is Central
     MI   Eastern / Central            four western Upper Peninsula counties
     NE   Central / Mountain           western panhandle
     NV   Pacific / Mountain           West Wendover
     ND   Central / Mountain           southwestern counties
     OR   Pacific / Mountain           most of Malheur County
     SD   Central / Mountain           split roughly along the Missouri River
     TN   Eastern / Central            eastern third is Eastern
     TX   Central / Mountain           El Paso and Hudspeth counties

   Florida, Kentucky, Indiana, Tennessee and Texas are the ones that matter most
   in practice — they carry real population on both sides of the line, and
   Florida additionally has the strictest SMS rules in State_TCPA_Rules.

   Until ZipCode_TimeZones is loaded, recipients in these states cannot be sent
   to safely.
   ============================================================================ */

/* ---------------------------------------------------------------------------
   VERIFY
   --------------------------------------------------------------------------- */

-- Should return 42 rows (36 states + DC + PR + VI + GU + AS + MP)
SELECT COUNT(*) AS StateDefaultsLoaded FROM dbo.State_TimeZone_Default;

-- Every zone id used here must exist in TimeZone_Display_Map, or the .NET
-- lookup will fail at runtime. Any rows returned are a problem.
SELECT d.StateCode, d.TimeZone
FROM   dbo.State_TimeZone_Default d
LEFT   JOIN dbo.TimeZone_Display_Map m ON m.TimeZoneId = d.TimeZone
WHERE  m.TimeZoneId IS NULL;

-- Which states in your actual queue data have no coverage yet?
-- Any state listed here is currently unsendable.
SELECT DISTINCT q.StateCode
FROM   dbo.SMS_Queue_Detail q
LEFT   JOIN dbo.State_TimeZone_Default d ON d.StateCode = q.StateCode
LEFT   JOIN dbo.ZipCode_TimeZones      z ON z.ZipCode   = q.ZipCode
WHERE  d.StateCode IS NULL
  AND  z.ZipCode   IS NULL
  AND  q.StateCode IS NOT NULL
ORDER  BY q.StateCode;
GO
