USE [GTXH_OMC];
GO

/* ═══════════════════════════════════════════════════════════════════════
   1. SCHEMA — three nullable columns. Nothing existing changes.
   ═══════════════════════════════════════════════════════════════════════ */

IF COL_LENGTH('dbo.ProcessFields', 'ParentFieldName') IS NULL
    ALTER TABLE dbo.ProcessFields ADD ParentFieldName nvarchar(200) NULL;
GO
IF COL_LENGTH('dbo.ProcessFields', 'PairedFieldName') IS NULL
    ALTER TABLE dbo.ProcessFields ADD PairedFieldName nvarchar(200) NULL;
GO
IF COL_LENGTH('dbo.ProcessFields', 'OptionsJson') IS NULL
    ALTER TABLE dbo.ProcessFields ADD OptionsJson nvarchar(max) NULL;
GO

/*
   ParentFieldName   this field's options depend on that field's value
   PairedFieldName   picking an option here auto-fills that field
   OptionsJson       per parent value: a plain list, or a { option: pairedValue } map
*/


/* ═══════════════════════════════════════════════════════════════════════
   2. FIND YOUR IDs — run first, note the ProcessId
   ═══════════════════════════════════════════════════════════════════════ */

SELECT  p.ProcessId, p.ProcessName, f.FieldId, f.FieldName, f.FieldType, f.DisplayOrder
FROM    dbo.ProcessFields f
JOIN    dbo.Processes p ON p.ProcessId = f.ProcessId
WHERE   f.IsDeleted = 0
  AND   f.FieldName IN ('FC_Name','Workqueue','Status_Code','Action_Code')
ORDER BY p.ProcessName, f.DisplayOrder;


/* ═══════════════════════════════════════════════════════════════════════
   3. SEED

   FC_Name      flat list
   Workqueue    filtered by FC_Name
   Status_Code  filtered by FC_Name, AND paired -> auto-fills Action_Code
   Action_Code  filled by Status_Code; kept editable so an agent can override

   DIRECTION IS DELIBERATE: Status -> Action only. Action codes repeat across
   statuses ("Billed Patient" serves two, "Need nurse audit review" three), so
   the reverse cannot be resolved without guessing.
   ═══════════════════════════════════════════════════════════════════════ */

DECLARE @ProcessId int = 5;   -- <<< SET THIS

BEGIN TRANSACTION;

-- ── FC_Name ────────────────────────────────────────────────────────────
UPDATE dbo.ProcessFields
SET    Options = N'Medicaid,Commercial', ParentFieldName = NULL,
       PairedFieldName = NULL, OptionsJson = NULL
WHERE  ProcessId = @ProcessId AND FieldName = 'FC_Name';

-- ── Workqueue ──────────────────────────────────────────────────────────
UPDATE dbo.ProcessFields
SET    ParentFieldName = N'FC_Name', PairedFieldName = NULL,
       OptionsJson = N'{
  "Medicaid":   ["30417 - Follow up","37020 (COB)","38503 - Denial"],
  "Commercial": ["21371 (Correspondence)","30406 - Follow up","38622 - Denial"]
}'
WHERE  ProcessId = @ProcessId AND FieldName = 'Workqueue';

-- ── Status_Code  ->  auto-fills Action_Code ────────────────────────────
-- NOTE: "Legacy Review" appears twice in the Medicaid sheet, mapped to both
-- "Stop Bill" and "Credentialing (671)". A JSON key can hold one value, so it is
-- seeded as "Stop Bill". CONFIRM WITH DENNIS which is correct, or split the
-- status into two distinct labels.
UPDATE dbo.ProcessFields
SET    ParentFieldName = N'FC_Name',
       PairedFieldName = N'Action_Code',
       OptionsJson = N'{
  "Medicaid": {
    "Submitting Inquiry Through portal": "Portal Inquiry",
    "Faxing Correspondence to Legacy": "Faxed Correspondence",
    "Requested fax from payor": "Pending Fax Receipt",
    "Requested retro auth": "Retro auth requested",
    "Claim Not On File": "Claim Resubmitted - Elect",
    "Claim in Process": "Need to Follow-Up",
    "Claim Paid": "Moved to Ins paid",
    "Need to check Expected reimbursement met or not": "Reimbursement review needed",
    "Provider Credentialing Issue": "Moved to Credentialing Issue",
    "Claim denied as Invalid CPT Code/Revenue code/HCPCS": "Need nurse audit review",
    "Claim denied as Invalid Dx Code": "Need HIM review",
    "Claim denied as need Medical records": "Submitted/Faxed Medical records",
    "Secondary Policy Terminated and no other Insurance": "Billed Patient",
    "Denied for PRIMARY EOB": "Submitted primary EOB",
    "Primary paid maximum": "Adjustment",
    "Claim denied for Incorrect modifier": "Need nurse audit review",
    "Claim denied for COB,Added other insurance and resubmitted claim": "Added Insurance and billed",
    "Patient not active on DOS": "Billed Patient",
    "Claim denied for COB": "Sent letter to Patient",
    "Claim denied as Unit exceeded": "need nurse audit review",
    "Claim denied for no auth, retro auth is not possible.Within Timeframe for appeal": "Appeal submitted",
    "Invalid NDC Billed": "Need Post rveiew",
    "Need newborn NICU level review": "Patient Charge Review Needed [167]",
    "When need review on claim bill type": "UR rveiew needed",
    "Claim denied incorrectly,called to insurance & send for reprocess": "Sent back for reprocess",
    "Any denied CMS claims needs to be reviwed": "HCFA Claims Review Needed [671]",
    "cpt 99291 denied as invalid discarge status code": "Denial Appeal-CCCA Review Needed [520]",
    "Voicemail left for Insurance to call back": "Voicemail/Insurance",
    "Voicemail left for patient to call back": "Voicemail/Patient",
    "CPT denied for CO-204 service /equipment not covered for Medicaid OR and careoregon and pacificsource insurance": "Adjustment",
    "Denied for Incomplete/invalid procedure Modifier(s)": "Nurse Audit Review",
    "When the account is added to coding log and if we not recieve no response": "Pending coding review",
    "Claim denied for COB and other ins is inactive.": "Submitted COB inquiry",
    "Pending for response from credentialing team": "Pending credentialing review",
    "COB investigation  is pending for review": "COB Investigation in process",
    "Need to update COB/MVA/WC details with Pacific source": "Submitted claim research form",
    "claim denied for consent form": "Submitted consent form",
    "Emailed Carol for Medicai CA claim status": "Emailed Carol for claim status",
    "Need to update TPL with dmap": "Submitted TPL update form",
    "claim denied for W9 form": "Submitted W-9 form",
    "TPL update form is pending for review by DMAP": "TPL update is pending",
    "Legacy Review": "Stop Bill"
  },
  "Commercial": {
    "Working on correspondence email": "Correspondence",
    "When we move the account to Billing Indicator and if no response recieved.": "Deferred Follow up",
    "Appeal sent and in process": "Appeal in process",
    "When submitting appeal to insurance": "Appeal Sent",
    "WHen claim is submitted and still in process": "Claim in process",
    "When claim is paid and payment is not released we use this action code.": "Claim paid, Not released",
    "When the claim is recently worked": "Claim Recently Billed/Worked",
    "When we resubmit the claim to insurnace electronically": "Claim Resubmitted - Elect",
    "When claim is set to pay and no payment informaiton is listed": "Claim set to pay",
    "While submitting the corrected claim to insurance": "Corrected Claim sent",
    "When appeal has been Faxed": "Faxed Appeal",
    "When we fax medical records to insurance": "Faxed Medical Records",
    "When medical records is in process": "Medical Records Inprocess",
    "When retro auth in process": "Retro auth in process",
    "When claim sent back for reprocess": "Sent back for reprocess",
    "Emailing the insurance for status": "Sent Email for status",
    "Claim is denied for itemized bill and when submitting the itemized bill": "Sent Itemized Bill",
    "Claim is denied and when we need to submit the reconsideration to insurnace": "Sent Reconsideration",
    "Secondary ins denied the claim for primary eob": "Submitted primary EOB",
    "when we submit the retro auth request with payor": "Submitted retro auth request",
    "When the claim is denied and moving the claim to 179": "Appeal Review Needed",
    "When claim is denied and need to change level of care": "Bill Editor Review",
    "WHen claim is denied for coding related issues": "HIM Coding Review",
    "WHen we receive a Audit letter from the insurnace": "Insurance Audit Hold",
    "When ED code and EM code is dened": "Need CCCA review",
    "When J code claim is denied": "Need POST review",
    "Claim paid and need to check rexcepted Reimbursement has met or not": "Need Reimbursement review",
    "When Claim denied for Invalid Units, Modifier, cpt code or revenue code/HCPCS": "Nurse Audit Review",
    "When the account is added to coding log and if we not recieve no response": "Pending coding review",
    "When the account is pending for adjustment approval": "pending for supervisor review on adjustment",
    "When LID appeal has been sent and if it is inprocess/ underreview": "Pending LID Appeal",
    "When the account added to NSA Review": "Pending NSA review",
    "When the account added to PLB Review": "Pending PLB review",
    "When the claim is denied and we need help from Onshore to take step": "Question/Escalation Log",
    "When the claim denied for level of care": "UR Review",
    "When claim is denied for COB issue and sending a letter to patient": "Letter Sent to Patient",
    "When we adjust the claim": "Adjustment",
    "When we bill patient": "Billed Patient",
    "When the account is in ZERO balance": "Zero balance",
    "When medical records needs to be sent.": "Pre-Billing MR/IS",
    "Voicemail left for Insurance to call back": "Voicemail/Insurance",
    "Voicemail left for patient to call back": "Voicemail/Patient",
    "When insurance is added and billed": "Added Insurance and billed",
    "Denied for Incomplete/invalid procedure Modifier(s)": "Nurse Audit Review",
    "Legacy Review": "Stop Bill",
    "Submitting Inquiry Through portal": "Portal Inquiry",
    "Faxing Correspondence to Legacy": "Faxed Correspondence",
    "Requested fax from payor": "Pending Fax Receipt",
    "Requested retro auth": "Retro auth requested"
  }
}'
WHERE  ProcessId = @ProcessId AND FieldName = 'Status_Code';

-- ── Action_Code ────────────────────────────────────────────────────────
-- Filled by Status_Code. Still filtered by FC_Name so an agent overriding the
-- auto-filled value can only pick one valid for their FC.
UPDATE dbo.ProcessFields
SET    ParentFieldName = N'FC_Name', PairedFieldName = NULL,
       OptionsJson = N'{
  "Medicaid": ["Portal Inquiry","Faxed Correspondence","Pending Fax Receipt","Retro auth requested",
    "Claim Resubmitted - Elect","Need to Follow-Up","Moved to Ins paid","Reimbursement review needed",
    "Moved to Credentialing Issue","Need nurse audit review","Need HIM review","Submitted/Faxed Medical records",
    "Billed Patient","Submitted primary EOB","Adjustment","Added Insurance and billed","Sent letter to Patient",
    "need nurse audit review","Appeal submitted","Need Post rveiew","Patient Charge Review Needed [167]",
    "UR rveiew needed","Sent back for reprocess","HCFA Claims Review Needed [671]",
    "Denial Appeal-CCCA Review Needed [520]","Voicemail/Insurance","Voicemail/Patient","Nurse Audit Review",
    "Pending coding review","Submitted COB inquiry","Pending credentialing review","COB Investigation in process",
    "Submitted claim research form","Submitted consent form","Emailed Carol for claim status",
    "Submitted TPL update form","Submitted W-9 form","TPL update is pending","Stop Bill","Credentialing (671)"],
  "Commercial": ["Correspondence","Deferred Follow up","Appeal in process","Appeal Sent","Claim in process",
    "Claim paid, Not released","Claim Recently Billed/Worked","Claim Resubmitted - Elect","Claim set to pay",
    "Corrected Claim sent","Faxed Appeal","Faxed Medical Records","Medical Records Inprocess",
    "Retro auth in process","Sent back for reprocess","Sent Email for status","Sent Itemized Bill",
    "Sent Reconsideration","Submitted primary EOB","Submitted retro auth request","Appeal Review Needed",
    "Bill Editor Review","HIM Coding Review","Insurance Audit Hold","Need CCCA review","Need POST review",
    "Need Reimbursement review","Nurse Audit Review","Pending coding review",
    "pending for supervisor review on adjustment","Pending LID Appeal","Pending NSA review","Pending PLB review",
    "Question/Escalation Log","UR Review","Letter Sent to Patient","Adjustment","Billed Patient","Zero balance",
    "Pre-Billing MR/IS","Voicemail/Insurance","Voicemail/Patient","Added Insurance and billed","Stop Bill",
    "Portal Inquiry","Faxed Correspondence","Pending Fax Receipt","Retro auth requested"]
}'
WHERE  ProcessId = @ProcessId AND FieldName = 'Action_Code';


-- ── Verify before committing ───────────────────────────────────────────
SELECT  FieldName, ParentFieldName, PairedFieldName,
        ISJSON(OptionsJson) AS JsonValid       -- every row must be 1
FROM    dbo.ProcessFields
WHERE   ProcessId = @ProcessId
  AND   FieldName IN ('FC_Name','Workqueue','Status_Code','Action_Code');

-- COMMIT TRANSACTION;
-- ROLLBACK TRANSACTION;
GO
