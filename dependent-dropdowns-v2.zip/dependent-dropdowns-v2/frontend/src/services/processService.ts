// REFERENCE ONLY — add the three marked fields to your existing interface.
export interface ProcessFieldDto {
  fieldId: number;
  processId: number;
  fieldName: string;
  fieldType: string | number;
  isRequired: boolean;
  isReadOnly: boolean;
  displayOrder: number;
  options?: string;
  validationRules?: string;
  defaultValue?: string;
  maxLength?: number;
  minLength?: number;
  isDeleted?: boolean;

  // ── ADD THESE THREE ─────────────────────────────────────────────────
  /** Field this one depends on, by NAME. null = ordinary flat dropdown. */
  parentFieldName?: string | null;
  /** Picking an option here auto-fills that field. Status_Code -> Action_Code. */
  pairedFieldName?: string | null;
  /** Per parent value: a plain list, or a { option: pairedValue } map. */
  optionsJson?: string | null;
}
