import { ProcessFieldDto } from '../services/processService';

/**
 * THE ONLY PLACE THAT KNOWS HOW DROPDOWN OPTIONS ARE STORED.
 *
 * Currently a JSON blob on ProcessFields.OptionsJson. If the lists outgrow that,
 * swapping to a real option table is a change to this file and nothing else.
 * Never parse OptionsJson anywhere but here.
 *
 * Two shapes are supported per parent value:
 *
 *   plain list      "Medicaid": ["30417 - Follow up", "37020 (COB)"]
 *   paired map      "Medicaid": { "Claim Paid": "Moved to Ins paid", ... }
 *
 * In the paired form the KEYS are the options and the VALUES are what to
 * auto-fill into PairedFieldName. Direction matters — see the note on
 * resolvePair below.
 */

export interface ResolvedOptions {
  options: string[];
  /** True when a parent is configured but not yet chosen — render disabled. */
  disabled: boolean;
  /** Placeholder text, e.g. "Select FC_Name first". */
  reason?: string;
  /** Field to auto-fill when an option is picked. Undefined when not paired. */
  pairedFieldName?: string;
  /** option value -> paired field value. Only present in the paired form. */
  pairing?: Record<string, string>;
}

type OptionEntry = string[] | Record<string, string>;
type OptionMap = Record<string, OptionEntry>;

const parseCsv = (csv?: string | null): string[] =>
  csv ? csv.split(',').map(o => o.trim()).filter(Boolean) : [];

function parseOptionsJson(json?: string | null): OptionMap | null {
  if (!json || !json.trim()) return null;
  try {
    const parsed = JSON.parse(json);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;

    const out: OptionMap = {};
    for (const [key, value] of Object.entries(parsed)) {
      if (Array.isArray(value)) {
        out[key] = value.map(v => String(v).trim()).filter(Boolean);
      } else if (value && typeof value === 'object') {
        const map: Record<string, string> = {};
        for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
          const kk = k.trim();
          const vv = String(v ?? '').trim();
          if (kk) map[kk] = vv;
        }
        if (Object.keys(map).length > 0) out[key] = map;
      }
    }
    return Object.keys(out).length > 0 ? out : null;
  } catch {
    // Malformed JSON must not take the grid down — falls back to the CSV.
    return null;
  }
}

/** Admin-entered keys and uploaded values will not always agree on case. */
function findKey(map: Record<string, unknown>, value: string): string | undefined {
  const needle = value.trim().toLowerCase();
  return Object.keys(map).find(k => k.trim().toLowerCase() === needle);
}

/**
 * Options for one field, for ONE ROW.
 *
 * Per row, not per column: row 1 may be Medicaid and row 2 Commercial in the same
 * column, so this must be called from inside the cell renderer with that row's
 * taskData — not hoisted out of it.
 */
export function resolveOptions(
  field: ProcessFieldDto,
  taskData: Record<string, unknown> | undefined,
  allFields: ProcessFieldDto[]
): ResolvedOptions {
  const parentName = field.parentFieldName?.trim();
  const pairedName = field.pairedFieldName?.trim() || undefined;

  // No dependency — behaves exactly as before this feature existed.
  if (!parentName) {
    return { options: parseCsv(field.options), disabled: false, pairedFieldName: pairedName };
  }

  const parentField = allFields.find(
    f => !f.isDeleted && f.fieldName.trim().toLowerCase() === parentName.toLowerCase()
  );

  // Parent named but missing (renamed or deleted) — fall back rather than
  // leaving the agent with a dead dropdown.
  if (!parentField) {
    return { options: parseCsv(field.options), disabled: false, pairedFieldName: pairedName };
  }

  const parentValue = taskData?.[parentField.fieldName];
  if (parentValue === null || parentValue === undefined || String(parentValue).trim() === '') {
    return { options: [], disabled: true, reason: `Select ${parentField.fieldName} first` };
  }

  const map = parseOptionsJson(field.optionsJson);
  if (!map) {
    // Dependency configured but nothing saved yet — do not blank the field.
    return { options: parseCsv(field.options), disabled: false, pairedFieldName: pairedName };
  }

  const key = findKey(map, String(parentValue));
  const entry = key ? map[key] : undefined;

  if (!entry) return { options: [], disabled: false, pairedFieldName: pairedName };

  if (Array.isArray(entry)) {
    return { options: entry, disabled: false, pairedFieldName: pairedName };
  }

  // Paired form: keys are the selectable options.
  return {
    options: Object.keys(entry),
    disabled: false,
    pairedFieldName: pairedName,
    pairing: entry,
  };
}

/**
 * The value to auto-fill into the paired field when `selected` is picked.
 *
 * DIRECTION IS DELIBERATE. Status -> Action Code only.
 *
 * Action codes repeat across statuses — "Billed Patient" is the action for both
 * "Secondary Policy Terminated and no other Insurance" and "Patient not active
 * on DOS", and "Need nurse audit review" covers three separate statuses. So
 * Status -> Action is a function, and Action -> Status is not. Reversing it
 * would have to guess, and it would guess wrong.
 */
export function resolvePair(
  resolved: ResolvedOptions,
  selected: string
): { fieldName: string; value: string } | null {
  if (!resolved.pairing || !resolved.pairedFieldName) return null;
  const key = findKey(resolved.pairing, selected);
  if (!key) return null;
  const value = resolved.pairing[key];
  if (!value) return null;
  return { fieldName: resolved.pairedFieldName, value };
}

/**
 * Every field depending on `fieldName`, directly or through a chain.
 *
 * Used to clear downstream values when a parent changes. Silently keeping a
 * stale child is worse than blanking it — the row looks right and reports wrong.
 */
export function getDependentFieldNames(
  fieldName: string,
  allFields: ProcessFieldDto[],
  seen: Set<string> = new Set()
): string[] {
  const key = fieldName.trim().toLowerCase();
  if (seen.has(key)) return [];        // guards a mis-configured cycle
  seen.add(key);

  const direct = allFields
    .filter(f => !f.isDeleted && f.parentFieldName?.trim().toLowerCase() === key)
    .map(f => f.fieldName);

  return direct.flatMap(name => [name, ...getDependentFieldNames(name, allFields, seen)]);
}

/**
 * True when a stored value is still in the row's valid list.
 *
 * Render invalid values — do NOT auto-clear on load. Tasks hold values entered
 * before this existed, and silently rewriting live task data on render is not
 * something the agent asked for.
 */
export function isValueStillValid(value: unknown, resolved: ResolvedOptions): boolean {
  if (value === null || value === undefined || String(value).trim() === '') return true;
  if (resolved.disabled || resolved.options.length === 0) return true;
  const v = String(value).trim().toLowerCase();
  return resolved.options.some(o => o.trim().toLowerCase() === v);
}

/** True when this field is filled by another field's selection. */
export function isAutoFilledBy(field: ProcessFieldDto, allFields: ProcessFieldDto[]): string | null {
  const partner = allFields.find(
    f => !f.isDeleted && f.pairedFieldName?.trim().toLowerCase() === field.fieldName.trim().toLowerCase()
  );
  return partner ? partner.fieldName : null;
}
