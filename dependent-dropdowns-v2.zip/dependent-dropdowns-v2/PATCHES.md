# Dependent dropdowns + Status→Action auto-fill

- **FC Name** filters Workqueue, Status Code, Action Code
- **Status Code** auto-fills Action Code

New file: `frontend/src/utils/fieldOptions.ts` (in this zip)

---

## Direction is deliberate — Status → Action only

Action codes repeat across statuses in your sheet:

```
Billed Patient           <- "Secondary Policy Terminated and no other Insurance"
                         <- "Patient not active on DOS"
Need nurse audit review  <- three separate statuses
Adjustment               <- two separate statuses
```

Status → Action is a function. Action → Status is not. Reversing it would have to
guess, so auto-fill runs one way. Action Code stays **editable** so an agent can
override, but it is filtered by FC Name — an override still has to be valid.

**One thing to confirm with Dennis:** `"Legacy Review"` appears twice in the
Medicaid sheet, mapped to both `Stop Bill` and `Credentialing (671)`. A JSON key
holds one value, so it is seeded as `Stop Bill`. Either that is a duplicate, or
the status needs splitting into two distinct labels.

---

## 1. SQL

Run `sql/dependent_dropdowns.sql`. Step 2 gives the ProcessId; set it in step 3.

Verified: 42 Medicaid pairs, 49 Commercial pairs, and every paired action code
exists in that FC's Action_Code list.

---

## 2. Backend — 4 edits

### 2a. `Core/Entities/ProcessField.cs`

```csharp
    /// <summary>Field this one depends on, by NAME. NULL = ordinary flat dropdown.</summary>
    public string? ParentFieldName { get; set; }

    /// <summary>Picking an option here auto-fills that field. Status_Code -> Action_Code.</summary>
    public string? PairedFieldName { get; set; }

    /// <summary>Per parent value: a plain list, or a { option: pairedValue } map.</summary>
    public string? OptionsJson { get; set; }
```

### 2b. `Application/DTOs/ProcessFieldDto.cs`

```csharp
    public string? ParentFieldName { get; set; }
    public string? PairedFieldName { get; set; }
    public string? OptionsJson { get; set; }
```

### 2c. `MappingService.MapToProcessFieldDto`

```csharp
        Options = field.Options,
        ParentFieldName = field.ParentFieldName,   // ADD
        PairedFieldName = field.PairedFieldName,   // ADD
        OptionsJson = field.OptionsJson,           // ADD
```

### 2d. `TaskService.cs` — TWO inline mappings, easy to miss

`TaskService` builds `ProcessFieldDto` by hand in two places rather than going
through `MappingService`. Miss these and the columns arrive null even though 2c is
right — the grid falls back to flat options and nothing works, with no error.

```
Ctrl+F in TaskService.cs:   new ProcessFieldDto
```

Add all three to **both**.

---

## 3. Frontend

### 3a. `services/processService.ts` — add three fields to `ProcessFieldDto`

See the reference file in this zip.

### 3b. Copy in `utils/fieldOptions.ts`

### 3c. `utils/columnGenerator.tsx` — three edits

#### Edit 1 — import

```tsx
import { resolveOptions, resolvePair, getDependentFieldNames, isValueStillValid } from './fieldOptions';
```

#### Edit 2 — the line-56 comment

FIND:
```tsx
    const options = field.options ? field.options.split(',').map(o => o.trim()) : [];
```

REPLACE WITH:
```tsx
    // Dropdown (case 3) resolves options PER ROW inside the cell renderer —
    // computing them here, once per column, cannot express "row 1 is Medicaid,
    // row 2 is Commercial" in the same column. Kept only for MultiSelect (case 4),
    // which has no dependency support yet.
    const options = field.options ? field.options.split(',').map(o => o.trim()) : [];
```

#### Edit 3 — replace the whole `case 3:` block

From `case 3: // Dropdown` down to the closing `);` before `case 4:`.

```tsx
          case 3: { // Dropdown
            // PER ROW — this row's parent value decides this row's options.
            const resolved = resolveOptions(field, row.original.taskData, processFields);
            const valueValid = isValueStillValid(value, resolved);

            /**
             * One handler for three things that must happen together:
             *   1. set this field
             *   2. auto-fill the paired field   (Status_Code -> Action_Code)
             *   3. clear anything downstream    (FC_Name changed -> clear the rest)
             *
             * All in ONE update. Doing them as separate calls would fire three
             * saves and let the row sit in an inconsistent state in between.
             */
            const handleDropdownUpdate = (newValue: string) => {
              const currentTaskData = row.original.taskData || {};

              // 3. clear dependents — a stale child looks right and reports wrong
              const dependents = getDependentFieldNames(fieldName, processFields);
              const cleared: Record<string, null> = {};
              for (const dep of dependents) {
                const v = currentTaskData[dep];
                if (v !== null && v !== undefined && v !== '') cleared[dep] = null;
              }

              // 2. auto-fill the paired field
              const pair = newValue ? resolvePair(resolved, newValue) : null;
              const paired: Record<string, string> = {};
              if (pair && !(pair.fieldName in cleared)) {
                paired[pair.fieldName] = pair.value;
              }

              if (field.isRequired && (!newValue || newValue.trim() === '')) {
                addToast?.(`Field '${fieldName}' is required.`, 'error');
              }

              const changes = { [fieldName]: newValue, ...cleared, ...paired };
              onUpdateTask(taskId, {
                taskData: { ...currentTaskData, ...changes },
                dataChanged: changes,
              });

              if (pair) {
                addToast?.(`${pair.fieldName} set to "${pair.value}".`, 'info');
              }
              const clearedNames = Object.keys(cleared);
              if (clearedNames.length > 0) {
                addToast?.(`${clearedNames.join(', ')} cleared — ${fieldName} changed.`, 'info');
              }
            };

            if (isEditing) {
              return (
                <select
                  data-cell-id={`${taskId}-field_${fieldName}`}
                  disabled={isReadOnly || resolved.disabled}
                  className="w-full p-1 text-xs border rounded bg-white outline-none focus:ring-1 focus:ring-brand-primary disabled:bg-gray-50 disabled:text-gray-400"
                  value={value ? String(value) : ''}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      if (!isReadOnly && !resolved.disabled) {
                        handleDropdownUpdate((e.target as HTMLSelectElement).value);
                        if (pendingValueRef) pendingValueRef.current = null;
                      }
                      setEditingCell(null);
                    }
                    if (e.key === 'Escape') {
                      if (discardingRef) discardingRef.current = true;
                      if (pendingValueRef) pendingValueRef.current = null;
                      !isReadOnly && setEditingCell(null);
                    }
                  }}
                  onChange={(e) => {
                    if (!isReadOnly && !resolved.disabled) {
                      if (pendingValueRef) {
                        pendingValueRef.current = { taskId, fieldName, value: e.target.value };
                      }
                      handleDropdownUpdate(e.target.value);
                    }
                  }}
                  onBlur={() => {
                    if (pendingValueRef) pendingValueRef.current = null;
                    !isReadOnly && setEditingCell(null);
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <option value="">
                    {resolved.disabled ? (resolved.reason ?? 'Select parent first') : 'Select...'}
                  </option>

                  {/* A stored value no longer in the list must stay selectable,
                      or opening the dropdown would silently blank live data. */}
                  {!valueValid && value && (
                    <option value={String(value)}>{String(value)} (not in list)</option>
                  )}

                  {resolved.options.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              );
            }

            return (
              <div
                data-cell-id={`${taskId}-field_${fieldName}`}
                className={`w-full h-full flex items-center flex-col justify-center ${!isReadOnly ? 'cursor-pointer hover:bg-gray-50/50 p-1' : 'p-1'} rounded transition-colors ${hasValidationError ? 'bg-red-50' : ''}`}
                onClick={() => !isReadOnly && setEditingCell({ id: taskId, field: `field_${fieldName}` })}
                title={
                  resolved.disabled
                    ? resolved.reason
                    : (!valueValid && value ? 'Not valid for the selected FC Name' : undefined)
                }
              >
                {hasValidationError && !value ? (
                  <span className="text-red-600 text-[10px] font-bold">is required</span>
                ) : (
                  <span className={`truncate ${!valueValid && value ? 'text-amber-600' : ''}`}>
                    {String(value || '')}
                  </span>
                )}
              </div>
            );
          }
```

Wrapped in `{ }` because it declares consts — same as `case 4` already does.

---

## 4. Test

1. FC Name empty → Workqueue, Status, Action all disabled, "Select FC_Name first"
2. Pick **Medicaid** → all three populate with Medicaid values only
3. Pick Status **"Claim Paid"** → Action Code fills **"Moved to Ins paid"**, toast confirms
4. Override Action Code manually → allowed, and only Medicaid actions offered
5. Change to **Commercial** → all three clear, lists reload
6. Old task with a stale value → amber, still selectable, **not** auto-cleared
7. A process with no dependencies → unchanged

Step 3 is the one to watch — one save, not two.

---

## 5. Known gaps — deliberate

**No admin UI.** Configuration is the SQL. The editor is a separate piece and
worth doing properly.

**Drag-to-fill and bulk update are not validated.** Both bypass the dropdown and
can push a Commercial value into a Medicaid row, and neither triggers auto-fill.
Next thing I would add.

**MultiSelect (case 4) has no dependency support.** Dropdown only.
