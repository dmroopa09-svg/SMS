using GTXH.OMC.Application.DTOs;

namespace GTXH.OMC.Application.Interfaces;

public interface IWorkPolicyService
{
    // ---- Configuration (admin) ---------------------------------------------------------------
    Task<ProcessWorkSettingsDto> GetSettingsAsync(int processId, CancellationToken ct = default);
    Task<ProcessWorkSettingsDto> SaveSettingsAsync(ProcessWorkSettingsDto settings, int userId, CancellationToken ct = default);

    /// <summary>Every active reason with its effective policy for the process. With userId, also UsedToday / CanStart.</summary>
    Task<List<ReasonPolicyDto>> GetReasonPoliciesAsync(int processId, int? userId = null, CancellationToken ct = default);
    Task<List<ReasonPolicyDto>> SaveReasonPoliciesAsync(int processId, List<ReasonPolicyDto> policies, int userId, CancellationToken ct = default);

    // ---- Enforcement (called from the break service and presence heartbeat) -----------------
    /// <summary>Disabled reason or MaxOccurrencesPerDay reached = not allowed.</summary>
    Task<BreakStartCheck> CheckCanStartBreakAsync(int userId, int processId, int reasonId, CancellationToken ct = default);

    /// <summary>Call after a break is ended: records DurationExceeded / InactivityExceeded / OutsideWindow.</summary>
    Task<List<PolicyBreachDto>> RecordBreakBreachesAsync(int breakLogId, CancellationToken ct = default);

    /// <summary>First heartbeat of the work day for a process = login. Records LateLogin.</summary>
    Task OnHeartbeatAsync(int userId, int processId, CancellationToken ct = default);

    /// <summary>Sign-out: records LastLogoutAt and EarlyLogout.</summary>
    Task OnSignOutAsync(int userId, CancellationToken ct = default);

    /// <summary>Manager/supervisor scope check: does the user have this process in UserProcessPermissions?</summary>
    Task<bool> CanManageProcessAsync(int userId, int processId, CancellationToken ct = default);

    // ---- Approvals ----------------------------------------------------------------------------
    Task<PagedBreachesDto> GetBreachesAsync(int viewerUserId, bool restrictToAssignedProcesses, BreachQuery query, CancellationToken ct = default);

    /// <summary>Approve or reject Pending breaches. Returns how many were changed.</summary>
    Task<int> DecideAsync(int viewerUserId, bool restrictToAssignedProcesses, DecideBreachesRequest request, CancellationToken ct = default);

    Task<List<PolicyBreachDto>> GetMyBreachesAsync(int userId, int days, CancellationToken ct = default);
    Task<bool> AddAgentCommentAsync(long breachId, int userId, string comment, CancellationToken ct = default);
}
