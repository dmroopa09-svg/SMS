namespace GTXH.OMC.Application.DTOs;

public static class BreachTypes
{
    public const string DurationExceeded = "DurationExceeded";
    public const string InactivityExceeded = "InactivityExceeded";
    public const string OutsideWindow = "OutsideWindow";
    public const string LateLogin = "LateLogin";
    public const string EarlyLogout = "EarlyLogout";
}

public static class BreachStatuses
{
    /// <summary>Breach noted, approval not required.</summary>
    public const string Recorded = "Recorded";
    public const string Pending = "Pending";
    public const string AutoApproved = "AutoApproved";
    public const string Approved = "Approved";
    public const string Rejected = "Rejected";
}

/// <summary>Per-process settings (shift, presence thresholds, inactivity popup).</summary>
public class ProcessWorkSettingsDto
{
    public int ProcessId { get; set; }
    public string TimeZoneId { get; set; } = "Central Standard Time";

    /// <summary>"HH:mm" or null.</summary>
    public string? ShiftStartTime { get; set; }
    public string? ShiftEndTime { get; set; }
    public int LoginGraceMin { get; set; }
    public int LogoutGraceMin { get; set; }
    public bool ShiftRequiresApproval { get; set; } = true;
    public bool ShiftAutoApprove { get; set; }

    public int IdleAfterMinutes { get; set; } = 5;
    public int OfflineAfterSeconds { get; set; } = 180;
    public int InactivityPromptMinutes { get; set; } = 120;

    /// <summary>False when the process has no saved row yet and these are the defaults.</summary>
    public bool IsSaved { get; set; }
}

/// <summary>A reason as it applies to one process: the policy row if there is one, otherwise the defaults.</summary>
public class ReasonPolicyDto
{
    public int ReasonId { get; set; }
    public string ReasonCode { get; set; } = string.Empty;
    public string ReasonLabel { get; set; } = string.Empty;
    /// <summary>1 = Break / sign-off, 2 = Inactivity, 3 = Delay.</summary>
    public int ReasonType { get; set; }

    public bool HasPolicy { get; set; }
    public bool IsEnabled { get; set; } = true;
    public int? AllowedDurationMin { get; set; }
    public int? MaxDurationMin { get; set; }
    /// <summary>"HH:mm" in the process time zone, or null = any time.</summary>
    public string? AllowedStartTime { get; set; }
    public string? AllowedEndTime { get; set; }
    public int? MaxOccurrencesPerDay { get; set; }
    public bool RequiresApproval { get; set; }
    public bool AutoApprove { get; set; }
    public bool IsPaidBreak { get; set; }
    public int DisplayOrder { get; set; }

    /// <summary>Agent app only: how many times the user has used it today.</summary>
    public int? UsedToday { get; set; }
    /// <summary>Agent app only: false when MaxOccurrencesPerDay is reached or the reason is disabled.</summary>
    public bool? CanStart { get; set; }
}

public class SaveReasonPoliciesRequest
{
    public List<ReasonPolicyDto> Policies { get; set; } = new();
}

public class BreakStartCheck
{
    public bool Allowed { get; set; } = true;
    public string? Message { get; set; }
    public ReasonPolicyDto? Policy { get; set; }
}

public class PolicyBreachDto
{
    public long BreachId { get; set; }
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public int ProcessId { get; set; }
    public string? ProcessName { get; set; }
    public int? ReasonId { get; set; }
    public string? ReasonLabel { get; set; }
    public int? BreakLogId { get; set; }
    public DateTime WorkDate { get; set; }
    public string BreachType { get; set; } = string.Empty;
    public string? Details { get; set; }
    public int? ExceededMinutes { get; set; }
    public string Status { get; set; } = BreachStatuses.Recorded;
    public string? AgentComment { get; set; }
    public int? DecidedByUserId { get; set; }
    public string? DecidedByName { get; set; }
    public DateTime? DecidedAt { get; set; }
    public string? DecisionComment { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class BreachQuery
{
    /// <summary>Default Pending. "All" for every status.</summary>
    public string? Status { get; set; } = BreachStatuses.Pending;
    public int? ProcessId { get; set; }
    public int? UserId { get; set; }
    /// <summary>yyyy-MM-dd, work date in the process time zone.</summary>
    public string? FromDate { get; set; }
    public string? ToDate { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 50;
}

public class PagedBreachesDto
{
    public List<PolicyBreachDto> Items { get; set; } = new();
    public int TotalCount { get; set; }
    public int PendingCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
}

public class DecideBreachesRequest
{
    public List<long> BreachIds { get; set; } = new();
    public bool Approve { get; set; }
    public string? Comment { get; set; }
}

public class AgentBreachCommentRequest
{
    public string Comment { get; set; } = string.Empty;
}
