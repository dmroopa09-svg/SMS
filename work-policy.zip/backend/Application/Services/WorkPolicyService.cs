using System.Collections.Concurrent;
using System.Data;
using System.Globalization;
using System.Text.Json;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace GTXH.OMC.Application.Services;

/// <summary>
/// ProcessReasonPolicy + ProcessWorkSettings: configuration, enforcement and the approval queue.
///
/// Clocks: UserBreakLogs.StartTime/EndTime are written with the app server's DateTime.Now, so
/// durations are measured on that clock. Times of day (shift, reason windows, work date) are
/// evaluated in the process time zone, converted from UTC - so neither the server's nor the
/// agent PC's time zone matters.
/// </summary>
public class WorkPolicyService : IWorkPolicyService
{
    private static readonly ConcurrentDictionary<int, (DateTime Expires, ProcessWorkSettingsDto Settings)> SettingsCache = new();
    private static readonly TimeSpan SettingsCacheFor = TimeSpan.FromSeconds(60);

    private readonly ApplicationDbContext _db;
    private readonly ILogger<WorkPolicyService> _logger;

    public WorkPolicyService(ApplicationDbContext db, ILogger<WorkPolicyService> logger)
    {
        _db = db;
        _logger = logger;
    }

    private async Task<SqlConnection> OpenAsync(CancellationToken ct)
    {
        var conn = new SqlConnection(_db.Database.GetConnectionString());
        await conn.OpenAsync(ct);
        return conn;
    }

    // =========================================================================================
    // Settings
    // =========================================================================================

    public async Task<ProcessWorkSettingsDto> GetSettingsAsync(int processId, CancellationToken ct = default)
    {
        if (SettingsCache.TryGetValue(processId, out var hit) && hit.Expires > DateTime.UtcNow)
            return hit.Settings;

        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(@"
            SELECT TimeZoneId, ShiftStartTime, ShiftEndTime, LoginGraceMin, LogoutGraceMin,
                   ShiftRequiresApproval, ShiftAutoApprove, IdleAfterMinutes, OfflineAfterSeconds, InactivityPromptMinutes
            FROM dbo.ProcessWorkSettings WHERE ProcessId = @P", conn);
        cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId;

        var s = new ProcessWorkSettingsDto { ProcessId = processId };
        await using (var r = await cmd.ExecuteReaderAsync(ct))
        {
            if (await r.ReadAsync(ct))
            {
                s.IsSaved = true;
                s.TimeZoneId = Str(r, 0) ?? s.TimeZoneId;
                s.ShiftStartTime = FormatTime(Time(r, 1));
                s.ShiftEndTime = FormatTime(Time(r, 2));
                s.LoginGraceMin = Int(r, 3) ?? 0;
                s.LogoutGraceMin = Int(r, 4) ?? 0;
                s.ShiftRequiresApproval = Bool(r, 5) ?? true;
                s.ShiftAutoApprove = Bool(r, 6) ?? false;
                s.IdleAfterMinutes = Int(r, 7) ?? s.IdleAfterMinutes;
                s.OfflineAfterSeconds = Int(r, 8) ?? s.OfflineAfterSeconds;
                s.InactivityPromptMinutes = Int(r, 9) ?? s.InactivityPromptMinutes;
            }
        }

        SettingsCache[processId] = (DateTime.UtcNow.Add(SettingsCacheFor), s);
        return s;
    }

    public async Task<ProcessWorkSettingsDto> SaveSettingsAsync(ProcessWorkSettingsDto settings, int userId, CancellationToken ct = default)
    {
        if (settings.ProcessId <= 0) throw new ArgumentException("processId is required");
        var start = ParseTime(settings.ShiftStartTime, "Shift start");
        var end = ParseTime(settings.ShiftEndTime, "Shift end");
        ValidateTimeZone(settings.TimeZoneId);

        if (settings.IdleAfterMinutes < 1) throw new ArgumentException("Idle after must be at least 1 minute");
        if (settings.OfflineAfterSeconds < 60) throw new ArgumentException("Offline after must be at least 60 seconds");
        if (settings.InactivityPromptMinutes < 1) throw new ArgumentException("Inactivity popup must be at least 1 minute");
        if (settings.LoginGraceMin < 0 || settings.LogoutGraceMin < 0) throw new ArgumentException("Grace minutes cannot be negative");

        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(@"
MERGE dbo.ProcessWorkSettings AS t
USING (SELECT @P AS ProcessId) AS s ON t.ProcessId = s.ProcessId
WHEN MATCHED THEN UPDATE SET
    TimeZoneId = @Tz, ShiftStartTime = @Start, ShiftEndTime = @End, LoginGraceMin = @LG, LogoutGraceMin = @OG,
    ShiftRequiresApproval = @SR, ShiftAutoApprove = @SA, IdleAfterMinutes = @Idle, OfflineAfterSeconds = @Off,
    InactivityPromptMinutes = @Prompt, ModifiedByUserId = @U, ModifiedDate = GETDATE()
WHEN NOT MATCHED THEN INSERT
    (ProcessId, TimeZoneId, ShiftStartTime, ShiftEndTime, LoginGraceMin, LogoutGraceMin, ShiftRequiresApproval,
     ShiftAutoApprove, IdleAfterMinutes, OfflineAfterSeconds, InactivityPromptMinutes, ModifiedByUserId)
    VALUES (@P, @Tz, @Start, @End, @LG, @OG, @SR, @SA, @Idle, @Off, @Prompt, @U);", conn);
        cmd.Parameters.Add("@P", SqlDbType.Int).Value = settings.ProcessId;
        cmd.Parameters.Add("@Tz", SqlDbType.VarChar, 64).Value = settings.TimeZoneId;
        cmd.Parameters.Add("@Start", SqlDbType.NVarChar, -1).Value = (object?)start?.ToString(@"hh\:mm\:ss") ?? DBNull.Value;
        cmd.Parameters.Add("@End", SqlDbType.NVarChar, -1).Value = (object?)end?.ToString(@"hh\:mm\:ss") ?? DBNull.Value;
        cmd.Parameters.Add("@LG", SqlDbType.Int).Value = settings.LoginGraceMin;
        cmd.Parameters.Add("@OG", SqlDbType.Int).Value = settings.LogoutGraceMin;
        cmd.Parameters.Add("@SR", SqlDbType.Bit).Value = settings.ShiftRequiresApproval;
        cmd.Parameters.Add("@SA", SqlDbType.Bit).Value = settings.ShiftAutoApprove;
        cmd.Parameters.Add("@Idle", SqlDbType.Int).Value = settings.IdleAfterMinutes;
        cmd.Parameters.Add("@Off", SqlDbType.Int).Value = settings.OfflineAfterSeconds;
        cmd.Parameters.Add("@Prompt", SqlDbType.Int).Value = settings.InactivityPromptMinutes;
        cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
        await cmd.ExecuteNonQueryAsync(ct);

        SettingsCache.TryRemove(settings.ProcessId, out _);
        return await GetSettingsAsync(settings.ProcessId, ct);
    }

    public async Task<bool> CanManageProcessAsync(int userId, int processId, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(
            "SELECT COUNT(*) FROM dbo.UserProcessPermissions WHERE UserId = @U AND ProcessId = @P", conn);
        cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
        cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId;
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) > 0;
    }

    // =========================================================================================
    // Reason policies
    // =========================================================================================

    public async Task<List<ReasonPolicyDto>> GetReasonPoliciesAsync(int processId, int? userId = null, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        var list = await LoadPoliciesAsync(conn, processId, null, ct);

        if (userId.HasValue)
        {
            var used = await CountBreaksTodayAsync(conn, userId.Value, processId, null, ct);
            foreach (var p in list)
            {
                p.UsedToday = used.GetValueOrDefault(p.ReasonId);
                p.CanStart = p.IsEnabled && !(p.MaxOccurrencesPerDay is > 0 && p.UsedToday >= p.MaxOccurrencesPerDay);
            }
        }
        return list;
    }

    public async Task<List<ReasonPolicyDto>> SaveReasonPoliciesAsync(int processId, List<ReasonPolicyDto> policies, int userId, CancellationToken ct = default)
    {
        if (processId <= 0) throw new ArgumentException("processId is required");

        foreach (var p in policies)
        {
            if (p.AllowedDurationMin is < 0 || p.MaxDurationMin is < 0 || p.MaxOccurrencesPerDay is < 0)
                throw new ArgumentException($"{p.ReasonLabel}: values cannot be negative");
            if (p.AllowedDurationMin.HasValue && p.MaxDurationMin.HasValue && p.MaxDurationMin < p.AllowedDurationMin)
                throw new ArgumentException($"{p.ReasonLabel}: maximum cannot be less than allowed");
            ParseTime(p.AllowedStartTime, $"{p.ReasonLabel} window start");
            ParseTime(p.AllowedEndTime, $"{p.ReasonLabel} window end");
        }

        await using var conn = await OpenAsync(ct);
        await using var tx = (SqlTransaction)await conn.BeginTransactionAsync(ct);
        try
        {
            foreach (var p in policies)
            {
                await using var cmd = new SqlCommand(@"
MERGE dbo.ProcessReasonPolicy AS t
USING (SELECT @P AS ProcessId, @R AS ReasonId) AS s ON t.ProcessId = s.ProcessId AND t.ReasonId = s.ReasonId
WHEN MATCHED THEN UPDATE SET
    IsEnabled = @En, AllowedDurationMin = @Al, MaxDurationMin = @Mx, AllowedStartTime = @St, AllowedEndTime = @Et,
    MaxOccurrencesPerDay = @Mo, RequiresApproval = @Ra, AutoApprove = @Aa, IsPaidBreak = @Pb, DisplayOrder = @Do,
    IsActive = 1, ModifiedByUserId = @U, ModifiedDate = GETDATE()
WHEN NOT MATCHED THEN INSERT
    (ProcessId, ReasonId, IsEnabled, AllowedDurationMin, MaxDurationMin, AllowedStartTime, AllowedEndTime,
     MaxOccurrencesPerDay, RequiresApproval, AutoApprove, IsPaidBreak, DisplayOrder, IsActive, CreatedByUserId, CreatedDate)
    VALUES (@P, @R, @En, @Al, @Mx, @St, @Et, @Mo, @Ra, @Aa, @Pb, @Do, 1, @U, GETDATE());", conn, tx);

                cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId;
                cmd.Parameters.Add("@R", SqlDbType.Int).Value = p.ReasonId;
                cmd.Parameters.Add("@En", SqlDbType.Bit).Value = p.IsEnabled;
                cmd.Parameters.Add("@Al", SqlDbType.Int).Value = (object?)p.AllowedDurationMin ?? DBNull.Value;
                cmd.Parameters.Add("@Mx", SqlDbType.Int).Value = (object?)p.MaxDurationMin ?? DBNull.Value;
                cmd.Parameters.Add("@St", SqlDbType.NVarChar, -1).Value = (object?)ParseTime(p.AllowedStartTime, "")?.ToString(@"hh\:mm\:ss") ?? DBNull.Value;
                cmd.Parameters.Add("@Et", SqlDbType.NVarChar, -1).Value = (object?)ParseTime(p.AllowedEndTime, "")?.ToString(@"hh\:mm\:ss") ?? DBNull.Value;
                cmd.Parameters.Add("@Mo", SqlDbType.Int).Value = (object?)p.MaxOccurrencesPerDay ?? DBNull.Value;
                cmd.Parameters.Add("@Ra", SqlDbType.Bit).Value = p.RequiresApproval;
                cmd.Parameters.Add("@Aa", SqlDbType.Bit).Value = p.AutoApprove;
                cmd.Parameters.Add("@Pb", SqlDbType.Bit).Value = p.IsPaidBreak;
                cmd.Parameters.Add("@Do", SqlDbType.Int).Value = p.DisplayOrder;
                cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
                await cmd.ExecuteNonQueryAsync(ct);
            }
            await tx.CommitAsync(ct);
        }
        catch
        {
            await tx.RollbackAsync(CancellationToken.None);
            throw;
        }

        return await LoadPoliciesAsync(conn, processId, null, ct);
    }

    // =========================================================================================
    // Enforcement
    // =========================================================================================

    public async Task<BreakStartCheck> CheckCanStartBreakAsync(int userId, int processId, int reasonId, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);
        var policy = (await LoadPoliciesAsync(conn, processId, reasonId, ct)).FirstOrDefault();
        if (policy == null) return new BreakStartCheck { Allowed = true };

        if (!policy.IsEnabled)
            return new BreakStartCheck { Allowed = false, Policy = policy, Message = $"\"{policy.ReasonLabel}\" is turned off for this process." };

        if (policy.MaxOccurrencesPerDay is > 0)
        {
            var used = (await CountBreaksTodayAsync(conn, userId, processId, reasonId, ct)).GetValueOrDefault(reasonId);
            if (used >= policy.MaxOccurrencesPerDay)
                return new BreakStartCheck
                {
                    Allowed = false,
                    Policy = policy,
                    Message = $"You've already taken \"{policy.ReasonLabel}\" {used} time(s) today. The limit is {policy.MaxOccurrencesPerDay}.",
                };
        }

        return new BreakStartCheck { Allowed = true, Policy = policy };
    }

    public async Task<List<PolicyBreachDto>> RecordBreakBreachesAsync(int breakLogId, CancellationToken ct = default)
    {
        var recorded = new List<PolicyBreachDto>();
        await using var conn = await OpenAsync(ct);

        int userId, processId, reasonId;
        DateTime startTime, endTime;
        int? storedAllowed;
        await using (var cmd = new SqlCommand(@"
            SELECT UserId, ProcessId, ReasonId, StartTime, EndTime, AllowedDurationMin
            FROM dbo.UserBreakLogs WHERE Id = @Id", conn))
        {
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = breakLogId;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (!await r.ReadAsync(ct) || r.IsDBNull(4)) return recorded; // not found / still open
            userId = r.GetInt32(0);
            processId = r.GetInt32(1);
            reasonId = r.GetInt32(2);
            startTime = r.GetDateTime(3);
            endTime = r.GetDateTime(4);
            storedAllowed = Int(r, 5);
        }

        var policy = (await LoadPoliciesAsync(conn, processId, reasonId, ct)).FirstOrDefault();
        if (policy == null) return recorded;

        var settings = await GetSettingsAsync(processId, ct);
        var tz = ResolveTimeZone(settings.TimeZoneId);
        // StartTime is on the app server clock; shift it onto the process clock by the same offset.
        var startLocal = ToProcessTime(startTime, tz);
        var workDate = startLocal.Date;
        var status = StatusFor(policy.RequiresApproval, policy.AutoApprove);

        // 1. Over the allowed duration
        var allowed = storedAllowed ?? policy.AllowedDurationMin;
        var minutes = (endTime - startTime).TotalMinutes;
        if (allowed is > 0 && minutes > allowed)
        {
            var over = (int)Math.Ceiling(minutes - allowed.Value);
            var details = $"{policy.ReasonLabel}: {(int)Math.Round(minutes)}m (allowed {allowed}m)";
            if (policy.MaxDurationMin is > 0 && minutes > policy.MaxDurationMin)
                details += $", over the {policy.MaxDurationMin}m maximum";

            var type = policy.ReasonType == 2 ? BreachTypes.InactivityExceeded : BreachTypes.DurationExceeded;
            var b = await InsertBreachAsync(conn, userId, processId, reasonId, breakLogId, workDate, type, details, over, status, ct);
            if (b != null) recorded.Add(b);
        }

        // 2. Outside the allowed window
        var winStart = ParseTime(policy.AllowedStartTime, "");
        var winEnd = ParseTime(policy.AllowedEndTime, "");
        if (winStart.HasValue && winEnd.HasValue && !InWindow(startLocal.TimeOfDay, winStart.Value, winEnd.Value))
        {
            var details = $"{policy.ReasonLabel} started at {startLocal:h:mm tt} (allowed {DateTime.Today.Add(winStart.Value):h:mm tt} - {DateTime.Today.Add(winEnd.Value):h:mm tt})";
            var b = await InsertBreachAsync(conn, userId, processId, reasonId, breakLogId, workDate, BreachTypes.OutsideWindow, details, null, status, ct);
            if (b != null) recorded.Add(b);
        }

        return recorded;
    }

    public async System.Threading.Tasks.Task OnHeartbeatAsync(int userId, int processId, CancellationToken ct = default)
    {
        var settings = await GetSettingsAsync(processId, ct);
        var tz = ResolveTimeZone(settings.TimeZoneId);
        var nowLocal = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tz);

        await using var conn = await OpenAsync(ct);

        int inserted;
        await using (var cmd = new SqlCommand(@"
            INSERT INTO dbo.UserDailyAttendance (UserId, ProcessId, WorkDate, FirstLoginAt)
            SELECT @U, @P, @D, @Now
            WHERE NOT EXISTS (SELECT 1 FROM dbo.UserDailyAttendance WITH (UPDLOCK, HOLDLOCK)
                              WHERE UserId = @U AND ProcessId = @P AND WorkDate = @D);
            SELECT @@ROWCOUNT;", conn))
        {
            cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId;
            cmd.Parameters.Add("@D", SqlDbType.Date).Value = nowLocal.Date;
            cmd.Parameters.Add("@Now", SqlDbType.DateTime2).Value = nowLocal;
            inserted = Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
        }

        // Only the first heartbeat of the day is a "login".
        if (inserted == 0) return;

        var start = ParseTime(settings.ShiftStartTime, "");
        if (!start.HasValue) return;

        var lateBy = nowLocal.TimeOfDay - start.Value - TimeSpan.FromMinutes(settings.LoginGraceMin);
        // Ignore "logins" more than 12h after shift start - that is a different shift, not lateness.
        if (lateBy <= TimeSpan.Zero || lateBy > TimeSpan.FromHours(12)) return;

        var details = $"Logged in at {nowLocal:h:mm tt} (shift starts {DateTime.Today.Add(start.Value):h:mm tt}" +
                      (settings.LoginGraceMin > 0 ? $", {settings.LoginGraceMin}m grace)" : ")");
        await InsertBreachAsync(conn, userId, processId, null, null, nowLocal.Date, BreachTypes.LateLogin, details,
            (int)Math.Ceiling(lateBy.TotalMinutes), StatusFor(settings.ShiftRequiresApproval, settings.ShiftAutoApprove), ct);
    }

    public async System.Threading.Tasks.Task OnSignOutAsync(int userId, CancellationToken ct = default)
    {
        await using var conn = await OpenAsync(ct);

        int? processId;
        await using (var cmd = new SqlCommand("SELECT ProcessId FROM dbo.UserPresence WHERE UserId = @U", conn))
        {
            cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
            var v = await cmd.ExecuteScalarAsync(ct);
            processId = v == null || v is DBNull ? null : Convert.ToInt32(v);
        }
        if (!processId.HasValue) return;

        var settings = await GetSettingsAsync(processId.Value, ct);
        var tz = ResolveTimeZone(settings.TimeZoneId);
        var nowLocal = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tz);

        await using (var cmd = new SqlCommand(@"
            UPDATE dbo.UserDailyAttendance SET LastLogoutAt = @Now
            WHERE UserId = @U AND ProcessId = @P AND WorkDate = @D", conn))
        {
            cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId.Value;
            cmd.Parameters.Add("@D", SqlDbType.Date).Value = nowLocal.Date;
            cmd.Parameters.Add("@Now", SqlDbType.DateTime2).Value = nowLocal;
            await cmd.ExecuteNonQueryAsync(ct);
        }

        var end = ParseTime(settings.ShiftEndTime, "");
        if (!end.HasValue) return;

        var earlyBy = end.Value - TimeSpan.FromMinutes(settings.LogoutGraceMin) - nowLocal.TimeOfDay;
        var start = ParseTime(settings.ShiftStartTime, "");
        // Only during the shift: signing out before it even started is not an "early logout".
        if (earlyBy <= TimeSpan.Zero || (start.HasValue && nowLocal.TimeOfDay < start.Value)) return;

        var details = $"Signed out at {nowLocal:h:mm tt} (shift ends {DateTime.Today.Add(end.Value):h:mm tt}" +
                      (settings.LogoutGraceMin > 0 ? $", {settings.LogoutGraceMin}m grace)" : ")");
        await InsertBreachAsync(conn, userId, processId.Value, null, null, nowLocal.Date, BreachTypes.EarlyLogout, details,
            (int)Math.Ceiling(earlyBy.TotalMinutes), StatusFor(settings.ShiftRequiresApproval, settings.ShiftAutoApprove), ct);
    }

    // =========================================================================================
    // Approvals
    // =========================================================================================

    public async Task<PagedBreachesDto> GetBreachesAsync(int viewerUserId, bool restrictToAssignedProcesses, BreachQuery query, CancellationToken ct = default)
    {
        var page = Math.Max(1, query.Page);
        var pageSize = Math.Clamp(query.PageSize, 1, 500);
        var result = new PagedBreachesDto { Page = page, PageSize = pageSize };

        DateTime? from = ParseDate(query.FromDate);
        DateTime? to = ParseDate(query.ToDate);
        var status = string.IsNullOrWhiteSpace(query.Status) || query.Status.Equals("All", StringComparison.OrdinalIgnoreCase)
            ? null : query.Status;

        const string where = @"
            WHERE (@Restrict = 0 OR b.ProcessId IN (SELECT ProcessId FROM dbo.UserProcessPermissions WHERE UserId = @Viewer))
              AND (@ProcessId IS NULL OR b.ProcessId = @ProcessId)
              AND (@UserId IS NULL OR b.UserId = @UserId)
              AND (@From IS NULL OR b.WorkDate >= @From)
              AND (@To IS NULL OR b.WorkDate <= @To)";

        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand($@"
            SELECT COUNT(*) FROM dbo.PolicyBreaches b {where} AND (@Status IS NULL OR b.Status = @Status);
            SELECT COUNT(*) FROM dbo.PolicyBreaches b {where} AND b.Status = 'Pending';

            SELECT b.BreachId, b.UserId, u.Username, b.ProcessId, pr.ProcessName, b.ReasonId, rm.ReasonLabel, b.BreakLogId,
                   b.WorkDate, b.BreachType, b.Details, b.ExceededMinutes, b.Status, b.AgentComment,
                   b.DecidedByUserId, du.Username, b.DecidedAt, b.DecisionComment, b.CreatedAt
            FROM dbo.PolicyBreaches b
            LEFT JOIN dbo.Users u         ON u.UserId = b.UserId
            LEFT JOIN dbo.Processes pr    ON pr.ProcessId = b.ProcessId
            LEFT JOIN dbo.ReasonMaster rm ON rm.ReasonId = b.ReasonId
            LEFT JOIN dbo.Users du        ON du.UserId = b.DecidedByUserId
            {where} AND (@Status IS NULL OR b.Status = @Status)
            ORDER BY CASE WHEN b.Status = 'Pending' THEN 0 ELSE 1 END, b.BreachId DESC
            OFFSET @Skip ROWS FETCH NEXT @Take ROWS ONLY;", conn);

        cmd.Parameters.Add("@Restrict", SqlDbType.Bit).Value = restrictToAssignedProcesses;
        cmd.Parameters.Add("@Viewer", SqlDbType.Int).Value = viewerUserId;
        cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = (object?)query.ProcessId ?? DBNull.Value;
        cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = (object?)query.UserId ?? DBNull.Value;
        cmd.Parameters.Add("@From", SqlDbType.Date).Value = (object?)from ?? DBNull.Value;
        cmd.Parameters.Add("@To", SqlDbType.Date).Value = (object?)to ?? DBNull.Value;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 20).Value = (object?)status ?? DBNull.Value;
        cmd.Parameters.Add("@Skip", SqlDbType.Int).Value = (page - 1) * pageSize;
        cmd.Parameters.Add("@Take", SqlDbType.Int).Value = pageSize;

        await using var r = await cmd.ExecuteReaderAsync(ct);
        if (await r.ReadAsync(ct)) result.TotalCount = r.GetInt32(0);
        await r.NextResultAsync(ct);
        if (await r.ReadAsync(ct)) result.PendingCount = r.GetInt32(0);
        await r.NextResultAsync(ct);
        while (await r.ReadAsync(ct)) result.Items.Add(ReadBreach(r));
        return result;
    }

    public async Task<int> DecideAsync(int viewerUserId, bool restrictToAssignedProcesses, DecideBreachesRequest request, CancellationToken ct = default)
    {
        var ids = (request.BreachIds ?? new List<long>()).Where(x => x > 0).Distinct().ToList();
        if (ids.Count == 0) throw new ArgumentException("Select at least one breach");
        if (!request.Approve && string.IsNullOrWhiteSpace(request.Comment))
            throw new ArgumentException("A comment is required when rejecting");

        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(@"
            UPDATE b SET Status = @NewStatus, DecidedByUserId = @Viewer, DecidedAt = SYSUTCDATETIME(), DecisionComment = @Comment
            FROM dbo.PolicyBreaches b
            WHERE b.BreachId IN (SELECT CAST([value] AS BIGINT) FROM OPENJSON(@Ids))
              AND b.Status = 'Pending'
              AND b.UserId <> @Viewer   -- nobody approves their own breach
              AND (@Restrict = 0 OR b.ProcessId IN (SELECT ProcessId FROM dbo.UserProcessPermissions WHERE UserId = @Viewer));
            SELECT @@ROWCOUNT;", conn);
        cmd.Parameters.Add("@NewStatus", SqlDbType.VarChar, 20).Value = request.Approve ? BreachStatuses.Approved : BreachStatuses.Rejected;
        cmd.Parameters.Add("@Viewer", SqlDbType.Int).Value = viewerUserId;
        cmd.Parameters.Add("@Comment", SqlDbType.NVarChar, 1000).Value = (object?)request.Comment?.Trim() ?? DBNull.Value;
        cmd.Parameters.Add("@Ids", SqlDbType.NVarChar, -1).Value = JsonSerializer.Serialize(ids);
        cmd.Parameters.Add("@Restrict", SqlDbType.Bit).Value = restrictToAssignedProcesses;
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
    }

    public async Task<List<PolicyBreachDto>> GetMyBreachesAsync(int userId, int days, CancellationToken ct = default)
    {
        var list = new List<PolicyBreachDto>();
        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(@"
            SELECT b.BreachId, b.UserId, u.Username, b.ProcessId, pr.ProcessName, b.ReasonId, rm.ReasonLabel, b.BreakLogId,
                   b.WorkDate, b.BreachType, b.Details, b.ExceededMinutes, b.Status, b.AgentComment,
                   b.DecidedByUserId, du.Username, b.DecidedAt, b.DecisionComment, b.CreatedAt
            FROM dbo.PolicyBreaches b
            LEFT JOIN dbo.Users u         ON u.UserId = b.UserId
            LEFT JOIN dbo.Processes pr    ON pr.ProcessId = b.ProcessId
            LEFT JOIN dbo.ReasonMaster rm ON rm.ReasonId = b.ReasonId
            LEFT JOIN dbo.Users du        ON du.UserId = b.DecidedByUserId
            WHERE b.UserId = @U AND b.WorkDate >= DATEADD(DAY, -@Days, CAST(GETDATE() AS DATE))
            ORDER BY b.BreachId DESC", conn);
        cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
        cmd.Parameters.Add("@Days", SqlDbType.Int).Value = Math.Clamp(days, 1, 90);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(ReadBreach(r));
        return list;
    }

    public async Task<bool> AddAgentCommentAsync(long breachId, int userId, string comment, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(comment)) throw new ArgumentException("Comment is required");
        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(@"
            UPDATE dbo.PolicyBreaches SET AgentComment = @C
            WHERE BreachId = @Id AND UserId = @U AND Status IN ('Pending', 'Recorded', 'AutoApproved');
            SELECT @@ROWCOUNT;", conn);
        cmd.Parameters.Add("@C", SqlDbType.NVarChar, 1000).Value = comment.Trim();
        cmd.Parameters.Add("@Id", SqlDbType.BigInt).Value = breachId;
        cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) > 0;
    }

    // =========================================================================================
    // Helpers
    // =========================================================================================

    private static async Task<List<ReasonPolicyDto>> LoadPoliciesAsync(SqlConnection conn, int processId, int? reasonId, CancellationToken ct)
    {
        // Effective values: ProcessReasonPolicy, then the older ProcessReason duration override,
        // then the ReasonMaster defaults.
        await using var cmd = new SqlCommand(@"
            SELECT r.ReasonId, r.ReasonCode, r.ReasonLabel, r.ReasonType, r.DefaultDurationMin, r.MaxDurationMin, r.DisplayOrder,
                   pol.Id, pol.IsEnabled, pol.AllowedDurationMin, pol.MaxDurationMin, pol.AllowedStartTime, pol.AllowedEndTime,
                   pol.MaxOccurrencesPerDay, pol.RequiresApproval, pol.AutoApprove, pol.IsPaidBreak, pol.DisplayOrder,
                   pr.AllowedDurationMin
            FROM dbo.ReasonMaster r
            OUTER APPLY (SELECT TOP 1 x.* FROM dbo.ProcessReasonPolicy x
                         WHERE x.ProcessId = @P AND x.ReasonId = r.ReasonId AND x.IsActive = 1 ORDER BY x.Id DESC) pol
            OUTER APPLY (SELECT TOP 1 y.AllowedDurationMin FROM dbo.ProcessReason y
                         WHERE y.ProcessId = @P AND y.ReasonId = r.ReasonId AND ISNULL(y.IsActive, 1) = 1 ORDER BY y.Id DESC) pr
            WHERE r.IsActive = 1 AND (@R IS NULL OR r.ReasonId = @R)
            ORDER BY r.ReasonType, COALESCE(pol.DisplayOrder, r.DisplayOrder), r.ReasonId", conn);
        cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId;
        cmd.Parameters.Add("@R", SqlDbType.Int).Value = (object?)reasonId ?? DBNull.Value;

        var list = new List<ReasonPolicyDto>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct))
        {
            var hasPolicy = !r.IsDBNull(7);
            list.Add(new ReasonPolicyDto
            {
                ReasonId = r.GetInt32(0),
                ReasonCode = Str(r, 1) ?? string.Empty,
                ReasonLabel = Str(r, 2) ?? string.Empty,
                ReasonType = Int(r, 3) ?? 0,
                HasPolicy = hasPolicy,
                IsEnabled = hasPolicy ? (Bool(r, 8) ?? true) : true,
                AllowedDurationMin = (hasPolicy ? Int(r, 9) : null) ?? Int(r, 18) ?? Int(r, 4),
                MaxDurationMin = (hasPolicy ? Int(r, 10) : null) ?? Int(r, 5),
                AllowedStartTime = hasPolicy ? FormatTime(Time(r, 11)) : null,
                AllowedEndTime = hasPolicy ? FormatTime(Time(r, 12)) : null,
                MaxOccurrencesPerDay = hasPolicy ? Int(r, 13) : null,
                RequiresApproval = hasPolicy && (Bool(r, 14) ?? false),
                AutoApprove = hasPolicy && (Bool(r, 15) ?? false),
                IsPaidBreak = hasPolicy && (Bool(r, 16) ?? false),
                DisplayOrder = (hasPolicy ? Int(r, 17) : null) ?? Int(r, 6) ?? 0,
            });
        }
        return list;
    }

    /// <summary>Breaks started today (process time zone), per reason.</summary>
    private async Task<Dictionary<int, int>> CountBreaksTodayAsync(SqlConnection conn, int userId, int processId, int? reasonId, CancellationToken ct)
    {
        var settings = await GetSettingsAsync(processId, ct);
        var tz = ResolveTimeZone(settings.TimeZoneId);
        var nowLocal = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tz);
        // Midnight in the process time zone, expressed on the app server clock StartTime uses.
        var dayStartOnServerClock = DateTime.Now - (nowLocal - nowLocal.Date);

        await using var cmd = new SqlCommand(@"
            SELECT ReasonId, COUNT(*) FROM dbo.UserBreakLogs
            WHERE UserId = @U AND ProcessId = @P AND StartTime >= @Since AND (@R IS NULL OR ReasonId = @R)
            GROUP BY ReasonId", conn);
        cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
        cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId;
        cmd.Parameters.Add("@Since", SqlDbType.DateTime2).Value = dayStartOnServerClock;
        cmd.Parameters.Add("@R", SqlDbType.Int).Value = (object?)reasonId ?? DBNull.Value;

        var counts = new Dictionary<int, int>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) counts[r.GetInt32(0)] = r.GetInt32(1);
        return counts;
    }

    private async Task<PolicyBreachDto?> InsertBreachAsync(SqlConnection conn, int userId, int processId, int? reasonId, int? breakLogId,
        DateTime workDate, string type, string details, int? exceededMinutes, string status, CancellationToken ct)
    {
        try
        {
            await using var cmd = new SqlCommand(@"
                INSERT INTO dbo.PolicyBreaches
                    (UserId, ProcessId, ReasonId, BreakLogId, WorkDate, BreachType, Details, ExceededMinutes, Status,
                     DecidedAt, DecisionComment)
                OUTPUT inserted.BreachId
                SELECT @U, @P, @R, @B, @D, @T, @Details, @Ex, @S,
                       CASE WHEN @S = 'AutoApproved' THEN SYSUTCDATETIME() END,
                       CASE WHEN @S = 'AutoApproved' THEN N'Auto-approved by policy' END
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.PolicyBreaches x
                    WHERE x.BreachType = @T
                      AND ((@B IS NOT NULL AND x.BreakLogId = @B)
                        OR (@B IS NULL AND x.BreakLogId IS NULL AND x.UserId = @U AND x.ProcessId = @P AND x.WorkDate = @D)));", conn);
            cmd.Parameters.Add("@U", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@P", SqlDbType.Int).Value = processId;
            cmd.Parameters.Add("@R", SqlDbType.Int).Value = (object?)reasonId ?? DBNull.Value;
            cmd.Parameters.Add("@B", SqlDbType.Int).Value = (object?)breakLogId ?? DBNull.Value;
            cmd.Parameters.Add("@D", SqlDbType.Date).Value = workDate;
            cmd.Parameters.Add("@T", SqlDbType.VarChar, 30).Value = type;
            cmd.Parameters.Add("@Details", SqlDbType.NVarChar, 500).Value = details.Length > 500 ? details[..500] : details;
            cmd.Parameters.Add("@Ex", SqlDbType.Int).Value = (object?)exceededMinutes ?? DBNull.Value;
            cmd.Parameters.Add("@S", SqlDbType.VarChar, 20).Value = status;

            var id = await cmd.ExecuteScalarAsync(ct);
            if (id == null || id is DBNull) return null; // already recorded

            return new PolicyBreachDto
            {
                BreachId = Convert.ToInt64(id),
                UserId = userId,
                ProcessId = processId,
                ReasonId = reasonId,
                BreakLogId = breakLogId,
                WorkDate = workDate,
                BreachType = type,
                Details = details,
                ExceededMinutes = exceededMinutes,
                Status = status,
                CreatedAt = DateTime.UtcNow,
            };
        }
        catch (Exception ex)
        {
            // A breach that can't be written must never fail the agent's break or sign-out.
            _logger.LogError(ex, "Could not record {Type} breach for user {UserId}, process {ProcessId}", type, userId, processId);
            return null;
        }
    }

    private static PolicyBreachDto ReadBreach(SqlDataReader r) => new()
    {
        BreachId = Convert.ToInt64(r.GetValue(0)),
        UserId = r.GetInt32(1),
        Username = Str(r, 2) ?? "Unknown",
        ProcessId = r.GetInt32(3),
        ProcessName = Str(r, 4),
        ReasonId = Int(r, 5),
        ReasonLabel = Str(r, 6),
        BreakLogId = Int(r, 7),
        WorkDate = r.GetDateTime(8),
        BreachType = Str(r, 9) ?? string.Empty,
        Details = Str(r, 10),
        ExceededMinutes = Int(r, 11),
        Status = Str(r, 12) ?? string.Empty,
        AgentComment = Str(r, 13),
        DecidedByUserId = Int(r, 14),
        DecidedByName = Str(r, 15),
        DecidedAt = r.IsDBNull(16) ? null : r.GetDateTime(16),
        DecisionComment = Str(r, 17),
        CreatedAt = r.GetDateTime(18),
    };

    private static string StatusFor(bool requiresApproval, bool autoApprove) =>
        !requiresApproval ? BreachStatuses.Recorded
        : autoApprove ? BreachStatuses.AutoApproved
        : BreachStatuses.Pending;

    private static bool InWindow(TimeSpan t, TimeSpan start, TimeSpan end) =>
        start <= end ? t >= start && t <= end : t >= start || t <= end; // overnight windows wrap

    /// <summary>An app-server-clock time expressed in the process time zone.</summary>
    private static DateTime ToProcessTime(DateTime serverClock, TimeZoneInfo tz)
    {
        var nowLocal = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tz);
        return nowLocal - (DateTime.Now - serverClock);
    }

    /// <summary>The process time zone; falls back to US Central if the saved id is missing or unknown.</summary>
    internal static TimeZoneInfo ResolveTimeZone(string? id)
    {
        foreach (var c in new[] { id, "Central Standard Time", "America/Chicago" })
        {
            if (string.IsNullOrWhiteSpace(c)) continue;
            try { return TimeZoneInfo.FindSystemTimeZoneById(c); }
            catch (TimeZoneNotFoundException) { }
            catch (InvalidTimeZoneException) { }
        }
        return TimeZoneInfo.Utc;
    }

    private static void ValidateTimeZone(string? id)
    {
        try { TimeZoneInfo.FindSystemTimeZoneById(id ?? string.Empty); }
        catch (Exception) { throw new ArgumentException($"Unknown time zone '{id}'. Use e.g. 'Central Standard Time'."); }
    }

    private static TimeSpan? ParseTime(string? value, string label)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        if (TimeSpan.TryParse(value, CultureInfo.InvariantCulture, out var t) && t >= TimeSpan.Zero && t < TimeSpan.FromDays(1))
            return t;
        if (DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
            return d.TimeOfDay;
        throw new ArgumentException($"{label}: '{value}' is not a valid time (use HH:mm)");
    }

    private static DateTime? ParseDate(string? value) =>
        DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d.Date : null;

    private static string? FormatTime(TimeSpan? t) => t?.ToString(@"hh\:mm");

    private static int? Int(SqlDataReader r, int i) => r.IsDBNull(i) ? null : Convert.ToInt32(r.GetValue(i));
    private static bool? Bool(SqlDataReader r, int i) => r.IsDBNull(i) ? null : Convert.ToBoolean(r.GetValue(i));
    private static string? Str(SqlDataReader r, int i) => r.IsDBNull(i) ? null : Convert.ToString(r.GetValue(i));

    /// <summary>AllowedStartTime may be TIME, DATETIME or text depending on how the column was created.</summary>
    private static TimeSpan? Time(SqlDataReader r, int i)
    {
        if (r.IsDBNull(i)) return null;
        return r.GetValue(i) switch
        {
            TimeSpan ts => ts,
            DateTime dt => dt.TimeOfDay,
            string s when TimeSpan.TryParse(s, CultureInfo.InvariantCulture, out var p) => p,
            _ => null,
        };
    }
}

/// <summary>Presence Idle/Offline limits from ProcessWorkSettings (falls back to the defaults).</summary>
public class WorkSettingsPresenceThresholdProvider : IPresenceThresholdProvider
{
    private readonly IWorkPolicyService _policy;

    public WorkSettingsPresenceThresholdProvider(IWorkPolicyService policy) => _policy = policy;

    public async Task<PresenceThresholdsDto> GetAsync(int? processId, CancellationToken ct = default)
    {
        if (processId is not > 0)
            return new PresenceThresholdsDto
            {
                IdleAfterMinutes = DefaultPresenceThresholdProvider.DefaultIdleAfterMinutes,
                OfflineAfterSeconds = DefaultPresenceThresholdProvider.DefaultOfflineAfterSeconds,
            };

        var s = await _policy.GetSettingsAsync(processId.Value, ct);
        return new PresenceThresholdsDto { IdleAfterMinutes = s.IdleAfterMinutes, OfflineAfterSeconds = s.OfflineAfterSeconds };
    }
}
