using System.Data;
using System.Text.Json;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Core.Enums;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace GTXH.OMC.Application.Services;

/// <summary>
/// Defaults until ProcessReasonPolicy drives them (next step - only this class changes).
/// Offline after 3 minutes without a heartbeat (heartbeats are every 60s, so one or two lost
/// requests don't flip anyone to Offline). Idle after 5 minutes without input in the Tasks app.
/// </summary>
public class DefaultPresenceThresholdProvider : IPresenceThresholdProvider
{
    public const int DefaultIdleAfterMinutes = 5;
    public const int DefaultOfflineAfterSeconds = 180;

    public System.Threading.Tasks.Task<PresenceThresholdsDto> GetAsync(int? processId, CancellationToken ct = default) =>
        System.Threading.Tasks.Task.FromResult(new PresenceThresholdsDto
        {
            IdleAfterMinutes = DefaultIdleAfterMinutes,
            OfflineAfterSeconds = DefaultOfflineAfterSeconds,
        });
}

public class UserPresenceService : IUserPresenceService
{
    /// <summary>A gap longer than this between heartbeats starts a new session.</summary>
    private const int NewSessionAfterSeconds = 30 * 60;

    /// <summary>Open breaks older than this are leftovers and are ignored.</summary>
    private const int StaleBreakHours = 16;

    private readonly ApplicationDbContext _db;
    private readonly IPresenceThresholdProvider _thresholds;
    private readonly IWorkPolicyService _policy;
    private readonly ILogger<UserPresenceService> _logger;

    public UserPresenceService(ApplicationDbContext db, IPresenceThresholdProvider thresholds, IWorkPolicyService policy,
        ILogger<UserPresenceService> logger)
    {
        _db = db;
        _thresholds = thresholds;
        _policy = policy;
        _logger = logger;
    }

    private async Task<SqlConnection> OpenAsync(CancellationToken ct)
    {
        var conn = new SqlConnection(_db.Database.GetConnectionString());
        await conn.OpenAsync(ct);
        return conn;
    }

    // =====================================================================================
    // Agent app
    // =====================================================================================

    public async System.Threading.Tasks.Task HeartbeatAsync(int userId, PresenceHeartbeatRequest request, CancellationToken ct = default)
    {
        var idleSeconds = Math.Clamp(request.IdleSeconds, 0, 86_400);
        int? processId = request.ProcessId is > 0 ? request.ProcessId : null;

        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(@"
MERGE dbo.UserPresence WITH (HOLDLOCK) AS t
USING (SELECT @UserId AS UserId) AS s ON t.UserId = s.UserId
WHEN MATCHED THEN UPDATE SET
    ProcessId        = COALESCE(@ProcessId, t.ProcessId),
    SessionStartUtc  = CASE WHEN t.SignedOutUtc IS NOT NULL
                              OR DATEDIFF(SECOND, t.LastHeartbeatUtc, SYSUTCDATETIME()) > @NewSessionAfter
                            THEN SYSUTCDATETIME() ELSE t.SessionStartUtc END,
    LastHeartbeatUtc = SYSUTCDATETIME(),
    LastInputUtc     = DATEADD(SECOND, -@IdleSeconds, SYSUTCDATETIME()),
    IsTabVisible     = @Visible,
    SignedOutUtc     = NULL
WHEN NOT MATCHED THEN
    INSERT (UserId, ProcessId, SessionStartUtc, LastHeartbeatUtc, LastInputUtc, IsTabVisible)
    VALUES (@UserId, @ProcessId, SYSUTCDATETIME(), SYSUTCDATETIME(),
            DATEADD(SECOND, -@IdleSeconds, SYSUTCDATETIME()), @Visible);", conn);

        cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
        cmd.Parameters.Add("@ProcessId", SqlDbType.Int).Value = (object?)processId ?? DBNull.Value;
        cmd.Parameters.Add("@IdleSeconds", SqlDbType.Int).Value = idleSeconds;
        cmd.Parameters.Add("@Visible", SqlDbType.Bit).Value = request.IsTabVisible;
        cmd.Parameters.Add("@NewSessionAfter", SqlDbType.Int).Value = NewSessionAfterSeconds;
        await cmd.ExecuteNonQueryAsync(ct);

        // First heartbeat of the work day = login time (attendance + LateLogin breach).
        if (processId.HasValue)
        {
            try { await _policy.OnHeartbeatAsync(userId, processId.Value, ct); }
            catch (Exception ex) { _logger.LogError(ex, "Attendance check failed for user {UserId}", userId); }
        }
    }

    public async System.Threading.Tasks.Task SignOutAsync(int userId, CancellationToken ct = default)
    {
        // Before marking Offline: needs the current process from the presence row.
        try { await _policy.OnSignOutAsync(userId, ct); }
        catch (Exception ex) { _logger.LogError(ex, "Sign-out attendance check failed for user {UserId}", userId); }

        await using var conn = await OpenAsync(ct);
        await using var cmd = new SqlCommand(
            "UPDATE dbo.UserPresence SET SignedOutUtc = SYSUTCDATETIME() WHERE UserId = @UserId", conn);
        cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
        await cmd.ExecuteNonQueryAsync(ct);
    }

    // =====================================================================================
    // Admin dashboard
    // =====================================================================================

    public async Task<TeamPresenceDto> GetTeamAsync(int viewerUserId, bool restrictToAssignedProcesses, int? processId, CancellationToken ct = default)
    {
        var result = new TeamPresenceDto
        {
            GeneratedUtc = DateTime.UtcNow,
            Thresholds = await _thresholds.GetAsync(processId, ct),
        };

        await using var conn = await OpenAsync(ct);

        // ---- 1. Processes in scope (same rule as the dashboard metrics) ------------------
        List<int>? scopeProcessIds = null; // null = every process (superadmin, no filter)
        if (restrictToAssignedProcesses)
        {
            scopeProcessIds = await ReadIntsAsync(conn,
                "SELECT DISTINCT ProcessId FROM dbo.UserProcessPermissions WHERE UserId = @UserId", ct,
                ("@UserId", viewerUserId));
            if (scopeProcessIds.Count == 0) return result;
        }
        if (processId.HasValue)
        {
            if (scopeProcessIds != null && !scopeProcessIds.Contains(processId.Value)) return result;
            scopeProcessIds = new List<int> { processId.Value };
        }

        var scopeJson = scopeProcessIds == null ? null : JsonSerializer.Serialize(scopeProcessIds);

        // ---- 2. Users who work in those processes ----------------------------------------
        var scopeUserIds = await ReadIntsAsync(conn, @"
            SELECT DISTINCT p.UserId
            FROM dbo.UserProcessPermissions p
            WHERE @Scope IS NULL OR p.ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@Scope))", ct,
            ("@Scope", (object?)scopeJson ?? DBNull.Value));
        if (scopeUserIds.Count == 0) return result;

        // Active users only. EF here because Users.Status is an enum with its own mapping.
        var users = await _db.Users.AsNoTracking()
            .Where(u => scopeUserIds.Contains(u.UserId) && u.Status == UserStatus.Active)
            .Select(u => new { u.UserId, u.Username })
            .ToListAsync(ct);
        if (users.Count == 0) return result;

        var idsJson = JsonSerializer.Serialize(users.Select(u => u.UserId));

        // ---- 3. Presence ------------------------------------------------------------------
        var presence = new Dictionary<int, PresenceRow>();
        await using (var cmd = new SqlCommand(@"
            SELECT p.UserId, p.ProcessId, pr.ProcessName, p.SessionStartUtc, p.LastHeartbeatUtc,
                   DATEDIFF(SECOND, p.LastHeartbeatUtc, SYSUTCDATETIME()) AS SecondsSinceHeartbeat,
                   DATEDIFF(SECOND, p.LastInputUtc, SYSUTCDATETIME())     AS SecondsSinceInput,
                   CASE WHEN p.SignedOutUtc IS NOT NULL THEN 1 ELSE 0 END  AS SignedOut
            FROM dbo.UserPresence p
            LEFT JOIN dbo.Processes pr ON pr.ProcessId = p.ProcessId
            WHERE p.UserId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@Ids))", conn))
        {
            cmd.Parameters.Add("@Ids", SqlDbType.NVarChar, -1).Value = idsJson;
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                presence[r.GetInt32(0)] = new PresenceRow
                {
                    ProcessId = r.IsDBNull(1) ? null : r.GetInt32(1),
                    ProcessName = r.IsDBNull(2) ? null : r.GetString(2),
                    SessionStartUtc = r.GetDateTime(3),
                    LastHeartbeatUtc = r.GetDateTime(4),
                    SecondsSinceHeartbeat = r.GetInt32(5),
                    SecondsSinceInput = r.GetInt32(6),
                    SignedOut = r.GetInt32(7) == 1,
                };
            }
        }

        // ---- 4. Open breaks (latest per user, leftovers ignored) --------------------------
        // StartTime is written with the app server's DateTime.Now, so it is compared with the
        // same clock here (not SQL's GETDATE, which runs in a different time zone).
        var now = DateTime.Now;
        var breaks = new Dictionary<int, BreakRow>();
        await using (var cmd = new SqlCommand(@"
            SELECT x.UserId, x.StartTime, x.AllowedDurationMin, x.ReasonLabel
            FROM (
                SELECT b.UserId, b.StartTime, b.AllowedDurationMin, r.ReasonLabel,
                       ROW_NUMBER() OVER (PARTITION BY b.UserId ORDER BY b.StartTime DESC) AS rn
                FROM dbo.UserBreakLogs b
                LEFT JOIN dbo.ReasonMaster r ON r.ReasonId = b.ReasonId
                WHERE b.EndTime IS NULL
                  AND b.StartTime >= @Since
                  AND b.UserId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@Ids))
            ) x
            WHERE x.rn = 1", conn))
        {
            cmd.Parameters.Add("@Ids", SqlDbType.NVarChar, -1).Value = idsJson;
            cmd.Parameters.Add("@Since", SqlDbType.DateTime2).Value = now.AddHours(-StaleBreakHours);
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                breaks[r.GetInt32(0)] = new BreakRow
                {
                    StartTime = r.GetDateTime(1),
                    AllowedMinutes = r.IsDBNull(2) ? null : r.GetInt32(2),
                    Reason = r.IsDBNull(3) ? "Break" : r.GetString(3),
                };
            }
        }

        // ---- 5. Task counts (processes in scope only) -------------------------------------
        var counts = new Dictionary<int, (int Completed, int Active)>();
        await using (var cmd = new SqlCommand(@"
            SELECT t.AssignedUserId,
                   SUM(CASE WHEN t.Status = 'Completed' AND t.CompletedDate >= @Today AND t.CompletedDate < @Tomorrow THEN 1 ELSE 0 END),
                   SUM(CASE WHEN t.Status IN ('Pending', 'InProgress') THEN 1 ELSE 0 END)
            FROM dbo.Tasks t
            WHERE t.AssignedUserId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@Ids))
              AND (@Scope IS NULL OR t.ProcessId IN (SELECT CAST([value] AS INT) FROM OPENJSON(@Scope)))
              AND (t.Status IN ('Pending', 'InProgress') OR (t.Status = 'Completed' AND t.CompletedDate >= @Today))
            GROUP BY t.AssignedUserId", conn) { CommandTimeout = 60 })
        {
            cmd.Parameters.Add("@Ids", SqlDbType.NVarChar, -1).Value = idsJson;
            cmd.Parameters.Add("@Scope", SqlDbType.NVarChar, -1).Value = (object?)scopeJson ?? DBNull.Value;
            cmd.Parameters.Add("@Today", SqlDbType.DateTime2).Value = DateTime.Today;   // same clock Tasks.CompletedDate uses
            cmd.Parameters.Add("@Tomorrow", SqlDbType.DateTime2).Value = DateTime.Today.AddDays(1);
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
                counts[r.GetInt32(0)] = (r.GetInt32(1), r.GetInt32(2));
        }

        // ---- 6. Thresholds per current process (cached per request) -----------------------
        var thresholdCache = new Dictionary<int, PresenceThresholdsDto>();
        async Task<PresenceThresholdsDto> ThresholdsFor(int? pid)
        {
            if (pid is null) return result.Thresholds;
            if (!thresholdCache.TryGetValue(pid.Value, out var t))
                thresholdCache[pid.Value] = t = await _thresholds.GetAsync(pid, ct);
            return t;
        }

        // ---- 7. Status ---------------------------------------------------------------------
        foreach (var u in users)
        {
            presence.TryGetValue(u.UserId, out var p);
            breaks.TryGetValue(u.UserId, out var b);
            counts.TryGetValue(u.UserId, out var c);
            var limits = await ThresholdsFor(p?.ProcessId);

            var dto = new TeamPresenceUserDto
            {
                UserId = u.UserId,
                Username = u.Username ?? string.Empty,
                ProcessId = p?.ProcessId,
                ProcessName = p?.ProcessName,
                SessionStartUtc = p?.SessionStartUtc,
                LastSeenUtc = p?.LastHeartbeatUtc,
                CompletedToday = c.Completed,
                ActiveTasks = c.Active,
            };

            if (p == null || p.SignedOut || p.SecondsSinceHeartbeat > limits.OfflineAfterSeconds)
            {
                dto.Status = PresenceStatuses.Offline;
            }
            else if (b != null)
            {
                dto.Status = PresenceStatuses.OnBreak;
                dto.BreakReason = b.Reason;
                dto.BreakMinutes = Math.Max(0, (int)(now - b.StartTime).TotalMinutes);
                dto.BreakAllowedMinutes = b.AllowedMinutes;
                dto.BreakExceeded = b.AllowedMinutes is > 0 && dto.BreakMinutes > b.AllowedMinutes;
            }
            else if (p.SecondsSinceInput >= limits.IdleAfterMinutes * 60)
            {
                dto.Status = PresenceStatuses.Idle;
                dto.IdleMinutes = p.SecondsSinceInput / 60;
            }
            else
            {
                dto.Status = PresenceStatuses.Online;
            }

            if (p != null && dto.Status != PresenceStatuses.Offline)
            {
                var hours = (DateTime.UtcNow - p.SessionStartUtc).TotalHours;
                if (hours >= 0.25) dto.TasksPerHour = Math.Round((decimal)(c.Completed / hours), 1);
            }

            result.Users.Add(dto);
        }

        // Most useful first: on break / idle (need attention), then online, then offline.
        static int Rank(string s) => s switch
        {
            PresenceStatuses.OnBreak => 0,
            PresenceStatuses.Idle => 1,
            PresenceStatuses.Online => 2,
            _ => 3,
        };
        result.Users = result.Users
            .OrderBy(x => Rank(x.Status))
            .ThenByDescending(x => x.BreakExceeded)
            .ThenBy(x => x.Username)
            .ToList();

        result.Summary = new TeamPresenceSummaryDto
        {
            Online = result.Users.Count(x => x.Status == PresenceStatuses.Online),
            Idle = result.Users.Count(x => x.Status == PresenceStatuses.Idle),
            OnBreak = result.Users.Count(x => x.Status == PresenceStatuses.OnBreak),
            Offline = result.Users.Count(x => x.Status == PresenceStatuses.Offline),
        };

        return result;
    }

    // -------------------------------------------------------------------------------------

    private static async Task<List<int>> ReadIntsAsync(SqlConnection conn, string sql, CancellationToken ct,
        params (string Name, object Value)[] parameters)
    {
        await using var cmd = new SqlCommand(sql, conn);
        foreach (var (name, value) in parameters)
        {
            var p = value is int
                ? cmd.Parameters.Add(name, SqlDbType.Int)
                : cmd.Parameters.Add(name, SqlDbType.NVarChar, -1);
            p.Value = value;
        }
        var list = new List<int>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(r.GetInt32(0));
        return list;
    }

    private sealed class PresenceRow
    {
        public int? ProcessId { get; init; }
        public string? ProcessName { get; init; }
        public DateTime SessionStartUtc { get; init; }
        public DateTime LastHeartbeatUtc { get; init; }
        public int SecondsSinceHeartbeat { get; init; }
        public int SecondsSinceInput { get; init; }
        public bool SignedOut { get; init; }
    }

    private sealed class BreakRow
    {
        public DateTime StartTime { get; init; }
        public int? AllowedMinutes { get; init; }
        public string Reason { get; init; } = "Break";
    }
}
