using Azure.Core;
using GTXH.OMC.Application.Interfaces;
using GTXH.OMC.Core.Entities;
using GTXH.OMC.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.Diagnostics;
using Task = System.Threading.Tasks.Task;

namespace GTXH.OMC.Application.Services
{
    public class UserBreakLogService : IUserBreakLogService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IWorkPolicyService _policy;
        private readonly ILogger<UserBreakLogService> _logger;

        public UserBreakLogService(ApplicationDbContext dbContext, IWorkPolicyService policy, ILogger<UserBreakLogService> logger)
        {
            _dbContext = dbContext;
            _policy = policy;
            _logger = logger;
        }

        /// <summary>Records policy breaches for a just-ended break. Never fails the break itself.</summary>
        private async Task RecordBreachesSafeAsync(int breakLogId)
        {
            try
            {
                await _policy.RecordBreakBreachesAsync(breakLogId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Could not evaluate policy breaches for break {BreakLogId}", breakLogId);
            }
        }
        public async Task<ActiveBreakDto> StartBreakAsync(int userId, int processId, int reasonId, string? comment)
        {
            var reason = await _dbContext.ReasonMasters.FindAsync(reasonId)
                ?? throw new InvalidOperationException("Unknown reason.");

            // ProcessReasonPolicy: reason turned off for the process, or MaxOccurrencesPerDay reached.
            var check = await _policy.CheckCanStartBreakAsync(userId, processId, reasonId);
            if (!check.Allowed)
                throw new InvalidOperationException(check.Message ?? "This break is not allowed right now.");

            var processOverride = await _dbContext.ProcessReasons
                .Where(x => x.ProcessId == processId && x.ReasonId == reasonId)
                .Select(x => x.AllowedDurationMin)
                .FirstOrDefaultAsync();

            var log = new UserBreakLog
            {
                UserId = userId,
                ProcessId = processId,
                ReasonId = reasonId,
                Comment = comment,
                StartTime = DateTime.Now,
                // Policy first, then the older per-process override, then the reason default.
                AllowedDurationMin = check.Policy?.AllowedDurationMin ?? processOverride ?? reason.DefaultDurationMin
            };

            await _dbContext.UserBreakLogs.AddAsync(log);
            await _dbContext.SaveChangesAsync();

            // ✅ Optional: also log audit
            await _dbContext.AuditLogs.AddAsync(new AuditLog
            {
                UserId = userId,
                Action = "UserActivityReason Break start",
                EntityType = "Process",
                EntityId = processId.ToString(),
                Details = $"Reason: {reason.ReasonLabel}" +
                (string.IsNullOrEmpty(comment) ? "" : $" | Comment: {comment}"),
                CreatedDate = DateTime.Now
            });

            await _dbContext.SaveChangesAsync();

            return new ActiveBreakDto
            {
                Id = log.Id,
                StartTime = log.StartTime,
                AllowedDurationMin = log.AllowedDurationMin
            };
        }
        public async Task<UserBreakLogResult> EndBreakAsync(int userId, ReasonType reasonType, string? comment, int? reasonId)
        {
            // 1️⃣ Fetch the active break for this ReasonType
            var activeBreak = await _dbContext.UserBreakLogs
                .Include(b => b.Reason) // include reason info
                .Where(b => b.UserId == userId && b.EndTime == null)
                .Where(b => b.Reason.ReasonType == reasonType)
                .OrderByDescending(b => b.StartTime)
                .FirstOrDefaultAsync();

            if (activeBreak == null)
                throw new Exception($"No active break found for ReasonType {reasonType}");

            // 2️⃣ Close the break
            activeBreak.EndTime = DateTime.Now;
            activeBreak.DurationMs = (long)(activeBreak.EndTime.Value - activeBreak.StartTime).TotalMilliseconds;

            if (reasonType == ReasonType.Delay)
            {
                activeBreak.Comment = comment;
                activeBreak.ReasonId = reasonId ?? 0;
            }

            // 3️⃣ Calculate allowed duration and status
            int allowedMin = activeBreak.AllowedDurationMin ?? activeBreak.Reason.DefaultDurationMin ?? 0;
            allowedMin = Math.Max(0, allowedMin);
            var allowedMs = allowedMin * 60 * 1000;

            if (allowedMin == 0)
                activeBreak.Status = "no_limit";
            else if (activeBreak.DurationMs <= allowedMs)
                activeBreak.Status = "within_limit";
            else
                activeBreak.Status = "exceeded";

            // 4️⃣ Log audit entry for ending break
            _dbContext.AuditLogs.Add(new AuditLog
            {
                UserId = userId,
                Action = "UserActivityReason Break end",
                EntityType = "Process",
                EntityId = activeBreak.ProcessId.ToString(),
                Details = $"Reason: {activeBreak.Reason.ReasonLabel}" +
                          (string.IsNullOrEmpty(activeBreak.Comment) ? "" : $" | Comment: {activeBreak.Comment}"),
                CreatedDate = DateTime.Now
            });

            await _dbContext.SaveChangesAsync();

            // Over the allowed time / outside the allowed window -> PolicyBreaches (approval queue).
            await RecordBreachesSafeAsync(activeBreak.Id);

            // 5️⃣ Automatically create Delay break if original break exceeded allowed time
            if (activeBreak.Status == "exceeded" && reasonType != ReasonType.Delay)
            {
                var delayReason = await _dbContext.ReasonMasters
                    .Where(r => r.ReasonType == ReasonType.Delay)
                    .OrderBy(r => r.ReasonId) // pick first available delay reason as placeholder
                    .FirstOrDefaultAsync();

                if (delayReason != null)
                {
                    var delayBreak = new UserBreakLog
                    {
                        UserId = userId,
                        ProcessId = activeBreak.ProcessId,
                        ReasonId = delayReason.ReasonId,
                        Comment = comment,
                        StartTime = DateTime.Now,
                        AllowedDurationMin = delayReason.DefaultDurationMin
                    };

                    _dbContext.UserBreakLogs.Add(delayBreak);

                    _dbContext.AuditLogs.Add(new AuditLog
                    {
                        UserId = userId,
                        Action = "UserActivityReason Delay break started",
                        EntityType = "Process",
                        EntityId = activeBreak.ProcessId.ToString(),
                        Details = $"Created due to exceeded break: {activeBreak.Reason.ReasonLabel}",
                        CreatedDate = DateTime.Now
                    });

                    await _dbContext.SaveChangesAsync();
                }
            }

            return new UserBreakLogResult
            {
                Status = activeBreak.Status,
                OverTimeMs = activeBreak.DurationMs > allowedMs ? activeBreak.DurationMs - allowedMs : 0
            };
        }
        // Start an inactivity break automatically
        public async Task<ActiveBreakDto> StartInactivityBreakAsync(int userId, int processId)
        {
            // Pick a default Inactivity reason
            var reason = await _dbContext.ReasonMasters
                .Where(r => r.ReasonType == ReasonType.Inactivity)
                .OrderBy(r => r.ReasonId)
                .FirstOrDefaultAsync();

            if (reason == null)
                throw new Exception("No inactivity reason configured");

            var policy = (await _policy.GetReasonPoliciesAsync(processId))
                .FirstOrDefault(p => p.ReasonId == reason.ReasonId);

            var log = new UserBreakLog
            {
                UserId = userId,
                ProcessId = processId,
                ReasonId = reason.ReasonId,
                StartTime = DateTime.Now,
                AllowedDurationMin = policy?.AllowedDurationMin ?? reason.DefaultDurationMin,
                Comment = "Auto-started due to inactivity"
            };

            _dbContext.UserBreakLogs.Add(log);

            _dbContext.AuditLogs.Add(new AuditLog
            {
                UserId = userId,
                Action = "UserActivityReason Inactivity Break start",
                EntityType = "Process",
                EntityId = processId.ToString(),
                Details = "Auto-started due to inactivity",
                CreatedDate = DateTime.Now
            });

            await _dbContext.SaveChangesAsync();

            return new ActiveBreakDto
            {
                Id = log.Id,
                StartTime = log.StartTime,
                AllowedDurationMin = log.AllowedDurationMin
            };
        }

        // End an inactivity break intelligently
        public async Task<UserBreakLogResult> EndInactivityBreakAsync(int userId, string? comment, int? reasonId)
        {
            var activeBreak = await _dbContext.UserBreakLogs
                .Include(b => b.Reason)
                .Where(b => b.UserId == userId && b.EndTime == null && b.Reason.ReasonType == ReasonType.Inactivity)
                .OrderByDescending(b => b.StartTime)
                .FirstOrDefaultAsync();

            if (activeBreak == null)
                return new UserBreakLogResult
                {
                    Status = "none",
                    OverTimeMs = 0
                };

            activeBreak.ReasonId = reasonId ?? 0;
            activeBreak.Comment = comment;
            activeBreak.EndTime = DateTime.Now;
            activeBreak.DurationMs = (long)(activeBreak.EndTime.Value - activeBreak.StartTime).TotalMilliseconds;

            int allowedMin = activeBreak.AllowedDurationMin ?? activeBreak.Reason.DefaultDurationMin ?? 0;
            var allowedMs = allowedMin * 60 * 1000;

            activeBreak.Status = allowedMin == 0 ? "no_limit" :
                                 activeBreak.DurationMs <= allowedMs ? "within_limit" : "exceeded";

            _dbContext.AuditLogs.Add(new AuditLog
            {
                UserId = userId,
                Action = "UserActivityReason Inactivity Break end",
                EntityType = "Process",
                EntityId = activeBreak.ProcessId.ToString(),
                Details = $"Ended inactivity break | Duration: {activeBreak.DurationMs} ms",
                CreatedDate = DateTime.Now
            });

            await _dbContext.SaveChangesAsync();

            await RecordBreachesSafeAsync(activeBreak.Id);

            // Optionally: create a Delay break if exceeded
            if (activeBreak.Status == "exceeded")
            {
                var delayReason = await _dbContext.ReasonMasters
                    .Where(r => r.ReasonType == ReasonType.Delay)
                    .OrderBy(r => r.ReasonId)
                    .FirstOrDefaultAsync();

                if (delayReason != null)
                {
                    _dbContext.UserBreakLogs.Add(new UserBreakLog
                    {
                        UserId = userId,
                        ProcessId = activeBreak.ProcessId,
                        ReasonId = delayReason.ReasonId,
                        StartTime = DateTime.Now,
                        AllowedDurationMin = delayReason.DefaultDurationMin,
                        Comment = $"Exceeded inactivity break: {activeBreak.Reason.ReasonLabel}"
                    });

                    await _dbContext.SaveChangesAsync();
                }
            }

            return new UserBreakLogResult
            {
                Status = activeBreak.Status,
                OverTimeMs = activeBreak.DurationMs > allowedMs ? activeBreak.DurationMs - allowedMs : 0
            };
        }
        public async Task<ActiveBreakDto?> GetActiveBreakAsync(int userId, ReasonType? reasonType = null)
        {
            var query = _dbContext.UserBreakLogs
                .Include(b => b.Reason) // optional, to access ReasonType
                .Where(x => x.UserId == userId && x.EndTime == null)
                .AsQueryable();

            if (reasonType.HasValue)
            {
                query = query.Where(x => x.Reason.ReasonType == reasonType.Value);
            }

            var log = await query
                .OrderByDescending(x => x.StartTime)
                .FirstOrDefaultAsync();

            if (log == null) return null;

            return new ActiveBreakDto
            {
                Id = log.Id,
                StartTime = log.StartTime,
                AllowedDurationMin = log.AllowedDurationMin
            };
        }
    }
}
