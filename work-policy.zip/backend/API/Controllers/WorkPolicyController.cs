using System.Security.Claims;
using GTXH.OMC.Application.DTOs;
using GTXH.OMC.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GTXH.OMC.API.Controllers;

/// <summary>
/// Process work policy, settings and breach approvals.
///
///   Agent app (any signed-in user)
///     GET  api/work-policy/{processId}/settings          shift + inactivity popup minutes
///     GET  api/work-policy/{processId}/reasons/mine      reasons with CanStart / UsedToday
///     GET  api/work-policy/breaches/mine?days=7
///     POST api/work-policy/breaches/{id}/comment         { comment }
///
///   Admin app (manager/supervisor of the process, or superadmin)
///     PUT  api/work-policy/{processId}/settings
///     GET  api/work-policy/{processId}/reasons
///     PUT  api/work-policy/{processId}/reasons           { policies: [...] }
///     POST api/work-policy/breaches/search               BreachQuery
///     POST api/work-policy/breaches/decide               { breachIds, approve, comment }
/// </summary>
[ApiController]
[Route("api/work-policy")]
[Authorize(AuthenticationSchemes = "Bearer")]
public class WorkPolicyController : ControllerBase
{
    // RoleId 2 = Manager, 6 = Supervisor (same as DashboardController). They see their own processes.
    private static readonly int[] ProcessScopedRoleIds = { 2, 6 };

    private readonly IWorkPolicyService _policy;
    private readonly IConfiguration _config;
    private readonly ILogger<WorkPolicyController> _logger;

    public WorkPolicyController(IWorkPolicyService policy, IConfiguration config, ILogger<WorkPolicyController> logger)
    {
        _policy = policy;
        _config = config;
        _logger = logger;
    }

    // ---- Agent app ---------------------------------------------------------------------------

    [HttpGet("{processId:int}/settings")]
    public Task<IActionResult> GetSettings(int processId, CancellationToken ct) =>
        Run(async _ => Ok(await _policy.GetSettingsAsync(processId, ct)));

    [HttpGet("{processId:int}/reasons/mine")]
    public Task<IActionResult> MyReasons(int processId, CancellationToken ct) =>
        Run(async userId => Ok(await _policy.GetReasonPoliciesAsync(processId, userId, ct)));

    [HttpGet("breaches/mine")]
    public Task<IActionResult> MyBreaches([FromQuery] int days, CancellationToken ct) =>
        Run(async userId => Ok(await _policy.GetMyBreachesAsync(userId, days <= 0 ? 7 : days, ct)));

    [HttpPost("breaches/{breachId:long}/comment")]
    public Task<IActionResult> Comment(long breachId, [FromBody] AgentBreachCommentRequest request, CancellationToken ct) =>
        Run(async userId =>
            await _policy.AddAgentCommentAsync(breachId, userId, request.Comment, ct)
                ? NoContent()
                : NotFound(Error("BREACH_NOT_FOUND", "Breach not found or already decided")));

    // ---- Admin app ---------------------------------------------------------------------------

    [HttpPut("{processId:int}/settings")]
    public Task<IActionResult> SaveSettings(int processId, [FromBody] ProcessWorkSettingsDto settings, CancellationToken ct) =>
        RunAsManager(processId, async userId =>
        {
            settings.ProcessId = processId;
            return Ok(await _policy.SaveSettingsAsync(settings, userId, ct));
        }, ct);

    [HttpGet("{processId:int}/reasons")]
    public Task<IActionResult> GetReasons(int processId, CancellationToken ct) =>
        RunAsManager(processId, async _ => Ok(await _policy.GetReasonPoliciesAsync(processId, null, ct)), ct);

    [HttpPut("{processId:int}/reasons")]
    public Task<IActionResult> SaveReasons(int processId, [FromBody] SaveReasonPoliciesRequest request, CancellationToken ct) =>
        RunAsManager(processId, async userId =>
            Ok(await _policy.SaveReasonPoliciesAsync(processId, request.Policies ?? new(), userId, ct)), ct);

    [HttpPost("breaches/search")]
    public Task<IActionResult> Search([FromBody] BreachQuery query, CancellationToken ct) =>
        RunAsApprover(async (userId, restricted) => Ok(await _policy.GetBreachesAsync(userId, restricted, query ?? new BreachQuery(), ct)));

    [HttpPost("breaches/decide")]
    public Task<IActionResult> Decide([FromBody] DecideBreachesRequest request, CancellationToken ct) =>
        RunAsApprover(async (userId, restricted) =>
        {
            var changed = await _policy.DecideAsync(userId, restricted, request, ct);
            return Ok(new { updated = changed });
        });

    // ---- Plumbing ----------------------------------------------------------------------------

    /// <summary>Roles that see every process (superadmin). Configure in appsettings: "WorkPolicy": { "AllProcessRoleIds": [1] }.</summary>
    private int[] AllProcessRoleIds =>
        _config.GetSection("WorkPolicy:AllProcessRoleIds").Get<int[]>() ?? new[] { 1 };

    private int? RoleId()
    {
        var claim = User.FindFirst(ClaimTypes.Role)?.Value ?? User.FindFirst("roleId")?.Value;
        return int.TryParse(claim, out var id) ? id : null;
    }

    private Task<IActionResult> RunAsApprover(Func<int, bool, Task<IActionResult>> action) =>
        Run(async userId =>
        {
            var role = RoleId();
            if (role.HasValue && AllProcessRoleIds.Contains(role.Value)) return await action(userId, false);
            if (role.HasValue && ProcessScopedRoleIds.Contains(role.Value)) return await action(userId, true);
            return StatusCode(403, Error("FORBIDDEN", "Only supervisors, managers and superadmins can do this"));
        });

    private Task<IActionResult> RunAsManager(int processId, Func<int, Task<IActionResult>> action, CancellationToken ct) =>
        RunAsApprover(async (userId, restricted) =>
        {
            if (restricted && !await _policy.CanManageProcessAsync(userId, processId, ct))
                return StatusCode(403, Error("FORBIDDEN", "You don't have access to this process"));
            return await action(userId);
        });

    private async Task<IActionResult> Run(Func<int, Task<IActionResult>> action)
    {
        if (!int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var userId))
            return Unauthorized();

        try
        {
            return await action(userId);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(Error("VALIDATION_ERROR", ex.Message));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Work policy request failed");
            return StatusCode(500, Error("SERVER_ERROR", "An error occurred while processing the work policy request"));
        }
    }

    private static object Error(string code, string message) => new { error = new { code, message } };
}
