/*
  Work policy: per-process settings, daily attendance, and breaches awaiting approval.

  Times of day (shift start/end, reason windows) are in the process's time zone - US Central by
  default - and are evaluated on the server from UTC, so the agent PC's clock never matters.
*/

-- 1. Per-process settings -----------------------------------------------------------------
IF OBJECT_ID('dbo.ProcessWorkSettings', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ProcessWorkSettings
    (
        ProcessId               INT          NOT NULL CONSTRAINT PK_ProcessWorkSettings PRIMARY KEY,
        TimeZoneId              VARCHAR(64)  NOT NULL CONSTRAINT DF_PWS_Tz DEFAULT ('Central Standard Time'),

        ShiftStartTime          TIME(0)      NULL,      -- e.g. 08:00 - login after start + grace = LateLogin
        ShiftEndTime            TIME(0)      NULL,      -- e.g. 17:00 - sign-out before end - grace = EarlyLogout
        LoginGraceMin           INT          NOT NULL CONSTRAINT DF_PWS_LoginGrace  DEFAULT (0),
        LogoutGraceMin          INT          NOT NULL CONSTRAINT DF_PWS_LogoutGrace DEFAULT (0),
        ShiftRequiresApproval   BIT          NOT NULL CONSTRAINT DF_PWS_ShiftReq    DEFAULT (1),
        ShiftAutoApprove        BIT          NOT NULL CONSTRAINT DF_PWS_ShiftAuto   DEFAULT (0),

        IdleAfterMinutes        INT          NOT NULL CONSTRAINT DF_PWS_Idle        DEFAULT (5),
        OfflineAfterSeconds     INT          NOT NULL CONSTRAINT DF_PWS_Offline     DEFAULT (180),
        InactivityPromptMinutes INT          NOT NULL CONSTRAINT DF_PWS_Prompt      DEFAULT (120),  -- agent app popup

        ModifiedByUserId        INT          NULL,
        ModifiedDate            DATETIME2    NOT NULL CONSTRAINT DF_PWS_Modified    DEFAULT (GETDATE()),

        CONSTRAINT FK_ProcessWorkSettings_Processes FOREIGN KEY (ProcessId) REFERENCES dbo.Processes (ProcessId) ON DELETE CASCADE,
        CONSTRAINT CK_PWS_Positive CHECK (IdleAfterMinutes > 0 AND OfflineAfterSeconds >= 60 AND InactivityPromptMinutes > 0
                                          AND LoginGraceMin >= 0 AND LogoutGraceMin >= 0)
    );
END
GO

-- 2. First login / last sign-out per user, process and work day ------------------------------
IF OBJECT_ID('dbo.UserDailyAttendance', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.UserDailyAttendance
    (
        Id            BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_UserDailyAttendance PRIMARY KEY,
        UserId        INT        NOT NULL,
        ProcessId     INT        NOT NULL,
        WorkDate      DATE       NOT NULL,      -- in the process time zone
        FirstLoginAt  DATETIME2  NOT NULL,      -- process time zone
        LastLogoutAt  DATETIME2  NULL           -- process time zone
    );
    CREATE UNIQUE INDEX UX_UserDailyAttendance ON dbo.UserDailyAttendance (UserId, ProcessId, WorkDate);
END
GO

-- 3. Breaches -----------------------------------------------------------------------------------
IF OBJECT_ID('dbo.PolicyBreaches', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PolicyBreaches
    (
        BreachId         BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PolicyBreaches PRIMARY KEY,
        UserId           INT            NOT NULL,
        ProcessId        INT            NOT NULL,
        ReasonId         INT            NULL,
        BreakLogId       INT            NULL,
        WorkDate         DATE           NOT NULL,
        BreachType       VARCHAR(30)    NOT NULL,
        Details          NVARCHAR(500)  NULL,
        ExceededMinutes  INT            NULL,
        Status           VARCHAR(20)    NOT NULL,   -- Recorded | Pending | AutoApproved | Approved | Rejected
        AgentComment     NVARCHAR(1000) NULL,
        DecidedByUserId  INT            NULL,
        DecidedAt        DATETIME2      NULL,
        DecisionComment  NVARCHAR(1000) NULL,
        CreatedAt        DATETIME2      NOT NULL CONSTRAINT DF_PolicyBreaches_Created DEFAULT (SYSUTCDATETIME()),

        CONSTRAINT CK_PolicyBreaches_Type CHECK (BreachType IN
            ('DurationExceeded', 'InactivityExceeded', 'OutsideWindow', 'LateLogin', 'EarlyLogout')),
        CONSTRAINT CK_PolicyBreaches_Status CHECK (Status IN
            ('Recorded', 'Pending', 'AutoApproved', 'Approved', 'Rejected'))
    );

    -- One breach of each type per break, and one late login / early logout per user, process and day.
    CREATE UNIQUE INDEX UX_PolicyBreaches_Break ON dbo.PolicyBreaches (BreakLogId, BreachType) WHERE BreakLogId IS NOT NULL;
    CREATE UNIQUE INDEX UX_PolicyBreaches_Shift ON dbo.PolicyBreaches (UserId, ProcessId, WorkDate, BreachType) WHERE BreakLogId IS NULL;
    CREATE INDEX IX_PolicyBreaches_Queue ON dbo.PolicyBreaches (Status, ProcessId, WorkDate) INCLUDE (UserId);
END
GO

-- 4. One policy row per process + reason (needed by the admin "save" upsert) ------------------
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_ProcessReasonPolicy_ProcessReason'
               AND object_id = OBJECT_ID('dbo.ProcessReasonPolicy'))
   AND NOT EXISTS (SELECT ProcessId, ReasonId FROM dbo.ProcessReasonPolicy GROUP BY ProcessId, ReasonId HAVING COUNT(*) > 1)
BEGIN
    CREATE UNIQUE INDEX UX_ProcessReasonPolicy_ProcessReason ON dbo.ProcessReasonPolicy (ProcessId, ReasonId);
END
GO

-- 5. UserBreakLogs lookups used on every break start/end and by the dashboard --------------------
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_UserBreakLogs_User_Start' AND object_id = OBJECT_ID('dbo.UserBreakLogs'))
    CREATE INDEX IX_UserBreakLogs_User_Start ON dbo.UserBreakLogs (UserId, ProcessId, StartTime) INCLUDE (ReasonId, EndTime);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_UserBreakLogs_Open' AND object_id = OBJECT_ID('dbo.UserBreakLogs'))
    CREATE INDEX IX_UserBreakLogs_Open ON dbo.UserBreakLogs (UserId, StartTime) INCLUDE (ReasonId, AllowedDurationMin) WHERE EndTime IS NULL;
GO

-- 6. Optional: keep ProcessReasonPolicy consistent with its parents --------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_ProcessReasonPolicy_Processes')
    ALTER TABLE dbo.ProcessReasonPolicy WITH CHECK
        ADD CONSTRAINT FK_ProcessReasonPolicy_Processes FOREIGN KEY (ProcessId) REFERENCES dbo.Processes (ProcessId);

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_ProcessReasonPolicy_ReasonMaster')
    ALTER TABLE dbo.ProcessReasonPolicy WITH CHECK
        ADD CONSTRAINT FK_ProcessReasonPolicy_ReasonMaster FOREIGN KEY (ReasonId) REFERENCES dbo.ReasonMaster (ReasonId);
GO
