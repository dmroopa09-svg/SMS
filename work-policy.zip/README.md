# Work policy: ProcessReasonPolicy, shift times and approvals

This builds on **user-activity.zip** (UserPresence). Install that first, then this one.

## How it behaves

| Setting | Effect |
|---|---|
| Reason **On** unticked | Agent can't start that reason for this process (blocked) |
| **Max / day** | Second lunch etc. blocked once the limit is reached (blocked) |
| **Allowed (min)** | Going over it creates a breach |
| **Max (min)** | Shown in the breach details as "over the maximum" (doesn't block) |
| **Allowed from / to** | Starting the reason outside the window creates a breach |
| **Shift start + login grace** | First login of the day after it creates a **Late login** breach |
| **Shift end - logout grace** | Signing out before it creates an **Early logout** breach |
| **Needs approval** | Breach goes to **Approvals** as Pending. The agent keeps working |
| **Auto-approve** | Breach is recorded and approved straight away |
| Neither ticked | Breach is recorded only (shows under "Recorded") |
| **Idle after / Offline after** | Used by the dashboard's User Activity |
| **Inactivity popup** | Replaces the 2-hour value hard-coded in App.tsx |

Shift times and windows are in the process time zone (US Central by default) and are worked out on the server.

**Who can approve:** managers and supervisors (roles 2 and 6) for processes in their `UserProcessPermissions`, plus the roles listed in `WorkPolicy:AllProcessRoleIds`. Nobody can approve their own breach. Rejecting needs a comment.

## 1. SQL
Run `sql/01_WorkPolicy.sql`. It creates `ProcessWorkSettings`, `UserDailyAttendance` and `PolicyBreaches`, and adds a unique index on `ProcessReasonPolicy (ProcessId, ReasonId)` if there are no duplicate rows.

## 2. Backend

| File | Goes to |
|---|---|
| `Application/DTOs/WorkPolicyDtos.cs` | Application/DTOs |
| `Application/Interfaces/IWorkPolicyService.cs` | Application/Interfaces |
| `Application/Services/WorkPolicyService.cs` | Application/Services (new) |
| `Application/Services/UserBreakLogService.cs` | **Replaces yours.** Same code, plus the policy check on start and breach recording on end |
| `Application/Services/UserPresenceService.cs` | **Replaces the one from user-activity.zip.** Adds login and logout attendance |
| `API/Controllers/WorkPolicyController.cs` | API/Controllers (new) |

**Program.cs.** Change the threshold provider line from user-activity.zip and add the policy service:
```csharp
builder.Services.AddScoped<IWorkPolicyService, WorkPolicyService>();
builder.Services.AddScoped<IPresenceThresholdProvider, WorkSettingsPresenceThresholdProvider>(); // was DefaultPresenceThresholdProvider
builder.Services.AddScoped<IUserPresenceService, UserPresenceService>();
```

**appsettings.json.** Set your superadmin RoleId(s). **1 is a guess; check your Roles table:**
```json
"WorkPolicy": { "AllProcessRoleIds": [1] }
```

**UserBreakLogsController.cs.** In `StartBreak`, add this catch **above** the existing `catch (Exception ex)`, so a blocked break returns a readable 400 instead of a 500:
```csharp
catch (InvalidOperationException ex)
{
    return BadRequest(new { error = new { code = "BREAK_NOT_ALLOWED", message = ex.Message } });
}
```

## 3. Admin app
- `src/api/workPolicy.ts` is new.
- `src/pages/WorkPolicySettings.tsx` is the per-process configuration page.
- `src/pages/BreachApprovals.tsx` is the approval queue.

Add both pages to your routes and sidebar, the same way the Clarification page is wired.

## 4. Agent app
`src/services/workPolicyService.ts` is new.

**App.tsx.** Replace the hard-coded inactivity popup time with the process setting:
```tsx
import { workPolicyService } from "./services/workPolicyService";

// replace:  const MODAL_AFTER = 120 * 60 * 1000;
const [MODAL_AFTER, setModalAfter] = useState(120 * 60 * 1000);
useEffect(() => {
  if (!isAuthenticated || !selectedProcess) return;
  workPolicyService
    .getSettings(selectedProcess.id)
    .then((s) => setModalAfter(s.inactivityPromptMinutes * 60 * 1000))
    .catch(() => {});
}, [isAuthenticated, selectedProcess?.id]);
```

**breakService.ts `startBreak`.** It saves the break to localStorage *before* calling the API, so a blocked break would leave a phantom running break. Wrap the API call:
```ts
let response: BreakResponseDto;
try {
  response = await apiClient.post<BreakResponseDto>(API_ENDPOINTS.userBreakLogs.start, data);
} catch (err) {
  localStorage.removeItem(this.storageKey(data.reasonType));
  Cookies.remove("breakReason");
  Cookies.remove("allowedDurationMin");
  throw err; // message: "You've already taken "Lunch Break" 1 time(s) today. The limit is 1."
}
```

**Reason picker (LogoutReasonModal).** Call `workPolicyService.getMyReasons(processId)` and grey out reasons where `canStart === false`, so agents see the limit before clicking. Send me that component if you want me to wire it.
