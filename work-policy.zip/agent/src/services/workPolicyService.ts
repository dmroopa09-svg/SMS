import { apiClient } from "./api";

/** Agent app endpoints include /api. */
const BASE = "/api/work-policy";

export interface AgentWorkSettings {
  processId: number;
  shiftStartTime: string | null;
  shiftEndTime: string | null;
  idleAfterMinutes: number;
  inactivityPromptMinutes: number;
}

export interface AgentReasonPolicy {
  reasonId: number;
  reasonCode: string;
  reasonLabel: string;
  reasonType: number;
  isEnabled: boolean;
  allowedDurationMin: number | null;
  maxOccurrencesPerDay: number | null;
  usedToday: number | null;
  /** false = turned off for this process, or today's limit reached. Grey it out in the reason picker. */
  canStart: boolean | null;
}

export interface AgentBreach {
  breachId: number;
  breachType: string;
  reasonLabel: string | null;
  details: string | null;
  exceededMinutes: number | null;
  status: "Recorded" | "Pending" | "AutoApproved" | "Approved" | "Rejected";
  agentComment: string | null;
  decisionComment: string | null;
  workDate: string;
}

export const workPolicyService = {
  getSettings: (processId: number) => apiClient.get<AgentWorkSettings>(`${BASE}/${processId}/settings`),

  getMyReasons: (processId: number) => apiClient.get<AgentReasonPolicy[]>(`${BASE}/${processId}/reasons/mine`),

  getMyBreaches: (days = 7) => apiClient.get<AgentBreach[]>(`${BASE}/breaches/mine?days=${days}`),

  addComment: (breachId: number, comment: string) =>
    apiClient.post<void>(`${BASE}/breaches/${breachId}/comment`, { comment }),
};
