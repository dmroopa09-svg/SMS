import { apiClient } from "./client";

// get/post/put are protected on BaseApiService; call them directly (TypeScript-only restriction).
const client = apiClient as unknown as {
  get<T>(url: string): Promise<T>;
  post<T>(url: string, body?: unknown): Promise<T>;
  put<T>(url: string, body?: unknown): Promise<T>;
};

/** apiClient's base URL already ends in /api. */
const BASE = "/work-policy";

export interface ProcessWorkSettings {
  processId: number;
  timeZoneId: string;
  shiftStartTime: string | null; // "HH:mm"
  shiftEndTime: string | null;
  loginGraceMin: number;
  logoutGraceMin: number;
  shiftRequiresApproval: boolean;
  shiftAutoApprove: boolean;
  idleAfterMinutes: number;
  offlineAfterSeconds: number;
  inactivityPromptMinutes: number;
  isSaved: boolean;
}

export interface ReasonPolicy {
  reasonId: number;
  reasonCode: string;
  reasonLabel: string;
  /** 1 = Break / sign-off, 2 = Inactivity, 3 = Delay */
  reasonType: number;
  hasPolicy: boolean;
  isEnabled: boolean;
  allowedDurationMin: number | null;
  maxDurationMin: number | null;
  allowedStartTime: string | null;
  allowedEndTime: string | null;
  maxOccurrencesPerDay: number | null;
  requiresApproval: boolean;
  autoApprove: boolean;
  isPaidBreak: boolean;
  displayOrder: number;
}

export type BreachStatus = "Recorded" | "Pending" | "AutoApproved" | "Approved" | "Rejected";
export type BreachType =
  | "DurationExceeded"
  | "InactivityExceeded"
  | "OutsideWindow"
  | "LateLogin"
  | "EarlyLogout";

export interface PolicyBreach {
  breachId: number;
  userId: number;
  username: string;
  processId: number;
  processName: string | null;
  reasonId: number | null;
  reasonLabel: string | null;
  breakLogId: number | null;
  workDate: string;
  breachType: BreachType;
  details: string | null;
  exceededMinutes: number | null;
  status: BreachStatus;
  agentComment: string | null;
  decidedByUserId: number | null;
  decidedByName: string | null;
  decidedAt: string | null;
  decisionComment: string | null;
  createdAt: string;
}

export interface BreachQuery {
  status?: BreachStatus | "All";
  processId?: number | null;
  userId?: number | null;
  fromDate?: string | null;
  toDate?: string | null;
  page?: number;
  pageSize?: number;
}

export interface PagedBreaches {
  items: PolicyBreach[];
  totalCount: number;
  pendingCount: number;
  page: number;
  pageSize: number;
}

export const BREACH_TYPE_LABELS: Record<BreachType, string> = {
  DurationExceeded: "Break over limit",
  InactivityExceeded: "Inactivity over limit",
  OutsideWindow: "Outside allowed time",
  LateLogin: "Late login",
  EarlyLogout: "Early logout",
};

export const REASON_TYPE_LABELS: Record<number, string> = {
  1: "Breaks & sign-off",
  2: "Inactivity",
  3: "Delay",
};

export const workPolicyApi = {
  getSettings: (processId: number) => client.get<ProcessWorkSettings>(`${BASE}/${processId}/settings`),
  saveSettings: (processId: number, s: ProcessWorkSettings) =>
    client.put<ProcessWorkSettings>(`${BASE}/${processId}/settings`, s),

  getReasons: (processId: number) => client.get<ReasonPolicy[]>(`${BASE}/${processId}/reasons`),
  saveReasons: (processId: number, policies: ReasonPolicy[]) =>
    client.put<ReasonPolicy[]>(`${BASE}/${processId}/reasons`, { policies }),

  searchBreaches: (q: BreachQuery) => client.post<PagedBreaches>(`${BASE}/breaches/search`, q),
  decide: (breachIds: number[], approve: boolean, comment?: string) =>
    client.post<{ updated: number }>(`${BASE}/breaches/decide`, { breachIds, approve, comment }),
};
