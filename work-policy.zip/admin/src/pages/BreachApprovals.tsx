import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, XCircle, Loader2, RefreshCw, ClipboardCheck } from "lucide-react";
import { apiClient } from "../api/client";
import type { ProcessDto } from "../types";
import { cn } from "../types";
import { useToast } from "../components/Toast";
import {
  workPolicyApi,
  BREACH_TYPE_LABELS,
  type BreachStatus,
  type PagedBreaches,
} from "../api/workPolicy";

const STATUS_STYLE: Record<BreachStatus, string> = {
  Pending: "bg-amber-50 text-amber-700 border-amber-200",
  Approved: "bg-emerald-50 text-emerald-700 border-emerald-200",
  AutoApproved: "bg-emerald-50 text-emerald-600 border-emerald-100",
  Rejected: "bg-red-50 text-red-700 border-red-200",
  Recorded: "bg-zinc-50 text-zinc-600 border-zinc-200",
};

const STATUS_LABEL: Record<BreachStatus, string> = {
  Pending: "Pending",
  Approved: "Approved",
  AutoApproved: "Auto-approved",
  Rejected: "Rejected",
  Recorded: "Recorded",
};

const PAGE_SIZE = 50;

/** Supervisor/manager queue of policy breaches (late login, break over limit, etc.). */
export default function BreachApprovals() {
  const { showToast } = useToast();
  const [processes, setProcesses] = useState<ProcessDto[]>([]);
  const [status, setStatus] = useState<BreachStatus | "All">("Pending");
  const [processId, setProcessId] = useState<number | null>(null);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [page, setPage] = useState(1);
  const [data, setData] = useState<PagedBreaches | null>(null);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [comment, setComment] = useState("");
  const [deciding, setDeciding] = useState(false);

  useEffect(() => {
    apiClient.getProcesses().then(setProcesses).catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await workPolicyApi.searchBreaches({
        status,
        processId,
        fromDate: fromDate || null,
        toDate: toDate || null,
        page,
        pageSize: PAGE_SIZE,
      });
      setData(res);
      setSelected(new Set());
    } catch (err: any) {
      showToast(err?.message || "Failed to load approvals", "error");
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, processId, fromDate, toDate, page]);

  useEffect(() => {
    load();
  }, [load]);

  const pendingIds = (data?.items ?? []).filter((b) => b.status === "Pending").map((b) => b.breachId);
  const allPendingSelected = pendingIds.length > 0 && pendingIds.every((id) => selected.has(id));

  const toggle = (id: number) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const decide = async (approve: boolean, ids: number[] = Array.from(selected)) => {
    if (ids.length === 0) return;
    if (!approve && !comment.trim()) {
      showToast("Add a comment to reject", "error");
      return;
    }
    setDeciding(true);
    try {
      const res = await workPolicyApi.decide(ids, approve, comment.trim() || undefined);
      showToast(`${res.updated} breach(es) ${approve ? "approved" : "rejected"}`, "success");
      setComment("");
      await load();
    } catch (err: any) {
      showToast(err?.message || "Failed to save the decision", "error");
    } finally {
      setDeciding(false);
    }
  };

  const totalPages = Math.max(1, Math.ceil((data?.totalCount ?? 0) / PAGE_SIZE));

  return (
    <div className="h-full overflow-auto bg-white p-6">
      <div className="max-w-7xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
              <ClipboardCheck className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-zinc-900">Approvals</h1>
              <p className="text-sm text-zinc-500">
                {data ? `${data.pendingCount} pending` : "Breaks over limit, late logins and early logouts"}
              </p>
            </div>
          </div>
          <button
            onClick={load}
            className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-zinc-600 border border-zinc-200 rounded-lg hover:bg-zinc-50"
          >
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            Refresh
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <select value={status} onChange={(e) => { setStatus(e.target.value as BreachStatus | "All"); setPage(1); }} className="px-3 py-2 border border-zinc-200 rounded-lg bg-white">
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
            <option value="AutoApproved">Auto-approved</option>
            <option value="Recorded">Recorded (no approval needed)</option>
            <option value="All">All</option>
          </select>
          <select value={processId ?? ""} onChange={(e) => { setProcessId(e.target.value ? Number(e.target.value) : null); setPage(1); }} className="px-3 py-2 border border-zinc-200 rounded-lg bg-white">
            <option value="">All my processes</option>
            {processes.map((p) => (
              <option key={p.processId} value={p.processId}>{p.processName}</option>
            ))}
          </select>
          <label className="flex items-center gap-2 text-zinc-500">
            From <input type="date" value={fromDate} onChange={(e) => { setFromDate(e.target.value); setPage(1); }} className="px-2 py-1.5 border border-zinc-200 rounded-lg" />
          </label>
          <label className="flex items-center gap-2 text-zinc-500">
            To <input type="date" value={toDate} onChange={(e) => { setToDate(e.target.value); setPage(1); }} className="px-2 py-1.5 border border-zinc-200 rounded-lg" />
          </label>
        </div>

        {/* Bulk bar */}
        {selected.size > 0 && (
          <div className="flex flex-wrap items-center gap-3 px-4 py-3 rounded-xl bg-blue-50 border border-blue-100">
            <span className="text-sm font-semibold text-blue-700">{selected.size} selected</span>
            <input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Comment (required to reject)"
              className="flex-1 min-w-[220px] px-3 py-1.5 text-sm border border-blue-200 rounded-lg bg-white outline-none"
            />
            <button disabled={deciding} onClick={() => decide(true)} className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 disabled:opacity-50">
              <CheckCircle2 className="w-4 h-4" /> Approve
            </button>
            <button disabled={deciding} onClick={() => decide(false)} className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-50">
              <XCircle className="w-4 h-4" /> Reject
            </button>
          </div>
        )}

        {/* Table */}
        <div className="border border-zinc-100 rounded-2xl shadow-sm overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-zinc-100 text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                <th className="px-4 py-3 w-10">
                  <input
                    type="checkbox"
                    disabled={pendingIds.length === 0}
                    checked={allPendingSelected}
                    onChange={() => setSelected(allPendingSelected ? new Set() : new Set(pendingIds))}
                  />
                </th>
                <th className="px-3 py-3">User</th>
                <th className="px-3 py-3">Process</th>
                <th className="px-3 py-3">Date</th>
                <th className="px-3 py-3">Breach</th>
                <th className="px-3 py-3">Details</th>
                <th className="px-3 py-3 text-right">Over by</th>
                <th className="px-3 py-3">Agent comment</th>
                <th className="px-3 py-3">Status</th>
                <th className="px-3 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {loading && !data ? (
                <tr><td colSpan={10} className="py-16 text-center"><Loader2 className="w-6 h-6 mx-auto text-blue-600 animate-spin" /></td></tr>
              ) : (data?.items.length ?? 0) === 0 ? (
                <tr><td colSpan={10} className="py-16 text-center text-zinc-400">Nothing here.</td></tr>
              ) : (
                data!.items.map((b) => (
                  <tr key={b.breachId} className={cn("hover:bg-zinc-50/60", selected.has(b.breachId) && "bg-blue-50/40")}>
                    <td className="px-4 py-3">
                      <input type="checkbox" disabled={b.status !== "Pending"} checked={selected.has(b.breachId)} onChange={() => toggle(b.breachId)} />
                    </td>
                    <td className="px-3 py-3 font-semibold text-zinc-900">{b.username}</td>
                    <td className="px-3 py-3 text-zinc-600">{b.processName ?? b.processId}</td>
                    <td className="px-3 py-3 text-zinc-500 whitespace-nowrap">
                      {new Date(b.workDate).toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" })}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <span className="font-medium text-zinc-800">{BREACH_TYPE_LABELS[b.breachType] ?? b.breachType}</span>
                      {b.reasonLabel && <span className="text-zinc-400"> · {b.reasonLabel}</span>}
                    </td>
                    <td className="px-3 py-3 text-zinc-600 max-w-xs">{b.details}</td>
                    <td className="px-3 py-3 text-right font-bold text-red-600">{b.exceededMinutes != null ? `${b.exceededMinutes}m` : "-"}</td>
                    <td className="px-3 py-3 text-zinc-600 max-w-xs">{b.agentComment ?? <span className="text-zinc-300">-</span>}</td>
                    <td className="px-3 py-3">
                      <span className={cn("px-2 py-0.5 text-[11px] font-semibold rounded-full border whitespace-nowrap", STATUS_STYLE[b.status])}>
                        {STATUS_LABEL[b.status]}
                      </span>
                      {b.decidedByName && (
                        <div className="text-[11px] text-zinc-400 mt-1" title={b.decisionComment ?? ""}>
                          by {b.decidedByName}
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      {b.status === "Pending" && (
                        <div className="flex items-center gap-1">
                          <button disabled={deciding} onClick={() => decide(true, [b.breachId])} className="p-1.5 rounded-md text-emerald-600 hover:bg-emerald-50" title="Approve">
                            <CheckCircle2 className="w-4 h-4" />
                          </button>
                          <button disabled={deciding} onClick={() => { setSelected(new Set([b.breachId])); if (!comment.trim()) showToast("Add a comment in the bar above, then Reject", "info"); else decide(false, [b.breachId]); }} className="p-1.5 rounded-md text-red-600 hover:bg-red-50" title="Reject">
                            <XCircle className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paging */}
        {data && data.totalCount > PAGE_SIZE && (
          <div className="flex items-center justify-end gap-3 text-sm">
            <span className="text-zinc-500">Page {page} of {totalPages}</span>
            <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="px-3 py-1.5 border border-zinc-200 rounded-lg disabled:opacity-40">Prev</button>
            <button disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} className="px-3 py-1.5 border border-zinc-200 rounded-lg disabled:opacity-40">Next</button>
          </div>
        )}
      </div>
    </div>
  );
}
