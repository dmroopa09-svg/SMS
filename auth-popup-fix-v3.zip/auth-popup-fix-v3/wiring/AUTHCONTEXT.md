# Wiring ensureSession() into app startup

`ensureSession()` is only useful if it runs BEFORE anything decides to render
LoginScreen. Today that decision is made by `isAuthenticated()`, which answers
locally and has been answering wrongly.

I have not seen AuthContext.tsx or LoginScreen.tsx, so this describes the shape
rather than a patch. Send those two files and I will wire them precisely.

## The boot sequence you want

    app starts
      |
      +-- token in localStorage?
      |     no  -> needs login  -> loginAgent()   [Negotiate, may prompt]
      |     yes -> GET /api/auth/me
      |              200 -> SESSION ACTIVE, never touch login-agent
      |              401 -> needs login -> loginAgent()

The important property: login-agent is reached ONLY when the server has
confirmed there is no usable session. Never on a locally-computed guess.

## In AuthContext

Replace the startup check that currently does something like
`setIsAuthenticated(authService.isAuthenticated())` with:

```tsx
  useEffect(() => {
    let cancelled = false;

    (async () => {
      setIsLoading(true);
      try {
        const state = await authService.ensureSession();

        if (cancelled) return;

        if (state === 'active') {
          setUser(authService.getUser());
          setIsAuthenticated(true);
          return;
        }

        // Only now is login-agent justified. This is the one call that can
        // surface a Windows prompt, so it must be the last resort rather than
        // the default path.
        const res = await authService.loginAgent();
        if (cancelled) return;

        setUser(res.user);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Session bootstrap failed:', error);
        if (!cancelled) setIsAuthenticated(false);
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, []);
```

## If LoginScreen currently calls loginAgent() on mount

Stop it doing that. With the above, AuthContext owns the decision. LoginScreen
should render only when bootstrap has finished AND concluded there is no
session — and ideally require a click rather than firing automatically, so the
Windows dialog never appears without the user having asked for anything.

## Also handle auth:unauthorized

apiClient dispatches this when a 401 survives a refresh and a retry. Listen for
it and drop to the logged-out state — but do NOT auto-call loginAgent() from the
handler. That turns one expired token into an unexpected credentials prompt in
the middle of whatever the agent was doing.

```tsx
  useEffect(() => {
    const onUnauthorized = () => {
      setIsAuthenticated(false);
      setUser(null);
    };
    window.addEventListener('auth:unauthorized', onUnauthorized);
    return () => window.removeEventListener('auth:unauthorized', onUnauthorized);
  }, []);
```

## What this does and does not achieve

REMOVES: every unnecessary trip to login-agent. Given that auth_expires_at was
being written with two different units, that was most of them - which is why the
prompt felt random and repeated.

DOES NOT REMOVE: the first prompt of a genuinely new session. With no token,
login-agent must run, and it is a Negotiate endpoint. Only trusting the host in
the browser (AuthServerAllowlist) removes that one - which you have already
proven works.

Combined: allowlist deployed -> no prompt at all. Allowlist refused -> one
prompt when the agent first opens the app, and none for the rest of the shift.
