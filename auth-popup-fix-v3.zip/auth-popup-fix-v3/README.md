# Windows credentials popup — root cause found in AuthContext

frontend/src/contexts/AuthContext.tsx   REPLACE   <-- the actual bug
frontend/src/services/api.ts            REPLACE
frontend/src/services/authService.ts    REPLACE

No backend changes. No registry changes required for THIS fix.

## The bug

    isAuthenticated: !!user && authService.isAuthenticated(),

That ran on EVERY RENDER. And authService.isAuthenticated() calls clearAuth()
when the local timestamp looks expired — so computing a boolean during render
WIPED localStorage as a side effect, returned false, App.tsx rendered
LoginScreen, LoginScreen called login(), and the user got a Windows prompt
mid-task.

Nothing had expired on the server. A component re-rendered.

And auth_expires_at was being written with two different units (authService used
seconds, api.ts used minutes, same key), so it was frequently wrong. Random
re-render + wrong timestamp = "again and again, in between other pages".

## Four fixes

1. isAuthenticated is now STATE. It changes only at explicit moments: bootstrap,
   login, logout, confirmed 401. Never computed during render, never with a side
   effect.

2. Bootstrap asks the SERVER via ensureSession() -> GET /api/auth/me. That is a
   Bearer endpoint, so it cannot raise a Negotiate challenge. login-agent runs
   ONLY after the server confirms there is no usable session.

3. login-agent is guarded to one attempt per app load. A failure can never
   become a loop of prompts. Reset on explicit logout or a genuine 401.

4. auth:unauthorized no longer auto-relogins. It drops to logged-out and lets
   the user act, instead of turning an expired token into a surprise dialog.

Plus, from the earlier drop: one unit conversion, no window.location.reload(),
one refresh implementation, refresh at 75% of lifetime.

## Expected behaviour after deploying

  - One Windows prompt when an agent first opens the app (or none, if the
    AuthServerAllowlist registry value is deployed — you have already proven
    that works)
  - Nothing for the rest of the shift
  - No prompt on re-render, navigation, or a transient network blip

## Still worth doing separately

The AuthServerAllowlist registry value removes even the first prompt. That is a
desktop-config task, not an application change, and your test with
--auth-server-allowlist already confirmed it works.

## Check before deploying

LoginScreen.tsx — if it calls login() automatically on mount, that is now
redundant, since AuthContext owns the decision and already calls login-agent
when needed. Two callers would mean two login-agent requests. Send me that file
if you want it checked.
