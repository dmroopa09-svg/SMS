import React, { createContext, useContext, useState, useEffect, useRef, useCallback, ReactNode } from 'react';
import { authService, LoginResponse } from '../services/authService';

interface AuthContextType {
  user: LoginResponse['user'] | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  error: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<LoginResponse['user'] | null>(null);

  /**
   * STATE, not a computed value.
   *
   * This used to be:
   *     isAuthenticated: !!user && authService.isAuthenticated()
   *
   * which ran on every render — and authService.isAuthenticated() calls
   * clearAuth() when the local timestamp looks expired. So computing a boolean
   * during render WIPED localStorage as a side effect, App.tsx saw false,
   * rendered LoginScreen, LoginScreen called login(), and the user got a Windows
   * prompt in the middle of whatever they were doing. Nothing had actually
   * expired server side; a component had simply re-rendered.
   *
   * Authentication state now changes only at explicit moments: bootstrap,
   * login, logout, or a confirmed 401.
   */
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  /**
   * login-agent is the only endpoint that can raise a Windows credentials
   * dialog. This guard makes sure it is attempted at most once per app load,
   * so a failure can never turn into a loop of prompts.
   */
  const loginAttemptedRef = useRef(false);

  const doLoginAgent = useCallback(async () => {
    if (loginAttemptedRef.current) {
      setIsAuthenticated(false);
      setUser(null);
      return;
    }
    loginAttemptedRef.current = true;

    const response = await authService.loginAgent();
    setUser(response.user);
    setIsAuthenticated(true);
  }, []);

  // ── Bootstrap ─────────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    const bootstrap = async () => {
      setIsLoading(true);
      setError(null);

      try {
        // Ask the SERVER whether the session is alive, instead of guessing from
        // a local timestamp that has been written with two different units.
        // /me is a Bearer endpoint, so it can never trigger a Negotiate
        // challenge — no prompt is possible on this path.
        const state = await authService.ensureSession();
        if (cancelled) return;

        if (state === 'active') {
          const storedUser = authService.getUser();
          if (storedUser) {
            setUser(storedUser);
            setIsAuthenticated(true);
            return;
          }
          // Valid token but no cached user object. Fall through to login-agent
          // to get the user payload back — the token alone is not enough to
          // render the header, process list, or anything keyed on userId.
        }

        // Only now is login-agent justified: the server has confirmed there is
        // no usable session. This is the one call that can surface a prompt, so
        // it must be the last resort rather than the default path.
        await doLoginAgent();
      } catch (err: unknown) {
        console.error('Session bootstrap failed:', err);
        if (cancelled) return;
        setError(err instanceof Error ? err.message : 'Login failed');
        setUser(null);
        setIsAuthenticated(false);
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    };

    bootstrap();

    // Raised by apiClient only after a 401 has survived a refresh AND a retry.
    // Deliberately does NOT call login-agent — that would turn one expired token
    // into an unexpected credentials dialog mid-task, which is the behaviour
    // being fixed. Drop to logged-out and let the user act.
    const handleUnauthorized = () => {
      console.warn('Authentication expired (401), clearing user session');
      authService.clearAuth();
      setUser(null);
      setIsAuthenticated(false);
      // Allow one fresh login-agent attempt, since this is a genuine expiry
      // rather than a render-time miscalculation.
      loginAttemptedRef.current = false;
    };

    window.addEventListener('auth:unauthorized', handleUnauthorized);

    return () => {
      cancelled = true;
      window.removeEventListener('auth:unauthorized', handleUnauthorized);
    };
  }, [doLoginAgent]);

  // ── Manual login (LoginScreen button) ─────────────────────────────────────
  const login = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    // A user-initiated retry always gets an attempt, regardless of the guard.
    loginAttemptedRef.current = false;

    try {
      await doLoginAgent();
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Login failed';
      setError(errorMessage);
      setUser(null);
      setIsAuthenticated(false);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [doLoginAgent]);

  const logout = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Not awaited as a promise — clearAuthNotUser is synchronous. Keeps
      // auth_user in storage deliberately, as before.
      authService.clearAuthNotUser();
      // await authService.logout();
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setUser(null);
      setIsAuthenticated(false);
      // A deliberate sign-out should be able to sign back in.
      loginAttemptedRef.current = false;
      setIsLoading(false);
    }
  }, []);

  const value: AuthContextType = {
    user,
    // Plain state. No function call, no side effect, no clearAuth() during render.
    isAuthenticated,
    isLoading,
    login,
    logout,
    error,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
