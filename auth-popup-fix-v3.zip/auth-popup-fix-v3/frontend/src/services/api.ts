import { API_BASE_URL, API_TIMEOUT, API_ENDPOINTS } from '../config/api';

export { API_ENDPOINTS };

const REFRESH_ENDPOINT = API_ENDPOINTS.auth.refresh;

/**
 * THE ONE PLACE that converts the API's `expiresIn` into milliseconds.
 *
 * This previously existed in three places with two different meanings —
 * authService used `* 1000` (seconds) while api.ts used `* 60 * 1000`
 * (minutes) — writing to the same localStorage key. Whichever ran last won, so
 * `auth_expires_at` flipped between two values while the user worked. When the
 * short one won, the session looked expired almost immediately.
 *
 * The heuristic: this app issues short-lived JWTs. A value under 240 cannot be
 * seconds, because that would be a token valid for under four minutes. So small
 * numbers are minutes, large numbers are seconds. 15 -> 15 min, 900 -> 15 min.
 *
 * Confirm what your AuthController actually returns and replace this with the
 * single correct multiplier. The heuristic is a safety net, not the answer.
 */
export function expiresInToMs(expiresIn: number): number {
  if (!expiresIn || expiresIn <= 0) return 0;
  return expiresIn < 240 ? expiresIn * 60_000 : expiresIn * 1_000;
}

/** Written by every path that obtains a token, so they cannot disagree again. */
export function storeTokenExpiry(expiresIn: number): void {
  localStorage.setItem('auth_expires_at', String(Date.now() + expiresInToMs(expiresIn)));
}

class ApiError extends Error {
  constructor(
    public code: string,
    message: string
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export class ApiClient {
  private baseUrl: string;
  private timeout: number;
  private refreshPromise: Promise<boolean> | null = null;

  constructor(baseUrl: string = API_BASE_URL, timeout: number = API_TIMEOUT) {
    this.baseUrl = baseUrl;
    this.timeout = timeout;
  }

  /**
   * The ONLY refresh implementation in the app. A raw fetch on purpose — going
   * through request() would re-enter the pre-request expiry check and fire a
   * second refresh before the first had finished.
   */
  private async doRefreshToken(): Promise<boolean> {
    const token = localStorage.getItem('auth_token');
    if (!token) return false;

    try {
      const response = await fetch(`${this.baseUrl}${REFRESH_ENDPOINT}`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        // Never send Windows credentials to a JWT endpoint.
        credentials: 'omit',
      });

      if (!response.ok) return false;
      const data = await response.json().catch(() => ({}));

      if (data?.token) {
        localStorage.setItem('auth_token', data.token);
        storeTokenExpiry(data.expiresIn);
        // Let authService re-arm its timer off the new lifetime without either
        // side owning the other.
        window.dispatchEvent(
          new CustomEvent('auth:refreshed', { detail: { expiresIn: data.expiresIn } })
        );
        return true;
      }

      return false;
    } catch (err) {
      console.error('Refresh error:', err);
      return false;
    }
  }

  /** Public so authService can delegate rather than keep a second implementation. */
  async refreshToken(): Promise<boolean> {
    if (this.refreshPromise) return this.refreshPromise;
    this.refreshPromise = this.doRefreshToken().finally(() => {
      this.refreshPromise = null;
    });
    return this.refreshPromise;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const isWindowsAuthEndpoint =
      endpoint.includes('/auth/login') || endpoint.includes('/auth/login-agent');

    // The refresh endpoint must NOT run the pre-request refresh check — that is
    // the re-entrancy that caused two refreshes per tick.
    const isRefreshEndpoint = endpoint.includes(REFRESH_ENDPOINT);

    const token = localStorage.getItem('auth_token');
    const expiresAt = localStorage.getItem('auth_expires_at');

    if (token && expiresAt && !isWindowsAuthEndpoint && !isRefreshEndpoint) {
      const expiresAtTime = parseInt(expiresAt, 10);
      // Refresh if within 2 minutes of expiry.
      if (Date.now() >= expiresAtTime - 120_000) {
        await this.refreshToken();
      }
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    };

    const currentToken = localStorage.getItem('auth_token');
    if (currentToken && !isWindowsAuthEndpoint) {
      headers['Authorization'] = `Bearer ${currentToken}`;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers,
        credentials: isWindowsAuthEndpoint ? 'include' : 'omit',
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        if (response.status === 401 && !isWindowsAuthEndpoint && !isRefreshEndpoint) {
          const refreshed = await this.refreshToken();

          if (refreshed) {
            const retryToken = localStorage.getItem('auth_token');
            const retryHeaders = {
              'Content-Type': 'application/json',
              ...((options.headers as Record<string, string>) || {}),
              Authorization: `Bearer ${retryToken}`,
            };

            const retryResponse = await fetch(`${this.baseUrl}${endpoint}`, {
              ...options,
              headers: retryHeaders,
              credentials: 'omit',
            });

            if (retryResponse.ok) {
              const ct = retryResponse.headers.get('content-type');
              if (!ct?.includes('application/json')) return {} as T;
              return retryResponse.json();
            }
          }

          localStorage.removeItem('auth_token');
          localStorage.removeItem('auth_user');
          localStorage.removeItem('auth_expires_at');
          window.dispatchEvent(new CustomEvent('auth:unauthorized'));
        }

        const errorData = await response.json().catch(() => ({
          error: { code: 'UNKNOWN_ERROR', message: `HTTP ${response.status}` },
        }));

        throw new ApiError(
          errorData?.error?.code ?? 'UNKNOWN_ERROR',
          errorData?.error?.message ?? `HTTP ${response.status}`
        );
      }

      const contentType = response.headers.get('content-type');
      if (!contentType?.includes('application/json')) return {} as T;

      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      if (error instanceof ApiError) throw error;
      if (error instanceof Error && error.name === 'AbortError') {
        throw new ApiError('TIMEOUT', 'Request timeout');
      }
      throw new ApiError(
        'NETWORK_ERROR',
        error instanceof Error ? error.message : 'Network error'
      );
    }
  }

  // ==============================
  // PUBLIC METHODS
  // ==============================
  async get<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: 'GET' });
  }

  async post<T>(endpoint: string, data?: unknown): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    });
  }

  async put<T>(endpoint: string, data?: unknown): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    });
  }

  async delete<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: 'DELETE' });
  }
}

export const apiClient = new ApiClient();
