import { apiClient, API_ENDPOINTS, expiresInToMs, storeTokenExpiry } from './api';
import Cookies from 'js-cookie';

export interface LoginResponse {
  token: string;
  expiresIn: number;
  user: {
    userId: number;
    username: string;
    windowsUsername: string;
    email: string;
    roleId: number;
    roleName: string;
    firstName: string;
    lastName: string;
  };
}

export interface RefreshResponse {
  token: string;
  expiresIn: number;
}

class AuthService {
  private tokenRefreshTimer: number | null = null;
  private refreshedListener: ((e: Event) => void) | null = null;

  constructor() {
    // apiClient owns refresh now. When IT refreshes (from the pre-request check
    // or a 401 retry), re-arm the timer off the new lifetime — otherwise the
    // timer would still be counting down to the OLD expiry.
    this.refreshedListener = (e: Event) => {
      const detail = (e as CustomEvent<{ expiresIn: number }>).detail;
      if (detail?.expiresIn) this.scheduleTokenRefresh(detail.expiresIn);
    };
    window.addEventListener('auth:refreshed', this.refreshedListener);
  }

  async loginAgent(): Promise<LoginResponse> {
    const response = await apiClient.get<LoginResponse>(API_ENDPOINTS.auth.loginAgent);

    localStorage.setItem('auth_token', response.token);
    localStorage.setItem('auth_user', JSON.stringify(response.user));
    // Single shared converter — was `expiresIn * 1000` here and
    // `expiresIn * 60 * 1000` in api.ts, writing the same key.
    storeTokenExpiry(response.expiresIn);

    Cookies.set('userId', String(response.user.userId), { expires: 1 });
    Cookies.set('loginId', response.user.windowsUsername, { expires: 1 });

    this.scheduleTokenRefresh(response.expiresIn);

    return response;
  }

  /**
   * Delegates to apiClient rather than calling POST /auth/refresh itself.
   *
   * The old version called apiClient.post(refresh), which re-entered the
   * pre-request expiry check and fired a SECOND refresh before the first
   * completed. Two refreshes per timer tick, and if the API rotates tokens the
   * second one presents a token that was just replaced.
   */
  async refreshToken(): Promise<boolean> {
    return apiClient.refreshToken();
  }

  /**
   * Decides whether the app already has a usable session, WITHOUT calling
   * login-agent.
   *
   * This exists because isAuthenticated() answers the question locally, by
   * comparing Date.now() against auth_expires_at — a value that has been
   * written with two different units by two different code paths. When that
   * timestamp was wrong, the app concluded it was logged out, rendered
   * LoginScreen, called login-agent, and the user got a Windows prompt while
   * holding a token the server would have accepted.
   *
   * Asking the server removes that whole class of failure: /me is [Authorize]
   * on the Bearer scheme, so it is answered by the JWT and can NEVER trigger a
   * Negotiate challenge. A 200 means the session is alive whatever localStorage
   * happens to say.
   *
   * Returns:
   *   'active'      -> usable session, do NOT call loginAgent()
   *   'needs-login' -> no usable session, loginAgent() is required
   *
   * NOTE: this cannot remove the FIRST prompt of a session. When there is no
   * token at all, login-agent must run, and that is a Negotiate endpoint. Only
   * trusting the host in the browser (AuthServerAllowlist) removes that one.
   * What this removes is every UNNECESSARY trip to login-agent — which, given
   * the units bug, was most of them.
   */
  async ensureSession(): Promise<'active' | 'needs-login'> {
    const token = this.getToken();
    if (!token) return 'needs-login';

    try {
      // credentials:'omit' — apiClient already omits for non-login endpoints.
      // Sending Windows credentials to a Bearer endpoint would be pointless and
      // is what invites a challenge in the first place.
      await apiClient.get(API_ENDPOINTS.auth.me);
    } catch {
      // 401 here means the token is genuinely dead. apiClient has already tried
      // a refresh and a retry before surfacing this.
      return 'needs-login';
    }

    // The server accepted the token, so any local expiry that disagrees is
    // wrong. Repair it rather than leaving isAuthenticated() to fail on the very
    // next check and bounce the user back to LoginScreen anyway.
    const expiresAt = localStorage.getItem('auth_expires_at');
    const parsed = expiresAt ? parseInt(expiresAt, 10) : NaN;
    const localExpiryLooksDead = Number.isNaN(parsed) || Date.now() >= parsed;

    if (localExpiryLooksDead) {
      // Refresh to obtain a token AND a trustworthy expiry in one step. If it
      // fails the session is still usable right now, so do not log the user out
      // over it — the next request will refresh or surface a real 401.
      await apiClient.refreshToken().catch(() => false);
    }

    return 'active';
  }

  async logout(): Promise<void> {
    try {
      await apiClient.post(API_ENDPOINTS.auth.logout);
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // NOTE: clearAuth() was commented out here. If AuthContext does not clear
      // it, the token survives logout. Left as-is deliberately — uncomment only
      // once you have checked what AuthContext does on logout.
      // this.clearAuth();
    }
  }

  getToken(): string | null {
    const token = localStorage.getItem('auth_token');
    return token && token !== 'undefined' ? token : null;
  }

  getUser(): LoginResponse['user'] | null {
    const userStr = localStorage.getItem('auth_user');
    if (!userStr || userStr === 'undefined') {
      return null;
    }
    try {
      return JSON.parse(userStr);
    } catch {
      return null;
    }
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    const expiresAt = localStorage.getItem('auth_expires_at');

    if (!token || !expiresAt) {
      return false;
    }

    const expiresAtTime = parseInt(expiresAt, 10);
    if (Number.isNaN(expiresAtTime)) {
      this.clearAuth();
      return false;
    }

    if (Date.now() >= expiresAtTime) {
      this.clearAuth();
      return false;
    }

    return true;
  }

  clearAuth(): void {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_user');
    localStorage.removeItem('auth_expires_at');

    if (this.tokenRefreshTimer) {
      clearTimeout(this.tokenRefreshTimer);
      this.tokenRefreshTimer = null;
    }
  }

  clearAuthNotUser(): void {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_expires_at');

    if (this.tokenRefreshTimer) {
      clearTimeout(this.tokenRefreshTimer);
      this.tokenRefreshTimer = null;
    }
  }

  private scheduleTokenRefresh(expiresIn: number): void {
    if (this.tokenRefreshTimer) {
      clearTimeout(this.tokenRefreshTimer);
    }

    const lifetimeMs = expiresInToMs(expiresIn);
    if (lifetimeMs <= 0) return;

    // Refresh at 75% of lifetime, or 2 minutes before expiry, whichever is
    // sooner. Earlier than the old "1 minute before" on purpose: browsers
    // throttle timers in background tabs, so a timer aimed at the last minute
    // can fire after the token is already dead.
    const target = Math.min(lifetimeMs * 0.75, lifetimeMs - 120_000);
    const refreshDelay = Math.max(30_000, target);

    this.tokenRefreshTimer = window.setTimeout(async () => {
      const ok = await this.refreshToken();

      if (!ok) {
        // NO window.location.reload() HERE.
        //
        // That was the proximate cause of the mid-session Windows popup: a
        // background timer failed, the page reloaded itself, the app booted
        // unauthenticated, LoginScreen called /auth/login-agent, and that
        // endpoint is Negotiate — so the user got a credentials prompt while
        // in the middle of something.
        //
        // Now: announce it and let AuthContext decide. A transient network
        // blip no longer costs the user their page.
        console.error('Token refresh failed');
        window.dispatchEvent(new CustomEvent('auth:refresh-failed'));

        // Retry once shortly after — most failures here are transient.
        this.tokenRefreshTimer = window.setTimeout(async () => {
          const retryOk = await this.refreshToken();
          if (!retryOk) {
            this.clearAuth();
            window.dispatchEvent(new CustomEvent('auth:unauthorized'));
          }
        }, 30_000);
      }
    }, refreshDelay);
  }
}

export const authService = new AuthService();
