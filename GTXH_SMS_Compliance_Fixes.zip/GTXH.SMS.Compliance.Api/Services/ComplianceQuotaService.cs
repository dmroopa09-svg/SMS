using GTXH.SMS.Common;
using GTXH.SMS.Compliance.Api.Data;
using GTXH.SMS.Messaging;
using StackExchange.Redis;
using System.Globalization;

namespace GTXH.SMS.Compliance.Api.Services;

/// <summary>
/// Campaign volume throttle at Compliance release (hour/day/week/month).
/// Uses campaign timezone from quota mirror for bucket boundaries.
/// </summary>
public sealed class ComplianceQuotaService
{
    private readonly IConnectionMultiplexer? _redis;
    private readonly IEventPublisher _publisher;
    private readonly ILogger<ComplianceQuotaService> _logger;
    private readonly bool _allowReleaseWithoutRedis;

    public ComplianceQuotaService(
        IEventPublisher publisher,
        ILogger<ComplianceQuotaService> logger,
        IConfiguration configuration,
        IConnectionMultiplexer? redis = null)
    {
        _publisher = publisher;
        _logger = logger;
        _redis = redis;

        // Escape hatch for a local dev box with no Redis. Defaults to FALSE so
        // that a missing or mistyped connection string can never silently
        // disable the volume limits in a deployed environment.
        _allowReleaseWithoutRedis =
            configuration.GetValue("Compliance:AllowReleaseWithoutRedis", false);
    }

    /// <summary>
    /// Reserve up to <paramref name="requested"/> slots. Returns granted count (0 if none).
    /// </summary>
    public async Task<int> ReserveUpToAsync(
        CampaignQuotaMirrorEntity mirror,
        int requested,
        CancellationToken ct)
    {
        if (requested <= 0)
            return 0;

        // ---------------------------------------------------------------
        // FAIL CLOSED WHEN THE COUNTER IS UNAVAILABLE.
        //
        // Previously this returned `requested`, which granted everything. That
        // meant a missing or mistyped Redis connection string silently disabled
        // every hour/day/week/month limit: a campaign configured for 100 would
        // send all of them, with no log line and no exception, because from the
        // service's point of view every release WAS granted.
        //
        // A volume control that cannot read its counter must refuse, not grant.
        // ---------------------------------------------------------------
        if (_redis is null || !_redis.IsConnected)
        {
            if (_allowReleaseWithoutRedis)
            {
                _logger.LogWarning(
                    "Redis unavailable and Compliance:AllowReleaseWithoutRedis is true — "
                    + "granting {Requested} for campaign {ID} WITHOUT quota enforcement. "
                    + "This setting must never be true outside a developer machine.",
                    requested, mirror.ID);
                return requested;
            }

            _logger.LogError(
                "Redis unavailable — campaign volume quota cannot be enforced. "
                + "Denying release of {Requested} message(s) for campaign {ID}. "
                + "Check the 'Redis' connection string.",
                requested, mirror.ID);

            return 0;
        }

        var windows = BuildWindows(mirror).ToList();
        if (windows.Count == 0)
            return requested;

        var db = _redis.GetDatabase();
        var now = DateTimeOffset.UtcNow;
        var tz = TimeZoneResolver.FindTimeZone(mirror.Timezone ?? "UTC");
        var local = TimeZoneInfo.ConvertTime(now, tz);

        var remaining = long.MaxValue;
        foreach (var (window, bucket, limit) in windows)
        {
            var key = $"quota:{mirror.ID}:{window}:{bucket}";
            var raw = await db.StringGetAsync(key);
            var used = raw.HasValue && long.TryParse(raw.ToString(), out var u) ? u : 0L;
            remaining = Math.Min(remaining, Math.Max(0, limit - used));
        }

        var n = (int)Math.Min(requested, remaining);
        if (n <= 0)
        {
            var (window, bucket, limit) = windows[0];
            await PublishExhaustedAsync(mirror, window, bucket, limit, limit, local, ct);
            return 0;
        }

        // Atomic INCR; roll back if any window overflows (race with other releasers).
        var incremented = new List<(string Key, int Count)>();
        foreach (var (window, bucket, limit) in windows)
        {
            var key = $"quota:{mirror.ID}:{window}:{bucket}";
            var used = await db.StringIncrementAsync(key, n);
            incremented.Add((key, n));
            if (used == n)
                await db.KeyExpireAsync(key, TimeSpan.FromDays(70));

            if (used > limit)
            {
                foreach (var (k, c) in incremented)
                    await db.StringDecrementAsync(k, c);

                _logger.LogInformation(
                    "Compliance quota denied campaign={ID} window={Window} limit={Limit}",
                    mirror.ID, window, limit);

                await PublishExhaustedAsync(mirror, window, bucket, limit, used - n, local, ct);
                return 0;
            }
        }

        return n;
    }

    private async Task PublishExhaustedAsync(
        CampaignQuotaMirrorEntity mirror,
        string window,
        string bucket,
        long limit,
        long used,
        DateTimeOffset local,
        CancellationToken ct) =>
        await _publisher.PublishAsync(
            Topics.QuotaExhausted,
            mirror.ID.ToString(),
            new QuotaExhaustedEvent
            {
                CampaignQueueId = mirror.ID,
                CampaignId = mirror.Campaign_Mstr_ID,
                ProducerService = ProducerServices.Compliance,
                Window = window,
                BucketId = bucket,
                Limit = limit,
                Used = used,
                NextBucketAt = NextBucket(window, local)
            },
            ct);

    private static IEnumerable<(string Window, string Bucket, long Limit)> BuildWindows(
        CampaignQuotaMirrorEntity c)
    {
        var now = DateTimeOffset.UtcNow;
        var tz = TimeZoneResolver.FindTimeZone(c.Timezone ?? "UTC");
        var local = TimeZoneInfo.ConvertTime(now, tz);

        if (c.LimitHour is > 0)
            yield return ("hour", local.ToString("yyyyMMddHH", CultureInfo.InvariantCulture), c.LimitHour);
        if (c.LimitDay is > 0)
            yield return ("day", local.ToString("yyyyMMdd", CultureInfo.InvariantCulture), c.LimitDay);
        if (c.LimitWeek is > 0)
        {
            var cal = CultureInfo.InvariantCulture.Calendar;
            var week = cal.GetWeekOfYear(local.DateTime, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
            yield return ("week", $"{local.Year:D4}W{week:D2}", c.LimitWeek);
        }
        if (c.LimitMonth is > 0)
            yield return ("month", local.ToString("yyyyMM", CultureInfo.InvariantCulture), c.LimitMonth);
    }

    private static DateTimeOffset NextBucket(string window, DateTimeOffset local)
    {
        var next = window switch
        {
            "hour" => new DateTimeOffset(local.Year, local.Month, local.Day, local.Hour, 0, 0, local.Offset).AddHours(1),
            "day" => new DateTimeOffset(local.Year, local.Month, local.Day, 0, 0, 0, local.Offset).AddDays(1),
            "week" => new DateTimeOffset(local.Year, local.Month, local.Day, 0, 0, 0, local.Offset).AddDays(7),
            _ => new DateTimeOffset(local.Year, local.Month, 1, 0, 0, 0, local.Offset).AddMonths(1)
        };
        return TimeZoneInfo.ConvertTime(next, TimeZoneInfo.Utc);
    }
}
