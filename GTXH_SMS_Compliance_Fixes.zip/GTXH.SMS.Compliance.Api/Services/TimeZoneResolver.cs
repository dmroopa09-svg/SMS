using GTXH.SMS.Compliance.Api.Data;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace GTXH.SMS.Compliance.Api.Services;

/// <summary>Fail-closed geo/TZ resolution result — never silently defaults.</summary>
public sealed record ComplianceGeoResolution(
    bool Ok,
    string? ReasonCode,
    string? IanaTimeZone,
    string? Source,
    string? StateCode,
    string? Zip5,
    string? AreaCode);

public sealed class TimeZoneResolver(ComplianceDbContext db, ILogger<TimeZoneResolver> logger)
{
    private static readonly Regex Digits = new(@"\D", RegexOptions.Compiled);

    /// <summary>
    /// States whose area codes carry a NANPA time zone letter that is wrong for
    /// them, because the state does not follow that zone's daylight-saving rule
    /// or spans more than one zone.
    /// </summary>
    private static readonly HashSet<string> AreaCodeUnreliableStates =
        new(StringComparer.OrdinalIgnoreCase)
        {
            // Split across two zones — the area code cannot distinguish which.
            "FL", "IN", "KY", "MI", "TN", "TX", "KS", "NE", "ND", "SD", "OR", "ID", "AK"
        };

    public async Task<ComplianceGeoResolution> ResolveStrictAsync(
        string? zipCode,
        string? stateCodeHint,
        string phone,
        CancellationToken ct)
    {
        var zip5 = NormalizeZip(zipCode);
        var area = ExtractAreaCode(phone);
        var hintState = NormalizeState(stateCodeHint);

        if (zip5 is null && area is null)
        {
            return Fail("PHONE_OR_ZIP_REQUIRED", zip5, area);
        }

        // Zip present → must resolve (do not silently skip to area).
        if (zip5 is not null)
        {
            // Exact ZIP5 first so the index is used, then longer rows (ZIP+4).
            //
            // NOTE: this deliberately does NOT match a stored three-digit prefix.
            // "941".StartsWith("94110") is false, so ZIP3 rows never match and
            // every lookup would return ZIP_NOT_FOUND. If ZipCode_TimeZones is
            // ever loaded with ZIP3 data as a shortcut, this method needs
            // changing — and be aware a ZIP3 region can straddle two time zones
            // in FL, IN, KY, NE, ND, OR and TX, so a ZIP3 match is a guess.
            var zipRow = await db.ZipCodeTimeZones.AsNoTracking()
                .Where(z => z.ZipCode == zip5 || z.ZipCode.StartsWith(zip5))
                .OrderBy(z => z.ZipCode.Length)
                .FirstOrDefaultAsync(ct);

            if (zipRow is null || string.IsNullOrWhiteSpace(zipRow.TimeZone))
            {
                logger.LogWarning("Zip {Zip} not found in ZipCode_TimeZones", zip5);
                return Fail("ZIP_NOT_FOUND", zip5, area);
            }

            if (!TryValidateIana(zipRow.TimeZone, out _))
                return Fail("TIMEZONE_INVALID", zip5, area);

            var state = NormalizeState(hintState) ?? NormalizeState(zipRow.StateCode);
            if (state is null)
                return Fail("STATE_UNRESOLVED", zip5, area);

            return new ComplianceGeoResolution(true, null, zipRow.TimeZone, "zip", state, zip5, area);
        }

        // No zip → area code required and must resolve.
        var npa = await db.NpaAreaCodes.AsNoTracking()
            .Where(n => n.NpaId == area
                     && n.InService == "Y"
                     && n.Use == "G"
                     && n.Country == "US")
            .FirstOrDefaultAsync(ct);

        if (npa is null)
        {
            logger.LogWarning("Area code {Area} not found / not in-service geographic US NPA", area);
            return Fail("AREA_NOT_FOUND", zip5, area);
        }

        var npaState = NormalizeState(npa.Location);

        // -----------------------------------------------------------------
        // ARIZONA.
        //
        // Arizona's area codes (480, 520, 602, 623, 928) carry TIME_ZONE = "M"
        // in the NANPA data, and the letter map sends M to America/Denver.
        //
        // Arizona does not observe daylight saving. From March to November its
        // local clock matches PACIFIC, not Mountain — so a Denver mapping
        // schedules every Arizona recipient an hour early for eight months of
        // the year, which is outside the legal window.
        //
        // America/Phoenix is Mountain Standard Time all year and is correct.
        //
        // The Navajo Nation in north-eastern Arizona DOES observe DST, so a
        // recipient there is now scheduled an hour late instead. That is the safe
        // direction, and only zip-level data can tell the two apart.
        // -----------------------------------------------------------------
        string? iana;
        if (string.Equals(npaState, "AZ", StringComparison.OrdinalIgnoreCase))
        {
            iana = "America/Phoenix";
        }
        else
        {
            iana = MapNanpaTimeZoneLetter(npa.TimeZone);
        }

        if (iana is null || !TryValidateIana(iana, out _))
            return Fail("TIMEZONE_UNRESOLVED", zip5, area);

        var stateFromArea = NormalizeState(hintState) ?? npaState;
        if (stateFromArea is null)
            return Fail("STATE_UNRESOLVED", zip5, area);

        // An area code in a split state gives an answer that is right for most of
        // the state and wrong for the rest — Texas has El Paso on Mountain,
        // Florida has the panhandle on Central. Not fatal, because the zone is
        // right for the majority, but worth surfacing: a campaign with many of
        // these has a zip data problem upstream.
        if (AreaCodeUnreliableStates.Contains(stateFromArea))
        {
            logger.LogWarning(
                "Area code {Area} resolved {State} to {Tz} without a zip. {State} spans more than "
                + "one time zone, so this is the dominant zone rather than a certainty. "
                + "Populate ZipCode_TimeZones to remove the guess.",
                area, stateFromArea, iana, stateFromArea);
        }

        return new ComplianceGeoResolution(true, null, iana, "area", stateFromArea, zip5, area);
    }

    public static string? MapNanpaTimeZoneLetter(string? code)
    {
        if (string.IsNullOrWhiteSpace(code)) return null;
        var c = code.Trim().ToUpperInvariant();
        return c switch
        {
            "E" => "America/New_York",
            "C" => "America/Chicago",
            "M" => "America/Denver",
            "P" => "America/Los_Angeles",
            // "MP" is not Mountain/Pacific — in the NANPA data it is the Northern
            // Mariana Islands. Mapping it to Los_Angeles is wrong by many hours.
            // Left unmapped so it fails closed rather than sending at a guessed
            // time; add Pacific/Saipan if those numbers are ever in scope.
            "A" or "AK" => "America/Anchorage",
            "H" or "HI" => "Pacific/Honolulu",
            _ => null
        };
    }

    public static TimeZoneInfo FindTimeZone(string id)
    {
        try
        {
            return TimeZoneInfo.FindSystemTimeZoneById(id);
        }
        catch (TimeZoneNotFoundException)
        {
            var windows = id switch
            {
                "America/New_York" => "Eastern Standard Time",
                "America/Chicago" => "Central Standard Time",
                "America/Denver" => "Mountain Standard Time",
                "America/Phoenix" => "US Mountain Standard Time",
                "America/Los_Angeles" => "Pacific Standard Time",
                "America/Anchorage" => "Alaskan Standard Time",
                "Pacific/Honolulu" => "Hawaiian Standard Time",
                "UTC" or "Etc/UTC" => "UTC",
                _ => id
            };
            return TimeZoneInfo.FindSystemTimeZoneById(windows);
        }
    }

    public static bool TryValidateIana(string id, out TimeZoneInfo? tz)
    {
        try
        {
            tz = FindTimeZone(id);
            return true;
        }
        catch
        {
            tz = null;
            return false;
        }
    }

    private static ComplianceGeoResolution Fail(string reason, string? zip5, string? area) =>
        new(false, reason, null, null, null, zip5, area);

    private static string? NormalizeZip(string? zip)
    {
        if (string.IsNullOrWhiteSpace(zip)) return null;
        var digits = Digits.Replace(zip, "");
        return digits.Length >= 5 ? digits[..5] : null;
    }

    private static string? ExtractAreaCode(string phone)
    {
        var digits = Digits.Replace(phone ?? "", "");
        if (digits.Length == 11 && digits.StartsWith('1'))
            digits = digits[1..];
        return digits.Length >= 10 ? digits[..3] : digits.Length == 3 ? digits : null;
    }

    private static string? NormalizeState(string? stateCode)
    {
        if (string.IsNullOrWhiteSpace(stateCode)) return null;
        var s = stateCode.Trim().ToUpperInvariant();
        return s.Length == 2 ? s : null;
    }
}
