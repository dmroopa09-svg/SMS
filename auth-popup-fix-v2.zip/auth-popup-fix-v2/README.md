# Windows credentials popup mid-session

frontend/src/services/api.ts           REPLACE
frontend/src/services/authService.ts   REPLACE

No other file changes. No backend changes.

## The loop that caused it

  refreshToken() fails
    -> clearAuth()
    -> window.location.reload()      forced reload, mid-work
    -> app boots unauthenticated
    -> LoginScreen calls loginAgent()
    -> GET /auth/login-agent, credentials:'include', [Authorize(Negotiate)]
    -> WINDOWS POPUP

The user was on any page. A background timer failed and the page reloaded
itself into a Windows challenge. That is why it looks random and "in between
other pages".

## Three fixes

1. ONE unit conversion. authService used expiresIn*1000 (seconds), api.ts used
   expiresIn*60*1000 (minutes), both writing auth_expires_at. Whichever ran last
   won, so the expiry flipped between two values while the user worked. Now a
   single expiresInToMs() / storeTokenExpiry() used by every path.

2. NO forced reload. Refresh failure now retries once after 30s, then dispatches
   auth:unauthorized. A transient network blip no longer costs the user their
   page or triggers a Negotiate call.

3. ONE refresh implementation. authService.refreshToken() called
   apiClient.post('/auth/refresh'), which re-entered the pre-request expiry check
   and fired a SECOND refresh first. Two refreshes per tick, and if your API
   rotates tokens the second presents one that was just replaced. authService now
   delegates, and the refresh endpoint is excluded from the pre-request check.

Also: refresh now fires at 75% of lifetime instead of 1 minute before expiry.
Background tabs throttle timers, so a timer aimed at the last minute can fire
after the token is already dead.

## CONFIRM THE UNIT

expiresInToMs() uses a heuristic (under 240 = minutes, else seconds) so it is
correct either way today. Check what AuthController actually returns and replace
it with the single correct multiplier. The heuristic is a safety net, not the
answer.

## This reduces frequency. It may not eliminate the popup.

Two separate problems:

  a) login-agent being called repeatedly   <- fixed here
  b) login-agent showing a popup instead of silent SSO   <- NOT code

If Kerberos SSO worked for these users, credentials:'include' would answer the
Negotiate challenge silently and they would never see a prompt. That it appears
at all means SSO is not seamless on those machines:

  - site must be in the Local Intranet zone
    (Internet Options > Security > Local intranet > Sites > Advanced)
  - "Automatic logon only in Intranet zone" enabled
  - Chrome/Edge: AuthServerAllowlist policy must include the host

Worth checking specifically on the users who complain. "Only some users" points
at per-machine zone configuration.

## Left alone deliberately

logout() has clearAuth() commented out, so the token survives logout. Flagged,
not changed - check what AuthContext does on logout before uncommenting.
