PHASE 0 — FOUNDATIONS
=====================

Nothing in this phase is visible. Everything later depends on it, and every part
of it is expensive to change once data exists.


ORDER OF WORK
-------------
    1. P0_01_Schema.sql          columns, indexes, status values, new tables
    2. P0_02_Procedures.sql      claim, release, reap, stop/start
    3. P0_03_AcceptanceTests.sql prove it works
    4. Sms.Core project          IdempotencyKey.cs, SmsStatus.cs

Run 1 and 2 against DEV first. Run 3 before trusting anything.


SAFE TO RUN, SAFE TO RE-RUN
---------------------------
Every change in the schema script is guarded, so a partial run is completed by
running the whole thing again. Nothing is dropped or rewritten — all additions
are nullable or defaulted, so existing rows stay valid and the current pipeline
keeps working while the new one is built beside it.

A rollback block is at the bottom of the schema script. It is only safe before
anything writes to these columns.


THE THREE DECISIONS MADE HERE
-----------------------------

1. IDEMPOTENCY KEY = SHA256( QueueMstId | AccountId | NormalizedPhone )

   Keyed on the RUN, not the campaign. Running a campaign again next month is a
   new run, a new key, a legitimate second message. Regenerating the same run
   after a partial failure produces identical keys and inserts nothing new,
   which makes generation safely resumable.

   Template version deliberately excluded. If someone edits a template and
   regenerates, the recipient has already been messaged — including the version
   would make that a different key and send a second text, silently, from an
   ordinary edit.

   Phone included, so an account with two mobiles can be messaged on both. One
   person reached twice via two accounts is a real risk but belongs to
   compliance's per-recipient cap, which counts across campaigns.

   The index is FILTERED (WHERE IdempotencyKey IS NOT NULL) so existing rows,
   which have no key, are unaffected and no backfill is needed.

2. THREE NEW STATUS VALUES

     7 Deferred     compliance said not yet; NextAttemptUtc holds when
     8 Evaluating   claimed by compliance
     9 DeadLetter   retries exhausted, terminal

   Two in-flight states rather than one, because "claimed" is ambiguous when
   two services claim from the same table. Evaluating means compliance holds it,
   Queued means delivery does. A stuck row then names its own stage.

3. RUNSTATUS ON SMS_Queue_Mst IS THE STOP SWITCH

   The claim joins to it. Setting a run to Stopped makes every instance's next
   claim return nothing — no instance is signalled, no message is withdrawn.
   This is why stop works identically for one instance or twenty.

   Added as a NEW column rather than reusing Status, so nothing reading Status
   today changes behaviour.


WHY THE CLAIM IS A STORED PROCEDURE
-----------------------------------
Two reasons, both hard requirements rather than preferences.

It needs table hints EF cannot express:

    ROWLOCK    row locks rather than escalating to page or table locks
    UPDLOCK    take the update lock immediately rather than upgrading from a
               shared lock, which is where deadlocks come from
    READPAST   skip rows another instance holds instead of waiting

READPAST is what makes instances independent. Without it instance two waits for
instance one, and adding instances increases queueing rather than throughput.

And it must be ONE statement. The obvious implementation — SELECT the rows, then
UPDATE them — has a gap between the two in which another instance selects the
same rows. Both then send. A single UPDATE ... OUTPUT has no such gap.


THE ACCEPTANCE TESTS
--------------------
Phase 0 is not done until all three pass.

TEST 1  Concurrent claim. Three SSMS windows claiming simultaneously from the
        same 3,000 rows. Passes when DuplicateClaims = 0.

        This cannot be proven by reading the code. Concurrency bugs are
        invisible until exercised and fail intermittently rather than
        consistently, which is exactly why they survive review and reach
        production.

        If one instance claims everything, the windows did not overlap and the
        test proved nothing. Rerun with tighter timing.

TEST 2  Idempotency. A duplicate key insert must fail with error 2601 or 2627.
        Also confirms NULL-key rows are still accepted, since the index is
        filtered.

TEST 3  Stop switch. Claims return rows while Running and zero after Stop, and
        rows already claimed stay claimed.


THE ONE PLACE THIS DESIGN CAN STILL DOUBLE-SEND
-----------------------------------------------
Worth understanding precisely, because it is the residual risk.

A row reaped from Queued may already have been sent — the instance could have
called Webex successfully and died before recording it. Reaping returns it to
Eligible and it sends again.

Three things reduce this. None eliminate it:

  1. The reaper timeout must be comfortably longer than the worst realistic
     send. Reaping a slow send manufactures the problem.
  2. The idempotency key stops duplicate ROWS, not a duplicate provider call —
     the row already exists and is simply being retried.
  3. Only a provider-side key closes it. Webex has an unused Correlation ID
     field; if Connect deduplicates on it, passing our key means the second call
     is ignored at their end.

Until that is confirmed, prefer a longer timeout. A message delayed fifteen
minutes is recoverable. A duplicate to a Florida recipient, whose limit is one
message per thirty days, is a breach of the strictest rule in State_TCPA_Rules.

TEST THIS: send the same Correlation ID to Webex twice and count what arrives.
Five minutes, and it decides how aggressive the reaper can safely be.


WHAT IS NOT IN PHASE 0
----------------------
No services, no Kafka, no business logic. Only the foundation and proof that it
holds.

Phase 1 is the campaign service, which needs Santosh's EOS and RM account-fetch
code.


BEFORE STARTING PHASE 1 — TWO THINGS TO SETTLE
----------------------------------------------
1. Which database the queue lives in. The design discussion agreed it would move
   to a separate one; the tables are currently in GD_Data. This affects every
   connection string and any cross-database join, and is much cheaper to decide
   now than after four services are wired.

2. Kafka as signal or as queue. The architecture document argues for signal,
   because it is the only shape that gives a genuine mid-campaign stop. Phase 0
   works either way — but Phase 1 publishes the first message, so it needs
   answering before that is written.
