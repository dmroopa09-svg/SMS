using System;
using System.Security.Cryptography;
using System.Text;

namespace Sms.Core.Identity
{
    /// <summary>
    /// Builds the key that stops the same person being messaged twice in one run.
    ///
    /// COMPOSITION
    ///     SHA256( QueueMstId | AccountId | NormalizedPhone )
    ///
    /// Three deliberate choices, each of which changes behaviour if reversed.
    ///
    /// KEYED ON THE RUN, NOT THE CAMPAIGN.
    /// Running a campaign again next month is a new run, so a new key, so a
    /// legitimate second message — which is what collections work requires.
    /// Regenerating the SAME run after a partial failure produces identical keys
    /// and inserts nothing new, which is what makes generation safely resumable.
    /// Keying on the campaign would make a campaign sendable exactly once, ever.
    ///
    /// TEMPLATE VERSION IS EXCLUDED.
    /// The question being answered is "have we already created a message for
    /// this person in this run?". If someone edits the template and regenerates,
    /// the recipient has still already been messaged. Including the version
    /// would make the regenerated row a different key and produce a second text
    /// — a silent duplicate caused by an ordinary edit.
    ///
    /// PHONE IS INCLUDED.
    /// An account with two mobiles can legitimately be messaged on both. The
    /// converse risk — one person reached twice because they appear under two
    /// accounts — is real, but it belongs to compliance's per-recipient cap,
    /// which counts across campaigns. Trying to solve it here would block the
    /// legitimate case as well.
    ///
    /// NORMALISE BEFORE HASHING. "(415) 555-0123" and "4155550123" are the same
    /// person and must produce the same key. Hashing raw input silently defeats
    /// the whole mechanism, and nothing about the resulting data looks wrong.
    /// </summary>
    public static class IdempotencyKey
    {
        /// <summary>
        /// Builds the key. The phone must ALREADY be normalised to E.164 — this
        /// method does not normalise, because doing so quietly would hide the
        /// requirement from callers.
        /// </summary>
        /// <exception cref="ArgumentException">
        /// If the phone is not in +1XXXXXXXXXX form. Failing loudly here is
        /// deliberate: a malformed key produces duplicates that nobody notices.
        /// </exception>
        public static string Build(long queueMstId, long accountId, string normalizedPhoneE164)
        {
            if (string.IsNullOrWhiteSpace(normalizedPhoneE164))
                throw new ArgumentException(
                    "Phone is required to build an idempotency key.", nameof(normalizedPhoneE164));

            if (!LooksNormalized(normalizedPhoneE164))
                throw new ArgumentException(
                    $"Phone '{normalizedPhoneE164}' is not normalised. Expected +1 followed by ten " +
                    "digits. Normalise before building the key, or two spellings of the same " +
                    "number will produce two keys and two messages.",
                    nameof(normalizedPhoneE164));

            // Pipe separators prevent field-boundary collisions. Without them
            // (12, 3) and (1, 23) produce identical input.
            var material = $"{queueMstId}|{accountId}|{normalizedPhoneE164}";

            var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(material));

            // Lower-case hex, 64 characters, matching CHAR(64) in the schema.
            return Convert.ToHexString(bytes).ToLowerInvariant();
        }

        /// <summary>
        /// +1 followed by exactly ten digits, and an area code that does not
        /// begin 0 or 1 — the same rule the normaliser applies.
        /// </summary>
        private static bool LooksNormalized(string phone)
        {
            if (phone.Length != 12) return false;
            if (phone[0] != '+' || phone[1] != '1') return false;

            for (var i = 2; i < 12; i++)
                if (!char.IsAsciiDigit(phone[i])) return false;

            return phone[2] != '0' && phone[2] != '1';
        }
    }
}
