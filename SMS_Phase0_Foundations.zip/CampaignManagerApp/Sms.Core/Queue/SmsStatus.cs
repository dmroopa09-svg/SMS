namespace Sms.Core.Queue
{
    /// <summary>
    /// Mirrors dbo.SMSStatus. Values are FIXED — they exist in data and in the
    /// stored procedures. Never renumber; only append.
    /// </summary>
    public enum SmsStatus
    {
        /// <summary>Created, awaiting compliance evaluation.</summary>
        Init = 0,

        /// <summary>Compliance refused. Terminal.</summary>
        Block = 1,

        /// <summary>Compliance passed. Awaiting delivery.</summary>
        Eligible = 2,

        /// <summary>Claimed by delivery; send in progress.</summary>
        Queued = 3,

        /// <summary>Provider accepted it. Not yet confirmed by the carrier.</summary>
        Sent = 4,

        /// <summary>Carrier confirmed delivery. Terminal.</summary>
        Delivered = 5,

        /// <summary>An attempt failed. May retry, depending on the reason.</summary>
        Failed = 6,

        /// <summary>
        /// Compliance says not yet — outside the recipient's local window.
        /// NextAttemptUtc holds when it becomes eligible again.
        /// </summary>
        Deferred = 7,

        /// <summary>Claimed by compliance; evaluation in progress.</summary>
        Evaluating = 8,

        /// <summary>Retries exhausted. Terminal.</summary>
        DeadLetter = 9
    }

    /// <summary>
    /// Mirrors dbo.SMS_Queue_Mst.RunStatus.
    ///
    /// This is the stop switch. The claim procedure joins on it, so setting a
    /// run to Stopped makes every instance's next claim return nothing — with no
    /// instance being signalled and no message being withdrawn.
    /// </summary>
    public enum SmsRunStatus
    {
        /// <summary>Generated but not started. Claims are not permitted.</summary>
        Pending = 0,

        /// <summary>Claims permitted.</summary>
        Running = 1,

        /// <summary>
        /// Stopped by an operator. Claims return nothing. Rows already claimed
        /// finish — abandoning them would strand work with nothing to recover it.
        /// </summary>
        Stopped = 2,

        /// <summary>No work remains.</summary>
        Completed = 3,

        /// <summary>Stopped permanently; will not resume.</summary>
        Cancelled = 4
    }

    public static class SmsStatusExtensions
    {
        /// <summary>
        /// Terminal states never change again. Anything arriving for a terminal
        /// row — a late delivery receipt, a retry — must be ignored rather than
        /// applied, or a duplicate callback can move a Delivered message
        /// backwards.
        /// </summary>
        public static bool IsTerminal(this SmsStatus status) => status
            is SmsStatus.Block
            or SmsStatus.Delivered
            or SmsStatus.DeadLetter;

        /// <summary>An instance currently holds this row.</summary>
        public static bool IsClaimed(this SmsStatus status) => status
            is SmsStatus.Evaluating
            or SmsStatus.Queued;

        /// <summary>Counts against a recipient's contact limit.</summary>
        /// <remarks>
        /// Sent and Delivered only. A blocked or cancelled message never reached
        /// anyone and must not consume the person's allowance — otherwise a
        /// cancelled campaign silently locks people out of the next one.
        /// </remarks>
        public static bool CountsAsContact(this SmsStatus status) => status
            is SmsStatus.Sent
            or SmsStatus.Delivered;
    }
}
