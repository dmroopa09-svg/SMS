/* ============================================================================
   PHASE 0 ACCEPTANCE TESTS
   ============================================================================

   Two things must be proven before anything is built on this foundation:

     TEST 1  three instances claiming concurrently never get the same row
     TEST 2  the idempotency key rejects a duplicate message

   Neither is provable by reading the code. Concurrency bugs are invisible until
   they are exercised, and they fail intermittently rather than consistently —
   which is why they survive code review and reach production.

   Run in a DEV database. Test 1 creates and removes its own data.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ============================================================================
   TEST 1 — CONCURRENT CLAIM
   ============================================================================

   HOW TO RUN
   ----------
   1. Run SETUP below, once.
   2. Open THREE separate SSMS query windows against the same database.
   3. Paste the INSTANCE block into each, changing @InstanceId to A, B and C.
   4. Run all three as close to simultaneously as you can manage. Exact timing
      does not matter — the loop runs long enough to overlap heavily.
   5. Run VERIFY.

   WHAT PASSES
   -----------
   DuplicateClaims = 0. Every row claimed exactly once, by exactly one instance.

   If it is anything other than zero, stop. Two instances took the same row,
   which in production means two texts to one person, and no amount of code
   above this layer can compensate.
   ============================================================================ */

/* ---------------------------------------------------------------------------
   SETUP — creates 3,000 test rows in a dedicated run
   --------------------------------------------------------------------------- */

IF OBJECT_ID('dbo.ZZ_ClaimTest_Log', 'U') IS NOT NULL DROP TABLE dbo.ZZ_ClaimTest_Log;
CREATE TABLE dbo.ZZ_ClaimTest_Log (
    ClaimedID   BIGINT       NOT NULL,
    InstanceId  VARCHAR(10)  NOT NULL,
    ClaimedAt   DATETIME2    NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

DECLARE @TestRunId BIGINT;

-- A run marked Running, so claims are permitted
INSERT INTO dbo.SMS_Queue_Mst (Campaign_Mstr_ID, RunTime, Status, CreatedBy, CreatedDt, RunStatus)
VALUES (999999, SYSUTCDATETIME(), 0, 'CLAIMTEST', SYSUTCDATETIME(), 1);

SET @TestRunId = SCOPE_IDENTITY();

PRINT 'Test run id: ' + CAST(@TestRunId AS VARCHAR(20));
PRINT 'Note this number — VERIFY and CLEANUP need it.';

-- 3,000 rows at Init
;WITH Numbers AS (
    SELECT TOP (3000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
    FROM sys.all_objects a CROSS JOIN sys.all_objects b
)
INSERT INTO dbo.SMS_Queue_Detail
    (SMSQueue_Mst_ID, AccountID, Mobile, StateCode, ZipCode, SMSStatus, MessageText, AttemptCount)
SELECT
    @TestRunId,
    9000000 + n,
    '555' + RIGHT('0000000' + CAST(n AS VARCHAR(7)), 7),
    'TX',
    '75201',
    0,                       -- Init
    'claim test',
    0
FROM Numbers;

PRINT 'Seeded 3000 rows at Init.';
GO


/* ---------------------------------------------------------------------------
   INSTANCE BLOCK — run in three windows, changing @InstanceId each time
   --------------------------------------------------------------------------- */
/*

DECLARE @InstanceId VARCHAR(10) = 'A';     -- <<< change to B and C
DECLARE @Claimed TABLE (
    ID BIGINT, SMSQueue_Mst_ID BIGINT, AccountID BIGINT, Mobile VARCHAR(20),
    StateCode VARCHAR(2), ZipCode VARCHAR(10), PatMobile VARCHAR(20),
    PatStateCode VARCHAR(2), PatZipCode VARCHAR(10), MessageText NVARCHAR(MAX),
    UseTimeZone VARCHAR(64), Allowed_From INT, Allowed_To INT, AttemptCount INT
);

DECLARE @Rounds INT = 0;

WHILE @Rounds < 200
BEGIN
    DELETE FROM @Claimed;

    INSERT INTO @Claimed
    EXEC dbo.usp_SMS_ClaimBatch
        @FromStatus  = 0,
        @ClaimStatus = 8,
        @BatchSize   = 25,
        @InstanceId  = @InstanceId;

    IF NOT EXISTS (SELECT 1 FROM @Claimed) BREAK;

    INSERT INTO dbo.ZZ_ClaimTest_Log (ClaimedID, InstanceId)
    SELECT ID, @InstanceId FROM @Claimed;

    SET @Rounds = @Rounds + 1;
END

SELECT @InstanceId AS Instance, COUNT(*) AS RowsClaimed
FROM dbo.ZZ_ClaimTest_Log WHERE InstanceId = @InstanceId;

*/
GO


/* ---------------------------------------------------------------------------
   VERIFY
   --------------------------------------------------------------------------- */
/*

-- THE TEST. Must be zero.
SELECT COUNT(*) AS DuplicateClaims
FROM (
    SELECT ClaimedID
    FROM   dbo.ZZ_ClaimTest_Log
    GROUP  BY ClaimedID
    HAVING COUNT(*) > 1
) dupes;

-- Work should be spread across instances. Perfectly even is not expected;
-- one instance taking everything means the others never overlapped and the
-- test proved nothing — rerun with tighter timing.
SELECT InstanceId, COUNT(*) AS RowsClaimed
FROM   dbo.ZZ_ClaimTest_Log
GROUP  BY InstanceId
ORDER  BY InstanceId;

-- Total claimed should equal total seeded, with nothing left behind.
SELECT
    (SELECT COUNT(*) FROM dbo.ZZ_ClaimTest_Log)                              AS TotalClaimed,
    (SELECT COUNT(DISTINCT ClaimedID) FROM dbo.ZZ_ClaimTest_Log)             AS DistinctClaimed,
    (SELECT COUNT(*) FROM dbo.SMS_Queue_Detail
     WHERE SMSQueue_Mst_ID = <TestRunId> AND SMSStatus = 0)                  AS StillUnclaimed;

*/
GO


/* ---------------------------------------------------------------------------
   CLEANUP
   --------------------------------------------------------------------------- */
/*

DELETE FROM dbo.SMS_Queue_Detail WHERE SMSQueue_Mst_ID = <TestRunId>;
DELETE FROM dbo.SMS_Queue_Mst    WHERE ID = <TestRunId>;
DROP TABLE dbo.ZZ_ClaimTest_Log;

*/
GO


/* ============================================================================
   TEST 2 — IDEMPOTENCY KEY

   Proves the database refuses a duplicate message rather than relying on
   application code to remember not to create one.
   ============================================================================ */

DECLARE @TestRun BIGINT;

INSERT INTO dbo.SMS_Queue_Mst (Campaign_Mstr_ID, RunTime, Status, CreatedBy, CreatedDt, RunStatus)
VALUES (999998, SYSUTCDATETIME(), 0, 'IDEMTEST', SYSUTCDATETIME(), 1);
SET @TestRun = SCOPE_IDENTITY();

DECLARE @Key CHAR(64) = REPLICATE('a', 64);

-- First insert: expected to succeed
INSERT INTO dbo.SMS_Queue_Detail
    (SMSQueue_Mst_ID, AccountID, Mobile, SMSStatus, IdempotencyKey, MessageText)
VALUES (@TestRun, 8888888, '5551234567', 0, @Key, 'first');

PRINT 'First insert succeeded — expected.';

-- Second insert, same key: expected to FAIL
BEGIN TRY
    INSERT INTO dbo.SMS_Queue_Detail
        (SMSQueue_Mst_ID, AccountID, Mobile, SMSStatus, IdempotencyKey, MessageText)
    VALUES (@TestRun, 8888888, '5551234567', 0, @Key, 'duplicate');

    PRINT '*** TEST 2 FAILED — the duplicate was accepted. The unique index is missing.';
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() IN (2601, 2627)
        PRINT 'TEST 2 PASSED — duplicate rejected by the unique index.';
    ELSE
        PRINT '*** TEST 2 INCONCLUSIVE — failed for a different reason: ' + ERROR_MESSAGE();
END CATCH

-- Rows with no key must still be allowed. The index is filtered so existing
-- rows, which have no key, are unaffected.
INSERT INTO dbo.SMS_Queue_Detail
    (SMSQueue_Mst_ID, AccountID, Mobile, SMSStatus, IdempotencyKey, MessageText)
VALUES (@TestRun, 7777777, '5559999999', 0, NULL, 'no key 1');

INSERT INTO dbo.SMS_Queue_Detail
    (SMSQueue_Mst_ID, AccountID, Mobile, SMSStatus, IdempotencyKey, MessageText)
VALUES (@TestRun, 7777776, '5559999998', 0, NULL, 'no key 2');

PRINT 'Two NULL-key rows accepted — expected, since the index is filtered.';

DELETE FROM dbo.SMS_Queue_Detail WHERE SMSQueue_Mst_ID = @TestRun;
DELETE FROM dbo.SMS_Queue_Mst    WHERE ID = @TestRun;
PRINT 'Test 2 cleaned up.';
GO


/* ============================================================================
   TEST 3 — THE STOP SWITCH

   Proves that stopping a run halts claiming, without touching in-flight rows.
   ============================================================================ */

DECLARE @StopRun BIGINT;

INSERT INTO dbo.SMS_Queue_Mst (Campaign_Mstr_ID, RunTime, Status, CreatedBy, CreatedDt, RunStatus)
VALUES (999997, SYSUTCDATETIME(), 0, 'STOPTEST', SYSUTCDATETIME(), 1);
SET @StopRun = SCOPE_IDENTITY();

;WITH N AS (SELECT TOP (100) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
            FROM sys.all_objects)
INSERT INTO dbo.SMS_Queue_Detail (SMSQueue_Mst_ID, AccountID, Mobile, SMSStatus, MessageText)
SELECT @StopRun, 6000000 + n, '555' + RIGHT('0000000' + CAST(n AS VARCHAR(7)), 7), 0, 'stop test'
FROM N;

DECLARE @Got TABLE (
    ID BIGINT, SMSQueue_Mst_ID BIGINT, AccountID BIGINT, Mobile VARCHAR(20),
    StateCode VARCHAR(2), ZipCode VARCHAR(10), PatMobile VARCHAR(20),
    PatStateCode VARCHAR(2), PatZipCode VARCHAR(10), MessageText NVARCHAR(MAX),
    UseTimeZone VARCHAR(64), Allowed_From INT, Allowed_To INT, AttemptCount INT);

-- While Running: a claim should return rows
INSERT INTO @Got EXEC dbo.usp_SMS_ClaimBatch 0, 8, 10, 'TEST', @StopRun;
PRINT 'While running, claimed: ' + CAST((SELECT COUNT(*) FROM @Got) AS VARCHAR(10)) + ' (expected 10)';

-- Stop it
EXEC dbo.usp_SMS_StopRun @QueueMstId = @StopRun, @StoppedBy = 'TEST', @Reason = 'acceptance test';

-- After stopping: a claim should return nothing
DELETE FROM @Got;
INSERT INTO @Got EXEC dbo.usp_SMS_ClaimBatch 0, 8, 10, 'TEST', @StopRun;

IF (SELECT COUNT(*) FROM @Got) = 0
    PRINT 'TEST 3 PASSED — no rows claimed after stop.';
ELSE
    PRINT '*** TEST 3 FAILED — rows were claimed from a stopped run.';

-- The ten already claimed remain claimed. Stopping does not abandon them.
SELECT SMSStatus, COUNT(*) AS Rows
FROM   dbo.SMS_Queue_Detail
WHERE  SMSQueue_Mst_ID = @StopRun
GROUP  BY SMSStatus;

DELETE FROM dbo.SMS_Queue_Detail WHERE SMSQueue_Mst_ID = @StopRun;
DELETE FROM dbo.SMS_Queue_Mst    WHERE ID = @StopRun;
PRINT 'Test 3 cleaned up.';
GO
