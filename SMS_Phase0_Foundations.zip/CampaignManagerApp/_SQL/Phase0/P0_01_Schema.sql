/* ============================================================================
   SMS PLATFORM — PHASE 0 MIGRATION
   ============================================================================

   Safe to run more than once. Every change is guarded, so a partial run can be
   completed by running the whole script again.

   NOTHING HERE DROPS OR REWRITES EXISTING DATA. All additions are nullable or
   defaulted, so existing rows remain valid and the current pipeline keeps
   working while the new one is built alongside it.

   Run against: GD_Data (or the SMS database, once that decision is made)
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ============================================================================
   1. SMS_Queue_Detail — new columns
   ============================================================================ */

/* ---------------------------------------------------------------------------
   1a. IdempotencyKey

   The single most important column in this migration.

   COMPOSITION:  SHA256( QueueMstId | AccountID | NormalizedPhone )

   Deliberately NOT including template version. The question this column answers
   is "have we already created a message for this person in this run?" — and if
   someone edits the template and regenerates the run, the recipient has still
   already been messaged. Including the version would make the regenerated row a
   different key and produce a second text.

   Deliberately keyed on the RUN, not the campaign. Running a campaign again next
   month is a new run, a new key, and a legitimate second message. Regenerating
   the SAME run after a partial failure produces identical keys and inserts
   nothing new, which is what makes generation safely resumable.

   Phone is included so an account with two mobiles can be messaged on both. The
   risk of the same person being reached twice via two accounts is handled at
   compliance by the per-recipient cap, not here.

   NULLABLE for now: existing rows have no key and cannot be given one
   retrospectively. The unique index is filtered so it only constrains new rows.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'IdempotencyKey')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD IdempotencyKey CHAR(64) NULL;
    PRINT 'Added SMS_Queue_Detail.IdempotencyKey';
END
GO

/* Filtered unique index. Existing rows (NULL key) are excluded, so this can be
   created without backfilling anything. Every new row is constrained. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'UQ_SMSQD_IdempotencyKey'
                 AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
BEGIN
    CREATE UNIQUE INDEX UQ_SMSQD_IdempotencyKey
        ON dbo.SMS_Queue_Detail (IdempotencyKey)
        WHERE IdempotencyKey IS NOT NULL;
    PRINT 'Created UQ_SMSQD_IdempotencyKey';
END
GO

/* ---------------------------------------------------------------------------
   1b. ProviderMessageId

   Webex returns transid on acceptance. Delivery receipts reference it. Without
   this column a receipt cannot be matched back to the message that produced it,
   which means delivery status can never be recorded.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'ProviderMessageId')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD ProviderMessageId NVARCHAR(128) NULL;
    PRINT 'Added SMS_Queue_Detail.ProviderMessageId';
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSQD_ProviderMessageId'
                 AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
BEGIN
    CREATE INDEX IX_SMSQD_ProviderMessageId
        ON dbo.SMS_Queue_Detail (ProviderMessageId)
        WHERE ProviderMessageId IS NOT NULL;
    PRINT 'Created IX_SMSQD_ProviderMessageId';
END
GO

/* ---------------------------------------------------------------------------
   1c. Claim columns

   ClaimedBy and ClaimedUtc make an in-flight row attributable. Two purposes:

     - the reaper finds rows claimed too long ago and returns them, which is
       what stops an instance dying from stranding work permanently
     - when a batch is stuck, ClaimedBy names the instance to go and look at
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'ClaimedBy')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD ClaimedBy VARCHAR(100) NULL;
    PRINT 'Added SMS_Queue_Detail.ClaimedBy';
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'ClaimedUtc')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD ClaimedUtc DATETIME2 NULL;
    PRINT 'Added SMS_Queue_Detail.ClaimedUtc';
END
GO

/* ---------------------------------------------------------------------------
   1d. NextAttemptUtc

   When a deferred or retrying message becomes eligible again.

   The status alone is not enough. A row marked Deferred with no timestamp gives
   nothing to query on, so the service would have to re-evaluate every deferred
   row on every cycle to find the ones now due.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'NextAttemptUtc')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD NextAttemptUtc DATETIME2 NULL;
    PRINT 'Added SMS_Queue_Detail.NextAttemptUtc';
END
GO

/* ---------------------------------------------------------------------------
   1e. AttemptCount

   Retry counting and the ceiling that stops infinite retries. Without a
   persisted count, a provider outage produces unbounded retries.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'AttemptCount')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD AttemptCount INT NOT NULL
        CONSTRAINT DF_SMSQD_AttemptCount DEFAULT (0);
    PRINT 'Added SMS_Queue_Detail.AttemptCount';
END
GO

/* ---------------------------------------------------------------------------
   1f. ComplianceReason

   Why a message was blocked or deferred, in words.

   The design discussion was explicit that when an account does not go out we
   must be able to say why. A status code alone cannot distinguish "no consent
   on record" from "recipient already had three this month" from "state has no
   TCPA rule loaded" — and those need different responses.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Detail') AND name = 'ComplianceReason')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Detail ADD ComplianceReason NVARCHAR(400) NULL;
    PRINT 'Added SMS_Queue_Detail.ComplianceReason';
END
GO

/* ============================================================================
   2. The claim index

   This is the index the whole design depends on. Every claim runs against it,
   on every cycle, from every instance.

   Column order is chosen for the claim predicate:
     SMSStatus first          the most selective filter
     SMSQueue_Mst_ID second   joins to the run for the stop check
     NextAttemptUtc third     filters deferred rows not yet due

   INCLUDE carries the columns the claim returns, so the claim is covered and
   never has to look up the base table.
   ============================================================================ */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSQD_Claim' AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
BEGIN
    CREATE INDEX IX_SMSQD_Claim
        ON dbo.SMS_Queue_Detail (SMSStatus, SMSQueue_Mst_ID, NextAttemptUtc)
        INCLUDE (AccountID, Mobile, StateCode, ZipCode, PatMobile, PatStateCode,
                 PatZipCode, MessageText, UseTimeZone, Allowed_From, Allowed_To,
                 AttemptCount);
    PRINT 'Created IX_SMSQD_Claim';
END
GO

/* Reaper index — finds rows claimed too long ago. Filtered so it stays small;
   only in-flight rows are ever in it. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = 'IX_SMSQD_Reaper' AND object_id = OBJECT_ID('dbo.SMS_Queue_Detail'))
BEGIN
    CREATE INDEX IX_SMSQD_Reaper
        ON dbo.SMS_Queue_Detail (ClaimedUtc)
        WHERE ClaimedUtc IS NOT NULL;
    PRINT 'Created IX_SMSQD_Reaper';
END
GO

/* ============================================================================
   3. SMSStatus — new values

   EXISTING VALUES ARE NOT CHANGED. Only additions.

     0  Init          created, awaiting compliance
     1  BLOCK         compliance refused          TERMINAL
     2  Eligible      compliance passed, awaiting delivery
     3  Queued        claimed by delivery, send in progress
     4  Sent          provider accepted
     5  Delivered     carrier confirmed           TERMINAL
     6  Failed        attempt failed, may retry
     7  Deferred      compliance says not yet; NextAttemptUtc holds when   [NEW]
     8  Evaluating    claimed by compliance                                [NEW]
     9  DeadLetter    retries exhausted           TERMINAL                 [NEW]

   Two in-flight states rather than one, because "claimed" is ambiguous when two
   different services claim from the same table. Evaluating means compliance
   holds it; Queued means delivery holds it. A stuck row then names its own
   stage without a join.
   ============================================================================ */
IF NOT EXISTS (SELECT 1 FROM dbo.SMSStatus WHERE ID = 7)
    INSERT INTO dbo.SMSStatus (ID, Status) VALUES (7, 'Deferred');

IF NOT EXISTS (SELECT 1 FROM dbo.SMSStatus WHERE ID = 8)
    INSERT INTO dbo.SMSStatus (ID, Status) VALUES (8, 'Evaluating');

IF NOT EXISTS (SELECT 1 FROM dbo.SMSStatus WHERE ID = 9)
    INSERT INTO dbo.SMSStatus (ID, Status) VALUES (9, 'DeadLetter');
GO

/* ============================================================================
   4. SMS_Queue_Mst — run-level stop switch

   The claim joins to this. Setting a run to Stopped makes every instance's next
   claim return nothing, without any of them being told.

   RunStatus, separate from the existing Status column, so nothing that reads
   Status today changes behaviour.

     0  Pending    generated, not started
     1  Running    claims permitted
     2  Stopped    claims return nothing        <-- the UI switch
     3  Completed  no work remains
     4  Cancelled  stopped permanently
   ============================================================================ */
IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Mst') AND name = 'RunStatus')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Mst ADD RunStatus TINYINT NOT NULL
        CONSTRAINT DF_SMSQM_RunStatus DEFAULT (0);
    PRINT 'Added SMS_Queue_Mst.RunStatus';
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID('dbo.SMS_Queue_Mst') AND name = 'StoppedBy')
BEGIN
    ALTER TABLE dbo.SMS_Queue_Mst ADD StoppedBy NVARCHAR(100) NULL;
    ALTER TABLE dbo.SMS_Queue_Mst ADD StoppedUtc DATETIME2 NULL;
    ALTER TABLE dbo.SMS_Queue_Mst ADD StoppedReason NVARCHAR(300) NULL;
    PRINT 'Added SMS_Queue_Mst stop audit columns';
END
GO

/* ============================================================================
   5. Sms_Delivery_Attempt — one row per ATTEMPT, not per message

   A message retried four times produces four rows here. SMS_Queue_Detail holds
   current state; this holds history.

   Without it, "why did this fail?" can only be answered for the most recent
   attempt, because each retry overwrites the last reason.
   ============================================================================ */
IF OBJECT_ID('dbo.Sms_Delivery_Attempt', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Sms_Delivery_Attempt (
        AttemptID          BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_Sms_Delivery_Attempt PRIMARY KEY,
        QueueDetailID      BIGINT        NOT NULL,
        AttemptNumber      INT           NOT NULL,
        AttemptedUtc       DATETIME2     NOT NULL
            CONSTRAINT DF_SDA_AttemptedUtc DEFAULT SYSUTCDATETIME(),
        InstanceId         VARCHAR(100)  NULL,
        Succeeded          BIT           NOT NULL,
        ProviderMessageId  NVARCHAR(128) NULL,
        ResponseCode       NVARCHAR(50)  NULL,
        ResponseMessage    NVARCHAR(500) NULL,
        DurationMs         INT           NULL
    );

    CREATE INDEX IX_SDA_QueueDetail ON dbo.Sms_Delivery_Attempt (QueueDetailID, AttemptNumber);
    PRINT 'Created Sms_Delivery_Attempt';
END
GO

/* ============================================================================
   6. Verification
   ============================================================================ */

PRINT '--- Columns added to SMS_Queue_Detail ---';
SELECT name, TYPE_NAME(user_type_id) AS DataType, is_nullable
FROM   sys.columns
WHERE  object_id = OBJECT_ID('dbo.SMS_Queue_Detail')
  AND  name IN ('IdempotencyKey','ProviderMessageId','ClaimedBy','ClaimedUtc',
                'NextAttemptUtc','AttemptCount','ComplianceReason')
ORDER  BY name;

PRINT '--- Indexes ---';
SELECT name, is_unique, has_filter
FROM   sys.indexes
WHERE  object_id = OBJECT_ID('dbo.SMS_Queue_Detail')
  AND  name LIKE 'IX_SMSQD%' OR name LIKE 'UQ_SMSQD%';

PRINT '--- Status values ---';
SELECT ID, Status FROM dbo.SMSStatus ORDER BY ID;

PRINT '--- Existing rows are untouched ---';
SELECT COUNT(*) AS TotalRows,
       SUM(CASE WHEN IdempotencyKey IS NULL THEN 1 ELSE 0 END) AS RowsWithoutKey
FROM   dbo.SMS_Queue_Detail;
GO


/* ============================================================================
   ROLLBACK

   Only if the migration must be reversed before anything depends on it. Once
   the services are writing these columns this will lose data.

   DROP INDEX UQ_SMSQD_IdempotencyKey  ON dbo.SMS_Queue_Detail;
   DROP INDEX IX_SMSQD_ProviderMessageId ON dbo.SMS_Queue_Detail;
   DROP INDEX IX_SMSQD_Claim           ON dbo.SMS_Queue_Detail;
   DROP INDEX IX_SMSQD_Reaper          ON dbo.SMS_Queue_Detail;

   ALTER TABLE dbo.SMS_Queue_Detail DROP CONSTRAINT DF_SMSQD_AttemptCount;
   ALTER TABLE dbo.SMS_Queue_Detail
       DROP COLUMN IdempotencyKey, ProviderMessageId, ClaimedBy, ClaimedUtc,
                   NextAttemptUtc, AttemptCount, ComplianceReason;

   ALTER TABLE dbo.SMS_Queue_Mst DROP CONSTRAINT DF_SMSQM_RunStatus;
   ALTER TABLE dbo.SMS_Queue_Mst
       DROP COLUMN RunStatus, StoppedBy, StoppedUtc, StoppedReason;

   DROP TABLE dbo.Sms_Delivery_Attempt;
   DELETE FROM dbo.SMSStatus WHERE ID IN (7,8,9);
   ============================================================================ */
