/* ============================================================================
   SMS PLATFORM — PHASE 0 STORED PROCEDURES
   ============================================================================

   Three procedures that make multi-instance processing safe:

     usp_SMS_ClaimBatch          take work, atomically
     usp_SMS_ReleaseDueDeferred  return deferred messages when their time comes
     usp_SMS_ReapStaleClaims     recover work from an instance that died

   These are stored procedures rather than EF because they need table hints
   (READPAST, UPDLOCK) that EF cannot express, and because correctness here
   depends on the statement being exactly what is intended.
   ============================================================================ */

SET NOCOUNT ON;
GO

/* ============================================================================
   usp_SMS_ClaimBatch

   Takes up to @BatchSize rows, marks them as held by this instance, and returns
   them — all in one statement.

   WHY ONE STATEMENT MATTERS
   -------------------------
   The naive version is SELECT the rows, then UPDATE them. Between those two
   statements another instance can select the same rows, and both send. A single
   UPDATE ... OUTPUT has no gap for that to happen in.

   THE HINTS
   ---------
   ROWLOCK    take row locks rather than escalating to page or table locks,
              which would block other instances unnecessarily
   UPDLOCK    take the update lock immediately rather than upgrading from a
              shared lock, which is where deadlocks come from
   READPAST   skip rows another instance already holds instead of waiting

   READPAST is what makes instances independent. Without it, instance two waits
   for instance one's transaction, and throughput does not improve with more
   instances — it just queues.

   THE STOP SWITCH
   ---------------
   The join to SMS_Queue_Mst on RunStatus = 1 is how a stopped run stops every
   instance at once. Nothing is signalled to anyone; the next claim simply finds
   no eligible rows. This is why stopping works identically for one instance or
   twenty.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_ClaimBatch', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_ClaimBatch;
GO

CREATE PROCEDURE dbo.usp_SMS_ClaimBatch
    @FromStatus   TINYINT,        -- 0 Init for compliance, 2 Eligible for delivery
    @ClaimStatus  TINYINT,        -- 8 Evaluating,           3 Queued
    @BatchSize    INT,
    @InstanceId   VARCHAR(100),
    @QueueMstId   BIGINT = NULL   -- optional: restrict to one run
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Now DATETIME2 = SYSUTCDATETIME();

    UPDATE TOP (@BatchSize) d
    SET    d.SMSStatus    = @ClaimStatus,
           d.ClaimedBy    = @InstanceId,
           d.ClaimedUtc   = @Now,
           d.RowUpdatedDt = @Now
    OUTPUT inserted.ID,
           inserted.SMSQueue_Mst_ID,
           inserted.AccountID,
           inserted.Mobile,
           inserted.StateCode,
           inserted.ZipCode,
           inserted.PatMobile,
           inserted.PatStateCode,
           inserted.PatZipCode,
           inserted.MessageText,
           inserted.UseTimeZone,
           inserted.Allowed_From,
           inserted.Allowed_To,
           inserted.AttemptCount
    FROM   dbo.SMS_Queue_Detail AS d WITH (ROWLOCK, UPDLOCK, READPAST)
    INNER  JOIN dbo.SMS_Queue_Mst AS m
           ON m.ID = d.SMSQueue_Mst_ID
    WHERE  d.SMSStatus = @FromStatus
      AND  m.RunStatus = 1                                   -- Running only
      AND  (d.NextAttemptUtc IS NULL OR d.NextAttemptUtc <= @Now)
      AND  (@QueueMstId IS NULL OR d.SMSQueue_Mst_ID = @QueueMstId);
END
GO


/* ============================================================================
   usp_SMS_ReleaseDueDeferred

   Moves Deferred rows back to their prior state once NextAttemptUtc has passed.

   Compliance defers a message when it is outside the recipient's local window.
   This is what brings it back — and it returns rows to Init so compliance
   re-evaluates rather than assuming the earlier decision still holds.

   RE-EVALUATING IS DELIBERATE. Between deferral and release, the recipient may
   have replied STOP, the campaign may have been stopped, or a state rule may
   have changed. Releasing straight to Eligible would send on a decision made
   hours ago against conditions that no longer apply.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_ReleaseDueDeferred', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_ReleaseDueDeferred;
GO

CREATE PROCEDURE dbo.usp_SMS_ReleaseDueDeferred
    @BatchSize INT = 1000
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Now DATETIME2 = SYSUTCDATETIME();

    UPDATE TOP (@BatchSize) d
    SET    d.SMSStatus        = 0,          -- back to Init for re-evaluation
           d.NextAttemptUtc   = NULL,
           d.ComplianceReason = NULL,
           d.RowUpdatedDt     = @Now
    FROM   dbo.SMS_Queue_Detail AS d WITH (ROWLOCK, UPDLOCK, READPAST)
    INNER  JOIN dbo.SMS_Queue_Mst AS m
           ON m.ID = d.SMSQueue_Mst_ID
    WHERE  d.SMSStatus      = 7             -- Deferred
      AND  d.NextAttemptUtc IS NOT NULL
      AND  d.NextAttemptUtc <= @Now
      AND  m.RunStatus      = 1;            -- not for a stopped run

    SELECT @@ROWCOUNT AS Released;
END
GO


/* ============================================================================
   usp_SMS_ReapStaleClaims

   Returns rows held by an instance that died.

   Without this, a process crashing mid-batch leaves its rows in Evaluating or
   Queued permanently. Nothing else will ever pick them up, and the campaign
   simply never finishes — with no error anywhere to explain why.

   ⚠ THE ONE PLACE THIS DESIGN CAN DOUBLE-SEND
   -------------------------------------------
   A row reaped from Queued (claimed by delivery) may already have been sent —
   the instance could have called Webex successfully and died before recording
   it. Reaping returns it to Eligible and it sends again.

   Three things reduce this, and it is worth understanding that they reduce
   rather than eliminate it:

     1. @StaleAfterMinutes must be comfortably longer than the worst realistic
        send. Reaping a slow send is how you manufacture the problem.
     2. The idempotency key stops duplicate ROWS but not a duplicate provider
        call, because the row already exists and is simply being retried.
     3. Only a provider-side idempotency key closes it fully. Webex has an
        unused Correlation ID field — if Connect deduplicates on it, passing our
        key means the second call is ignored at their end.

   Until that is confirmed, prefer a longer timeout. A message delayed fifteen
   minutes is recoverable; a duplicate to a Florida recipient on a one-per-30-day
   limit is not.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_ReapStaleClaims', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_ReapStaleClaims;
GO

CREATE PROCEDURE dbo.usp_SMS_ReapStaleClaims
    @StaleAfterMinutes INT = 15,
    @BatchSize         INT = 500
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Now    DATETIME2 = SYSUTCDATETIME();
    DECLARE @Cutoff DATETIME2 = DATEADD(MINUTE, -@StaleAfterMinutes, @Now);

    DECLARE @Reaped TABLE (ID BIGINT, PriorStatus TINYINT, ClaimedBy VARCHAR(100));

    UPDATE TOP (@BatchSize) d
    SET    d.SMSStatus  = CASE d.SMSStatus
                              WHEN 8 THEN 0   -- Evaluating -> Init
                              WHEN 3 THEN 2   -- Queued     -> Eligible
                              ELSE d.SMSStatus
                          END,
           d.ClaimedBy  = NULL,
           d.ClaimedUtc = NULL,
           d.RowUpdatedDt = @Now
    OUTPUT inserted.ID, deleted.SMSStatus, deleted.ClaimedBy INTO @Reaped
    FROM   dbo.SMS_Queue_Detail AS d WITH (ROWLOCK, UPDLOCK, READPAST)
    WHERE  d.SMSStatus IN (3, 8)
      AND  d.ClaimedUtc IS NOT NULL
      AND  d.ClaimedUtc <= @Cutoff;

    /* Returned so the caller can log loudly. Reaping is never routine — every
       row here means an instance died holding work, and a rising count is a
       symptom worth chasing rather than absorbing. */
    SELECT ID, PriorStatus, ClaimedBy FROM @Reaped;
END
GO


/* ============================================================================
   usp_SMS_StopRun  /  usp_SMS_StartRun

   The UI switch. Stopping does not touch any in-flight row — instances finish
   what they hold and then find nothing. See the architecture note on why
   abandoning a claimed batch would be worse than completing it.
   ============================================================================ */

IF OBJECT_ID('dbo.usp_SMS_StopRun', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_StopRun;
GO

CREATE PROCEDURE dbo.usp_SMS_StopRun
    @QueueMstId BIGINT,
    @StoppedBy  NVARCHAR(100),
    @Reason     NVARCHAR(300) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.SMS_Queue_Mst
    SET    RunStatus     = 2,
           StoppedBy     = @StoppedBy,
           StoppedUtc    = SYSUTCDATETIME(),
           StoppedReason = @Reason
    WHERE  ID = @QueueMstId
      AND  RunStatus IN (0, 1);   -- idempotent: stopping a stopped run is fine

    /* What the operator needs to see: what is still in flight, and what will
       now never send. */
    SELECT
        SUM(CASE WHEN SMSStatus IN (3,8)     THEN 1 ELSE 0 END) AS StillInFlight,
        SUM(CASE WHEN SMSStatus IN (0,2,7)   THEN 1 ELSE 0 END) AS WillNotSend,
        SUM(CASE WHEN SMSStatus IN (4,5)     THEN 1 ELSE 0 END) AS AlreadySent
    FROM dbo.SMS_Queue_Detail
    WHERE SMSQueue_Mst_ID = @QueueMstId;
END
GO

IF OBJECT_ID('dbo.usp_SMS_StartRun', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_SMS_StartRun;
GO

CREATE PROCEDURE dbo.usp_SMS_StartRun
    @QueueMstId BIGINT,
    @StartedBy  NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.SMS_Queue_Mst
    SET    RunStatus     = 1,
           StoppedBy     = NULL,
           StoppedUtc    = NULL,
           StoppedReason = NULL
    WHERE  ID = @QueueMstId
      AND  RunStatus IN (0, 2);   -- not a completed or cancelled run

    SELECT @@ROWCOUNT AS RunsStarted;
END
GO
